#include "AssignmentBoilerplate.h"
#include <stdio.h>
#include <string.h>
#include <ctype.h>

void trim_copy(char *dest, const char *src) {
    int start = 0;
    int end = (int)strlen(src);
    while (src[start] && isspace((unsigned char)src[start])) start++;
    while (end > start && isspace((unsigned char)src[end - 1])) end--;
    {
        int i, j = 0;
        for (i = start; i < end; i++) dest[j++] = src[i];
        dest[j] = '\0';
    }
}

int clamp_non_negative(int value) { return value < 0 ? 0 : value; }

int safe_choice(int choice, int low, int high) {
    return choice >= low && choice <= high;
}

void make_banner(const char *label, char *dest, int dest_size) {
    snprintf(dest, dest_size, "==== %s ====", label);
}
