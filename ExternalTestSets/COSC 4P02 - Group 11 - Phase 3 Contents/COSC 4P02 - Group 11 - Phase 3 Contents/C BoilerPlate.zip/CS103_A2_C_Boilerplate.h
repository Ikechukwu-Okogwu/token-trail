#ifndef ASSIGNMENT_BOILERPLATE_H
#define ASSIGNMENT_BOILERPLATE_H
void trim_copy(char *dest, const char *src);
int clamp_non_negative(int value);
int safe_choice(int choice, int low, int high);
void make_banner(const char *label, char *dest, int dest_size);
#endif
