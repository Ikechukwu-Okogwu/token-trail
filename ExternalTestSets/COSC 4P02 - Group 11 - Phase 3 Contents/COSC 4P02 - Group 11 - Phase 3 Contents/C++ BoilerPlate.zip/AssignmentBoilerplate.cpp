#include <iostream>
#include "AssignmentBoilerplate.hpp"

void logStart(const std::string& name) {
    std::cout << "[START] " << name << std::endl;
}

void logEnd(const std::string& name) {
    std::cout << "[END] " << name << std::endl;
}
