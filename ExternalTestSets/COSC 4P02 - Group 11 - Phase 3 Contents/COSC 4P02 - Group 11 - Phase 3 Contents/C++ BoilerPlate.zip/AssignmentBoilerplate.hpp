#ifndef ASSIGNMENT_BOILERPLATE_HPP
#define ASSIGNMENT_BOILERPLATE_HPP
#include <string>
void logStart(const std::string& name);
void logEnd(const std::string& name);
#endif
