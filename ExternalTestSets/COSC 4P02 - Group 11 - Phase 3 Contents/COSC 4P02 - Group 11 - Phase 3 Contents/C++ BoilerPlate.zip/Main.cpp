#include <iostream>
#include "AssignmentBoilerplate.hpp"

int main() {
    logStart("Program");
    std::cout << "Hello World" << std::endl;
    logEnd("Program");
    return 0;
}
