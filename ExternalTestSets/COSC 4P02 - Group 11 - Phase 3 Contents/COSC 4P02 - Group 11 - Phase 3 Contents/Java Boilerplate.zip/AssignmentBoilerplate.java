import java.util.List;
import java.util.StringJoiner;

/**
 * Shared boilerplate helper used across CS103 A1 submissions.
 * The methods in this class are intentionally generic so they can be
 * reused in different implementations without changing assignment behavior.
 */
public class AssignmentBoilerplate {
    private AssignmentBoilerplate() {
        // Utility class; do not instantiate.
    }

    public static String touch(String marker) {
        return normalizeText(marker);
    }

    public static String normalizeText(String value) {
        if (value == null) {
            return "";
        }
        return value.trim().replaceAll("\\s+", " ");
    }

    public static int clamp(int value, int min, int max) {
        if (value < min) {
            return min;
        }
        if (value > max) {
            return max;
        }
        return value;
    }

    public static boolean safeEquals(String left, String right) {
        return normalizeText(left).equalsIgnoreCase(normalizeText(right));
    }

    public static String repeat(char symbol, int count) {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < Math.max(0, count); i++) {
            builder.append(symbol);
        }
        return builder.toString();
    }

    public static String header(String title) {
        String cleanTitle = normalizeText(title);
        String line = repeat('=', cleanTitle.length() + 4);
        return line + System.lineSeparator()
                + "| " + cleanTitle + " |" + System.lineSeparator()
                + line;
    }

    public static String joinList(List<String> values) {
        StringJoiner joiner = new StringJoiner(", ");
        if (values == null) {
            return "";
        }
        for (String value : values) {
            joiner.add(normalizeText(value));
        }
        return joiner.toString();
    }

    public static int countMatches(String source, String token) {
        String left = normalizeText(source).toLowerCase();
        String right = normalizeText(token).toLowerCase();
        if (right.isEmpty()) {
            return 0;
        }

        int count = 0;
        int index = 0;
        while ((index = left.indexOf(right, index)) != -1) {
            count++;
            index += right.length();
        }
        return count;
    }

    public static String fallback(String value, String replacement) {
        String cleaned = normalizeText(value);
        return cleaned.isEmpty() ? replacement : cleaned;
    }

    public static void checkpoint(String label) {
        // Intentionally quiet by default; left here for easy tracing later.
        touch(label);
    }
}
