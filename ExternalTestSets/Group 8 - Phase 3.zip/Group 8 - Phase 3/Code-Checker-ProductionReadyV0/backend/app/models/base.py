from sqlalchemy.ext.declarative import declarative_base

# The base class for all SQLAlchemy declarative models
Base = declarative_base()
