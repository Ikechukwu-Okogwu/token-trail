from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager
import asyncio
import logging

from sqlalchemy import text

from app.core.config import get_settings
from app.api.v1.router import api_router
from app.core.database import engine, Base, AsyncSessionLocal
from app.services.archival_service import finalize_overdue_archives
from app.core.security import get_password_hash
from app.models.instructor import Instructor
from sqlalchemy import select
# Import models to ensure they are registered with Base
import app.models.instructor
import app.models.course
import app.models.assignment
import app.models.submission
import app.models.stored_file
import app.models.comparison_result
import app.models.boilerplate
import app.models.repository
import app.models.repository_submission


settings = get_settings()
logger = logging.getLogger(__name__)
ARCHIVE_SCHEDULER_LOCK_KEY = 90243011


async def _seed_default_instructor() -> None:
    """Create the default faculty account if it doesn't already exist."""
    async with AsyncSessionLocal() as session:
        existing = await session.scalar(select(Instructor).where(Instructor.email == "faculty@brocku.ca"))
        if not existing:
            session.add(Instructor(
                username="faculty",
                email="faculty@brocku.ca",
                password_hash=get_password_hash("password123"),
                first_name="Faculty",
                last_name="Demo",
                auth_provider="local",
            ))
            await session.commit()
            logger.info("Seeded default instructor: faculty@brocku.ca")


async def run_archive_scheduler(stop_event: asyncio.Event) -> None:
    """Periodically archive assignments that are older than the 30-day grace window."""
    while not stop_event.is_set():
        try:
            async with AsyncSessionLocal() as session:
                lock_row = await session.execute(
                    text("SELECT pg_try_advisory_xact_lock(:lock_key)"),
                    {"lock_key": ARCHIVE_SCHEDULER_LOCK_KEY},
                )
                lock_acquired = bool(lock_row.scalar())

                if not lock_acquired:
                    await session.rollback()
                    logger.debug("Archive scheduler skipped; lock held by another worker")
                    continue

                archived_count = await finalize_overdue_archives(
                    session,
                    batch_size=settings.ARCHIVE_SWEEP_BATCH_SIZE,
                )
                if archived_count > 0:
                    await session.commit()
                    logger.info("Archive scheduler finalized %s overdue assignment(s)", archived_count)
                else:
                    await session.rollback()
        except Exception:
            logger.exception("Archive scheduler iteration failed")

        try:
            await asyncio.wait_for(stop_event.wait(), timeout=settings.ARCHIVE_SWEEP_INTERVAL_SECONDS)
        except asyncio.TimeoutError:
            continue

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan events."""
    archive_stop_event = asyncio.Event()
    archive_task = None

    # Retry DB initialization so startup does not race with container readiness.
    for attempt in range(5):
        try:
            async with engine.begin() as conn:
                await conn.execute(text("SELECT 1"))

                # If an old integer-ID schema exists, reset legacy tables once so
                # the current UUID-based model metadata can initialize cleanly.
                legacy_id_type = await conn.execute(
                    text(
                        """
                        SELECT data_type
                        FROM information_schema.columns
                        WHERE table_name = 'submissions' AND column_name = 'id'
                        """
                    )
                )
                submissions_id_type = legacy_id_type.scalar_one_or_none()
                if submissions_id_type == "integer":
                    await conn.execute(text("DROP TABLE IF EXISTS comparisons CASCADE"))
                    await conn.execute(text("DROP TABLE IF EXISTS access_keys CASCADE"))
                    await conn.execute(text("DROP TABLE IF EXISTS stored_files CASCADE"))
                    await conn.execute(text("DROP TABLE IF EXISTS submissions CASCADE"))
                    await conn.execute(text("DROP TABLE IF EXISTS assignments CASCADE"))
                    await conn.execute(text("DROP TABLE IF EXISTS courses CASCADE"))
                    await conn.execute(text("DROP TABLE IF EXISTS instructors CASCADE"))

                await conn.run_sync(Base.metadata.create_all)

                # Schema migrations for existing tables (safe to re-run)
                # 1. stored_files: make submission_id nullable, add repository_submission_id
                await conn.execute(text("""
                    ALTER TABLE stored_files ALTER COLUMN submission_id DROP NOT NULL
                """))
                await conn.execute(text("""
                    DO $$ BEGIN
                        ALTER TABLE stored_files ADD COLUMN repository_submission_id UUID REFERENCES repository_submissions(id) ON DELETE CASCADE;
                    EXCEPTION WHEN duplicate_column THEN NULL;
                    END $$
                """))
                # 2. comparison_results: make target_submission_id nullable, add cross-repo fields
                await conn.execute(text("""
                    ALTER TABLE comparison_results ALTER COLUMN target_submission_id DROP NOT NULL
                """))
                await conn.execute(text("""
                    DO $$ BEGIN
                        ALTER TABLE comparison_results ADD COLUMN target_repo_submission_id UUID REFERENCES repository_submissions(id) ON DELETE CASCADE;
                    EXCEPTION WHEN duplicate_column THEN NULL;
                    END $$
                """))
                await conn.execute(text("""
                    DO $$ BEGIN
                        ALTER TABLE comparison_results ADD COLUMN comparison_type VARCHAR(20) DEFAULT 'internal';
                    EXCEPTION WHEN duplicate_column THEN NULL;
                    END $$
                """))

                await conn.execute(text("""
                    CREATE INDEX IF NOT EXISTS idx_assignments_status_deadline
                    ON assignments (status, deadline)
                """))

                # 3. instructors: add profile + OAuth columns (safe to re-run)
                for col_sql in [
                    "ALTER TABLE instructors ALTER COLUMN password_hash DROP NOT NULL",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN first_name VARCHAR(100); EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN last_name VARCHAR(100); EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN title VARCHAR(20); EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN department VARCHAR(150); EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN google_id VARCHAR(255) UNIQUE; EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN avatar_url VARCHAR(512); EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN auth_provider VARCHAR(10) NOT NULL DEFAULT 'local'; EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN updated_at TIMESTAMPTZ; EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                    "DO $$ BEGIN ALTER TABLE instructors ADD COLUMN last_login_at TIMESTAMPTZ; EXCEPTION WHEN duplicate_column THEN NULL; END $$",
                ]:
                    await conn.execute(text(col_sql))

                # Backfill first_name / last_name for existing seed account
                await conn.execute(text("""
                    UPDATE instructors
                    SET first_name = 'Faculty', last_name = 'Demo'
                    WHERE email = 'faculty@brocku.ca'
                      AND first_name IS NULL
                """))

            await _seed_default_instructor()
            break
        except Exception:
            if attempt == 4:
                raise
            await asyncio.sleep(2)

    if settings.ARCHIVE_SCHEDULER_ENABLED:
        archive_task = asyncio.create_task(run_archive_scheduler(archive_stop_event))

    yield

    archive_stop_event.set()
    if archive_task:
        try:
            await asyncio.wait_for(archive_task, timeout=5)
        except asyncio.TimeoutError:
            archive_task.cancel()
    # Cleanup here if needed

app = FastAPI(
    title="Academic Integrity Code Comparison System API",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=[o.strip() for o in settings.ALLOWED_ORIGINS.split(",")],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Root endpoint
@app.get("/")
def read_root():
    return {"message": "Code-Checker API running"}

app.include_router(api_router, prefix=settings.API_V1_STR)
