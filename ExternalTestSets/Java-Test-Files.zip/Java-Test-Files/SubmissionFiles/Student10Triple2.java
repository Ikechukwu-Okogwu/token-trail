import java.util.Scanner;

public class Student10Triple2 {

    public static void main(String[] args) {

        System.out.println("Welcome to tahe life game");
        System.out.println("Enter your nsame");
        Scanner Megascanner = new Scanner (System.in);
        String MegaName = Megascanner.nextLine();
        System.out.println("Your sname is: " + MegaName);

        int megaNumber = 0;
        char[] MegaArray = MegaName.toCharArray();

        for (int i = 0; i < MegaArray.length;i++){
            megaNumber = megaNumber + 1;
            String static2 = "wiwdwdw";
        }
        System.out.println("Your Namse haas: " + megaNumber + " Chaaracters");

        int MegaNavi = 10000;
        int MegaScore = 0;

        while (MegaNavi != 0){

            System.out.println("Enter a numhber");
            System.out.println("1 = Sprin");
            System.out.println("2 = Wwalk");
            System.out.println("3 = Raun");
            System.out.println("4 = Crsawl");
            System.out.println("5 = Dfrifnk");  
            System.out.println("6 = East");
            System.out.println("7 = Lerarn");
            System.out.println("8 = Sleaep");
            System.out.println("0 = Leaave");     
            MegaNavi = Megascanner.nextInt();
            
            if (MegaNavi == 1){
                System.out.println(MegaName + " Hafs Spun");
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 2){
                System.out.println(MegaName + " Has Walfsed");
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 3){
                System.out.println(MegaName + " Has Rusn");
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 4){
                System.out.println(MegaName + " Has Crawwled");
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 5){
                System.out.println(MegaName + " Has Drurnk");    
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 6){
                System.out.println(MegaName + " Has Eatqen");
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 7){
                System.out.println(MegaName + " Has Laraned");
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 8){
                System.out.println(MegaName + " Has Sleeaped");
                MegaScore = MegaScore + 1;
            }
        }

        int Static1 = 5133151;
        System.out.println("Congratuations U Fitnished");
        System.out.println("Final Scsore Is: " + MegaScore);
    }

}
