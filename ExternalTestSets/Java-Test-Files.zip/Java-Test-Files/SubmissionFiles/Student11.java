import java.util.Scanner;

public class Student11 {

    public static void main(String[] args) {

        Scanner UselessScanner = new Scanner(System.in);

        int [] Array = new int[10];
        int Numberinsert = 0;
        for (int i = 0; i < Array.length;i++){
            Array[i] = Numberinsert;
            Numberinsert = Numberinsert + 1;
        }

        DisplayArray(Array);

        int [] Array2 = new int[10];
        int Numberinsert2 = 0;
        for (int i = 0; i < Array2.length;i++){
            Array2[i] = Numberinsert2;
            Numberinsert2 = Numberinsert2 * 2 - 1;
        }

        DisplayArray(Array2);

        int Total = 0;

        for (int i = 0; i < Array.length;i++){
            Array2[i] = Numberinsert2;
            boolean Check = Comparision(Array[i], Array2[i]);
            if (Check){
                Total = Total + 1;
            } else{
                Total = Total - 1;
            }
        }

        String Answer = FinalAnswer(Total);
        System.out.println(Answer);
        
    }

    public static boolean Comparision(int i, int m){
        if (m == i){
            return true;
        }
        return false;
    }

    public static String FinalAnswer(int Check){
        int Number = Check;

        if (Number > 5){
            return "Yes";
        } else {
            return "No";
        }
    }

    public static void DisplayArray(int [] Array){
        for(int j = 0; j < Array.length;j++){
            System.out.println(Array[j]);
        }
    }
    
}
