import java.lang.invoke.VarHandle.AccessMode;

public class Student12 {

    public static void main(String[] args) {

        String Answer = Random1();
        System.out.println(Answer);

        String TrueAnswer = Random2(Answer);
        System.out.println(TrueAnswer);

        Random3(Answer, TrueAnswer);

        
    }

    public static String Random1(){

        char [] Array = new char[5];
        Array[0] = 'a';
        Array[1] = 'b';
        Array[2] = 'c';
        Array[3] = 'd';
        Array[4] = 'e';
        int a = 0;
        String answer = "";

        while (a < 5){
            answer = answer + Array[a];
            a++;
            a++;
        }
        return answer;
    }

    public static String Random2(String Combo){
        char [] Array2 = Combo.toCharArray();
        int b = 0;
        while (b < 5){
            Array2[b]++;
            Array2[b]++;
        }

        String TrueAnswer = "";

        for (int i = 0; i < Array2.length; i++){
            TrueAnswer = TrueAnswer + Array2[i];
        }
        return TrueAnswer;
    }

    public static void Random3(String Answer1, String Answer2){
        String One = Answer1;
        String Two = Answer2;

        if (One.equals(Two)){
            System.out.println("Yay");
        } else{
            System.out.println("Nay");
        }
    }
}
