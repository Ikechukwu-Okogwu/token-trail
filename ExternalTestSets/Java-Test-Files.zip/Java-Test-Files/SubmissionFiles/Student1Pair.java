import java.io.*;
import java.util.Scanner;

public class Student1Pair{

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter in 2 Numbers");
        int Num1 = scanner.nextInt();
        int Num2 = scanner.nextInt();
        int add = add(Num1,Num2);
        System.out.println(add);
        int sub = sub(Num1,Num2);
        System.out.println(sub);
        int mul = mul(Num1,Num2);
        System.out.println(mul);
        double div = div(Num1,Num2);        
        System.out.println(div);


        double newnum = add * mul;
        double newnum2 = sub / div;
        
        double Combination = newnum + newnum2;
        System.out.println(Combination);
        Figureoutcoolnum(Combination);


        
    }


    public static int add(int m, int n){
        int c = m + n;
        return c;
    }

    public static int sub(int m, int n){
        int c = m - n;
        return c;
    }

    public static int mul(int m, int n){
        int c = m * n;
        return c;
    }

    public static double div(int m, int n){
        double c = m / n;
        return c;
    }

    public static void Figureoutcoolnum(double m){
        double Number = m;
        if (Number > 10000){
            System.out.println("Number is greater than 10000");
        } else if (Number > 1000){
            System.out.println("Number is greater than 1000");

        } else if (Number > 100){
            System.out.println("Number is greater than 100");

        } else if (Number > 10){
            System.out.println("Number is greater than 10");

        } else if (Number < 1){
            System.out.println("Number is greater than 1");
        } else {
            System.out.println("Number is negaitve");
        }
    }

    public static void EvenOrOdd(int n){
        int number = n;

        if (number % 2 == 0){
            System.out.println("even");
        } else{
            System.out.println("odd");
        }
    }
}