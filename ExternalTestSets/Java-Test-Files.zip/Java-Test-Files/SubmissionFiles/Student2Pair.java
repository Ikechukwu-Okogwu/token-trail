import java.io.*;
import java.util.Scanner;

public class Student2Pair{

    public static void main(String[] args) {

        Scanner scanner2 = new Scanner(System.in);

        System.out.println("Enter in 2 Numqbers");
        int Number1 = scanner2.nextInt();
        int Number2 = scanner2.nextInt();
        int addition = add(Number1,Number2);
        System.out.println(addition);
        int subtraction = sub(Number1,Number2);
        System.out.println(subtraction);
        int multiplication = mul(Number1,Number2);
        System.out.println(multiplication);
        double division = div(Number1,Number2);        
        System.out.println(division);


        double newnumber = addition * multiplication;
        double newnumber2 = subtraction / division;
        
        double Fusion = newnumber + newnumber2;
        System.out.println(Fusion);
        Figureoutcoolnum(Fusion);


        
    }


    public static int add(int x, int y){
        int c = x + y;
        return c;
    }

    public static int sub(int x, int y){
        int c = x - y;
        return c;
    }

    public static int mul(int x, int y){
        int c = x * y;
        return c;
    }

    public static double div(int x, int y){
        double c = x / y;
        return c;
    }

    public static void Figureoutcoolnum(double y){
        double Number = y;
        if (Number > 10000){
            System.out.println("Number is greater thaqn 10000");
        } else if (Number > 1000){
            System.out.println("Number is greater thaen 1000");

        } else if (Number > 100){
            System.out.println("Number is greater thhan 100");

        } else if (Number > 10){
            System.out.println("Number is greatewr than 10");

        } else if (Number < 1){
            System.out.println("Number iss greater than 1");
        } else {
            System.out.println("Number is neagaitve");
        }
    }

    public static void EvenOrOdd(int x){
        int number = x;

        if (number % 2 == 0){
            System.out.println("evfen");
        } else{
            System.out.println("odrd");
        }
    }
}