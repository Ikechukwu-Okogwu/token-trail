import java.io.*;
import java.util.Scanner;


public class Student3Triple {

    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        System.out.println("Put in 2 numbers for Array parameters");
        int Para1 = scanner.nextInt();
        int Para2 = scanner.nextInt();

        double [][] Array = new double [Para1][Para2];
        System.out.println("Created Array, now we need a range for input, put maximum number");
        int Maxnum = scanner.nextInt();

        for (int i = 0; i < Array.length; i++){
            for (int j = 0; j < Array.length; j++){
                Array[i][j] = Math.random() * (Maxnum);
            }
        }

        DisplayArray(Array);

        System.out.println("Enter number to search for in randomized array");
        double Searchnum = scanner.nextInt();
        boolean answer = LocateTarget(Array,Searchnum);

        if (answer == true){
            System.out.println("Found");
        } else{
            System.out.println("NotFound");
        }

        System.out.println("Now lets see total sum of all the numbers");
        double TotalSum = TotalSum(Array);

        if (TotalSum > 100){
            System.out.println("Number is higher than 100");
        } else {
            System.out.println("Number is less than 100");
        }
   
    }

    public static void DisplayArray(double [][] Array){

        System.out.println("Displaying Double Array");

        for (int i = 0; i < Array.length; i++){
            for (int j = 0; j < Array.length; j++){
                System.out.println(Array[i][j]);
            }
        }
    }

    public static boolean LocateTarget(double [][] Array, double Target){

        for (int i = 0; i < Array.length; i++){
            for (int j = 0; j < Array.length; j++){
                if (Target == Array[i][j]){
                    return true;
                }
                System.out.println(Array[i][j]);
            }
        }
        return false;
    }

    public static double TotalSum (double [][] Array){
    
        double Totalnum = 0;

        for (int i = 0; i < Array.length; i++){
            for (int j = 0; j < Array.length; j++){
             Totalnum = Totalnum + Array[i][j];
            }
        }

        return Totalnum;
    }
    
}
