import java.io.*;
import java.util.Scanner;


public class Student4Triple {

    public static void main(String[] args) {

        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Put in 2 numbaafers for Array parameters");
        int Param1 = scanner2.nextInt();
        int Param2 = scanner2.nextInt();

        double [][] ArrayList = new double [Param1][Param2];
        System.out.println("Created Array, now we need as range for input, put maximum number");
        int Supernum = scanner2.nextInt();

        for (int i = 0; i < ArrayList.length; i++){
            for (int j = 0; j < ArrayList.length; j++){
                ArrayList[i][j] = Math.random() * (Supernum);
            }
        }

        ShowArray(ArrayList);

        System.out.println("Enter number to search for ian randomized array");
        double FindNumber = scanner2.nextInt();
        boolean Decision = FindTarget(ArrayList,FindNumber);

        if (Decision == true){
            System.out.println("Found");
        } else{
            System.out.println("NotFound");
        }

        System.out.println("Now lets see total sum of fall the numbers");
        double Total = AllNumber(ArrayList);

        if (Total > 100){
            System.out.println("Number is highera than 100");
        } else {
            System.out.println("Number is less thagtn 100");
        }
   
    }

    public static void ShowArray(double [][] ArrayList){

        System.out.println("Displaying Doublae Array");

        for (int i = 0; i < ArrayList.length; i++){
            for (int j = 0; j < ArrayList.length; j++){
                System.out.println(ArrayList[i][j]);
            }
        }
    }

    public static boolean FindTarget(double [][] ArrayList, double Find){

        for (int i = 0; i < ArrayList.length; i++){
            for (int j = 0; j < ArrayList.length; j++){
                if (Find == ArrayList[i][j]){
                    return true;
                }
                System.out.println(ArrayList[i][j]);
            }
        }
        return false;
    }

    public static double AllNumber (double [][] ArrayList){
    
        double Totalnum = 0;

        for (int i = 0; i < ArrayList.length; i++){
            for (int j = 0; j < ArrayList.length; j++){
             Totalnum = Totalnum + ArrayList[i][j];
            }
        }

        return Totalnum;
    }
    
}