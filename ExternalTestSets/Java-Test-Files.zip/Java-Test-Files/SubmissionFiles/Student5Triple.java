import java.io.*;
import java.util.Scanner;

public class Student5Triple {

    public static void main(String[] args) {

        Scanner scanner2 = new Scanner(System.in);
        System.out.println("Put in 2 numbers for Array parameters");
        int Param1 = scanner2.nextInt();
        int Param2 = scanner2.nextInt();

        double [][] ArrayList = new double [Param1][Param2];
        System.out.println("Created Array, now we need a range for input, put maximum number");
        int Supernum = scanner2.nextInt();

        for (int i = 0; i < ArrayList.length; i++){
            for (int j = 0; j < ArrayList.length; j++){
                ArrayList[i][j] = Math.random() * (Supernum);
            }
        }

        System.out.println("Displaying Double Array");

        for (int i = 0; i < ArrayList.length; i++){
            for (int j = 0; j < ArrayList.length; j++){
                System.out.println(ArrayList[i][j]);
            }
        }

        char value = 'n';

        System.out.println("Enter number to search for in randomized array");
        double FindNumber = scanner2.nextInt();

        boolean Decision = false;;

        for (int i = 0; i < ArrayList.length; i++){
            for (int j = 0; j < ArrayList.length; j++){
                if (FindNumber == ArrayList[i][j]){
                    Decision = true;
                }
                System.out.println(ArrayList[i][j]);
            }
        }

        int Coolnum = 102931;

        if (Decision == true){
            System.out.println("Found");
        } else{
            System.out.println("NotFound");
        }

        System.out.println("Now lets see total sum of all the numbers");

        double Totalnum = 0;

        for (int i = 0; i < ArrayList.length; i++){
            for (int j = 0; j < ArrayList.length; j++){
             Totalnum = Totalnum + ArrayList[i][j];
            }
        }

        
        String string = "Filler Noise";

        if (Totalnum > 100){
            System.out.println("Number is higher than 100");
        } else {
            System.out.println("Number is less than 100");
        }

        scanner2.close();
        System.out.println("bye bye");
   
    }
    
}