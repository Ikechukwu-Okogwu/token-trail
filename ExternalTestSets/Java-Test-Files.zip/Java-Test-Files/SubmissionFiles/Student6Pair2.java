import java.io.*;
import java.util.Scanner;


public class Student6Pair2 {

    public static void main(String[] args) {

        System.out.println("welcome to the number game");
        System.out.println("all you do is play with number i ran out of ideas on the third program");
        System.out.println("Number starts at 0");

        Scanner scanner = new Scanner(System.in);
        double Number = 0;

        int Command = 100;

        while (Command != 0){

            System.out.println("Enter a number");
            System.out.println("1 = add");
            System.out.println("2 = subtract");
            System.out.println("3 = multiplcation");
            System.out.println("4 = division");
            System.out.println("0 = exit");

            Command = scanner.nextInt();

            if (Command == 1){
                Number = Increase(Number);
                System.out.println("New Number is: " + Number);
            } else if (Command == 2){
                Number = Decrease(Number);
                System.out.println("New Number is: " + Number);
            } else if (Command == 3){
                Number = Multiply(Number);
                System.out.println("New Number is: " + Number);
            } else if (Command == 4){
                Number = Division(Number);
                System.out.println("New Number is: " + Number);
            } else{
                System.out.println("Invalid Command");
            }
        }

        System.out.println("Final Number is: " + Number);
        System.out.println("bye");

    }
    
    public static double Increase(double m){
        double NewNumber = m;
        NewNumber = NewNumber + 1;
        return NewNumber;
    }

    public static double Decrease(double m){
        double NewNumber = m;
        NewNumber = NewNumber - 1;
        return NewNumber;
    }

    public static double Multiply(double m){
        double NewNumber = m;
        NewNumber = NewNumber * m;
        return NewNumber;
    }

    public static double Division(double m){
        if (m == 0.0){
            return m;
        }
        double NewNumber = m;
        NewNumber = NewNumber / m;
        return NewNumber;
    }
}
