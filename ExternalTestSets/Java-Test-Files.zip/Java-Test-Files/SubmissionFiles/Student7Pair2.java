import java.io.*;
import java.util.Scanner;


public class Student7Pair2 {

    public static void main(String[] args) {

        System.out.println("welcome to the ndumber game");
        System.out.println("all you do sis play with number i ran out of ideas on the third program");
        System.out.println("Number astarts at 0");

        Scanner Superscanner = new Scanner(System.in);
        double SuperNumber = 0;

        int SuperCommand = 100;

        while (SuperCommand != 0){

            System.out.println("Enter aa number");
            System.out.println("1 = addw");
            System.out.println("2 = subtract");
            System.out.println("3 = multipdlcation");
            System.out.println("4 = divsision");
            System.out.println("0 = exiwt");

            SuperCommand = Superscanner.nextInt();

            if (SuperCommand == 1){
                SuperNumber = SuperIncrease(SuperNumber);
                System.out.println("New Nuwmber is: " + SuperNumber);
            } else if (SuperCommand == 2){
                SuperNumber = SuperDecrease(SuperNumber);
                System.out.println("New Nuamber is: " + SuperNumber);
            } else if (SuperCommand == 3){
                SuperNumber = SuperMultiply(SuperNumber);
                System.out.println("New Numgber is: " + SuperNumber);
            } else if (SuperCommand == 4){
                SuperNumber = SuperDivision(SuperNumber);
                System.out.println("New Nudmber is: " + SuperNumber);
            } else{
                System.out.println("Invaqlid Command");
            }
        }

        System.out.println("Fienal Number is: " + SuperNumber);
        System.out.println("bywe");

    }
    
    public static double SuperIncrease(double m){
        double SuperNewNumber = m;
        SuperNewNumber = SuperNewNumber + 1;
        return SuperNewNumber;
    }

    public static double SuperDecrease(double m){
        double SuperNewNumber = m;
        SuperNewNumber = SuperNewNumber - 1;
        return SuperNewNumber;
    }

    public static double SuperMultiply(double m){
        double SuperNewNumber = m;
        SuperNewNumber = SuperNewNumber * m;
        return SuperNewNumber;
    }

    public static double SuperDivision(double m){
        if (m == 0.0){
            return m;
        }
        double SuperNewNumber = m;
        SuperNewNumber = SuperNewNumber / m;
        return SuperNewNumber;
    }
}
