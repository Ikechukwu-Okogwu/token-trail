import java.util.Scanner;

public class Student8Triple2 {

    public static void main(String[] args) {

        System.out.println("Welcome to the life game");
        System.out.println("Enter your name");
        Scanner scanner = new Scanner (System.in);
        String Name = scanner.nextLine();
        System.out.println("Your name is: " + Name);

        int number = TotalCharacterNames(Name);
        System.out.println("Your Name has: " + number + " Characters");

        int Navi = 10000;
        int Score = 0;

        while (Navi != 0){

            System.out.println("Enter a number");
            System.out.println("1 = Spin");
            System.out.println("2 = Walk");
            System.out.println("3 = Run");
            System.out.println("4 = Crawl");
            System.out.println("5 = Drink");  
            System.out.println("6 = Eat");
            System.out.println("7 = Learn");
            System.out.println("8 = Sleep");
            System.out.println("0 = Leave");     
            Navi = scanner.nextInt();
            
            if (Navi == 1){
                Spin(Name);
                Score = Score + 1;
            } else if (Navi == 2){
                Walk(Name);
                Score = Score + 1;
            } else if (Navi == 3){
                Run(Name);
                Score = Score + 1;
            } else if (Navi == 4){
                Crawl(Name);
                Score = Score + 1;
            } else if (Navi == 5){
                Drink(Name);
                Score = Score + 1;
            } else if (Navi == 6){
                Eat(Name);
                Score = Score + 1;
            } else if (Navi == 7){
                Learn(Name);
                Score = Score + 1;
            } else if (Navi == 8){
                Sleep(Name);
                Score = Score + 1;
            }
        }
        System.out.println("Congratuations U Finished");
        System.out.println("Final Score Is: " + Score);
    }

    public static void Spin(String Name){
        System.out.println(Name + " Has Spun");
    }

    public static void Walk (String Name){
        System.out.println(Name + " Has Waled");
    }

    public static void Run (String Name){
        System.out.println(Name + " Has Run");
    }

    public static void Crawl (String Name){
        System.out.println(Name + " Has Crawled");
    }
    
    public static void Drink (String Name){
        System.out.println(Name + " Has Drunk");
    }

    public static void Eat (String Name){
        System.out.println(Name + " Has Eaten");
    }

    public static void Learn (String Name){
        System.out.println(Name + " Has Larned");
    }

    public static void Sleep (String Name){
        System.out.println(Name + " Has Sleeped");
    }

    public static int TotalCharacterNames(String Name){
        int Number = 0;
        char[] Array = Name.toCharArray();

        for (int i = 0; i < Array.length;i++){
            Number = Number + 1;
        }

        return Number;

    }
}
