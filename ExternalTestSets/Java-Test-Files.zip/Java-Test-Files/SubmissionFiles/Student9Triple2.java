import java.util.Scanner;

public class Student9Triple2 {

    public static void main(String[] args) {

        System.out.println("Welcome to the life game");
        System.out.println("Enter your name");
        Scanner Megascanner = new Scanner (System.in);
        String MegaName = Megascanner.nextLine();
        System.out.println("Your name is: " + MegaName);

        int Meganumber = MegaTotalCharacterNames(MegaName);
        System.out.println("Your Name has: " + Meganumber + " Characters");

        int MegaNavi = 10000;
        int MegaScore = 0;

        while (MegaNavi != 0){

            System.out.println("Enter a number");
            System.out.println("1 = Spin");
            System.out.println("2 = Walk");
            System.out.println("3 = Run");
            System.out.println("4 = Crawl");
            System.out.println("5 = Drink");  
            System.out.println("6 = Eat");
            System.out.println("7 = Learn");
            System.out.println("8 = Sleep");
            System.out.println("0 = Leave");     
            MegaNavi = Megascanner.nextInt();
            
            if (MegaNavi == 1){
                MegaSpin(MegaName);
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 2){
                MegaWalk(MegaName);
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 3){
                MegaRun(MegaName);
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 4){
                megaCrawl(MegaName);
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 5){
                MegaDrink(MegaName);
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 6){
                MegaEat(MegaName);
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 7){
                MegaLearn(MegaName);
                MegaScore = MegaScore + 1;
            } else if (MegaNavi == 8){
                MegaSleep(MegaName);
                MegaScore = MegaScore + 1;
            }
        }
        System.out.println("Congratuations U Finished");
        System.out.println("Final Score Is: " + MegaScore);
    }

    public static void MegaSpin(String MegaName){
        System.out.println(MegaName + " Has Spun");
    }

    public static void MegaWalk (String MegaName){
        System.out.println(MegaName + " Has Waled");
    }

    public static void MegaRun (String MegaName){
        System.out.println(MegaName + " Has Run");
    }

    public static void megaCrawl (String MegaName){
        System.out.println(MegaName + " Has Crawled");
    }
    
    public static void MegaDrink (String MegaName){
        System.out.println(MegaName + " Has Drunk");
    }

    public static void MegaEat (String MegaName){
        System.out.println(MegaName + " Has Eaten");
    }

    public static void MegaLearn (String MegaName){
        System.out.println(MegaName + " Has Larned");
    }

    public static void MegaSleep (String MegaName){
        System.out.println(MegaName + " Has Sleeped");
    }

    public static int MegaTotalCharacterNames(String MegaName){
        int megaNumber = 0;
        char[] MegaArray = MegaName.toCharArray();

        for (int i = 0; i < MegaArray.length;i++){
            megaNumber = megaNumber + 1;
        }

        return megaNumber;

    }
}
