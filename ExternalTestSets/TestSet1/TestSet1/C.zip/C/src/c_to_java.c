#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define INITIAL_CAPACITY 3
#define MAX_NAME 50
#define MAX_GRADES 5

typedef struct {
    char name[MAX_NAME];
    float grades[MAX_GRADES];
    int grade_count;
    float average;
} Student;

void calculate_average(Student *s) {
    float sum = 0;
    for (int i = 0; i < s->grade_count; i++) {
        sum += s->grades[i];
    }
    s->average = s->grade_count > 0 ? sum / s->grade_count : 0;
}

void add_student(Student **arr, int *size, int *capacity) {
    if (*size >= *capacity) {
        *capacity *= 2;
        *arr = realloc(*arr, (*capacity) * sizeof(Student));
        if (*arr == NULL) {
            printf("Memory allocation failed!\n");
            exit(1);
        }
    }

    Student *s = &((*arr)[*size]);

    printf("Enter name: ");
    fgets(s->name, MAX_NAME, stdin);
    s->name[strcspn(s->name, "\n")] = 0;

    printf("Enter number of grades (max %d): ", MAX_GRADES);
    scanf("%d", &s->grade_count);

    for (int i = 0; i < s->grade_count; i++) {
        printf("Grade %d: ", i + 1);
        scanf("%f", &s->grades[i]);
    }
    getchar(); // consume newline

    calculate_average(s);
    (*size)++;
}

int compare_students(const void *a, const void *b) {
    Student *s1 = (Student *)a;
    Student *s2 = (Student *)b;
    return (s2->average > s1->average) - (s2->average < s1->average);
}

void save_to_file(Student *arr, int size) {
    FILE *fp = fopen("students.txt", "w");
    if (!fp) {
        printf("Error opening file!\n");
        return;
    }

    for (int i = 0; i < size; i++) {
        fprintf(fp, "%s %d ", arr[i].name, arr[i].grade_count);
        for (int j = 0; j < arr[i].grade_count; j++) {
            fprintf(fp, "%.2f ", arr[i].grades[j]);
        }
        fprintf(fp, "\n");
    }

    fclose(fp);
    printf("Saved to students.txt\n");
}

void load_from_file(Student **arr, int *size, int *capacity) {
    FILE *fp = fopen("students.txt", "r");
    if (!fp) {
        printf("No existing file found.\n");
        return;
    }

    *size = 0;

    while (!feof(fp)) {
        if (*size >= *capacity) {
            *capacity *= 2;
            *arr = realloc(*arr, (*capacity) * sizeof(Student));
        }

        Student *s = &((*arr)[*size]);

        if (fscanf(fp, "%s %d", s->name, &s->grade_count) != 2)
            break;

        for (int i = 0; i < s->grade_count; i++) {
            fscanf(fp, "%f", &s->grades[i]);
        }

        calculate_average(s);
        (*size)++;
    }

    fclose(fp);
    printf("Loaded %d students.\n", *size);
}

void print_students(Student *arr, int size) {
    for (int i = 0; i < size; i++) {
        printf("%s | Avg: %.2f\n", arr[i].name, arr[i].average);
    }
}

void class_stats(Student *arr, int size) {
    if (size == 0) return;

    float max = arr[0].average, min = arr[0].average, sum = 0;

    for (int i = 0; i < size; i++) {
        if (arr[i].average > max) max = arr[i].average;
        if (arr[i].average < min) min = arr[i].average;
        sum += arr[i].average;
    }

    printf("Class Average: %.2f\n", sum / size);
    printf("Highest Avg: %.2f\n", max);
    printf("Lowest Avg: %.2f\n", min);
}

int main() {
    int capacity = INITIAL_CAPACITY;
    int size = 0;

    Student *students = malloc(capacity * sizeof(Student));

    load_from_file(&students, &size, &capacity);

    int choice;

    do {
        printf("\n1. Add Student\n2. Show Students\n3. Sort by Avg\n4. Stats\n5. Save\n0. Exit\nChoice: ");
        scanf("%d", &choice);
        getchar();

        switch (choice) {
            case 1:
                add_student(&students, &size, &capacity);
                break;
            case 2:
                print_students(students, size);
                break;
            case 3:
                qsort(students, size, sizeof(Student), compare_students);
                printf("Sorted!\n");
                break;
            case 4:
                class_stats(students, size);
                break;
            case 5:
                save_to_file(students, size);
                break;
        }
    } while (choice != 0);

    free(students);
    return 0;
}
