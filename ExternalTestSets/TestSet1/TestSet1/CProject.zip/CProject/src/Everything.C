#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>

// enum
typedef enum {
    TASK_NEW,
    TASK_RUNNING,
    TASK_DONE
} TaskStatus;

// struct
typedef struct {
    int id;
    char name[20];
    float progress;
    TaskStatus status;
} Task;

// union
union Data {
    int i;
    float f;
};

// global + extern demo
int globalCounter = 0;
extern int globalCounter;

// static + inline
static inline int increment(int x) {
    return x + 1;
}

// _Thread_local
_Thread_local int threadLocalCounter = 0;

// _Atomic
_Atomic int atomicTasksProcessed = 0;

// function prototype
void processTask(Task *restrict t);

// _Noreturn
_Noreturn void fatalError(const char *msg) {
    printf("Fatal: %s\n", msg);
    exit(1);
}

/** Main loooooooooooooop
*
*/
int main(void) {

    // primitive types
    char c = 'X';
    signed char sc = -5;
    unsigned char uc = 250;

    short s = -100;
    unsigned short us = 100;

    int i = 0;
    unsigned int ui = 10U;

    long l = 1000L;
    unsigned long ul = 2000UL;

    long long ll = 10000LL;
    unsigned long long ull = 20000ULL;

    float f = 1.5f;
    double d = 2.5;
    long double ld = 3.5L;

    _Bool flag = 1;

    printf("System initialized: %c %d %u\n", c, sc, uc);

    // array
    Task tasks[3] = {
        {1, "TaskA", 0.0f, TASK_NEW},
        {2, "TaskB", 0.0f, TASK_NEW},
        {3, "TaskC", 0.0f, TASK_NEW}
    };

    // for loop
    for (int idx = 0; idx < 3; idx++) {

        // pointer + restrict
        Task *restrict t = &tasks[idx];

        processTask(t);

        // switch
        switch (t->status) {
            case TASK_DONE:
                printf("Task %d completed\n", t->id);
                break;
            default:
                printf("Task %d not done\n", t->id);
        }
    }

    // while loop
    int count = 0;
    while (count < 2) {
        printf("While loop iteration %d\n", count);
        count++;
    }

    // do-while
    int dw = 0;
    do {
        printf("Do-while iteration %d\n", dw);
        dw++;
    } while (dw < 1);

    // goto
    int retry = 0;
retry_label:
    if (retry < 1) {
        retry++;
        goto retry_label;
    }

    // union usage
    union Data data;
    data.i = 42;
    printf("Union int: %d\n", data.i);
    data.f = 3.14f;
    printf("Union float: %.2f\n", data.f);

    // const + volatile
    const int maxTasks = 3;
    volatile int observed = globalCounter;

    printf("Processed (atomic): %d\n", atomicTasksProcessed);

    // sizeof
    printf("Size of Task: %zu\n", sizeof(Task));

    // _Static_assert
    _Static_assert(sizeof(int) >= 2, "int too small");

    // _Generic
    #define type_of(x) _Generic((x), \
        int: "int", \
        float: "float", \
        default: "other")

    printf("Type of f: %s\n", type_of(f));

    // register (hint only)
    register int fastVar = 5;
    fastVar = increment(fastVar);

    // if-else
    if (flag) {
        printf("Flag is true\n");
    } else {
        printf("Flag is false\n");
    }

    // break + continue
    for (int j = 0; j < 5; j++) {
        if (j == 2) continue;
        if (j == 4) break;
        printf("Loop j=%d\n", j);
    }

    return 0;
}

// function definition
void processTask(Task *restrict t) {

    if (t == NULL) {
        fatalError("Null task");
    }

    t->status = TASK_RUNNING;

    // simulate progress
    for (int step = 0; step < 3; step++) {
        t->progress += 33.3f;
    }

    t->status = TASK_DONE;

    // atomic increment
    atomicTasksProcessed++;

    // thread local usage
    threadLocalCounter++;

    // static local
    static int totalProcessed = 0;
    totalProcessed++;

    printf("Processed task %d (%s), total=%d\n",
           t->id, t->name, totalProcessed);
}