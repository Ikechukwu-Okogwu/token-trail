package VariableValueSwitching;

public class AllPrimatives {
    public static void main(String[] args) {
        // byte
        byte myByte = 100;
        System.out.println("byte: " + myByte);

        // short
        short myShort = 10000;
        System.out.println("short: " + myShort);

        // int
        int myInt = 100000;
        System.out.println("int: " + myInt);

        // long
        long myLong = 10000000000L;
        System.out.println("long: " + myLong);

        // float
        float myFloat = 3.14f;
        System.out.println("float: " + myFloat);

        // double
        double myDouble = 3.1415926535;
        System.out.println("double: " + myDouble);

        // char
        char myChar = 'A';
        System.out.println("char: " + myChar);

        // boolean
        boolean myBoolean = true;
        System.out.println("boolean: " + myBoolean);
    }
}
