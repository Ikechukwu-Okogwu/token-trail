package VariableValueSwitching;

public class CopiedAllPrimatives {
    public static void main(String[] args) {
        CopiedAllPrimatives c = new CopiedAllPrimatives();
        c.myFunction();
    }

    private void myFunction(){
        // byte
        byte someByteMaybe = 27;
        System.out.println("byte: " + someByteMaybe);

        // short
        short hopefullyNotMyShortPlease = 11902;
        System.out.println("short: " + hopefullyNotMyShortPlease);

        // int
        int pleaseDontFindMyStolenInt = 8567432;
        System.out.println("int: " + pleaseDontFindMyStolenInt);

        // long
        long iHopeThatSteallingThisLongSegmentOfCodeWontBeNoticedIfIChangeTheValues = 54322143567L;
        System.out.println("long: " + iHopeThatSteallingThisLongSegmentOfCodeWontBeNoticedIfIChangeTheValues);

        // float
        float maybeFloatingTheCodeOutOfMainWillHelp = 6.28f;
        System.out.println("float: " + maybeFloatingTheCodeOutOfMainWillHelp);

        // double
        double iveRunOutOfCleverNamesDouble = 35.9952;
        System.out.println("double: " + iveRunOutOfCleverNamesDouble);

        // char
        char waitIHaveOneMore = '☹';
        System.out.println("char: " + waitIHaveOneMore);

        // boolean
        boolean IWillGetAwayWithPlagiarism = false;
        System.out.println("boolean: " + IWillGetAwayWithPlagiarism);
    }
}
