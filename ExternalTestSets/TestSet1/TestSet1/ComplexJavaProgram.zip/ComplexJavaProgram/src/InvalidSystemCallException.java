package ComplexJavaProgram.MIPS;

public class InvalidSystemCallException extends  RuntimeException{

    InvalidSystemCallException(String message){
        super(message);
    }
}
