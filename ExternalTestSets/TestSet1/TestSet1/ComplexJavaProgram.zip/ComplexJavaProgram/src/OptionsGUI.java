/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ComplexJavaProgram.MIPS;

import com.formdev.flatlaf.FlatDarculaLaf;
import com.formdev.flatlaf.FlatDarkLaf;
import com.formdev.flatlaf.FlatIntelliJLaf;
import com.formdev.flatlaf.FlatLightLaf;
import com.formdev.flatlaf.extras.FlatSVGIcon;
import com.formdev.flatlaf.ui.FlatUIUtils;
import com.formdev.flatlaf.util.UIScale;
import org.parker.mips.ResourceHandler;
import org.parker.mips.gui.theme.IJThemeInfo;
import org.parker.mips.gui.theme.IJThemesManager;
import org.parker.mips.gui.theme.ThemeHandler;
import org.parker.mips.misc.SerializableFont;
import org.parker.mips.preferences.Preference;
import org.parker.mips.preferences.Preferences;

import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.awt.event.WindowListener;
import java.awt.geom.Rectangle2D;
import java.io.File;
import java.util.*;
import java.util.logging.Logger;

/**
 *
 * @author parke
 */
public class OptionsGUI extends JFrame {

	private static final Logger LOGGER = Logger.getLogger(OptionsGUI.class.getName());

	private static final Preferences systemPrefs = Preferences.ROOT_NODE.getNode("system");
	private static final Preferences emulatorPrefs = systemPrefs.getNode("emulator");
	private static final Preferences runtimePrefs = emulatorPrefs.getNode("runtime");
	private static final Preferences loggerPrefs = systemPrefs.getNode("logger");
	private static final Preferences assemblerPrefs = systemPrefs.getNode("assembler");
	private static final Preferences defaultSysCllPluginPrefs = systemPrefs.getNode("plugins/systemCalls/Base");
	private static final Preferences guiPrefs = systemPrefs.getNode("gui");
	private static final Preferences themePrefs = systemPrefs.getNode("theme");

	public OptionsGUI() {
		initComponents();

		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();
		this.setLocation(dim.width/2-this.getSize().width/2, dim.height/2-this.getSize().height/2);

		initGUIThemeComponents();
		initEditorThemeComponents();

		this.setTitle("Options");
		try {
			this.setIconImage(new FlatSVGIcon("images/project.svg").getImage());
		} catch (Exception e) {

		}

		Object reference = this;
		WindowListener exitListener = new WindowAdapter() {

			@Override
			public void windowClosing(WindowEvent e) {
				Preference.removeAllObserversLinkedToObject(reference);
			}
		};

		this.addWindowListener(exitListener);

		loggerPrefs.getRawPreference("showStackTrace", false).LinkJButton(this, this.showStackTraceJCheckBox);
		loggerPrefs.getRawPreference("showCallerClass", false).LinkJButton(this, this.showCallerClassNameJCheckBox);
		loggerPrefs.getRawPreference("showCallerMethod",false).LinkJButton(this, this.showCallerMethodNameJCheckBox);
		loggerPrefs.getRawPreference("systemLogLevel","INFO").LinkJList(this, this.systemLogLevelJList);
		loggerPrefs.getRawPreference("assemblerLogLevel","ASSEMBLER_MESSAGE").LinkJList(this, this.assemblerLogLevelJList);
		loggerPrefs.getRawPreference("runtimeLogLevel","RUN_TIME_MESSAGE").LinkJList(this, this.runtimeLogLevelJList);
		loggerPrefs.getRawPreference("logSystemCallMessages", true).LinkJButton(this, this.logSystemCallMessagesButton);

		guiPrefs.getRawPreference("enableGUIAutoUpdateWhileRunning", true).LinkJButton(this, this.enableAutoGUIUpdatesWhileRuning);
		guiPrefs.getRawPreference("GUIAutoUpdateRefreshTime", 100).LinkJSlider(this, this.guiUpdateTimeSlider);

		// Assembler
		assemblerPrefs.getRawPreference("saveCleanedFile", false).LinkJButton(this, this.saveCleanedFileButton);
		assemblerPrefs.getRawPreference("savePreProcessedFile",false).LinkJButton(this, this.savePreProcessorFileButton);
		assemblerPrefs.getRawPreference("saveCompilationInfo",false).LinkJButton(this, this.saveAssemblerInfoFileButton);

		// PreProcessor
		assemblerPrefs.getRawPreference("includeRegDef", true).LinkJButton(this, this.includeRegDefButton);
		assemblerPrefs.getRawPreference("includeSysCallDef", true).LinkJButton(this, this.includeSysCallDefButton);

		// Processor
		// Run Time
		runtimePrefs.getRawPreference("breakOnRunTimeError", true).LinkJButton(this, this.breakOnRunTimeErrorButton);
		runtimePrefs.getRawPreference("adaptiveMemory", false).LinkJButton(this, this.adaptiveMemoryButton);
		runtimePrefs.getRawPreference("enableBreakPoints", true).LinkJButton(this, this.enableBreakPointsButton);

		// Non RunTime
		emulatorPrefs.getRawPreference("reloadMemoryOnReset", true).LinkJButton(this, this.reloadMemoryOnResetButton);

		// System Calls
		defaultSysCllPluginPrefs.getRawPreference("resetProcessorOnTrap0", false).LinkJButton(this, this.resetProcessorOnTrap0Button);

		// Others
		this.loadOptionsButton.addActionListener((ae) -> {
			JFileChooser fc = ResourceHandler.createFileChooser(ResourceHandler.USER_SAVED_CONFIG_PATH);
			int val = ResourceHandler.openFileChooser(fc);

			if (JFileChooser.APPROVE_OPTION == val) {
				Preferences.loadPreferencesFromFile(fc.getSelectedFile());
			}
		});

		this.saveCurrentOptionsButton.addActionListener((ae) -> {
			JFileChooser fc = ResourceHandler.createFileChooser(ResourceHandler.USER_SAVED_CONFIG_PATH);
			int val = ResourceHandler.openFileChooser(fc);

			if (JFileChooser.APPROVE_OPTION == val) {
				Preferences.savePreferencesToFile(fc.getSelectedFile());
			}
		});

		this.setVisible(true);
	}

	private void initGUIThemeComponents() {
		// add font families
		// get current font
		Preference<SerializableFont> currentGUIFont = themePrefs.getRawPreference("currentGUIFont",new SerializableFont("Segoe UI", 0, 15));
		String currentFamily = currentGUIFont.val().getName();
		String currentSize = Integer.toString(currentGUIFont.val().getSize());

		String[] allSystemFonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();

		ArrayList<String> families = new ArrayList<>(Arrays.asList(allSystemFonts));
		if (!families.contains(currentFamily)) {
			families.add(currentFamily);
		}
		families.sort(String.CASE_INSENSITIVE_ORDER);

		guiFontList.setModel(new AbstractListModel<String>() {
			String[] strings = families.toArray(new String[0]);

			public int getSize() {
				return strings.length;
			}

			public String getElementAt(int i) {
				return strings[i];
			}
		});
		guiFontList.setSelectedValue(currentFamily, false);

		guiFontList.addListSelectionListener((lse) -> {
			SerializableFont temp = currentGUIFont.val();
			temp.setName(guiFontList.getSelectedValue());
			currentGUIFont.val(temp);
		});
		currentGUIFont.addLikedObserver(this, new Observer() {
			@Override
			public void update(Observable o, Object arg) {
				String current = currentGUIFont.val().getName();
				if (!current.equals(guiFontList.getSelectedValue())) {
					guiFontList.setSelectedValue(current, true);
				}
			}
		});

		// add font sizes
		ArrayList<String> sizes = new ArrayList<>(Arrays.asList("10", "12", "14", "16", "18", "20", "24", "28"));
		if (!sizes.contains(currentSize)) {
			sizes.add(currentSize);
		}
		sizes.sort(String.CASE_INSENSITIVE_ORDER);

		guiFontSizeList.setModel(new AbstractListModel<String>() {
			String[] strings = sizes.toArray(new String[0]);

			public int getSize() {
				return strings.length;
			}

			public String getElementAt(int i) {
				return strings[i];
			}
		});

		guiFontSizeList.setSelectedValue(currentSize, false);



		guiFontSizeList.addListSelectionListener((lse) -> {
			String fontSize = guiFontSizeList.getSelectedValue();
			int val = Integer.parseInt(fontSize);
			SerializableFont temp = currentGUIFont.val();
			temp.setSize(val);
			currentGUIFont.val(temp);
		});

		currentGUIFont.addLikedObserver(this, (e, a) -> {
			String current = Integer.toString(currentGUIFont.val().getSize());
			if (!current.equals(guiFontList.getSelectedValue())) {
				guiFontList.setSelectedValue(current, true);
			}
		});

		{
			updateThemesList();

			Preference<String> currentGUITheme = themePrefs.getRawPreference("currentGUITheme","Flat Dark");

			guiThemeList.setSelectedValue(IJThemesManager.getTheme(currentGUITheme.val()), true);

			currentGUITheme.addLikedObserver(this, (o,v) -> {
				if (!guiThemeList.getSelectedValue().equals(IJThemesManager.getTheme((String)v)))
					guiThemeList.setSelectedValue(IJThemesManager.getTheme((String)v), true);
			});

			guiThemeList.addListSelectionListener((e) -> {
					if (e.getValueIsAdjusting()) {
						return;
					}
					IJThemeInfo val = guiThemeList.getSelectedValue();
					
					if (guiThemeList.getSelectedValue() == null) {
						return;
					}

					if (!val.name.equals(currentGUITheme.val())){
						currentGUITheme.val(val.name);
					}
				});

		}

	}

	private void updateThemesList() {
		ArrayList<IJThemeInfo> themes = new ArrayList();

		int filterLightDark = 0;
		boolean showLight = (filterLightDark != 2);
		boolean showDark = (filterLightDark != 1);

		// load theme infos
		IJThemesManager.loadBundledThemes();
		IJThemesManager.loadThemesFromDirectory();

		// sort themes by name
		Comparator<? super IJThemeInfo> comparator = (t1, t2) -> t1.name.compareToIgnoreCase(t2.name);
		IJThemesManager.bundledThemes.sort(comparator);
		IJThemesManager.moreThemes.sort(comparator);

		// remember selection (must be invoked before clearing themes field)
		IJThemeInfo oldSel = guiThemeList.getSelectedValue();

		themes.clear();
		// categories.clear();

		// add core themes at beginning
		// categories.put(themes.size(), "Core Themes");
		if (showLight)
			themes.add(new IJThemeInfo("Flat Light", null, false, null, null, null, null, null,
					FlatLightLaf.class.getName()));
		if (showDark)
			themes.add(new IJThemeInfo("Flat Dark", null, true, null, null, null, null, null,
					FlatDarkLaf.class.getName()));
		if (showLight)
			themes.add(new IJThemeInfo("Flat IntelliJ", null, false, null, null, null, null, null,
					FlatIntelliJLaf.class.getName()));
		if (showDark)
			themes.add(new IJThemeInfo("Flat Darcula", null, true, null, null, null, null, null,
					FlatDarculaLaf.class.getName()));

		// add themes from directory
		// categories.put( themes.size(), "Current Directory" );
		themes.addAll(IJThemesManager.moreThemes);

		// add uncategorized bundled themes
		// categories.put( themes.size(), "IntelliJ Themes" );
		for (IJThemeInfo ti : IJThemesManager.bundledThemes) {
			boolean show = (showLight && !ti.dark) || (showDark && ti.dark);
			if (show && !ti.name.contains("/"))
				themes.add(ti);
		}

		// add categorized bundled themes
		String lastCategory = null;
		for (IJThemeInfo ti : IJThemesManager.bundledThemes) {
			boolean show = (showLight && !ti.dark) || (showDark && ti.dark);
			int sep = ti.name.indexOf('/');
			if (!show || sep < 0)
				continue;

			String category = ti.name.substring(0, sep).trim();
			if (!Objects.equals(lastCategory, category)) {
				lastCategory = category;
				// categories.put( themes.size(), category );
			}

			themes.add(ti);
		}

		// fill themes list
		guiThemeList.setModel(new AbstractListModel<IJThemeInfo>() {
			@Override
			public int getSize() {
				return themes.size();
			}

			@Override
			public IJThemeInfo getElementAt(int index) {
				return themes.get(index);
			}
		});

		// restore selection
		if (oldSel != null) {
			for (int i = 0; i < themes.size(); i++) {
				IJThemeInfo theme = themes.get(i);
				if (oldSel.name.equals(theme.name) && Objects.equals(oldSel.resourceName, theme.resourceName)
						&& Objects.equals(oldSel.themeFile, theme.themeFile)
						&& Objects.equals(oldSel.lafClassName, theme.lafClassName)) {
					guiThemeList.setSelectedIndex(i);
					break;
				}
			}

			// select first theme if none selected
			if (guiThemeList.getSelectedIndex() < 0)
				guiThemeList.setSelectedIndex(0);
		}

		// scroll selection into visible area
		int sel = guiThemeList.getSelectedIndex();
		if (sel >= 0) {
			Rectangle bounds = guiThemeList.getCellBounds(sel, sel);
			if (bounds != null)
				guiThemeList.scrollRectToVisible(bounds);
		}
	}

	private void initEditorThemeComponents() {

		Preference<SerializableFont> currentEditorFont = themePrefs.getRawPreference("currentEditorFont",new SerializableFont("Segoe UI", 0, 15));
		//Font currentFont = OptionsHandler.currentEditorFont.val();
		String currentFamily = currentEditorFont.val().getName();
		String currentSize = Integer.toString(currentEditorFont.val().getSize());

		String[] allSystemFonts = GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames();
		ArrayList<String> families = new ArrayList<>(Arrays.asList(allSystemFonts));
		if (!families.contains(currentFamily)) {
			families.add(currentFamily);
		}
		families.sort(String.CASE_INSENSITIVE_ORDER);

		editorFontList.setModel(new AbstractListModel<String>() {
			String[] strings = families.toArray(new String[0]);

			public int getSize() {
				return strings.length;
			}

			public String getElementAt(int i) {
				return strings[i];
			}
		});
		editorFontList.setSelectedValue(currentFamily, false);

		editorFontList.addListSelectionListener((lse) -> {
			 SerializableFont temp = currentEditorFont.val();
			 temp.setName(editorFontList.getSelectedValue());
			currentEditorFont.val(temp);
		});

		currentEditorFont.addLikedObserver(this, (o,v) -> {
			String current = currentEditorFont.val().getName();
			if (!current.equals(editorFontList.getSelectedValue())) {
				editorFontList.setSelectedValue(current, true);
			}
		});

		// add font sizes
		ArrayList<String> sizes = new ArrayList<>(Arrays.asList("10", "12", "14", "16", "18", "20", "24", "28"));
		if (!sizes.contains(currentSize)) {
			sizes.add(currentSize);
		}
		sizes.sort(String.CASE_INSENSITIVE_ORDER);

		editorFontSizeList.setModel(new AbstractListModel<String>() {
			String[] strings = sizes.toArray(new String[0]);

			public int getSize() {
				return strings.length;
			}

			public String getElementAt(int i) {
				return strings[i];
			}
		});

		editorFontSizeList.setSelectedValue(currentSize, false);

		editorFontSizeList.addListSelectionListener((lse) -> {
			String fontSize = editorFontSizeList.getSelectedValue();
			int val = Integer.parseInt(fontSize);
			SerializableFont temp = currentEditorFont.val();
			temp.setSize(val);
			currentEditorFont.val(temp);
		});

		currentEditorFont.addLikedObserver(this, (o,v) -> {
			String current = Integer.toString(currentEditorFont.val().getSize());
			if (!current.equals(editorFontList.getSelectedValue())) {
				editorFontList.setSelectedValue(current, true);
			}
		});

		{// loads list of available themes
			Preference<String> currentEditorTheme = themePrefs.getRawPreference("currentEditorTheme","Dark");

			File file = new File(ResourceHandler.EDITOR_THEMES);
			File[] files = file.listFiles();
			if (files != null) {

				String[] names = new String[files.length];
				for (int i = 0; i < files.length; i++) {
					names[i] = files[i].getName().split("\\.")[0];
				}
				this.editorThemeList.setModel(new DefaultComboBoxModel(names));
				this.editorThemeList.setSelectedValue(currentEditorTheme.val(), true);

				this.editorThemeList.addListSelectionListener((ae) -> {
					// System.err.println("asdasdasdasdasda");
					String name = (String) editorThemeList.getSelectedValue();

					if (!name.equals(currentEditorTheme.val())) {
						currentEditorTheme.val(name);
						// ASM_GUI.loadCurrentTheme();
					}
					// ThemeHandler.readThemeFromThemeName();
				});
			}
		}

	}

	/**
	 * This method is called from within the constructor to initialize the form.
	 * WARNING: Do NOT modify this code. The content of this method is always
	 * regenerated by the Form Editor.
	 */
	@SuppressWarnings("unchecked")
	// <editor-fold defaultstate="collapsed" desc="Generated
	// Code">//GEN-BEGIN:initComponents
	private void initComponents() {

		themedJTabbedPane1 = new JTabbedPane();
		themedJPanel11 = new JPanel();
		//themedJLabel2 = new javax.swing.JLabel();
		//logSystemMessagesButton = new javax.swing.JCheckBox();
		//logMessagesButton = new javax.swing.JCheckBox();
		//logWarningsButton = new javax.swing.JCheckBox();
		//logErrorsButton = new javax.swing.JCheckBox();
		themedJLabel3 = new JLabel();
		enableAutoGUIUpdatesWhileRuning = new JCheckBox();
		themedJLabel5 = new JLabel();
		saveCurrentOptionsButton = new JButton();
		jSeparator1 = new JSeparator();
		loadOptionsButton = new JButton();
		guiUpdateTimeSlider = new JSlider();
		themedJLabel8 = new JLabel();
		themedJPanel12 = new JPanel();
		breakOnRunTimeErrorButton = new JCheckBox();
		themedJLabel1 = new JLabel();
		adaptiveMemoryButton = new JCheckBox();
		enableBreakPointsButton = new JCheckBox();
		jSeparator3 = new JSeparator();
		themedJLabel10 = new JLabel();
		reloadMemoryOnResetButton = new JCheckBox();
		themedJPanel13 = new JPanel();
		themedJLabel6 = new JLabel();
		savePreProcessorFileButton = new JCheckBox();
		saveAssemblerInfoFileButton = new JCheckBox();
		saveCleanedFileButton = new JCheckBox();
		jSeparator2 = new JSeparator();
		themedJLabel9 = new JLabel();
		includeRegDefButton = new JCheckBox();
		includeSysCallDefButton = new JCheckBox();
		themedJPanel15 = new JPanel();
		themedJLabel7 = new JLabel();
		logSystemCallMessagesButton = new JCheckBox();
		resetProcessorOnTrap0Button = new JCheckBox();
		themedJPanel14 = new JPanel();
		jTabbedPane1 = new JTabbedPane();
		jPanel1 = new JPanel();
		themedJLabel13 = new JLabel();
		jScrollPane2 = new JScrollPane();
		guiThemeList = new JList<>();
		jScrollPane3 = new JScrollPane();
		guiFontList = new JList<>();
		themedJLabel4 = new JLabel();
		jScrollPane4 = new JScrollPane();
		guiFontSizeList = new JList<>();
		themedJLabel12 = new JLabel();
		jPanel2 = new JPanel();
		jScrollPane1 = new JScrollPane();
		editorThemeList = new JList<>();
		themedJLabel11 = new JLabel();
		jScrollPane5 = new JScrollPane();
		editorFontSizeList = new JList<>();
		themedJLabel14 = new JLabel();
		jScrollPane6 = new JScrollPane();
		editorFontList = new JList<>();
		themedJLabel15 = new JLabel();

		logPanel = new JPanel();
		systemLogLevelJList = new JList<String>();
		assemblerLogLevelJList = new JList<String>();
		runtimeLogLevelJList = new JList<String>();
		showStackTraceJCheckBox = new JCheckBox();
		showCallerMethodNameJCheckBox = new JCheckBox();
		showCallerClassNameJCheckBox = new JCheckBox();

		setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);

		//themedJLabel2.setText("Log Options");

		//logSystemMessagesButton.setText("Log System Messages");

		//logMessagesButton.setText("Log Messages");

		//logWarningsButton.setText("Log Warnigs");

		//logErrorsButton.setText("Log Errors");

		themedJLabel3.setText("GUI Options");

		enableAutoGUIUpdatesWhileRuning.setText("Enable Auto GUI Updates While Runing");

		themedJLabel5.setHorizontalAlignment(SwingConstants.LEFT);
		themedJLabel5.setText("Options");

		saveCurrentOptionsButton.setText("Save Current Options");

		jSeparator1.setOrientation(SwingConstants.VERTICAL);

		loadOptionsButton.setText("Load Options");

		guiUpdateTimeSlider.setMaximum(500);
		guiUpdateTimeSlider.setMinimum(1);
		guiUpdateTimeSlider.setValue(100);

		themedJLabel8.setHorizontalAlignment(SwingConstants.CENTER);
		Preference<Integer> GUIAutoUpdateRefreshTime = guiPrefs.getRawPreference("GUIAutoUpdateRefreshTime", 100);
		themedJLabel8.setText("Update Time: " + GUIAutoUpdateRefreshTime.val() + " ms");
		GUIAutoUpdateRefreshTime.addLikedObserver(this, (o, v) -> {
			themedJLabel8.setText("Update Time: " + v + " ms");
		});

		GroupLayout themedJPanel11Layout = new GroupLayout(themedJPanel11);
		themedJPanel11.setLayout(themedJPanel11Layout);
		themedJPanel11Layout.setHorizontalGroup(themedJPanel11Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(themedJPanel11Layout.createSequentialGroup().addContainerGap()
						.addGroup(themedJPanel11Layout
								.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								//.addComponent(themedJLabel2, javax.swing.GroupLayout.PREFERRED_SIZE,
								//		javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								//.addComponent(logSystemMessagesButton, javax.swing.GroupLayout.PREFERRED_SIZE,
								//		javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								//.addComponent(logErrorsButton, javax.swing.GroupLayout.PREFERRED_SIZE,
								//		javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								//.addComponent(logWarningsButton, javax.swing.GroupLayout.PREFERRED_SIZE,
								//		javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								//.addComponent(logMessagesButton, javax.swing.GroupLayout.PREFERRED_SIZE,
								//		javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
								.addComponent(themedJLabel3, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(enableAutoGUIUpdatesWhileRuning, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(guiUpdateTimeSlider, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(themedJLabel8, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 18, Short.MAX_VALUE)
						.addComponent(jSeparator1, GroupLayout.PREFERRED_SIZE, 15,
								GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(themedJPanel11Layout
								.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								.addComponent(themedJLabel5, GroupLayout.PREFERRED_SIZE, 153,
										GroupLayout.PREFERRED_SIZE)
								.addComponent(loadOptionsButton, GroupLayout.DEFAULT_SIZE, 171,
										Short.MAX_VALUE)
								.addComponent(saveCurrentOptionsButton, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addGap(146, 146, 146)));
		themedJPanel11Layout.setVerticalGroup(themedJPanel11Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(themedJPanel11Layout.createSequentialGroup().addContainerGap().addGroup(themedJPanel11Layout
						.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addComponent(themedJLabel3, GroupLayout.PREFERRED_SIZE,
								GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(themedJLabel5, GroupLayout.PREFERRED_SIZE,
								GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						//.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(themedJPanel11Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addGroup(themedJPanel11Layout.createSequentialGroup()
										//.addComponent(logSystemMessagesButton, javax.swing.GroupLayout.PREFERRED_SIZE,
										//		javax.swing.GroupLayout.DEFAULT_SIZE,
										//		javax.swing.GroupLayout.PREFERRED_SIZE)
										//.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										//.addComponent(logMessagesButton, javax.swing.GroupLayout.PREFERRED_SIZE,
										//		javax.swing.GroupLayout.DEFAULT_SIZE,
										//		javax.swing.GroupLayout.PREFERRED_SIZE)
										//.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										//.addComponent(logWarningsButton, javax.swing.GroupLayout.PREFERRED_SIZE,
										//		javax.swing.GroupLayout.DEFAULT_SIZE,
										//		javax.swing.GroupLayout.PREFERRED_SIZE)
										//.addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
										//.addComponent(logErrorsButton, javax.swing.GroupLayout.PREFERRED_SIZE,
										//		javax.swing.GroupLayout.DEFAULT_SIZE,
										//		javax.swing.GroupLayout.PREFERRED_SIZE)
										//.addGap(18, 18, 18)
										//.addComponent(themedJLabel3, javax.swing.GroupLayout.PREFERRED_SIZE,
										//		javax.swing.GroupLayout.DEFAULT_SIZE,
										//		javax.swing.GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(enableAutoGUIUpdatesWhileRuning,
												GroupLayout.PREFERRED_SIZE,
												GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE))
								.addGroup(themedJPanel11Layout.createSequentialGroup()
										.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(loadOptionsButton, GroupLayout.PREFERRED_SIZE,
												GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)
										.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
										.addComponent(saveCurrentOptionsButton, GroupLayout.PREFERRED_SIZE,
												GroupLayout.DEFAULT_SIZE,
												GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(themedJLabel8, GroupLayout.PREFERRED_SIZE,
								GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addComponent(guiUpdateTimeSlider, GroupLayout.PREFERRED_SIZE,
								GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addContainerGap(126, Short.MAX_VALUE))
				.addComponent(jSeparator1));

		themedJTabbedPane1.addTab("General", themedJPanel11);

		breakOnRunTimeErrorButton.setText("Break On RunTime Error");

		themedJLabel1.setText("RunTime Options");

		adaptiveMemoryButton.setText("Adaptive Memory");

		enableBreakPointsButton.setText("Enable BreakPoints");

		jSeparator3.setOrientation(SwingConstants.VERTICAL);

		themedJLabel10.setText("General Options");

		reloadMemoryOnResetButton.setText("Reload Memory on Reset");

		GroupLayout themedJPanel12Layout = new GroupLayout(themedJPanel12);
		themedJPanel12.setLayout(themedJPanel12Layout);
		themedJPanel12Layout.setHorizontalGroup(themedJPanel12Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(themedJPanel12Layout.createSequentialGroup().addContainerGap()
						.addGroup(themedJPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addComponent(themedJLabel1, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(breakOnRunTimeErrorButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(adaptiveMemoryButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(enableBreakPointsButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGap(121, 121, 121)
						.addComponent(jSeparator3, GroupLayout.PREFERRED_SIZE, 15,
								GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(themedJPanel12Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addComponent(themedJLabel10, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(reloadMemoryOnResetButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addContainerGap(125, Short.MAX_VALUE)));
		themedJPanel12Layout.setVerticalGroup(themedJPanel12Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(jSeparator3)
				.addGroup(themedJPanel12Layout.createSequentialGroup().addContainerGap().addGroup(themedJPanel12Layout
						.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addGroup(themedJPanel12Layout.createSequentialGroup()
								.addComponent(themedJLabel1, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(breakOnRunTimeErrorButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(adaptiveMemoryButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(
										enableBreakPointsButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(themedJPanel12Layout.createSequentialGroup()
								.addComponent(themedJLabel10, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(reloadMemoryOnResetButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addContainerGap(269, Short.MAX_VALUE)));

		themedJTabbedPane1.addTab("Processor", themedJPanel12);

		themedJLabel6.setText("Assembler Options");

		savePreProcessorFileButton.setText("Save PreProcessed File");

		saveAssemblerInfoFileButton.setText("Save Assembler Info File");

		saveCleanedFileButton.setText("Save Cleaned File");

		jSeparator2.setOrientation(SwingConstants.VERTICAL);

		themedJLabel9.setText("PreProcessor Option");

		includeRegDefButton.setText("Include regdef");

		includeSysCallDefButton.setText("Include syscalldef");

		GroupLayout themedJPanel13Layout = new GroupLayout(themedJPanel13);
		themedJPanel13.setLayout(themedJPanel13Layout);
		themedJPanel13Layout.setHorizontalGroup(themedJPanel13Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(GroupLayout.Alignment.TRAILING, themedJPanel13Layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(themedJPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addComponent(themedJLabel6, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(saveCleanedFileButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(savePreProcessorFileButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(saveAssemblerInfoFileButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						// .addComponent(linkedFileButton, javax.swing.GroupLayout.PREFERRED_SIZE,
						// javax.swing.GroupLayout.DEFAULT_SIZE,
						// javax.swing.GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED, 152, Short.MAX_VALUE)
						.addComponent(jSeparator2, GroupLayout.PREFERRED_SIZE, 15,
								GroupLayout.PREFERRED_SIZE)
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(themedJPanel13Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addComponent(themedJLabel9, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(includeRegDefButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(includeSysCallDefButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGap(144, 144, 144)));
		themedJPanel13Layout.setVerticalGroup(themedJPanel13Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addComponent(jSeparator2, GroupLayout.Alignment.TRAILING)
				.addGroup(themedJPanel13Layout.createSequentialGroup().addContainerGap().addGroup(themedJPanel13Layout
						.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addGroup(themedJPanel13Layout.createSequentialGroup()
								.addComponent(themedJLabel6, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(saveCleanedFileButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(savePreProcessorFileButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(saveAssemblerInfoFileButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addGroup(themedJPanel13Layout.createSequentialGroup()
								.addComponent(themedJLabel9, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(includeRegDefButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(includeSysCallDefButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						// .addComponent(linkedFileButton, javax.swing.GroupLayout.PREFERRED_SIZE,
						// javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
						.addContainerGap(244, Short.MAX_VALUE)));

		themedJTabbedPane1.addTab("Assembler", themedJPanel13);

		themedJLabel7.setText("SystemCall Options");

		logSystemCallMessagesButton.setText("Log SystemCall Messages");

		resetProcessorOnTrap0Button.setText("Reset Processor On Trap 0");

		GroupLayout themedJPanel15Layout = new GroupLayout(themedJPanel15);
		themedJPanel15.setLayout(themedJPanel15Layout);
		themedJPanel15Layout.setHorizontalGroup(themedJPanel15Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(themedJPanel15Layout.createSequentialGroup().addContainerGap()
						.addGroup(themedJPanel15Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addComponent(resetProcessorOnTrap0Button, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(themedJLabel7, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(logSystemCallMessagesButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addContainerGap(423, Short.MAX_VALUE)));
		themedJPanel15Layout
				.setVerticalGroup(themedJPanel15Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addGroup(themedJPanel15Layout.createSequentialGroup().addContainerGap()
								.addComponent(themedJLabel7, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(logSystemCallMessagesButton, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addComponent(resetProcessorOnTrap0Button, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addContainerGap(294, Short.MAX_VALUE)));

		themedJTabbedPane1.addTab("SystemCalls", themedJPanel15);

		themedJLabel13.setText("Font Size");

		jScrollPane2.setViewportView(guiThemeList);

		guiFontList.setModel(new AbstractListModel<String>() {
			String[] strings = { "1", "2", "3", "4" };

			public int getSize() {
				return strings.length;
			}

			public String getElementAt(int i) {
				return strings[i];
			}
		});
		guiFontList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jScrollPane3.setViewportView(guiFontList);

		themedJLabel4.setText("Theme");

		guiFontSizeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jScrollPane4.setViewportView(guiFontSizeList);

		themedJLabel12.setText("Font");

		GroupLayout jPanel1Layout = new GroupLayout(jPanel1);
		jPanel1.setLayout(jPanel1Layout);
		jPanel1Layout.setHorizontalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
						.addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								.addComponent(themedJLabel4, GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
								.addComponent(jScrollPane2, GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								.addComponent(themedJLabel12, GroupLayout.DEFAULT_SIZE, 200, Short.MAX_VALUE)
								.addComponent(jScrollPane3, GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								.addComponent(themedJLabel13, GroupLayout.DEFAULT_SIZE, 150,Short.MAX_VALUE)
								.addComponent(jScrollPane4, GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
						.addContainerGap(0, Short.MAX_VALUE)));
		jPanel1Layout.setVerticalGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(jPanel1Layout.createSequentialGroup().addContainerGap()
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(themedJLabel4, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(themedJLabel12, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(themedJLabel13, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel1Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
								.addGroup(GroupLayout.Alignment.TRAILING,
										jPanel1Layout.createSequentialGroup().addComponent(jScrollPane2).addGap(13, 13,
												13))
								.addGroup(GroupLayout.Alignment.TRAILING,
										jPanel1Layout.createSequentialGroup().addGroup(jPanel1Layout
												.createParallelGroup(GroupLayout.Alignment.TRAILING)
												.addComponent(jScrollPane4, GroupLayout.Alignment.LEADING)
												.addComponent(jScrollPane3, GroupLayout.DEFAULT_SIZE, 297,
														Short.MAX_VALUE))
												.addContainerGap()))));

		jTabbedPane1.addTab("GUI", jPanel1);

		editorThemeList.setModel(new AbstractListModel<String>() {
			String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };

			public int getSize() {
				return strings.length;
			}

			public String getElementAt(int i) {
				return strings[i];
			}
		});
		jScrollPane1.setViewportView(editorThemeList);

		themedJLabel11.setText("Theme");

		editorFontSizeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jScrollPane5.setViewportView(editorFontSizeList);

		themedJLabel14.setText("Font");

		editorFontList.setModel(new AbstractListModel<String>() {
			String[] strings = { "1", "2", "3", "4" };

			public int getSize() {
				return strings.length;
			}

			public String getElementAt(int i) {
				return strings[i];
			}
		});
		editorFontList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		jScrollPane6.setViewportView(editorFontList);

		themedJLabel15.setText("Font Size");

		GroupLayout jPanel2Layout = new GroupLayout(jPanel2);
		jPanel2.setLayout(jPanel2Layout);
		jPanel2Layout.setHorizontalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap()
						.addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								.addComponent(jScrollPane1, GroupLayout.DEFAULT_SIZE, 237, Short.MAX_VALUE)
								.addComponent(themedJLabel11, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								.addComponent(themedJLabel14, GroupLayout.DEFAULT_SIZE,
										GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
								.addComponent(jScrollPane6, GroupLayout.PREFERRED_SIZE, 200,
										GroupLayout.PREFERRED_SIZE))
						.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
						.addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
								.addComponent(jScrollPane5, GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
								.addComponent(themedJLabel15, GroupLayout.PREFERRED_SIZE, 150,
										GroupLayout.PREFERRED_SIZE))
						.addContainerGap(0, Short.MAX_VALUE)));
		jPanel2Layout.setVerticalGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.LEADING)
				.addGroup(jPanel2Layout.createSequentialGroup().addContainerGap().addGroup(jPanel2Layout
						.createParallelGroup(GroupLayout.Alignment.LEADING)
						.addGroup(jPanel2Layout.createSequentialGroup().addGroup(jPanel2Layout
								.createParallelGroup(GroupLayout.Alignment.BASELINE)
								.addComponent(themedJLabel14, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addComponent(themedJLabel15, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
								.addGroup(jPanel2Layout.createParallelGroup(GroupLayout.Alignment.TRAILING)
										.addComponent(jScrollPane5, GroupLayout.Alignment.LEADING)
										.addComponent(jScrollPane6)))
						.addGroup(jPanel2Layout.createSequentialGroup()
								.addComponent(themedJLabel11, GroupLayout.PREFERRED_SIZE,
										GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
								.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED).addComponent(
										jScrollPane1, GroupLayout.DEFAULT_SIZE, 297, Short.MAX_VALUE)))
						.addContainerGap()));

		jTabbedPane1.addTab("Editor", jPanel2);

		themedJTabbedPane1.addTab("Theme", themedJPanel14);

		{//logging panel

			JScrollPane bruhScroll1 = new JScrollPane();
			JLabel systemLevelsLogJLable = new JLabel();
			JLabel runtimeLevelsLogJLable = new JLabel();
			JScrollPane bruhScroll2 = new JScrollPane();
			JLabel assemblerLevelsLogJLable = new JLabel();
			JScrollPane bruhScroll3 = new JScrollPane();

			systemLogLevelJList.setModel(new AbstractListModel<String>() {
				String[] strings = { "OFF", "SEVERE", "WARNING", "INFO", "CONFIG", "FINE", "FINER", "FINEST" };
				public int getSize() { return strings.length; }
				public String getElementAt(int i) { return strings[i]; }
			});
			bruhScroll1.setViewportView(systemLogLevelJList);

			systemLevelsLogJLable.setText("System Levels");

			runtimeLevelsLogJLable.setText("RunTime Levels");

			runtimeLogLevelJList.setModel(new AbstractListModel<String>() {
				String[] strings = { "OFF", "RUN_TIME_ERROR", "RUN_TIME_WARNING", "RUN_TIME_MESSAGE" };
				public int getSize() { return strings.length; }
				public String getElementAt(int i) { return strings[i]; }
			});
			bruhScroll2.setViewportView(runtimeLogLevelJList);

			assemblerLevelsLogJLable.setText("Assembler Levels");

			assemblerLogLevelJList.setModel(new AbstractListModel<String>() {
				String[] strings = { "OFF", "ASSEMBLER_ERROR", "ASSEMBLER_WARNING", "ASSEMBLER_MESSAGE" };
				public int getSize() { return strings.length; }
				public String getElementAt(int i) { return strings[i]; }
			});
			bruhScroll3.setViewportView(assemblerLogLevelJList);

			showCallerMethodNameJCheckBox.setText("Show Caller Method Name");

			showStackTraceJCheckBox.setText("Show Stack Trace On Error");

			showCallerClassNameJCheckBox.setText("Show Caller Class Name");

			GroupLayout loggerLayout = new GroupLayout(logPanel);
			logPanel.setLayout(loggerLayout);
			loggerLayout.setHorizontalGroup(
					loggerLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
							.addGroup(loggerLayout.createSequentialGroup()
									.addContainerGap()
									.addGroup(loggerLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
											.addComponent(bruhScroll1)
											.addComponent(systemLevelsLogJLable, GroupLayout.DEFAULT_SIZE, 120, Short.MAX_VALUE))
									.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
									.addGroup(loggerLayout.createParallelGroup(GroupLayout.Alignment.LEADING, false)
											.addComponent(bruhScroll2)
											.addComponent(runtimeLevelsLogJLable, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
											.addComponent(bruhScroll3, GroupLayout.DEFAULT_SIZE, 180, Short.MAX_VALUE)
											.addComponent(assemblerLevelsLogJLable, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
									.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
									.addGroup(loggerLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
											.addComponent(showCallerMethodNameJCheckBox)
											.addComponent(showCallerClassNameJCheckBox)
											.addComponent(showStackTraceJCheckBox))
									.addContainerGap(GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
			);
			loggerLayout.setVerticalGroup(
					loggerLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
							.addGroup(loggerLayout.createSequentialGroup()
									.addContainerGap()
									.addGroup(loggerLayout.createParallelGroup(GroupLayout.Alignment.BASELINE)
											.addComponent(systemLevelsLogJLable)
											.addComponent(assemblerLevelsLogJLable))
									.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
									.addGroup(loggerLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
											.addComponent(bruhScroll1, GroupLayout.DEFAULT_SIZE, 251, Short.MAX_VALUE)
											.addGroup(loggerLayout.createSequentialGroup()
													.addGroup(loggerLayout.createParallelGroup(GroupLayout.Alignment.LEADING)
															.addGroup(loggerLayout.createSequentialGroup()
																	.addComponent(showCallerMethodNameJCheckBox, GroupLayout.PREFERRED_SIZE, 25, GroupLayout.PREFERRED_SIZE)
																	.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
																	.addComponent(showCallerClassNameJCheckBox)
																	.addPreferredGap(LayoutStyle.ComponentPlacement.UNRELATED)
																	.addComponent(showStackTraceJCheckBox))
															.addComponent(bruhScroll3, GroupLayout.PREFERRED_SIZE, 111, GroupLayout.PREFERRED_SIZE))
													.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
													.addComponent(runtimeLevelsLogJLable)
													.addPreferredGap(LayoutStyle.ComponentPlacement.RELATED)
													.addComponent(bruhScroll2, GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)))
									.addContainerGap())
			);

			themedJTabbedPane1.addTab("Logging", logPanel);
		}

		GroupLayout themedJPanel14Layout = new GroupLayout(themedJPanel14);
		themedJPanel14.setLayout(themedJPanel14Layout);
		themedJPanel14Layout.setHorizontalGroup(themedJPanel14Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(jTabbedPane1));
		themedJPanel14Layout.setVerticalGroup(themedJPanel14Layout
				.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(jTabbedPane1));

		GroupLayout layout = new GroupLayout(getContentPane());
		getContentPane().setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(themedJTabbedPane1,
						GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));
		layout.setVerticalGroup(
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(themedJTabbedPane1,
						GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE));

		pack();
	}// </editor-fold>//GEN-END:initComponents

	/**
	 * @param args the command line arguments
	 */
	public static void main(String args[]) {
		/* Set the Nimbus look and feel */
		// <editor-fold defaultstate="collapsed" desc=" Look and feel setting code
		// (optional) ">
		/*
		 * If Nimbus (introduced in Java SE 6) is not available, stay with the default
		 * look and feel. For details see
		 * http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html
		 */

		// </editor-fold>
		// </editor-fold>
		// </editor-fold>
		// </editor-fold>

		/* Create and display the form */
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				new OptionsGUI().setVisible(true);
			}
		});
	}

	// Variables declaration - do not modify//GEN-BEGIN:variables
	private JCheckBox adaptiveMemoryButton;
	private JCheckBox breakOnRunTimeErrorButton;
	private JList<String> editorFontList;
	private JList<String> editorFontSizeList;
	private JList<String> editorThemeList;
	private JCheckBox enableAutoGUIUpdatesWhileRuning;
	private JCheckBox enableBreakPointsButton;
	private JList<String> guiFontList;
	private JList<String> guiFontSizeList;
	private JList<IJThemeInfo> guiThemeList;
	private JSlider guiUpdateTimeSlider;
	private JCheckBox includeRegDefButton;
	private JCheckBox includeSysCallDefButton;
	private JPanel jPanel1;
	private JPanel jPanel2;
	private JScrollPane jScrollPane1;
	private JScrollPane jScrollPane2;
	private JScrollPane jScrollPane3;
	private JScrollPane jScrollPane4;
	private JScrollPane jScrollPane5;
	private JScrollPane jScrollPane6;
	private JSeparator jSeparator1;
	private JSeparator jSeparator2;
	private JSeparator jSeparator3;
	private JTabbedPane jTabbedPane1;
	private JButton loadOptionsButton;
	//private javax.swing.JCheckBox logErrorsButton;
	//private javax.swing.JCheckBox logMessagesButton;
	private JCheckBox logSystemCallMessagesButton;
	//private javax.swing.JCheckBox logSystemMessagesButton;
	//private javax.swing.JCheckBox logWarningsButton;
	private JCheckBox reloadMemoryOnResetButton;
	private JCheckBox resetProcessorOnTrap0Button;
	private JCheckBox saveCleanedFileButton;
	private JCheckBox saveAssemblerInfoFileButton;
	private JButton saveCurrentOptionsButton;
	private JCheckBox savePreProcessorFileButton;
	private JLabel themedJLabel1;
	private JLabel themedJLabel10;
	private JLabel themedJLabel11;
	private JLabel themedJLabel12;
	private JLabel themedJLabel13;
	private JLabel themedJLabel14;
	private JLabel themedJLabel15;
	//private javax.swing.JLabel themedJLabel2;
	private JLabel themedJLabel3;
	private JLabel themedJLabel4;
	private JLabel themedJLabel5;
	private JLabel themedJLabel6;
	private JLabel themedJLabel7;
	private JLabel themedJLabel8;
	private JLabel themedJLabel9;
	private JPanel themedJPanel11;
	private JPanel themedJPanel12;
	private JPanel themedJPanel13;
	private JPanel themedJPanel14;
	private JPanel themedJPanel15;
	private JTabbedPane themedJTabbedPane1;
	//log options tab
	private JPanel logPanel;
	private JList<String> systemLogLevelJList;
	private JList<String> assemblerLogLevelJList;
	private JList<String> runtimeLogLevelJList;
	private JCheckBox showStackTraceJCheckBox;
	private JCheckBox showCallerMethodNameJCheckBox;
	private JCheckBox showCallerClassNameJCheckBox;
	// End of variables declaration//GEN-END:variables

}

class ListCellTitledBorder implements Border {

	private final JList<?> list;
	private final String title;

	ListCellTitledBorder(JList<?> list, String title) {
		this.list = list;
		this.title = title;
	}

	@Override
	public boolean isBorderOpaque() {
		return true;
	}

	@Override
	public Insets getBorderInsets(Component c) {
		int height = c.getFontMetrics(list.getFont()).getHeight();
		return new Insets(height, 0, 0, 0);
	}

	@Override
	public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
		FontMetrics fm = c.getFontMetrics(list.getFont());
		int titleWidth = fm.stringWidth(title);
		int titleHeight = fm.getHeight();

// fill background
		g.setColor(list.getBackground());
		g.fillRect(x, y, width, titleHeight);

		int gap = UIScale.scale(4);

		Graphics2D g2 = (Graphics2D) g.create();
		try {
			FlatUIUtils.setRenderingHints(g2);

			g2.setColor(UIManager.getColor("Label.disabledForeground"));

			// paint separator lines
			int sepWidth = (width - titleWidth) / 2 - gap - gap;
			if (sepWidth > 0) {
				int sy = y + Math.round(titleHeight / 2f);
				float sepHeight = UIScale.scale((float) 1);

				g2.fill(new Rectangle2D.Float(x + gap, sy, sepWidth, sepHeight));
				g2.fill(new Rectangle2D.Float(x + width - gap - sepWidth, sy, sepWidth, sepHeight));
			}

			// draw title
			int xt = x + ((width - titleWidth) / 2);
			int yt = y + fm.getAscent();

			FlatUIUtils.drawString(list, g2, title, xt, yt);
		} finally {
			g2.dispose();
		}
	}
}
