package ComplexJavaProgram.MIPS;

public class UnloadInternalSystemCallException extends RuntimeException{

}
