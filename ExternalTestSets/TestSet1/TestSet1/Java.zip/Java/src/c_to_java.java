import java.io.*;
import java.util.*;

class Student {
    String name;
    float[] grades;
    int gradeCount;
    float average;

    public Student(int maxGrades) {
        grades = new float[maxGrades];
        gradeCount = 0;
    }

    public void calculateAverage() {
        float sum = 0;
        for (int i = 0; i < gradeCount; i++) {
            sum += grades[i];
        }
        average = gradeCount > 0 ? sum / gradeCount : 0;
    }
}

public class StudentManager {
    static final int INITIAL_CAPACITY = 3;
    static final int MAX_GRADES = 5;

    static ArrayList<Student> students = new ArrayList<>();

    static Scanner scanner = new Scanner(System.in);

    public static void addStudent() {
        Student s = new Student(MAX_GRADES);

        System.out.print("Enter name: ");
        s.name = scanner.nextLine();

        System.out.print("Enter number of grades (max " + MAX_GRADES + "): ");
        s.gradeCount = scanner.nextInt();

        for (int i = 0; i < s.gradeCount; i++) {
            System.out.print("Grade " + (i + 1) + ": ");
            s.grades[i] = scanner.nextFloat();
        }
        scanner.nextLine(); // consume newline

        s.calculateAverage();
        students.add(s);
    }

    public static void printStudents() {
        for (Student s : students) {
            System.out.printf("%s | Avg: %.2f\n", s.name, s.average);
        }
    }

    public static void sortStudents() {
        students.sort((s1, s2) -> Float.compare(s2.average, s1.average));
        System.out.println("Sorted!");
    }

    public static void saveToFile() {
        try (PrintWriter pw = new PrintWriter(new FileWriter("students.txt"))) {
            for (Student s : students) {
                pw.print(s.name + " " + s.gradeCount + " ");
                for (int i = 0; i < s.gradeCount; i++) {
                    pw.print(s.grades[i] + " ");
                }
                pw.println();
            }
            System.out.println("Saved to students.txt");
        } catch (IOException e) {
            System.out.println("Error writing file!");
        }
    }

    public static void loadFromFile() {
        File file = new File("students.txt");
        if (!file.exists()) {
            System.out.println("No existing file found.");
            return;
        }

        try (Scanner fileScanner = new Scanner(file)) {
            students.clear();

            while (fileScanner.hasNext()) {
                Student s = new Student(MAX_GRADES);

                s.name = fileScanner.next();
                s.gradeCount = fileScanner.nextInt();

                for (int i = 0; i < s.gradeCount; i++) {
                    s.grades[i] = fileScanner.nextFloat();
                }

                s.calculateAverage();
                students.add(s);
            }

            System.out.println("Loaded " + students.size() + " students.");
        } catch (Exception e) {
            System.out.println("Error reading file!");
        }
    }

    public static void classStats() {
        if (students.isEmpty()) return;

        float max = students.get(0).average;
        float min = students.get(0).average;
        float sum = 0;

        for (Student s : students) {
            if (s.average > max) max = s.average;
            if (s.average < min) min = s.average;
            sum += s.average;
        }

        System.out.printf("Class Average: %.2f\n", sum / students.size());
        System.out.printf("Highest Avg: %.2f\n", max);
        System.out.printf("Lowest Avg: %.2f\n", min);
    }

    public static void main(String[] args) {
        loadFromFile();

        int choice;

        do {
            System.out.println("\n1. Add Student\n2. Show Students\n3. Sort by Avg\n4. Stats\n5. Save\n0. Exit");
            System.out.print("Choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    addStudent();
                    break;
                case 2:
                    printStudents();
                    break;
                case 3:
                    sortStudents();
                    break;
                case 4:
                    classStats();
                    break;
                case 5:
                    saveToFile();
                    break;
            }

        } while (choice != 0);
    }
}
