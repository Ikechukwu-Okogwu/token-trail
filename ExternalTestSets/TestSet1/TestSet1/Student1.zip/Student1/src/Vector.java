package ClassOfAssignments.Student1;

public interface Vector {
    Vector append(double[] doubleArray);
    Vector append(int[] intArray);
    Vector append(Vector V);
    Vector append(double aDouble);
    Vector clone();
    boolean equal(Vector V);
    int getLength();
    double getValue(int i);
    Vector add(Vector V);
    Vector add(double aDouble);
    Vector sub(Vector V);
    Vector subV(int l, int r);
    Vector mult(Vector V);
    Vector mult(double aDouble);
    Vector normalize();
    double euclidianDistance(Vector V);
}

