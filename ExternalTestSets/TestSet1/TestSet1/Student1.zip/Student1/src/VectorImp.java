package ClassOfAssignments.Student1;

import java.util.Arrays;

public class VectorImp implements Vector{
    private double[] data;
    //Constructors
    public VectorImp() {
        this.data = new double[0];
    }
    public VectorImp(int size, double D) {
        this.data = new double[size];
        for(int i = 0; i < size; i++){
            this.data[i] = D;
        }
    }
    public VectorImp(double[] D) {
        data = D;
    }
    public VectorImp(int[] I) {
        this.data = new double[I.length];
        for (int i = 0; i < I.length; i++) {
            this.data[i] = I[i];
        }
    }
    // Methods
    @Override
    public Vector append(double[] doubleArray) {
        double[] vec = new double[doubleArray.length + data.length];
        //build original half
        for (int i = 0; i < data.length; i++) {
            vec[i] = data[i];
        }
        //build appended half
        for(int j = 0; j < doubleArray.length; j++){
            vec[j+data.length] = doubleArray[j];
        }
        return new VectorImp(vec);
    }


    @Override
    public Vector append(int[] intArray) {
        double[] vec = new double[intArray.length + data.length];
        //original half
        for (int i = 0; i < data.length; i++) {
            vec[i] = data[i];
        }
        // appended half
        for(int j = 0; j < intArray.length; j++){
            vec[j+data.length] = intArray[j];
        }
        return new VectorImp(vec);
    }


    @Override
    public Vector append(Vector V) {
        double[] vec = new double[V.getLength() + data.length];
        for (int i = 0; i < data.length; i++) {
            vec[i] = data[i];
        }
        for(int j = 0; j < V.getLength(); j++){
            vec[j+data.length] = V.getValue(j);
        }
        return new VectorImp(vec);
    }
    @Override
    public Vector append(double aDouble) {
        return append(new double[]{aDouble});
    }

    @Override
    public Vector clone() {
        return new VectorImp(this.data);
    }

    @Override
    public boolean equal(Vector V) {
        if (this.getLength() != V.getLength()) return false;
        for (int i = 0; i < data.length; i++) {
            if (data[i] != V.getValue(i)) {
                return false;
            }
        }
        return true;
    }

    @Override
    public int getLength() {
        return data.length;
    }

    @Override
    public double getValue(int i) {
        if(i>data.length){
            return 0;
        }
        return data[i];
    }

    @Override
    public Vector add(Vector V) {
        double[] result = new double[data.length];
        for (int i = 0; i < data.length; i++) {
            result[i] = data[i] + V.getValue(i);

        }
        return new VectorImp(result);
    }

    @Override
    public Vector add(double aDouble) {
        double[] newVec = new double[data.length];
        for(int i = 0; i < data.length; i++){
            newVec[i] = data[i] + aDouble;
        }
        return new VectorImp(newVec);
    }


    @Override
    public Vector sub(Vector V) {

        double[] result = new double[data.length];
        for (int i = 0; i < data.length; i++){
            result[i] = this.data[i] - V.getValue(i);
        }
        return new VectorImp(result);
    }

    @Override
    public Vector subV(int l, int r) {
        double[] result = Arrays.copyOfRange(data, l, r + 1);
        return new VectorImp(result);
    }

    @Override
    public Vector mult(Vector V) {
        if (this.getLength() != V.getLength()) return this;
        double[] result = new double[data.length];
        for (int i = 0; i < data.length; i++){
            result[i] = this.data[i] * V.getValue(i);
        }
        return new VectorImp(result);
    }

    @Override
    public Vector mult(double aDouble) {

        double[] result = new double[data.length];
        for (int i = 0; i < data.length; i++){
            result[i] = this.data[i] * aDouble;
        }
        return new VectorImp(result);
    }

    @Override
    public Vector normalize() {
        double totalNum = 0;
        double[] result = new double[data.length];
        for(int i = 0; i < data.length; i++){
            totalNum += (data[i]*data[i]);
        }
        double rooted = Math.sqrt(totalNum);
        for(int j = 0; j < data.length; j++){
            result[j] = data[j]/rooted;
        }
        return new VectorImp(result);
    }

    @Override
    public double euclidianDistance(Vector V) {
        double sum = 0;
        for (int i = 0; i < data.length; i++) {
            double diff = this.data[i] - V.getValue(i);
            sum += diff * diff;
        }
        return Math.sqrt(sum);
    }
}
