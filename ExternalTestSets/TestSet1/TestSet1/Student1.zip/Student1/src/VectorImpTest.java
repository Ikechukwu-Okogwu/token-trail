package ClassOfAssignments.Student1;

import static org.junit.jupiter.api.Assertions.*;

class VectorImpTest {

    @org.junit.jupiter.api.Test
    void testAppendDoubleArr() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] testSet2 = {0.1, 0.2, 0.3};
        double[] key = {0.1, 0.2, 0.3, 0.4, 0.5, 0.1, 0.2, 0.3};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(key);
        assertEquals(true, p2.equal(p1.append(testSet2)));
    }

    @org.junit.jupiter.api.Test
    void testAppendInteger() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        int[] testSet2 = {1, 2, 3};
        double[] key = {0.1, 0.2, 0.3, 0.4, 0.5, 1, 2, 3};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(key);
        assertEquals(true, p2.equal(p1.append(testSet2)));
    }

    @org.junit.jupiter.api.Test
    void testAppendVector() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] testSet2 = {1, 2, 3};
        double[] key = {0.1, 0.2, 0.3, 0.4, 0.5, 1, 2, 3};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet2);
        var pt = new VectorImp(key);
        assertEquals(true, pt.equal(p1.append(p2)));
    }

    @org.junit.jupiter.api.Test
    void testClone() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        var p1 = new VectorImp(testSet);
        assertEquals(true, p1.equal(p1.clone()));
    }
    @org.junit.jupiter.api.Test
    void testNullClone() {
        double[] testSet = {};
        var p1 = new VectorImp(testSet);
        assertEquals(true, p1.equal(p1.clone()));
    }
    //.equal
    @org.junit.jupiter.api.Test
    void equalOnVoid() {
        double[] testSet = new double[3];
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet);
        assertEquals(true, p1.equal(p2));
    }
    @org.junit.jupiter.api.Test
    void equalDifferentSizes() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] testSet2 = {0.1, 0.2, 0.3};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet2);
        assertEquals(false, p1.equal(p2));
    }
    @org.junit.jupiter.api.Test
    void equalShouldReturnTrue() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet);
        assertEquals(true, p1.equal(p2));
    }
    @org.junit.jupiter.api.Test
    void equalShouldReturnFalse() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] testSet2 = {0.1, 0.2, 0.3, 0.2, 0.5};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet2);
        assertEquals(false, p1.equal(p2));
    }

    @org.junit.jupiter.api.Test
    void getLengthGreater0() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        var p1 = new VectorImp(testSet);
        assertEquals(5, p1.getLength());
    }
    @org.junit.jupiter.api.Test
    void getLength0() {
        double[] testSet = {};
        var p1 = new VectorImp(testSet);
        assertEquals(0, p1.getLength());
    }

    @org.junit.jupiter.api.Test
    void getValueValid() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        var p1 = new VectorImp(testSet);
        assertEquals(0.1, p1.getValue(0));
    }
    @org.junit.jupiter.api.Test
    void getValueInValid() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        var p1 = new VectorImp(testSet);
        assertEquals(0, p1.getValue(6));
    }

    @org.junit.jupiter.api.Test
    void addTest() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] testSet2 = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] key = {0.2, 0.4, 0.6, 0.8, 1};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet2);
        var keyp = new VectorImp(key);
        assertEquals(true, keyp.equal(p1.add(p2)));
    }

    @org.junit.jupiter.api.Test
    void addTestDouble() {
        double[] testSet = {1, 2, 3, 4, 5};
        double[] key = {3, 4, 5, 6, 7};
        var p1 = new VectorImp(testSet);
        double mutator = 2;
        var keyp = new VectorImp(key);


        assertEquals(true, keyp.equal(p1.add(mutator)));
    }

    @org.junit.jupiter.api.Test
    void subTest() {
        double[] testSet = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] testSet2 = {0.1, 0.2, 0.3, 0.4, 0.5};
        double[] key = {0, 0, 0, 0, 0};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet2);
        var keyp = new VectorImp(key);
        assertEquals(true, keyp.equal(p1.sub(p2)));
    }

    @org.junit.jupiter.api.Test
    void subTestDouble() {
        double[] testSet = {1, 2, 3, 4, 5};
        double[] key = {2, 3, 4};
        var p1 = new VectorImp(testSet);
        var keyp = new VectorImp(key);
        assertEquals(true, keyp.equal(p1.subV(1, 3)));
    }

    @org.junit.jupiter.api.Test
    void multTest() {
        double[] testSet = {1, 2, 3, 4, 5};
        double[] testSet2 = {1, 2, 3, 4, 5};
        double[] key = {1, 4, 9, 16, 25};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet2);
        var keyp = new VectorImp(key);
        assertEquals(true, keyp.equal(p1.mult(p2)));
    }
    @org.junit.jupiter.api.Test
    void multTestDifferentSizes() {
        double[] testSet = {1, 2, 3, 4, 5};
        double[] testSet2 = {1, 2, 3};
        double[] key = {1, 2, 3, 4, 5};
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet2);
        var keyp = new VectorImp(key);
        assertEquals(true, keyp.equal(p1.mult(p2)));
    }

    @org.junit.jupiter.api.Test
    void testMultDouble() {
        double[] testSet = {1, 2, 3, 4, 5};
        double[] testSet2 = {1, 2, 3, 4, 5};
        double[] key = {2, 4, 6, 8, 10};
        var p1 = new VectorImp(testSet);

        var keyp = new VectorImp(key);
        assertEquals(true, keyp.equal(p1.mult(2)));
    }

    @org.junit.jupiter.api.Test
    void normalizeTestResult() {
        double[] testSet = {3,4};
        double[] key = new double[2];
        key[0] = (double) 3 /5;
        key[1] = (double) 4 /5;
        var p1 = new VectorImp(testSet);
        var keyp = new VectorImp(key);
        assertEquals(true, keyp.equal(p1.normalize()));
    }

    @org.junit.jupiter.api.Test
    void euclidianDistanceTestResult() {
        double[] testSet = {2,2};
        double[] testSet2 = {1,2};
        double key = 1;
        var p1 = new VectorImp(testSet);
        var p2 = new VectorImp(testSet2);
        assertEquals(key, p1.euclidianDistance(p2));
    }
}