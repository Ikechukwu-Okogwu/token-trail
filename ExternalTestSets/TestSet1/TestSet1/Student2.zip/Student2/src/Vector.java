package ClassOfAssignments.Student2;

public interface Vector {
    Vector append(double[] doubleArray);
    Vector append(int[] intArray);
    Vector append(Vector V);
    Vector append(double aDouble);
    Vector clone() ;	// returns a clone of this
    Boolean equal(Vector V); //this and V are the same
    int getLength() ;		//returns number of elements in this
    Double getValue(int i)  ;//returns the value  this[i]
    Vector add(Vector V)  ;   //add this to V, returning a Vector the same size as this
    Vector add(double aDouble); //add aDouble to every element of this
    Vector sub(Vector V); //sub this – V
    Vector subV(int l, int r);  //will return a sub vector between the
    //indices l and r inclusive
    Vector Mult(Vector V); //Multiple every element of this by corresponding element in V
    Vector Mult(double aDouble);  //Multiply every element of this by aDouble
    Vector Normalize() ;  //returns this as a normalized vector
    Double EuclidianDistance(Vector V); //returns the Euclidian distance between this and V.

}
