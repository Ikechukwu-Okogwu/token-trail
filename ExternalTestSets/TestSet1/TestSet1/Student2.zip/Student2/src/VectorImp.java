package ClassOfAssignments.Student2;

public class VectorImp implements Vector {
    private int size;
    private double[] arr;
    public VectorImp() { //empty
        this.size = 0;
        this.arr = new double[0];
    }
    public VectorImp(int size, double D) { //creates a vector of size – size with elements initialized to D
        if(size <= 0){
            throw new IllegalArgumentException("size must be greater than 0");
        }
        this.size = size;
        this.arr = new double[size];
        for(int i = 0; i < size; i++){
            this.arr[i] = D;
        }
    }
    public VectorImp(double[] D) {    //creates a vector initialized to array D
        this.size = D.length;
        this.arr = D.clone();
    }
    public VectorImp(int[] I) {   //creates a vector initialized to array I
        this.size = I.length;
        this.arr = new double[this.size];
        for(int i = 0; i < this.size; i++){
            this.arr[i] = I[i];
        }
    }

    public Vector append(double[] doubleArray){
        double[] newArr = new double[this.size + doubleArray.length];
        for(int i = 0; i < this.size; i++){
            newArr[i] = this.arr[i];
        }
        for(int i = this.size; i < doubleArray.length+this.size; i++){
            newArr[i] = doubleArray[i-this.size];
        }
        return new VectorImp(newArr);
    }
    public Vector append(int[] intArray){
        double[] newArr = new double[this.size + intArray.length];
        for(int i = 0; i < this.size; i++){
            newArr[i] = this.arr[i];
        }
        for(int i = this.size; i < intArray.length+this.size; i++){
            newArr[i] = intArray[i-this.size];
        }
        return new VectorImp(newArr);
    }
    public Vector append(Vector V){
        double[] newArr = new double[this.size + V.getLength()];
        for(int i = 0; i < this.size; i++){
            newArr[i] = this.arr[i];
        }
        for(int i = 0; i < V.getLength(); i++){
            newArr[i+(this.size)] = V.getValue(i);
        }
        return new VectorImp(newArr);
    }
    public Vector append(double aDouble){
        double[] newArr = new double[this.size + 1];
        for(int i = 0; i < this.size; i++){
            newArr[i] = this.arr[i];
        }
        newArr[this.size] = aDouble;
        return new VectorImp(newArr);
    }
    public Vector clone() { // returns a clone of this
        return new VectorImp(this.arr.clone());
    }
    public Boolean equal(Vector V){ //this and V are the same
        if(V == null){
            throw new NullPointerException("V cannot be null");
        }
        Boolean e = true;
        if(V.getLength() != this.size){
            e = false;
        }  else {
            for(int i = 0; i < this.size; i++){
                if(V.getValue(i) != this.arr[i]){
                    e = false;
                    break;
                }
            }
        }
        return e;
    }
    public int getLength() { //returns number of elements in this
        return this.size;
    }
    public Double getValue(int i)  { //returns the value  this[i]
        if(i >= this.size){
            throw new IllegalArgumentException("i must be less than size.");
        }
        return this.arr[i];
    }
    public Vector add(Vector V)  { //add this to V, returning a Vector the same size as this
        if(V == null){
            throw new NullPointerException("V cannot be null");
        }
        if(V.getLength() != this.size){
            throw new IllegalArgumentException("Vectors must be the same length");
        }
        double[] newArr = new double[this.size];
        for(int i = 0; i < this.size;i++){
            newArr[i] = this.arr[i] + V.getValue(i);
        }
        return new VectorImp(newArr);
    }
    public Vector add(double aDouble){ //add aDouble to every element of this
        double[] newArr = this.arr.clone();
        for(int i = 0; i < size; i++){
            newArr[i] += aDouble;
        }
        return new VectorImp(newArr);
    }
    public Vector sub(Vector V){ //sub this – V
        if(V == null){
            throw new NullPointerException("V cannot be null");
        }
        if(V.getLength() != this.size){
            throw new IllegalArgumentException("Vectors must be the same length");
        }
        double[] newArr = this.arr.clone();
        for(int i = 0; i < this.size; i++){
            newArr[i] -= V.getValue(i);
        }
        return new VectorImp(newArr);
    }
    public Vector subV(int l, int r){ //will return a sub vector between the indices l and r inclusive
        if (l < 0 || r >= this.size || l > r)
            throw new IndexOutOfBoundsException("Invalid sub vector indices");
        double[] newArr = new double[r - l + 1];
        for(int i = l; i <= r; i++){
            newArr[i-l] = this.arr[i];
        }
        return new VectorImp(newArr);
    }
    public Vector Mult(Vector V){ //Multiple every element of this by corresponding element in V
        if(V.getLength() != this.size){
            throw new IllegalArgumentException("Vectors must be the same length");
        }
        double[] newArr = this.arr.clone();
        for(int i = 0; i < this.size; i++){
            newArr[i] *= V.getValue(i);
        }
        return new VectorImp(newArr);
    }

    public Vector Mult(double aDouble){ //Multiply every element of this by aDouble
        double[] newArr = this.arr.clone();
        for(int i = 0; i < size; i++){
            newArr[i] *= aDouble;
        }
        return new VectorImp(newArr);
    }
    public Vector Normalize() { // returns this as a normalized vector
        double magnitude = 0.0;
        for (double v : this.arr) {
            magnitude += v * v;
        }
        magnitude = Math.sqrt(magnitude);
        double[] newArr = this.arr.clone();
        if (magnitude != 0){
            for (int i = 0; i < this.size; i++) {
                newArr[i] /= magnitude;
            }
        }
        return new VectorImp(newArr);
    }
    public Double EuclidianDistance(Vector V)  { //returns the Euclidean distance between this and V.
        if(V == null){throw new NullPointerException("V cannot be null");}
        if(this.size != V.getLength()){
            throw new IllegalArgumentException("Vectors must be the same length.");
        }
        double total = 0;
        for(int i = 0; i < this.size; i++){
            total += Math.pow(this.arr[i] - V.getValue(i), 2);
        }
        return Math.sqrt(total);
    }

}
