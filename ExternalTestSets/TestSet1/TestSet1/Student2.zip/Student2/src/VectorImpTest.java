package ClassOfAssignments.Student2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VectorImpTest {

    /** Tests For Constructor VectorImp() */

    @Test
    void defaultConstructorIsEmpty(){
        Vector test = new VectorImp();
        assertEquals(0, test.getLength());
        assertThrows(IllegalArgumentException.class, () ->  test.getValue(0));
    }


    /** Tests For Constructor VectorImp(int I, double D) */

    @Test
    void constructorIDHasAMinSizeOfOne(){
        assertThrows(IllegalArgumentException.class, () -> new VectorImp(0, 3.0));
        assertThrows(IllegalArgumentException.class, () -> new VectorImp(-1, 3.0));
    }

    @Test
    void constructorIDHasTheCorrectSize(){
        Vector test = new VectorImp(1, 1.0);
        assertEquals(1.0, test.getValue(0));
        assertThrows(IllegalArgumentException.class, () -> test.getValue(2));
    }

    @Test
    void constructorIDTracksTheCorrectSize(){
        Vector test = new VectorImp(1, 1.0);
        assertEquals(1, test.getLength());
    }

    @Test
    void constructorIDHasCorrectElements(){
        Vector test = new VectorImp(3, 1.0);
        assertEquals(1.0, test.getValue(0));
        assertEquals(1.0, test.getValue(1));
        assertEquals(1.0, test.getValue(2));
    }


    /** Tests For Constructor VectorImp(double[] D) */

    @Test
    void constructorDArrIsProducesCorrectSize(){
        double[] D = new double[3];
        Vector test = new VectorImp(D);
        assertEquals(3,test.getLength());
    }

    @Test
    void constructorDArrProducesTheCorrectElements(){
        double[] D = {0.0, 1.1,2.2};
        Vector test = new VectorImp(D);
        assertEquals(0.0, test.getValue(0));
        assertEquals(1.1, test.getValue(1));
        assertEquals(2.2, test.getValue(2));
    }

    @Test
    void constructorDArrDoesNotRefGivenArr(){
        double[] D = {1, 2};
        Vector v = new VectorImp(D);

        D[0] = 99;

        assertEquals(1, v.getValue(0));
    }

    /** Test For Constructor VectorImp(int[] I) */

    @Test
    void constructorIArrTracksTheCorrectSize(){
        double[] D = new double[3];
        Vector test = new VectorImp(D);
        assertEquals(3,test.getLength());
    }

    @Test
    void constructorIArrProducesTheCorrectElements(){
        int[] D = {0, 1,2};
        Vector test = new VectorImp(D);

        assertEquals(0.0, test.getValue(0));
        assertEquals(1.0, test.getValue(1));
        assertEquals(2.0, test.getValue(2));
    }

    @Test
    void constructorIArrDoesNotRefGivenArr(){
        int[] I = {1,3,4};
        Vector V = new VectorImp(I);
        I[1] = 100;
        assertEquals(3, V.getValue(1));
    }

    /** Tests For .append(double[] D) */

    @Test
    void appendDArrProducesVOfCorrectSize(){
        double[] D = new double[1];
        Vector v = new VectorImp(1, 0.0);
        v = v.append(D);
        assertEquals(2, v.getLength());
    }

    @Test
    void appendDArrProducesArrOfCorrectElements(){
        double[] D = new double[]{2.3,34.0,-52.6};
        Vector v = new VectorImp(1, 1.0);
        v = v.append(D);
        assertEquals(1.0, v.getValue(0));
        assertEquals(2.3, v.getValue(1));
        assertEquals(34.0, v.getValue(2));
        assertEquals(-52.6, v.getValue(3));
    }

    @Test
    void appendDArrDoesNotModifyOriginal(){
        double[] D = new double[]{2.3,34.0,-52.6};
        Vector v = new VectorImp(1, 1.0);
        v.append(D);
        assertEquals(1, v.getLength());
    }


    /** Tests For .append(int[] I) */

    @Test
    void appendIArrProducesArrOfCorrectSize(){
        int[] I = new int[1];
        Vector v = new VectorImp(1, 0.0);
        v = v.append(I);
        assertEquals(2, v.getLength());
    }

    @Test
    void appendIArrProducesArrOfCorrectElements(){
        int[] I = new int[]{2,3,-6};
        Vector v = new VectorImp(1, 1.0);
        v = v.append(I);
        assertEquals(1.0, v.getValue(0));
        assertEquals(2, v.getValue(1));
        assertEquals(3, v.getValue(2));
        assertEquals(-6, v.getValue(3));
    }

    @Test
    void appendIArrDoesNotModifyOriginal(){
        int[] I = new int[]{2,3,-6};
        Vector v = new VectorImp(1, 1.0);
        v.append(I);
        assertEquals(1, v.getLength());
    }


    /** Tests For .append(Vector V) */

    @Test
    void appendVProducesArrOfCorrectSize(){
        Vector v1 = new VectorImp(1, 0.0);
        Vector v2 = new VectorImp(1, 0.0);
        Vector v = v1.append(v2);
        assertEquals(v1.getLength()+v2.getLength(), v.getLength());
    }

    @Test
    void appendVProducesArrOfCorrectElements(){
        Vector v1 = new VectorImp(1, 1.0);
        Vector v2 = new VectorImp(1, 0.0);
        Vector v = v1.append(v2);
        assertEquals(1.0, v.getValue(0));
        assertEquals(0.0, v.getValue(1));
    }

    @Test
    void appendVDoesNotModifyOriginal(){
        Vector v = new VectorImp(1, 1.0);
        v.append(new VectorImp(1, 0.0));
        assertEquals(1, v.getLength());
    }


    /** Tests For .append(double D) */

    @Test
    void appendDToEmptyVProducesVContainingD(){
        Vector v = new VectorImp();
        v = v.append(3.0);
        assertTrue(new VectorImp(1,3.0).equal(v));
    }

    @Test
    void appendDToNonEmptyVIsElementsInVAndD(){
        Vector v = new VectorImp(1,1.0);
        v = v.append(3.0);
        assertEquals(1.0,v.getValue(0));
        assertEquals(3.0,v.getValue(1));
    }

    @Test
    void appendDDoesNotModifyOriginal(){
        Vector v = new VectorImp(1, 1.0);
        v.append(3.0);
        assertEquals(1, v.getLength());
    }

    /** Tests For .clone() */

    @Test
    void cloneHasTheSameElementsAsOriginal(){
        Vector v = new VectorImp(1,0.0);
        Vector clone = v.clone();
        assertTrue(v.equal(clone));
    }

    @Test
    void modifyingCloneDoesNotModifyOriginal(){
        Vector v = new VectorImp(1,0.0);
        v.clone().append(3.0);
        assertEquals(1, v.getLength());

    }

    /** Tests For .equal(Vector V) */

    @Test
    void equalThrowsExceptionGivenWhenNull(){
        Vector v = new VectorImp(1,1);
        assertThrows(NullPointerException.class, () -> v.equal(null));
    }

    @Test
    void notEqualWhenVsAreDifferentLengths(){
        Vector v1 = new VectorImp(1,1);
        Vector v2 = new VectorImp(2,2);
        assertFalse(v1.equal(v2));
    }

    @Test
    void twoVWithTheSameEAreEqual(){
        double[] D = {1.0,2.0,3.0};
        Vector v1 = new VectorImp(D);
        Vector v2 = new VectorImp(D);
        assertTrue(v1.equal(v2));
    }

    @Test
    void twoVWithDifferentEAreNotEqual(){
        double[] D1 = {2.0,3.0,1.0};
        double[] D2 = {2.0,3.0,2.0};
        Vector v1 = new VectorImp(D1);
        Vector v2 = new VectorImp(D2);
        assertFalse(v1.equal(v2));
    }


    /** Tests For .getLength() */

    @Test
    void VWithGEHasLengthG(){
        Vector v = new VectorImp(5, 1.0);
        assertEquals(5, v.getLength());
    }


    /** Tests For .add(Vector V) */

    @Test
    void addVThrowsExceptionWhenNull(){
        Vector v = new VectorImp();
        assertThrows(NullPointerException.class, () -> v.add(null));
    }

    @Test
    void addVThrowsExceptionWhenDifferentSizes(){
        assertThrows(IllegalArgumentException.class, () -> new VectorImp().add(new VectorImp(1, 1.0)));
    }

    @Test
    void addVThreePlusTwoIsFive(){
        Vector v1 = new VectorImp(3,3.0);
        Vector v2 = new VectorImp(3,2.0);
        Vector v3 = new VectorImp(3,5.0);
        v1 = v1.add(v2);
        assertTrue(v1.equal(v3));
    }
    @Test
    void addVThreePlusNegTwoIsOne(){
        Vector v1 = new VectorImp(3,3.0);
        Vector v2 = new VectorImp(3,-2.0);
        Vector v3 = new VectorImp(3,1.0);
        v1 = v1.add(v2);
        assertTrue(v1.equal(v3));
    }

    @Test
    void addVDoesNotModifyOriginal(){
        Vector v = new VectorImp(1,1.0);
        v.add(new VectorImp(1, 2.0));
        assertEquals(1, v.getValue(0));
    }


    /** Tests For .add(double D) */

    @Test
    void addDThreePlusTwoIsFive(){
        Vector v1 = new VectorImp(3,3.0);
        Vector v3 = new VectorImp(3,5.0);
        v1 = v1.add(2.0);
        assertTrue(v1.equal(v3));
    }

    @Test
    void addDThreePlusNegTwoIsOne(){
        Vector v1 = new VectorImp(3,3.0);
        Vector v3 = new VectorImp(3,1.0);
        v1 = v1.add(-2.0);
        assertTrue(v1.equal(v3));
    }
    @Test
    void addDDoesNotModifyOriginal(){
        Vector v = new VectorImp(1,1.0);
        v.add(3.0);
        assertEquals(1, v.getValue(0));
    }


    /** Tests For .sub(Vector V) */

    @Test
    void subVThrowsExceptionWhenNull(){
        Vector v = new VectorImp();
        assertThrows(NullPointerException.class, () -> v.sub(null));
    }

    @Test
    void subVThrowsExceptionWhenSizesAreDifferent(){
        Vector v1 = new VectorImp();
        Vector v2 = new VectorImp(1,1);
        assertThrows(IllegalArgumentException.class, () -> v1.sub(v2));
    }

    @Test
    void subVThreeMinusTwoIsOne(){
        Vector v1 = new VectorImp(3,3.0);
        Vector v2 = new VectorImp(3,2.0);
        Vector v3 = new VectorImp(3,1.0);
        v1 = v1.sub(v2);
        assertTrue(v1.equal(v3));
    }

    @Test
    void subVThreeSubNegTwoIsFive(){
        Vector v1 = new VectorImp(3,3.0);
        Vector v2 = new VectorImp(3,-2.0);
        Vector v3 = new VectorImp(3,5.0);
        v1 = v1.sub(v2);
        assertTrue(v1.equal(v3));
    }

    @Test
    void subVDoesNotModifyOriginal(){
        Vector v = new VectorImp(1,1.0);
        v.sub(new VectorImp(1, 2.0));
        assertEquals(1, v.getValue(0));
    }


    /** Tests For .subV(int l, int r) */

    @Test
    void subVThrowsExceptionWhenLIsGreaterThanR(){
        Vector v = new VectorImp();
        assertThrows(IndexOutOfBoundsException.class, () -> v.subV(2,1));
    }

    @Test
    void subVThrowsExceptionWhenLIsLessThanZero(){
        Vector v = new VectorImp();
        assertThrows(IndexOutOfBoundsException.class, () -> v.subV(-1,1));
    }

    @Test
    void subVThrowsExceptionWhenRIsGreaterThanSize(){
        Vector v = new VectorImp();
        assertThrows(IndexOutOfBoundsException.class, () -> v.subV(0,1));
    }

    @Test
    void subVThrowsExceptionWhenRIsEqualToSize(){
        Vector v = new VectorImp(1,1.0);
        assertThrows(IndexOutOfBoundsException.class, () -> v.subV(0,1));
    }

    @Test
    void subVProvidesVOfLengthOneWhenLEqualsR(){
        Vector v = new VectorImp(new double[]{1.0,2.0,3.0,4.0,5.0});
        assertEquals(1,v.subV(1,1).getLength());
        assertEquals(2.0,v.subV(1,1).getValue(0));
    }

    @Test
    void subVSelectsCorrectValues(){
        double[] D = {1.0,2.0,3.0,4.0,5.0};
        Vector v = new VectorImp(D);
        v = v.subV(1,3);
        assertEquals(2.0,v.getValue(0));
        assertEquals(3.0,v.getValue(1));
        assertEquals(4.0,v.getValue(2));
    }


    /** Tests For .Mult(Vector) */

    @Test
    void multiplyVByNullVThrowsException(){
        Vector v = new VectorImp();
        assertThrows(NullPointerException.class, () -> v.Mult(null));
    }

    @Test
    void multiplyVThrowsExceptionWhenGivenVOfDifferentSizes(){
        Vector v1 = new VectorImp(1, 0.0);
        Vector v2 = new VectorImp(2, 0.0);
        assertThrows(IllegalArgumentException.class, () -> v1.Mult(v2));
    }

    @Test
    void multiplyVThreeByVFiveIsFifteen(){
        Vector v1 = new VectorImp(1, 3.0);
        Vector v2 = new VectorImp(1, 5.0);
        Vector v3 = new VectorImp(1, 15.0);
        assertTrue(v3.equal(v1.Mult(v2)));
    }

    @Test
    void multiplyVectorDoesNotModifyOriginal(){
        Vector v = new VectorImp(1,1.0);
        v.Mult(new VectorImp(1, 3.0));
        assertEquals(1.0, v.getValue(0));
    }


    /** Tests For .Mult(double D) */

    @Test
    void multiplyVThreeByFiveIsFifteen(){
        Vector v = new VectorImp(1, 3.0);
        v = v.Mult(5.0);
        assertEquals(15.0,v.getValue(0));
    }

    @Test
    void multiplyDDoesNotModifyOriginal(){
        Vector v = new VectorImp(1,1.0);
        v.Mult(3.0);
        assertEquals(1.0, v.getValue(0));
    }


    /** Tests For .Normalize() */

    @Test
    void testNormalizeBasic() {
        Vector v = new VectorImp(new double[]{3, 4});
        Vector normalized = v.Normalize();

        double magnitude = 0;
        for (int i = 0; i < normalized.getLength(); i++) {
            magnitude += Math.pow(normalized.getValue(i), 2);
        }
        magnitude = Math.sqrt(magnitude);

        assertEquals(1.0, magnitude);
    }

    @Test
    void normalizeZeroVector() {
        Vector v = new VectorImp(new double[]{0, 0, 0});
        Vector normalized = v.Normalize();

        assertTrue(v.equal(normalized));
    }

    @Test
    void normalizeNegativeValues() {
        Vector v = new VectorImp(new double[]{-2, -2});
        Vector normalized = v.Normalize();

        double expected = -1 / Math.sqrt(2);
        assertEquals(expected, normalized.getValue(0));
        assertEquals(expected, normalized.getValue(1));
    }

    @Test
    void normalizeDoesNotMutateOriginal() {
        Vector v = new VectorImp(new double[]{10, 0});
        Vector normalized = v.Normalize();

        assertEquals(10.0, v.getValue(0));
        assertEquals(0.0, v.getValue(1));

        assertEquals(1.0, normalized.getValue(0));
        assertEquals(0.0, normalized.getValue(1));
    }


    /** Tests For .EuclideanDistance() */

    @Test
    void edThrowsExceptionWhenGivenNullV(){
        Vector v = new VectorImp(1,1.0);
        assertThrows(NullPointerException.class, () -> v.EuclidianDistance(null));
    }

    @Test
    void edThrowsExceptionWhenGivenVOfDifferentSizes(){
        Vector v1 = new VectorImp(1,1.0);
        Vector v2 = new VectorImp(2,1.0);
        assertThrows(IllegalArgumentException.class, () -> v1.EuclidianDistance(v2));
    }

    @Test
    void edOfOneDimensionalEqualVectorsIsZero(){
        Vector v1 = new VectorImp(1, 3.0);
        Vector v2 = new VectorImp(1, 3.0);
        assertEquals(0, v1.EuclidianDistance(v2));
    }

    @Test
    void edOfTwoDimensionalEqualVectorsIsZero(){
        Vector v1 = new VectorImp(new double[]{3.0,3.0});
        Vector v2 = new VectorImp(new double[]{3.0,3.0});
        assertEquals(0, v1.EuclidianDistance(v2));
    }

}