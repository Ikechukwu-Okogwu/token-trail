package ClassOfAssignments.Student4;

public interface Vector {

    //methods
    Vector append(double[] doubleArray);
    Vector append(int[] intArray);
    Vector append(Vector V);
    Vector append(double aDouble);
    Vector clone();
    boolean equal(Vector V);
    int getLength();
    double getValue(int i);
    Vector add(Vector V);
    Vector add(double aDouble);
    Vector sub(Vector V);
    Vector subV(int l, int r);
    Vector Mult(Vector V);
    Vector Mult(double aDouble);
    Vector Normalize();
    Double EuclidianDistance(Vector V);

}