package ClassOfAssignments.Student4;

public class VectorImp implements Vector {

    private double[] vectorData;
    private int vectorSize;

    //constructors
    public VectorImp(){
        this.vectorData = new double[0];
        this.vectorSize = 0;
    }

    public VectorImp(int size, double D) {
        if (size < 0)
            throw new IllegalArgumentException();
        vectorData = new double[size];
        vectorSize = size;
        for (int i = 0; i < size; i++) {
            vectorData[i] = D;
        }
    }

    public VectorImp(double[] D){
        vectorData = D;
        vectorSize = D.length;
    }

    public VectorImp(int[] I){
        vectorSize = I.length;
        vectorData = new double[I.length];
        for(int i = 0; i < I.length; i++){
            vectorData[i]= I[i];
        }
    }

    //methods
    public VectorImp append(double[] doubleArray){
        try {
            double[] newVector = new double[vectorSize + doubleArray.length];
            System.arraycopy(vectorData, 0, newVector, 0, vectorSize);
            System.arraycopy(doubleArray, 0, newVector, vectorSize, doubleArray.length);
            return new VectorImp(newVector);
        } catch (OutOfMemoryError e) {
            System.err.println("Vector length would cause a memory error");
            return this;
        }
    }

    public VectorImp append(int[] intArray){
        try {
            double[] newVector = new double[vectorSize + intArray.length];
            System.arraycopy(vectorData, 0, newVector, 0, vectorSize);
            for (int i = vectorSize; i < newVector.length; i++) {
                newVector[i] = intArray[i - vectorSize];
            }
            return new VectorImp(newVector);
        } catch (OutOfMemoryError e) {
            System.err.println("Vector length would cause a memory error");
            return this;
        }
    }

    //no need for try catch block, since it calls an earlier append function that has one
    public VectorImp append(Vector V){
        VectorImp v = (VectorImp) V;
        return append(v.vectorData);
    }

    //no need for try catch block, since it calls an earlier append function that has one
    public VectorImp append(double aDouble){
        double[] singleVal = {aDouble};
        return append(singleVal);
    }

    public VectorImp clone(){
        return new VectorImp(this.vectorData);
    } 	// returns a clone of this

    public boolean equal(Vector V){
        VectorImp v = (VectorImp) V;

        if(v.vectorSize != this.vectorSize)
            return false;
        for(int i = 0; i < this.vectorSize; i++) {
            if (v.vectorData[i] != this.vectorData[i])
                return false;
        }
        return true;
    } //this and V are the same

    public int getLength(){
        return this.vectorSize;
    }	//returns number of elements in this

    public double getValue(int i){
        if (i < 0 || i >= this.vectorSize)
            throw new IllegalArgumentException();

        return this.vectorData[i];
    }  //returns the value  this[i]

    public VectorImp add(Vector V){
        VectorImp v = (VectorImp) V;

        if(v.vectorSize > this.vectorSize)
            throw new IllegalArgumentException();

        double[] sumVector = new double[this.vectorSize];
        for(int i = 0; i < this.vectorSize; i++){
            if(i < v.vectorSize) {
                sumVector[i] = v.vectorData[i] + this.vectorData[i];
                if (sumVector[i] > Double.MAX_VALUE) {
                    System.err.println("Adding this vector would exceed the maximum value, addition not performed");
                    throw new RuntimeException();
                }
            }
            else
                sumVector[i] = this.vectorData[i];
        }

        return new VectorImp(sumVector);
    }     //add this to V, returning a Vector the same size as this

    public VectorImp add(double aDouble){
        double[] sumVector = new double[this.vectorSize];
        for(int i = 0; i < this.vectorSize; i++){
            sumVector[i] = this.vectorData[i] + aDouble;
            if (sumVector[i] > Double.MAX_VALUE) {
                System.err.println("Adding this number would exceed the maximum value, addition not performed");
                throw new RuntimeException();
            }
        }

        return new VectorImp(sumVector);
    } //add aDouble to every element of this

    public VectorImp sub(Vector V){
        VectorImp v = (VectorImp) V;

        if(v.vectorSize > this.vectorSize)
            throw new IllegalArgumentException();

        double[] diffVector = new double[this.vectorSize];
        for(int i = 0; i < this.vectorSize; i++){
            if(i < v.vectorSize) {
                diffVector[i] = this.vectorData[i] - v.vectorData[i];
                if (diffVector[i] < -Double.MAX_VALUE) {
                    throw new RuntimeException();
                }
            }
            else
                diffVector[i] = this.vectorData[i];
        }

        return new VectorImp(diffVector);
    } //sub this – V

    public VectorImp subV(int l, int r){
        if(l < 0 || r > this.vectorSize || l > r)
            throw new IllegalArgumentException();

        double[] subVector = new double[r - l + 1];
        for (int i = 0; i <= (r - l); i++) {
            subVector[i] = this.vectorData[i + l];
        }
        return new VectorImp(subVector);
    }  //will return a sub vector between the

    public VectorImp Mult(Vector V){
        VectorImp v = (VectorImp) V;

        if(v.vectorSize > this.vectorSize)
            throw new IllegalArgumentException();

        double[] productVector = new double[this.vectorSize];
        for(int i = 0; i < this.vectorSize; i++){
            if(i < v.vectorSize) {
                productVector[i] = this.vectorData[i] * v.vectorData[i];
                if (productVector[i] > Double.MAX_VALUE) {
                    System.err.println("Multiplying this vector would exceed the maximum value, multiplication not performed");
                    throw new RuntimeException();
                }
            }
            else
                productVector[i] = this.vectorData[i];
        }

        return new VectorImp(productVector);
    } //Multiple every element of this by corresponding element in V

    public VectorImp Mult(double aDouble){
        double[] productVector = new double[this.vectorSize];
        for(int i = 0; i < this.vectorSize; i++){
            productVector[i] = this.vectorData[i] * aDouble;
            if (productVector[i] > Double.MAX_VALUE) {
                System.err.println("Multiplying this vector would exceed the maximum value, multiplication not performed");
                throw new RuntimeException();
            }
        }

        return new VectorImp(productVector);
    }  //Multiply every element of this by aDouble

    public VectorImp Normalize(){
        double magnitude = 0;
        double[] normalizedVector = new double[this.vectorSize];
        for(int i = 0; i < this.vectorSize; i++){
            magnitude += (this.vectorData[i] * this.vectorData[i]);
        }

        //if this vector is a zero vector, the magnitude will be zero
        //cannot divide by zero, and the result will be the unchanged zero vector
        //so simply return the vector unchanged
        if(magnitude == 0){
            return new VectorImp(this.vectorData);
        }

        magnitude = Math.sqrt(magnitude);

        for(int j = 0; j < this.vectorSize; j++){
            normalizedVector[j] = this.vectorData[j]/magnitude;
        }

        return new VectorImp(normalizedVector);
    }   //returns this as a normalized vector

    public Double EuclidianDistance(Vector V){
        VectorImp v = (VectorImp) V;

        if(v.vectorSize != this.vectorSize)
            throw new IllegalArgumentException();

        double[] differences = new double[this.vectorSize];
        double distance = 0;
        for(int i = 0; i < this.vectorSize; i++){
            differences[i] = (this.vectorData[i] - v.vectorData[i]) * (this.vectorData[i] - v.vectorData[i]);
            distance += differences[i];
        }

        distance = Math.sqrt(distance);
        return distance;
    } //returns the Euclidian distance between this and V.
}
