package ClassOfAssignments.Student4;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertThrows;

class VectorImpTest {

    public VectorImp generateRandomVector(int size){
        VectorImp newVector = new VectorImp();
        for(int i = 0; i < size; i++){
            newVector = newVector.append(Math.random());
        }

        return newVector;
    }

    public double getMagnitude(VectorImp V){
        double magnitude = 0;
        for(int i = 0; i < V.getLength(); i++){
            magnitude += (V.getValue(i) * V.getValue(i));
        }

       return Math.sqrt(magnitude);
    }

    @Test
    //tests that a new empty vector has a length of 0
    void NewVectorIsOfLengthZero(){
        VectorImp testVector = new VectorImp();
        assertEquals(0, testVector.getLength());
    }

    @Test
    //tests that a new vector declared with the size param has the proper length and value
    void NewHomogenousVectorHasCorrectValues(){
        int size = 6;
        double value = 3.14;
        VectorImp testVector = new VectorImp(size, value);
        assertEquals(size, testVector.getLength());
        for(int i = 0; i < size; i++){
            assertEquals(value, testVector.getValue(i));
        }
    }

    @Test
    //tests that using a negative number in a vector throws exception for both constructors that take a size param
    void NegativeSizeVectorThrowsException(){
        int size = -2;
        double value = 3.14;
        int iValue = 4;
        assertThrows(IllegalArgumentException.class, () ->{
            VectorImp intDoubleVector = new VectorImp(size, value);
        });
        assertThrows(IllegalArgumentException.class, () ->{
            VectorImp intNegVector = new VectorImp(size, iValue);
        });
    }

    @Test
    //tests that a vector initialized with a double array has the same size as double array
    void NewDoubleVectorIsOfSameLength(){
        double[] newArray = {3, 2, 4};
        VectorImp testVector = new VectorImp(newArray);
        int doubleLength = testVector.getLength();
        assertEquals(newArray.length, doubleLength);
    }

    @Test
    //tests that a vector initialized with a double array has the same values as double array
    void NewDoubleVectorHasSameData(){
        double[] newArray = {3, 2, 4, 5.7, 4.7, -3.1};
        VectorImp testVector = new VectorImp(newArray);
        for(int i = 0; i < newArray.length; i++){
            assertEquals(newArray[i], testVector.getValue(i));
        }
    }

    @Test
    //tests that a vector initialized with an int array has the same values once typecast into doubles
    void NewIntVectorHasSameDataAndCorrectTypecasts(){
        int[] newArray = {1, 2, 3, 4, -7, 4726, 372916};
        VectorImp testVector = new VectorImp(newArray);
        for(int i = 0; i < newArray.length; i++){
            assertEquals(newArray[i], testVector.getValue(i));
        }
    }

    @Test
    //tests numerous instances of appending a double array to an existing vector
    void TestAppendDoubleArrayCases(){
        double[] firstArray = {1, -0.5, 0.25, -0.125, 0.0625, 2.4, 4.8};
        double[] secondArray = {-21, 68.4, -5.45};
        double[] blankArray = new double[0];

        VectorImp testVector = new VectorImp(firstArray);

        //appending a blank array produces an equal vector
        VectorImp testVectorToAppend = testVector.append(blankArray);
        assertEquals(true, testVector.equal(testVectorToAppend));

        //appending a nonempty array produces a vector with the length of the existing vector plus the length of the appended array
        testVectorToAppend = testVectorToAppend.append(secondArray);
        assertEquals((testVector.getLength() + secondArray.length), (testVectorToAppend.getLength()));

        //the values of the resulting vector are equal to the values of the initial vector plus the appended array
        for(int i = 0; i < testVectorToAppend.getLength(); i++){
            if (i < testVector.getLength())
                assertEquals(testVector.getValue(i), testVectorToAppend.getValue(i));
            else
                assertEquals(secondArray[i - testVector.getLength()], testVectorToAppend.getValue(i));
        }
    }

    @Test
    //tests numerous instances of appending a double array to an existing vector
    void TestAppendIntArrayCases(){
        int[] firstArray = {1, 1, 2, 3, 5, 8, 13};
        int[] secondArray = {21, 34, 55};
        int[] blankArray = new int[0];

        VectorImp testVector = new VectorImp(firstArray);

        //appending a blank array produces an equal vector
        VectorImp testVectorToAppend = testVector.append(blankArray);
        assertEquals(true, testVector.equal(testVectorToAppend));

        //appending an array, then taking the subVector of that vector corresponding to the second array produces
        //equal values to the second array
        testVectorToAppend = testVectorToAppend.append(secondArray);
        testVectorToAppend = testVectorToAppend.subV(firstArray.length, testVectorToAppend.getLength() - 1);
        for(int i = 0; i < secondArray.length; i++){
            assertEquals(testVectorToAppend.getValue(i), secondArray[i]);
        }
    }

    @Test
        //tests instances of appending a vector to another vector, showing the result is equal to appending an array
    void TestAppendVectorCases(){
        int[] firstArray = {1, 1, 2, 3, 5, 8, 13};
        int[] secondArray = {21, 34, 55};
        double[] thirdArray = new double[secondArray.length];
        for(int i = 0; i < secondArray.length; i++)
            thirdArray[i] = secondArray[i];
        int[] blankArray = new int[0];

        VectorImp testVector = new VectorImp(firstArray);
        VectorImp secondVector = new VectorImp(secondArray);
        VectorImp blankVector = new VectorImp(blankArray);

        //tests that appending a blank vector returns an equal vector
        VectorImp testVectorToAppend = testVector.append(blankVector);
        assertEquals(true, testVector.equal(testVectorToAppend));

        //tests that vectors created with different append methods are still equal as long as the values are the same
        //tests double[] vs vector
        VectorImp compareAppendMethod = testVector.append(secondArray);
        testVectorToAppend = testVector.append(secondVector);
        assertEquals(true, compareAppendMethod.equal(testVectorToAppend));

        //tests int[] vs vector
        compareAppendMethod = testVector.append(thirdArray);
        assertEquals(true, compareAppendMethod.equal(testVectorToAppend));
    }

    @Test
    /*this function tests that the failsafe for vectors exceeding the maximum possible length works.
    If appending a vector or array would cause a memory error, an error message is thrown and the original
    vector is returned.

    This exponential appending function causes a memory error after approximately 27 iterations.
    Because the failsafe is in place, the vector will not be changed after the 27th iteration
    so the two vectors are identical.*/
    void TestVectorLimits(){
        VectorImp recursion = new VectorImp(1, 1);
        VectorImp recursion2 = new VectorImp(1, 1);
        for(int i = 0; i < 28; i++){
            recursion = recursion.append(recursion);
        }

        for(int i = 0; i < 29; i++){
            recursion2 = recursion2.append(recursion2);
        }

        assertEquals(true, recursion.equal(recursion2));
    }

    @Test
    //same principle as the previous test, but done with the int[] append method
    void TestVectorLimitsInt(){
        int[] initialLargeArray = new int[500000000];
        VectorImp iteration = new VectorImp();
        VectorImp iteration2 = new VectorImp();
        for(int i = 0; i < 2; i++){
            iteration = iteration.append(initialLargeArray);
        }

        for(int i = 0; i < 3; i++){
            iteration2 = iteration2.append(initialLargeArray);
        }

        assertEquals(true, iteration.equal(iteration2));
    }

    @Test
    //tests that appending a single value will increment the size properly
    void TestSingleValueAppend(){
        double single = 12;
        VectorImp lengthEight = new VectorImp(8, 0);
        VectorImp lengthNine = lengthEight.append(single);
        assertEquals(lengthEight.getLength() + 1, lengthNine.getLength());
    }

    @Test
    //randomly generates a vector, clones it, then tests that the resulting vector is equal in size,
    //and that any index will result in the same value from both vectors.
    void CloneRandomVector(){
        VectorImp clonee = generateRandomVector(100);

        //same length
        VectorImp cloned = clonee.clone();
        assertEquals(cloned.getLength(), clonee.getLength());

        //same values
        for(int j = 0; j < 1; j++){
            assertEquals(cloned.getValue(j), clonee.getValue(j));
        }
    }

    @Test
    //tests that cloning an empty vector functions and that the resulting vector is empty
    void CloneEmptyVector(){
        VectorImp clonee = new VectorImp();
        VectorImp cloned = clonee.clone();

        //length is the same
        assertEquals(cloned.getLength(), clonee.getLength());

        //length is zero
        assertEquals(0, clonee.getLength());
    }

    @Test
    //tests that two empty vectors are equal,
    //and two different vectors with the same value created by different means are still equal
    void TestVectorEqualMethod(){
        VectorImp vector1 = new VectorImp();
        VectorImp vector2 = new VectorImp();
        VectorImp vector3 = new VectorImp(1, 5);

        //two empty vectors
        assertEquals(true, vector1.equal(vector2));

        //double[] and double append method
        double[] newArray = {2.0, -3.0, 4};
        vector1 = vector1.append(newArray);
        vector1 = vector1.append(5.0);

        //int[] and vector append method
        int[] newerArray = {2, -3, 4};
        vector2 = vector2.append(newerArray);
        vector2 = vector2.append(vector3);

        assertEquals(true, vector1.equal(vector2));
    }

    @Test
    //tests negative input for getValue function
    void TestNegativeValueInput(){
        VectorImp newVector = new VectorImp(6, 5);
        int value = -1;
        assertThrows(IllegalArgumentException.class, () ->{
            double negative = newVector.getValue(value);
        });
    }

    @Test
    //tests out of bounds input for getValue function
    void TestOutOfBoundsValueInput(){
        VectorImp newVector = new VectorImp(6, 5);
        int value = 6;
        assertThrows(IllegalArgumentException.class, () ->{
            double outOfBounds = newVector.getValue(value);
        });
    }

    @Test
    //tests cases right on the bounds, to verify that the vector is properly 0-indexed
    void TestBoundsValueInput(){
        int[] edges = {1, 0, 0, 0, 0, 1};
        VectorImp newVector = new VectorImp(edges);

        //first value
        assertEquals(1, newVector.getValue(0));

        //last value, checked first manually then by size - 1
        assertEquals(1, newVector.getValue(5));
        assertEquals(1, newVector.getValue(newVector.getLength() - 1));
    }

    @Test
    //tests that exception is thrown if someone tries to add a larger vector to a smaller one
    void TestAddLargerVectorException(){
        VectorImp smallerVector = new VectorImp(5, 3);
        VectorImp biggerVector =  new VectorImp(7, 4);
        assertThrows(IllegalArgumentException.class, () ->{
            VectorImp sumVector = smallerVector.add(biggerVector);
        });
    }

    @Test
    //tests that the value indexing works properly, by adding a smaller vector to a larger one
    void TestAddSmallerVector(){
        VectorImp smallerVector = new VectorImp(5, 3);
        VectorImp biggerVector =  new VectorImp(7, 4);
        VectorImp sumVector = biggerVector.add(smallerVector);
        int count = 0;
        for(int i = 0; i < sumVector.getLength(); i++){
            if(sumVector.getValue(i) == 7)
                count++;
        }

        //count should be equal to the size of the smaller array
        assertEquals(count, 5);
        assertEquals(count, smallerVector.getLength());
    }

    @Test
    //tests that adding an empty vector to a nonempty vector returns a copy of the nonempty vector
    void TestAddEmptyVector(){
        VectorImp emptyVector = new VectorImp();
        VectorImp fullVector = new VectorImp(7, 8);
        VectorImp sumVector = fullVector.add(emptyVector);

        assertEquals(true, sumVector.equal(fullVector));
    }

    @Test
    //tests that the error message is properly handled if someone exceeds the memory limit of an individual value
    void TestAdditionLimits(){
        assertThrows(RuntimeException.class, () ->{
            VectorImp recursion = new VectorImp(1, 1);
            while(true){
                recursion = recursion.add(recursion);
            }
        });
    }

    @Test
    //tests single value addition cases of a positive number, negative number, and zero
    void TestSingleValueAddition(){
        double[] vectorArray = {1, -1, 3.1, -5.2, 8};
        VectorImp newVector = new VectorImp(vectorArray);
        VectorImp sumVector = newVector.add(0);

        //tests adding 0 to vector
        assertEquals(true, newVector.equal(sumVector));

        //tests adding positive number
        sumVector = newVector.add(3);
        for(int i = 0; i < newVector.getLength(); i++){
            assertEquals(sumVector.getValue(i), vectorArray[i] + 3);
        }

        //tests adding negative number
        VectorImp diffVector = newVector.add(-3);
        for(int i = 0; i < newVector.getLength(); i++){
            assertEquals(diffVector.getValue(i), vectorArray[i] - 3);
        }
    }

    @Test
    //tests that the error message is properly handled if someone exceeds the memory limit of an individual value
    void TestSingleValueAdditionLimits(){
        assertThrows(RuntimeException.class, () ->{
            VectorImp iteration = new VectorImp(1, 0);
            while(true){
                iteration = iteration.add(Double.MAX_VALUE/4);
            }
        });
    }

    @Test
    //tests that exception is thrown if someone tries to subtract a larger value from a smaller one
    void TestSubLargerVectorException(){
        VectorImp smallerVector = new VectorImp(4, 6);
        VectorImp biggerVector =  new VectorImp(8, 7);
        assertThrows(RuntimeException.class, () ->{
            VectorImp diffVector = smallerVector.sub(biggerVector);
        });
    }

    @Test
    //tests that the value indexing works properly, by subtracting a smaller vector from a larger one
    void TestSubSmallerVector(){
        VectorImp smallerVector = new VectorImp(8, 4);
        VectorImp biggerVector =  new VectorImp(67, 2);
        VectorImp diffVector = biggerVector.sub(smallerVector);
        int count = 0;
        for(int i = 0; i < diffVector.getLength(); i++){
            if(diffVector.getValue(i) == -2)
                count++;
        }

        //count should be equal to the size of the smaller array
        assertEquals(count, 8);
        assertEquals(count, smallerVector.getLength());
    }

    @Test
    //tests that adding an empty vector to a nonempty vector returns a copy of the nonempty vector
    void TestSubEmptyVector(){
        VectorImp emptyVector = new VectorImp();
        VectorImp fullVector = new VectorImp(78, 453);
        VectorImp diffVector = fullVector.add(emptyVector);

        assertEquals(true, diffVector.equal(fullVector));
    }

    @Test
    //tests that for any random vector, adding it and then subtracting it from a vector produces the same result
    void TestConsecutiveAdditionSubtraction(){
        VectorImp baseVector = new VectorImp(432, 43);
        VectorImp newVector = generateRandomVector(100);
        assertEquals(true, baseVector.equal(baseVector.add(newVector).sub(newVector)));
    }

    @Test
    //tests all 3 exception cases of sub-vector method
    void ShowExceptionHandlingForSubVectorMethod(){
        int a = -1;
        int b = 6;
        int c = 3;
        int d = 4;

        //exception for first index below zero
        assertThrows(IllegalArgumentException.class, () ->{
            VectorImp randVector = generateRandomVector(5);
            randVector = randVector.subV(a, d);
        });

        //exception for second index above zero
        assertThrows(IllegalArgumentException.class, () ->{
            VectorImp randVector = generateRandomVector(5);
            randVector = randVector.subV(c, b);
        });

        //exception for first index greater than second index
        assertThrows(IllegalArgumentException.class, () ->{
            VectorImp randVector = generateRandomVector(5);
            randVector = randVector.subV(d, c);
        });
    }

    @Test
    //tests inclusivity of the second index by passing the same into the method twice, then verifying it produces
    //a one sized vector with the value of the respective index
    void ShowThatSecondIndexIsInclusive(){
        int[] newArray = {1, 2, 3, 4, 5};
        int index = 3;
        VectorImp newVector = new VectorImp(newArray);
        VectorImp subVector = newVector.subV(index, index);

        assertEquals(1, subVector.getLength());
        assertEquals(subVector.getValue(0), newVector.getValue(index));
    }

    @Test
    //tests that exception is thrown if someone tries to multiply a larger vector with a smaller one
    void TestMultLargerVectorException(){
        VectorImp smallerVector = new VectorImp(2, 5);
        VectorImp biggerVector =  new VectorImp(7, 2);
        assertThrows(IllegalArgumentException.class, () ->{
            VectorImp productVector = smallerVector.Mult(biggerVector);
        });
    }

    @Test
        //tests that the value indexing works properly, by multiplying a smaller vector with a larger one
    void TestMultSmallerVector(){
        VectorImp smallerVector = new VectorImp(4, 2);
        VectorImp biggerVector =  new VectorImp(8, 3);
        VectorImp productVector = biggerVector.Mult(smallerVector);
        int count = 0;
        for(int i = 0; i < productVector.getLength(); i++){
            if(productVector.getValue(i) == 6)
                count++;
        }

        //count should be equal to the size of the smaller array
        assertEquals(count, 4);
        assertEquals(count, smallerVector.getLength());
    }

    @Test
    //tests that the error message is properly handled if someone exceeds the memory limit of an individual value
    void TestMultiplicationLimits(){
        assertThrows(RuntimeException.class, () ->{
            VectorImp recursion = new VectorImp(1, 2);
            while(true){
                recursion = recursion.Mult(recursion);
            }
        });
    }

    @Test
    //tests that multiplying a vector with an empty vector does not alter the result
    void TestBlankMultiplication(){
        VectorImp blankVector = new VectorImp();
        VectorImp newVector = new VectorImp(6, 7);

        assertEquals(true, newVector.equal(newVector.Mult(blankVector)));
    }

    @Test
    //tests that multiplying a vector by a vector of all zeroes produces an all zero vector
    void TestZeroMultiplication(){
        VectorImp blankVector = new VectorImp(6, 0);
        VectorImp newVector = new VectorImp(6, 7);

        assertEquals(true, blankVector.equal(blankVector.Mult(newVector)));
    }

    @Test
        //tests that the error message is properly handled if someone exceeds the memory limit of an individual value
    void TestSingleValMultiplicationLimits(){
        assertThrows(RuntimeException.class, () ->{
            VectorImp recursion = new VectorImp(5, 2);
            int exponent = (int) recursion.getValue(0);
            while(true){
                recursion = recursion.Mult(exponent);
                exponent = (int) recursion.getValue(0);
            }
        });
    }

    @Test
    //tests that any random vector will have all zero values if multiplied by zero
    void TestSingleValZeroMultiplication(){
        VectorImp newVector = generateRandomVector(10);
        VectorImp blankVector = newVector.Mult(0);

        for(int i = 0; i < 10; i++)
            assertEquals(0, blankVector.getValue(i));
    }

    @Test
    //tests that unit vector of a zero vector remains a zero vector
    void ZeroUnitVectorEqualsItself(){
        VectorImp blankVector = new VectorImp(9, 0);
        VectorImp unitVector = blankVector.Normalize();

        assertEquals(true, blankVector.equal(unitVector));
    }

    @Test
    //tests with a custom and random vector that the magnitude after normalization will always be one
    void NormalizedVectorAlwaysHasMagnitudeOne(){
        double[] custom = {4.3, 1.3, -6.5, 4, 65, 3};
        VectorImp customVector = new VectorImp(custom);
        VectorImp randomVector = generateRandomVector(70);

        customVector = customVector.Normalize();
        randomVector = randomVector.Normalize();

        //output annoyingly does not exaclty equal 1, it is off by around 10^-15
        //created this arbitrarily small margin of error double to check if the result approximates 1
        double marginOfError = 0.000000000001;

        boolean approximatesOneCustom = (1 - getMagnitude(customVector) < marginOfError && 1 - getMagnitude(customVector) > -marginOfError);
        assertEquals(approximatesOneCustom, true);
        boolean approximatesOneRandom = (1 - getMagnitude(randomVector) < marginOfError && 1 - getMagnitude(randomVector) > -marginOfError);
        assertEquals(approximatesOneRandom, true);
    }

    @Test
    //tests that exception is thrown if someone tries to get the euclidian distance of a smaller vector
    void TestDistanceSmallerVectorException(){
        VectorImp smallerVector = new VectorImp(50, 35);
        VectorImp biggerVector =  new VectorImp(67, 466);
        assertThrows(IllegalArgumentException.class, () ->{
            double distance = biggerVector.EuclidianDistance(smallerVector);
        });
    }

    @Test
    //tests that exception is thrown if someone tries to get the euclidian distance of a larger vector
    void TestDistanceLargerVectorException(){
        VectorImp smallerVector = new VectorImp(34, 75);
        VectorImp biggerVector =  new VectorImp(788, 135);
        assertThrows(IllegalArgumentException.class, () ->{
            double distance = smallerVector.EuclidianDistance(biggerVector);
        });
    }

    @Test
    //tests that two identical vectors have a distance of zero, tests with custom, random, and blank vector
    void TwoIdenticalVectorsHaveDistanceZero(){
        double[] custom = {6.3, -2.6, 425.6, -55.5, 7, 68, 0, -3};
        VectorImp customVector = new VectorImp(custom);
        VectorImp randomVector = generateRandomVector(20);
        VectorImp blankVector = new VectorImp();

        VectorImp customClone = customVector.clone();
        VectorImp randomClone = randomVector.clone();
        VectorImp blankClone = blankVector.clone();

        assertEquals(0, customVector.EuclidianDistance(customClone));
        assertEquals(0, randomVector.EuclidianDistance(randomClone));
        assertEquals(0, blankVector.EuclidianDistance(blankClone));
    }

    @Test
    //tests that any two nonzero opposite unit vectors have a euclidian distance of 2
    void TwoOppositeUnitVectorsHaveDistanceTwo(){
        VectorImp randomVector = generateRandomVector(20);
        VectorImp oppositeVector = new VectorImp();
        VectorImp blankVector = new VectorImp(20, 0);
        for(int i = 0; i < 20; i++){
            oppositeVector = oppositeVector.append(-randomVector.getValue(i));
        }

        //verify that two vectors are opposite
        assertEquals(true, blankVector.equal(oppositeVector.add(randomVector)));

        randomVector = randomVector.Normalize();
        oppositeVector = oppositeVector.Normalize();

        double distance = randomVector.EuclidianDistance(oppositeVector);

        //similar to above, result is not identical to 2, need variable to act as margin of error
        double marginOfError = 0.000000000001;

        boolean approximatesTwo = (2 - distance < marginOfError && 2 - distance > -marginOfError);
        assertEquals(approximatesTwo, true);
    }
}