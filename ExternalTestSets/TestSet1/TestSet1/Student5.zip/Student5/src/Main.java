package ClassOfAssignments.Student5;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}