package ClassOfAssignments.Student5;

public interface Vector {


    // append methods
   Vector append(double[] double_array);


     Vector append(int[] intArray);


     Vector append(Vector v);


     Vector append(double aDouble);


    // other methods
     Vector clone();

     Boolean equal (Vector V);

    int getLength();


   double getValue(int i);


    // add and sub
    Vector add(Vector v);


    Vector add(double aDouble);


     Vector sub(Vector v);


     Vector subV(int i, int r);

    Vector Mult(Vector V) ;
    Vector Mult(double aDouble) ;
    Vector Normalize();
    Double EuclidianDistance(Vector V); 


}
