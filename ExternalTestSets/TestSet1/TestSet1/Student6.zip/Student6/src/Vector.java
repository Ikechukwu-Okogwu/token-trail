package ClassOfAssignments.Student6;

/** Interface for a basic vector class
 *
 * @author Professor Dave Bockus
 * @version 1.0 Nov 12th, 2025
 */
public interface Vector {


    /** Appends an array of doubles to the end of the vector
     *
     * @param doubleArray   Array to be appended to the end of the vector
     * @return  Updated Vector
     */
    Vector append(double[] doubleArray);

    /** Appends an array of ints to the end of the vector
     *
     * @param intArray  Array to be appended to the end of the vector
     * @return  Updated Vector
     */
    Vector append(int[] intArray);

    /** Appends a vector to the end of this vector
     *
     * @param V Vector to be appended to the end of the main vector
     * @return  Updated Vector
     */
    Vector append(Vector V);

    /** Appends a double to the end of the vector
     *
     * @param aDouble The double to be appended to the end of the vector
     * @return  Updated Vector
     */
    Vector append(double aDouble);

    /** Creates an identical copy of the Vector but with a new, separate address.
     *
     * @return  Copy of this Vector
     */
    Vector clone(); 	// returns a clone of this

    /** Checks if all elements in this Vector and V are the same
     *  Returns true if they are
     *  Returns false if not
     *
     * @param V Vector to be compared to
     * @return  true if all the vectors are the same. False if not
     */
    Boolean equal(Vector V); //this and V are the same

    /** The number of elements in the vector
     *
     * @return  number of elements in the vector
     */
    int getLength(); 		//returns number of elements in this

    /** Gets the double value at point i in the vector
     *
     * @param i position in Vector
     * @return  Double at position i
     */
    Double getValue(int i);  //returns the value  this[i]

    /** Adds Vector V to this Vector
     *
     * @param V Vector to be added
     * @return  Vector with each element being the sum of the corresponding elements in both vectors
     */
    Vector add(Vector V);     //add this to V, returning a Vector the same size as this

    /** Adds aDouble to each element of the vector
     *
     * @param aDouble   Value to be added to each element of the vector
     * @return  this vector with each element increased by aDouble
     */
    Vector add(double aDouble); //add aDouble to every element of this

    /** Subtracts Vector V from this Vector
     *
     * @param V Vector to be subtracted from this
     * @return  Vector with each element being this Vector's elements - Vector V's corresponding element
     */
    Vector sub(Vector V); //sub this – V

    /** Subvector between points l and r
     * l and r inclusive
     *
     * @param l left-most element included in the subvector
     * @param r right-most element included in the subvector
     * @return  subvector between the elements l and r
     */
    Vector subV(int l, int r);  //will return a sub vector between the
    //indices l and r inclusive

    /** Multiplies every element of this by corresponding element in V
     *
     * @param V Vector to multiply this by
     * @return  Vector Product of this and V
     */
    Vector Mult(Vector V); //Multiple every element of this by corresponding element in V

    /** Multiplies every element of the Vector by aDouble
     *
     * @param aDouble   double to multiple each element by
     * @return  Vector of the products of a double and the elements of this Vector
     */
    Vector Mult(double aDouble);  //Multiply every element of this by aDouble

    /** Normalized vector
     *
     * @return  Normalized Vector
     */
    Vector Normalize();   //returns this as a normalized vector

    /**Euclidian distance between this Vector and Vector V
     *
     * @param V Vector to compare the distance to
     * @return  Euclidian Distance between the two Vectors
     */
    Double EuclidianDistance(Vector V); //returns the Euclidian distance between this and V.

}
