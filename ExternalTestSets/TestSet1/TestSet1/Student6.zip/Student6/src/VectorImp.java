package ClassOfAssignments.Student6;
/**Stolen code, bwahaha
 *
 *
 * @author Mal Icous 1239876
 */

import java.util.Arrays;
import java.util.Objects;

public class VectorImp implements Vector {

    public int size;
    public double[] vector;

    /**Creates an empty vector
     *
     */
    VectorImp(){vector = new double[0];}  //empty

    /** creates a vector of size – size
     * with elements initialized to D
     * @param size  Size of Vector
     * @param D Value to initialize elements to
     */
    VectorImp(int size, double D){
        if(size < 0){
            throw new IllegalArgumentException("Vector Size Must Be a Positive Integer");
        }
        vector = new double[size];
        for(int i = 0; i < size; i++){
            vector[i] = D;
        }
    }

    /** creates a vector initialized to array D
     *
     * @param D Array of the vector
     */
    VectorImp(double[] D){vector = D.clone();}

    /** Creates a vector initialized to array I
     *
     * @param I array to initialize the vector to
     */
    VectorImp(int[] I){
        vector = new double[I.length];
        for(int i = 0; i < I.length; i++){
            vector[i] = I[i];
        }
    }

    /**Gets a copy of the vector array of Vector V
     *
     * @param V Vector to have elements copied
     * @return  double array of elements
     */
    private double[] getVector(Vector V){
        int VLen = V.getLength();
        double[] vector = new double[VLen];
        for(int i = 0; i < VLen; i++){
            vector[i] = V.getValue(i);
        }
        return vector;
    }

    // Methods
    @Override
    public Vector append(double[] doubleArray) {
        double[] vec = new double[doubleArray.length + vector.length];
        //build original half
        for (int i = 0; i < vector.length; i++) {
            vec[i] = vector[i];
        }
        //build appended half
        for(int j = 0; j < doubleArray.length; j++){
            vec[j+vector.length] = doubleArray[j];
        }
        return new VectorImp(vec);
    }


    @Override
    public Vector append(int[] intArray) {
        double[] vec = new double[intArray.length + vector.length];
        //original half
        for (int i = 0; i < vector.length; i++) {
            vec[i] = vector[i];
        }
        // appended half
        for(int j = 0; j < intArray.length; j++){
            vec[j+vector.length] = intArray[j];
        }
        return new VectorImp(vec);
    }


    @Override
    public Vector append(Vector V) {
        double[] vec = new double[V.getLength() + vector.length];
        for (int i = 0; i < vector.length; i++) {
            vec[i] = vector[i];
        }
        for(int j = 0; j < V.getLength(); j++){
            vec[j+vector.length] = V.getValue(j);
        }
        return new VectorImp(vec);
    }
    @Override
    public Vector append(double aDouble) {
        return append(new double[]{aDouble});
    }

    /** Creates an identical copy of the Vector but with a new, separate address.
     *  Creates a new VectorImp made from a cloned copy of this Vector's Vector Array
     *
     * @return  Copy of this Vector
     */
    @Override
    public Vector clone() {
        return new VectorImp(this.vector.clone());
    }

    /** Checks if all elements in this Vector and V are the same
     *  Returns false if the vectors are of different lengths
     *  Returns false if the vectors have a different element
     *  Returns true otherwise
     *
     * @param V Vector to be compared to
     * @return  true if all the vectors are the same. false if not
     */
    @Override
    public Boolean equal(Vector V) {
        if(V.getLength() != vector.length) return false;
        for(int i = 0; i < V.getLength(); i++){
            if(!Objects.equals(V.getValue(i), this.getValue(i))) return false;
        }
        return true;
    }

    /** The number of elements in the vector
     *
     * @return  number of elements in the vector
     */
    @Override
    public int getLength() {
        return vector.length;
    }

    /** Gets the double value at point i in the vector
     *
     * @param i position in Vector
     * @return  Double at position i
     */
    @Override
    public Double getValue(int i) {
        return vector[i];
    }


    public VectorImp add(Vector V){
        VectorImp v = (VectorImp) V;

        if(v.size > this.size)
            throw new IllegalArgumentException();

        double[] sumVector = new double[this.size];
        for(int i = 0; i < this.size; i++){
            if(i < v.size) {
                sumVector[i] = v.vector[i] + this.vector[i];
                if (sumVector[i] > Double.MAX_VALUE) {
                    System.err.println("Adding this vector would exceed the maximum value, addition not performed");
                    throw new RuntimeException();
                }
            }
            else
                sumVector[i] = this.vector[i];
        }

        return new VectorImp(sumVector);
    }     //add this to V, returning a Vector the same size as this

    public VectorImp add(double aDouble){
        double[] sumVector = new double[this.size];
        for(int i = 0; i < this.size; i++){
            sumVector[i] = this.vector[i] + aDouble;
            if (sumVector[i] > Double.MAX_VALUE) {
                System.err.println("Adding this number would exceed the maximum value, addition not performed");
                throw new RuntimeException();
            }
        }

        return new VectorImp(sumVector);
    } //add aDouble to every element of this

    public VectorImp sub(Vector V){
        VectorImp v = (VectorImp) V;

        if(v.size > this.size)
            throw new IllegalArgumentException();

        double[] diffVector = new double[this.size];
        for(int i = 0; i < this.size; i++){
            if(i < v.size) {
                diffVector[i] = this.vector[i] - vector[i];
                if (diffVector[i] < -Double.MAX_VALUE) {
                    throw new RuntimeException();
                }
            }
            else
                diffVector[i] = this.vector[i];
        }

        return new VectorImp(diffVector);
    } //sub this – V

    public VectorImp subV(int l, int r){
        if(l < 0 || r > this.size || l > r)
            throw new IllegalArgumentException();

        double[] subVector = new double[r - l + 1];
        for (int i = 0; i <= (r - l); i++) {
            subVector[i] = this.vector[i + l];
        }
        return new VectorImp(subVector);
    }  //will return a sub vector between the

    public VectorImp Mult(Vector V){
        VectorImp v = (VectorImp) V;

        if(v.size > this.size)
            throw new IllegalArgumentException();

        double[] productVector = new double[this.size];
        for(int i = 0; i < this.size; i++){
            if(i < v.size) {
                productVector[i] = this.vector[i] * v.vector[i];
                if (productVector[i] > Double.MAX_VALUE) {
                    System.err.println("Multiplying this vector would exceed the maximum value, multiplication not performed");
                    throw new RuntimeException();
                }
            }
            else
                productVector[i] = this.vector[i];
        }

        return new VectorImp(productVector);
    } //Multiple every element of this by corresponding element in V

    public VectorImp Mult(double aDouble){
        double[] productVector = new double[this.size];
        for(int i = 0; i < this.size; i++){
            productVector[i] = this.vector[i] * aDouble;
            if (productVector[i] > Double.MAX_VALUE) {
                System.err.println("Multiplying this vector would exceed the maximum value, multiplication not performed");
                throw new RuntimeException();
            }
        }

        return new VectorImp(productVector);
    }  //Multiply every element of this by aDouble

    /** Normalized vector
     *
     * @return  Normalized Vector
     */
    @Override
    public Vector Normalize() {
        double magnitude = Magnitude();
        for(int i = 0; i < vector.length; i++){
            vector[i] = vector[i]/magnitude;
        }
        return this;
    }

    /**The magnitude of the vector
     * Magnitude is the sqrt of the sum of the squares of each element of the vector
     * used for normalizing the vector
     *
     *
     * @return Magnitude of the vector
     */
    private double Magnitude(){
        double sumOfSquares = 0;
        for (double d : vector) {
            sumOfSquares += d * d;
        }
        return Math.sqrt(sumOfSquares);
    }

    /**Euclidean distance between this Vector and Vector V
     *
     * @param V Vector to compare the distance to
     * @return  Euclidean Distance between the two Vectors
     */
    @Override
    public Double EuclidianDistance(Vector V)  { //returns the Euclidean distance between this and V.
        if(V == null){throw new NullPointerException("V cannot be null");}
        if(this.size != V.getLength()){
            throw new IllegalArgumentException("Vectors must be the same length.");
        }
        double total = 0;
        for(int i = 0; i < this.size; i++){
            total += Math.pow(this.vector[i] - V.getValue(i), 2);
        }
        return Math.sqrt(total);
    }
}
