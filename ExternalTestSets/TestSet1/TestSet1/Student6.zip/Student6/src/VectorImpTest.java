package ClassOfAssignments.Student6; /**Testing class for VectorImp implementation class of the given Vector Interface
 * 100% Method, Line and Branch Coverage of VectorImp is obtained
 * All edge cases should be tested
 * Function naming scheme is taken from given video
 * https://www.youtube.com/watch?v=vZm0lHciFsQ
 *
 * @author Steve Mastrokalos 7276900
 * @Version 1.0 Nov 13th, 2025
 */

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class VectorImpTest {
    double[] testDoubleArray = {8,72,-994,1950,995.9,25.0,0,-503,0.824,7098, Math.PI}; //len = 11
    int[] testIntArray = {8,72,-994,1950,-9959,250,0,-503,-824,7098,10};    //len = 11
    double[] sumArray = {16.0, 144.0, -1988.0, 3900.0, -8963.1, 275.0, 0.0, -1006.0, -823.176, 14196.0, 13.141592653589793}; //testDoubleArray + testIntArray

    @Test
    void doubleArrayConstructorShouldConstructVectorWithInputAsVector(){
        var vector = new VectorImp(testDoubleArray);
        for(int i = 0; i < testDoubleArray.length; i++){
            assertEquals(testDoubleArray[i], vector.getValue(i));
        }
    }

    @Test
    void intArrayConstructorShouldConstructVectorWithInputAsVector(){
        var vector = new VectorImp(testIntArray);
        for(int i = 0; i < testIntArray.length; i++){
            assertEquals(testIntArray[i], vector.getValue(i));
        }
    }

    @Test
    void initializedValuesConstructorShouldCreatedACorrectlySizedArrayOfCorrectlyInitializedValuesInAllCases(){
        for(int i = 0; i <= 10; i++) {
            for(int j = -1; j <= 1; j++) {
                var vector = new VectorImp(i, j);
                for(int k = 0; k < i; k++){
                    assertEquals(vector.getValue(k), j);
                }
            }
        }
    }

    @Test
    void negativeSizeShouldReturnIllegalArgumentException(){
        assertThrows(IllegalArgumentException.class, () -> {new VectorImp(-1, 3.2);});
    }

    @Test
    void appendDoubleShouldAddNewValueToEnd() {
        var vector = new VectorImp();
        vector.append(3.14);
        assertEquals(3.14, vector.getValue(0));
        vector.append(2);
    }

    @Test
    void AppendIntShouldAddIntegerArrayToOnlyTheEndOfVector() {
        var vector = new VectorImp(2, 3);
        vector.append(testIntArray);
        for(int i = 2; i < vector.getLength(); i++){
            assertEquals(vector.getValue(i), testIntArray[i-2]);
        }
    }

    @Test
    void AppendVectorShouldAddCopyOfVectorTwoToEndOfVectorOne() {
        var vector1 = new VectorImp(testDoubleArray);
        var vector2 = new VectorImp(testIntArray);
        var newVector = vector1.clone().append(vector2);
        for(int i = 0; i < vector1.getLength(); i++){
            assertEquals(vector1.getValue(i), newVector.getValue(i));
        }
        for(int i = 0; i < vector2.getLength(); i++){
            assertEquals(vector2.getValue(i), newVector.getValue(i+vector1.getLength()));
        }
    }

    @Test
    void testCloneShouldNotBeTheSameObject() {
        var vector = new VectorImp(testDoubleArray);
        var clone = vector.clone();
        assertNotSame(clone, vector);
    }

    @Test
    void testCloneVectorShouldHaveTheSameValues(){
        var vector = new VectorImp(testDoubleArray);
        var clone = vector.clone();
        assertEquals(clone.getLength(), vector.getLength());
        for(int i = 0; i < vector.getLength(); i++){
            assertEquals(clone.getValue(i), vector.getValue(i));
        }
    }

    @Test
    void equalVectorsShouldBeTrue() {
        var vector = new VectorImp(testDoubleArray);
        var clone = vector.clone();
        assertEquals(true, vector.equal(clone));
    }

    @Test
    void differentSizedVectorsShouldBeFalse(){
        var vector = new VectorImp(testDoubleArray);
        assertEquals(false, vector.equal(new VectorImp(2, 1)));
    }

    @Test
    void differentVectorsShouldBeFalse(){
        var vector = new VectorImp(testDoubleArray);
        var differentVector = new VectorImp(testIntArray);
        assertEquals(false, vector.equal(differentVector));
    }

    @Test
    void getLengthOfTestIntArrayShouldBeEleven() {
        var vector = new VectorImp(testIntArray);
        assertEquals(testIntArray.length, vector.getLength());
    }

    @Test
    void getValueShouldReturnAccurateValuesInOrder() {
        var vector = new VectorImp(testDoubleArray);
        for(int i = 0; i < testDoubleArray.length; i++){
            assertEquals(testDoubleArray[i], vector.getValue(i));
        }
    }

    @Test
    void addDoubleVectorAndIntVectorShouldMakeFirstVectorEqualToTheSumOfTheVectors() {
        var vector = new VectorImp(testDoubleArray);
        var vector2 = new VectorImp(testIntArray);
        vector.add(vector2);
        for(int i = 0; i < vector.getLength(); i++) {
            assertEquals(sumArray[i], vector.getValue(i));
        }
    }

    @Test
    void addVectorsOfDifferentSizesShouldReturnIllegalArgumentException(){
        var vector = new VectorImp(testDoubleArray);
        assertThrows(IllegalArgumentException.class, () -> {vector.add(new VectorImp(2, 1));});
    }

    @Test
    void addVectorOfLengthOneShouldBeTreatedAsADouble(){
        var vector = new VectorImp(testDoubleArray);
        var oneDVector = new VectorImp(1, 2);
        assertDoesNotThrow(() -> {vector.add(oneDVector);});

        for(int i = 0; i < vector.getLength(); i++){
            assertEquals(testDoubleArray[i] + 2, vector.getValue(i));
        }
    }

    @Test
    void addingTwoVectorsOfLengthOneShouldWork(){
        var vector1 = new VectorImp(1, 2);
        var vector2 = new VectorImp(1, 3);
        assertEquals(true, vector1.add(vector2).equal(new VectorImp(1, 5)));
    }

    @Test
    void addingAScalarToVectorShouldAddScalarValueToEachElement() {
        var vector = new VectorImp(testDoubleArray).add(2);
        for(int i = 0; i < testDoubleArray.length; i++){
            assertEquals(testDoubleArray[i] + 2, vector.getValue(i));
        }
    }

    @Test
    void subtractingVector2FromVector1ShouldMakeFirstVectorEqualToTheDifference(){
        var vector = new VectorImp(testDoubleArray);
        var minuend = new VectorImp(11, 3);
        var difference = vector.clone().sub(minuend);
        assertEquals(true, difference.equal(vector.add(new VectorImp(11, -3))));
    }

    @Test
    void subVShouldCreateSubVectorBetweenlAndR() {
        var vector = new VectorImp(testDoubleArray).subV(1, 6);
        double[] subArray = new double[6];
        System.arraycopy(testDoubleArray, 1, subArray, 0, 6);
        for(int i = 0; i < subArray.length; i++){
            assertEquals(subArray[i], vector.getValue(i));
        }
    }

    @Test
    void subVShouldWorkIfLAndRAreFlipped() {
        var vector = new VectorImp(testDoubleArray).subV(6, 1);
        double[] subArray = new double[6];
        System.arraycopy(testDoubleArray, 1, subArray, 0, 6);
        for(int i = 0; i < subArray.length; i++){
            assertEquals(subArray[i], vector.getValue(i));
        }
    }

    @Test
    void subVShouldProduceAVectorWithOneDimensionIfLIsEqualToR() {
        var vector = new VectorImp(testDoubleArray).subV(6, 6);
        System.out.println(vector.getLength());
        double[] subArray = new double[1];
        System.arraycopy(testDoubleArray, 6, subArray, 0, 1);
        assertEquals(subArray[0], vector.getValue(0));
    }

    @Test
    void multShouldMakeTheVectorBecomeTheDotProductOfThisAndVectorV() {
        var vector = new VectorImp(testDoubleArray);
        var oneDVector = new VectorImp(11, 2);
        vector.Mult(oneDVector);
        for(int i = 0; i < vector.getLength(); i++) {
            assertEquals(testDoubleArray[i]*2, vector.getValue(i));
        }
    }

    @Test
    void multWithVectorSizeOneShouldWorkLikeScalarMult(){
        var vector = new VectorImp(testDoubleArray);
        var oneDVector = new VectorImp(1, 2);
        vector.Mult(oneDVector);
        for(int i = 0; i < vector.getLength(); i++) {
            assertEquals(testDoubleArray[i]*2, vector.getValue(i));
        }
    }

    @Test
    void multOfVectorsLargerThanOneWithDifferentSizesShouldProduceIllegalArgumentException(){
        var vector = new VectorImp(testDoubleArray);
        assertThrows(IllegalArgumentException.class, () -> {vector.Mult(new VectorImp(2, 1));});
    }

    @Test
    void multOfVectorWithAScalarShouldProduceAVectorWithAllElementsMultipliedByTheScalar(){
        var vector = new VectorImp(testDoubleArray).Mult(3);
        for(int i = 0; i < vector.getLength(); i++) {
            assertEquals(testDoubleArray[i]*3, vector.getValue(i));
        }
    }

    @Test
    void normalizeShouldDivideAllElementsByTheMagnitude() {
        var vector = new VectorImp(testDoubleArray);
        var normalized = vector.clone().Normalize();

        double sumOfSquares = 0;
        for (int i = 0; i < vector.getLength(); i++) {
            sumOfSquares += Math.pow(vector.getValue(i), 2);
        }
        double magnitude = Math.sqrt(sumOfSquares);

        for(int i = 0; i < vector.getLength(); i++){
            assertEquals(vector.getValue(i)/magnitude, normalized.getValue(i));
        }
    }

    @Test
    void normalizeANullVectorShouldNotCrash(){
        assertDoesNotThrow(() -> {new VectorImp(testDoubleArray).Normalize();});
    }

    @Test
    void euclideanDistanceBetweenDifferentlySizedVectorsShouldThrowIllegalArgumentException(){
        assertThrows(IllegalArgumentException.class, () ->{new VectorImp(2, 3).EuclidianDistance(new VectorImp(1, 1));});
    }

    @Test
    void euclidianDistanceBetweenZeroSquareAndOneSquareShouldBeSqrtTwo() {
        var vector1 = new VectorImp(2, 1);
        var vector2 = new VectorImp(2, 0);

        double sum = 0;
        for(int i = 0; i < vector1.getLength(); i++){
            double temp = vector1.getValue(i) - vector2.getValue(i);
            sum += temp * temp;
        }

        assertEquals(Math.sqrt(sum), vector1.EuclidianDistance(vector2));
        assertEquals(Math.sqrt(2), vector1.EuclidianDistance(vector2));
    }
}