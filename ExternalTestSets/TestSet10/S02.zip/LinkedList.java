public class LinkedList {
    private Node head;
    private int size;

    private static class Node {
        int data;
        Node next;
        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }

    public LinkedList() {
        this.head = null;
        this.size = 0;
    }

    public void insertFront(int value) {
        Node n = new Node(value);
        n.next = head;
        head = n;
        size++;
    }

    public void insertEnd(int value) {
        Node n = new Node(value);
        if (head == null) {
            head = n;
        } else {
            Node ptr = head;
            while (ptr.next != null) {
                ptr = ptr.next;
            }
            ptr.next = n;
        }
        size++;
    }

    public boolean search(int value) {
        Node ptr = head;
        while (ptr != null) {
            if (ptr.data == value) {
                return true;
            }
            ptr = ptr.next;
        }
        return false;
    }

    public boolean delete(int value) {
        if (head == null) {
            return false;
        }
        if (head.data == value) {
            head = head.next;
            size--;
            return true;
        }
        Node ptr = head;
        while (ptr.next != null) {
            if (ptr.next.data == value) {
                ptr.next = ptr.next.next;
                size--;
                return true;
            }
            ptr = ptr.next;
        }
        return false;
    }

    public void reverse() {
        Node p = null;
        Node c = head;
        Node n = null;
        while (c != null) {
            n = c.next;
            c.next = p;
            p = c;
            c = n;
        }
        head = p;
    }

    public int getSize() {
        return size;
    }

    public void printList() {
        Node ptr = head;
        System.out.print("List: ");
        while (ptr != null) {
            System.out.print(ptr.data + " -> ");
            ptr = ptr.next;
        }
        System.out.println("null");
    }

    public int getAt(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index out of range: " + index);
        }
        Node ptr = head;
        for (int k = 0; k < index; k++) {
            ptr = ptr.next;
        }
        return ptr.data;
    }

    public void insertAt(int index, int value) {
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index out of range: " + index);
        }
        if (index == 0) {
            insertFront(value);
            return;
        }
        Node n = new Node(value);
        Node ptr = head;
        for (int k = 0; k < index - 1; k++) {
            ptr = ptr.next;
        }
        n.next = ptr.next;
        ptr.next = n;
        size++;
    }

    public static void main(String[] args) {
        LinkedList lst = new LinkedList();
        for (int k = 1; k <= 10; k++) {
            lst.insertEnd(k * 5);
        }
        lst.printList();
        System.out.println("Size: " + lst.getSize());
        System.out.println("Search 25: " + lst.search(25));
        System.out.println("Search 99: " + lst.search(99));
        lst.delete(25);
        lst.printList();
        lst.reverse();
        lst.printList();
        lst.insertAt(3, 999);
        lst.printList();
        System.out.println("Element at 3: " + lst.getAt(3));
    }
}
