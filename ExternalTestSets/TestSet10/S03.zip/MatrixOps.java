public class MatrixOps {
    private int[][] matrix;
    private int rows;
    private int cols;

    public MatrixOps(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.matrix = new int[rows][cols];
    }

    public MatrixOps(int[][] data) {
        this.rows = data.length;
        this.cols = data[0].length;
        this.matrix = new int[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                this.matrix[i][j] = data[i][j];
            }
        }
    }

    public void set(int row, int col, int value) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            throw new IndexOutOfBoundsException("Invalid position");
        }
        matrix[row][col] = value;
    }

    public int get(int row, int col) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            throw new IndexOutOfBoundsException("Invalid position");
        }
        return matrix[row][col];
    }

    public MatrixOps add(MatrixOps other) {
        if (this.rows != other.rows || this.cols != other.cols) {
            throw new IllegalArgumentException("Matrix dimensions must match for addition");
        }
        MatrixOps result = new MatrixOps(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.matrix[i][j] = this.matrix[i][j] + other.matrix[i][j];
            }
        }
        return result;
    }

    public MatrixOps multiply(MatrixOps other) {
        if (this.cols != other.rows) {
            throw new IllegalArgumentException("Incompatible dimensions for multiplication");
        }
        MatrixOps result = new MatrixOps(this.rows, other.cols);
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < other.cols; j++) {
                int sum = 0;
                for (int k = 0; k < this.cols; k++) {
                    sum += this.matrix[i][k] * other.matrix[k][j];
                }
                result.matrix[i][j] = sum;
            }
        }
        return result;
    }

    public MatrixOps transpose() {
        MatrixOps result = new MatrixOps(cols, rows);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.matrix[j][i] = this.matrix[i][j];
            }
        }
        return result;
    }

    public int trace() {
        if (rows != cols) {
            throw new IllegalStateException("Trace requires a square matrix");
        }
        int sum = 0;
        for (int i = 0; i < rows; i++) {
            sum += matrix[i][i];
        }
        return sum;
    }

    public MatrixOps scalarMultiply(int scalar) {
        MatrixOps result = new MatrixOps(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.matrix[i][j] = this.matrix[i][j] * scalar;
            }
        }
        return result;
    }

    public boolean isSymmetric() {
        if (rows != cols) return false;
        for (int i = 0; i < rows; i++) {
            for (int j = i + 1; j < cols; j++) {
                if (matrix[i][j] != matrix[j][i]) {
                    return false;
                }
            }
        }
        return true;
    }

    public void print() {
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                System.out.printf("%6d", matrix[i][j]);
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        int[][] dataA = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int[][] dataB = {{9, 8, 7}, {6, 5, 4}, {3, 2, 1}};
        MatrixOps a = new MatrixOps(dataA);
        MatrixOps b = new MatrixOps(dataB);
        System.out.println("Matrix A:");
        a.print();
        System.out.println("Matrix B:");
        b.print();
        System.out.println("A + B:");
        a.add(b).print();
        System.out.println("A * B:");
        a.multiply(b).print();
        System.out.println("Transpose of A:");
        a.transpose().print();
        System.out.println("Trace of A: " + a.trace());
        System.out.println("A * 3:");
        a.scalarMultiply(3).print();
        System.out.println("A symmetric? " + a.isSymmetric());
    }
}
