public class MatrixOps {
    private int[][] matrix;
    private int rows;
    private int cols;

    public MatrixOps(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.matrix = new int[rows][cols];
    }

    public MatrixOps(int[][] data) {
        this.rows = data.length;
        this.cols = data[0].length;
        this.matrix = new int[rows][cols];
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                this.matrix[r][c] = data[r][c];
            }
        }
    }

    public MatrixOps transpose() {
        MatrixOps res = new MatrixOps(cols, rows);
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                res.matrix[c][r] = this.matrix[r][c];
            }
        }
        return res;
    }

    public boolean isSymmetric() {
        if (rows != cols) return false;
        for (int r = 0; r < rows; r++) {
            for (int c = r + 1; c < cols; c++) {
                if (matrix[r][c] != matrix[c][r]) {
                    return false;
                }
            }
        }
        return true;
    }

    public MatrixOps scalarMultiply(int scalar) {
        MatrixOps res = new MatrixOps(rows, cols);
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                res.matrix[r][c] = this.matrix[r][c] * scalar;
            }
        }
        return res;
    }

    public void set(int row, int col, int value) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            throw new IndexOutOfBoundsException("Invalid position");
        }
        matrix[row][col] = value;
    }

    public int get(int row, int col) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            throw new IndexOutOfBoundsException("Invalid position");
        }
        return matrix[row][col];
    }

    public int trace() {
        if (rows != cols) {
            throw new IllegalStateException("Trace requires a square matrix");
        }
        int total = 0;
        for (int r = 0; r < rows; r++) {
            total += matrix[r][r];
        }
        return total;
    }

    public MatrixOps add(MatrixOps other) {
        if (this.rows != other.rows || this.cols != other.cols) {
            throw new IllegalArgumentException("Matrix dimensions must match for addition");
        }
        MatrixOps res = new MatrixOps(rows, cols);
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                res.matrix[r][c] = this.matrix[r][c] + other.matrix[r][c];
            }
        }
        return res;
    }

    public MatrixOps multiply(MatrixOps other) {
        if (this.cols != other.rows) {
            throw new IllegalArgumentException("Incompatible dimensions for multiplication");
        }
        MatrixOps res = new MatrixOps(this.rows, other.cols);
        for (int r = 0; r < this.rows; r++) {
            for (int c = 0; c < other.cols; c++) {
                int acc = 0;
                for (int k = 0; k < this.cols; k++) {
                    acc += this.matrix[r][k] * other.matrix[k][c];
                }
                res.matrix[r][c] = acc;
            }
        }
        return res;
    }

    public void print() {
        for (int r = 0; r < rows; r++) {
            for (int c = 0; c < cols; c++) {
                System.out.printf("%6d", matrix[r][c]);
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        int[][] d1 = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int[][] d2 = {{9, 8, 7}, {6, 5, 4}, {3, 2, 1}};
        MatrixOps m1 = new MatrixOps(d1);
        MatrixOps m2 = new MatrixOps(d2);
        System.out.println("Matrix A:");
        m1.print();
        System.out.println("Matrix B:");
        m2.print();
        System.out.println("A + B:");
        m1.add(m2).print();
        System.out.println("A * B:");
        m1.multiply(m2).print();
        System.out.println("Transpose of A:");
        m1.transpose().print();
        System.out.println("Trace of A: " + m1.trace());
        System.out.println("A * 3:");
        m1.scalarMultiply(3).print();
        System.out.println("A symmetric? " + m1.isSymmetric());
    }
}
