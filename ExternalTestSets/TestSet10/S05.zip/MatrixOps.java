public class MatrixOps {
    private int[][] matrix;
    private int rows;
    private int cols;

    public MatrixOps(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.matrix = new int[rows][cols];
    }

    public MatrixOps(int[][] data) {
        this.rows = data.length;
        this.cols = data[0].length;
        this.matrix = new int[rows][cols];
        for (int a = 0; a < rows; a++) {
            for (int b = 0; b < cols; b++) {
                this.matrix[a][b] = data[a][b];
            }
        }
    }

    public void set(int row, int col, int value) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            throw new IndexOutOfBoundsException("Invalid position");
        }
        matrix[row][col] = value;
    }

    public int get(int row, int col) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            throw new IndexOutOfBoundsException("Invalid position");
        }
        return matrix[row][col];
    }

    public MatrixOps add(MatrixOps other) {
        if (this.rows != other.rows || this.cols != other.cols) {
            throw new IllegalArgumentException("Matrix dimensions must match for addition");
        }
        MatrixOps out = new MatrixOps(rows, cols);
        for (int a = 0; a < rows; a++) {
            for (int b = 0; b < cols; b++) {
                out.matrix[a][b] = this.matrix[a][b] + other.matrix[a][b];
            }
        }
        return out;
    }

    public MatrixOps multiply(MatrixOps other) {
        if (this.cols != other.rows) {
            throw new IllegalArgumentException("Incompatible dimensions for multiplication");
        }
        MatrixOps out = new MatrixOps(this.rows, other.cols);
        for (int a = 0; a < this.rows; a++) {
            for (int b = 0; b < other.cols; b++) {
                int val = 0;
                for (int k = 0; k < this.cols; k++) {
                    val += this.matrix[a][k] * other.matrix[k][b];
                }
                out.matrix[a][b] = val;
            }
        }
        return out;
    }

    public MatrixOps transpose() {
        MatrixOps out = new MatrixOps(cols, rows);
        for (int a = 0; a < rows; a++) {
            for (int b = 0; b < cols; b++) {
                out.matrix[b][a] = this.matrix[a][b];
            }
        }
        return out;
    }

    public int trace() {
        if (rows != cols) {
            throw new IllegalStateException("Trace requires a square matrix");
        }
        int val = 0;
        for (int a = 0; a < rows; a++) {
            val += matrix[a][a];
        }
        return val;
    }

    public MatrixOps scalarMultiply(int scalar) {
        MatrixOps out = new MatrixOps(rows, cols);
        for (int a = 0; a < rows; a++) {
            for (int b = 0; b < cols; b++) {
                out.matrix[a][b] = this.matrix[a][b] * scalar;
            }
        }
        return out;
    }

    public boolean isSymmetric() {
        if (rows != cols) return false;
        for (int a = 0; a < rows; a++) {
            for (int b = a + 1; b < cols; b++) {
                if (matrix[a][b] != matrix[b][a]) {
                    return false;
                }
            }
        }
        return true;
    }

    public void print() {
        for (int a = 0; a < rows; a++) {
            for (int b = 0; b < cols; b++) {
                System.out.printf("%6d", matrix[a][b]);
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        int[][] x = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
        int[][] y = {{9, 8, 7}, {6, 5, 4}, {3, 2, 1}};
        MatrixOps p = new MatrixOps(x);
        MatrixOps q = new MatrixOps(y);
        System.out.println("Matrix A:");
        p.print();
        System.out.println("Matrix B:");
        q.print();
        System.out.println("A + B:");
        p.add(q).print();
        System.out.println("A * B:");
        p.multiply(q).print();
        System.out.println("Transpose of A:");
        p.transpose().print();
        System.out.println("Trace of A: " + p.trace());
        System.out.println("A * 3:");
        p.scalarMultiply(3).print();
        System.out.println("A symmetric? " + p.isSymmetric());
    }
}
