public class BinarySearchTree {
    private TreeNode root;

    private static class TreeNode {
        int key;
        TreeNode left;
        TreeNode right;
        TreeNode(int key) {
            this.key = key;
            this.left = null;
            this.right = null;
        }
    }

    public BinarySearchTree() {
        this.root = null;
    }

    public void insert(int key) {
        root = insertRecursive(root, key);
    }

    private TreeNode insertRecursive(TreeNode node, int key) {
        if (node == null) {
            return new TreeNode(key);
        }
        if (key < node.key) {
            node.left = insertRecursive(node.left, key);
        } else if (key > node.key) {
            node.right = insertRecursive(node.right, key);
        }
        return node;
    }

    public boolean contains(int key) {
        return containsRecursive(root, key);
    }

    private boolean containsRecursive(TreeNode node, int key) {
        if (node == null) return false;
        if (key == node.key) return true;
        if (key < node.key) return containsRecursive(node.left, key);
        return containsRecursive(node.right, key);
    }

    public void inorderTraversal() {
        System.out.print("Inorder: ");
        inorderHelper(root);
        System.out.println();
    }

    private void inorderHelper(TreeNode node) {
        if (node == null) return;
        inorderHelper(node.left);
        System.out.print(node.key + " ");
        inorderHelper(node.right);
    }

    public void preorderTraversal() {
        System.out.print("Preorder: ");
        preorderHelper(root);
        System.out.println();
    }

    private void preorderHelper(TreeNode node) {
        if (node == null) return;
        System.out.print(node.key + " ");
        preorderHelper(node.left);
        preorderHelper(node.right);
    }

    public int findMin() {
        if (root == null) throw new IllegalStateException("Tree is empty");
        TreeNode current = root;
        while (current.left != null) {
            current = current.left;
        }
        return current.key;
    }

    public int findMax() {
        if (root == null) throw new IllegalStateException("Tree is empty");
        TreeNode current = root;
        while (current.right != null) {
            current = current.right;
        }
        return current.key;
    }

    public int height() {
        return heightHelper(root);
    }

    private int heightHelper(TreeNode node) {
        if (node == null) return -1;
        int leftH = heightHelper(node.left);
        int rightH = heightHelper(node.right);
        return 1 + Math.max(leftH, rightH);
    }

    public int countNodes() {
        return countHelper(root);
    }

    private int countHelper(TreeNode node) {
        if (node == null) return 0;
        return 1 + countHelper(node.left) + countHelper(node.right);
    }

    public void delete(int key) {
        root = deleteRecursive(root, key);
    }

    private TreeNode deleteRecursive(TreeNode node, int key) {
        if (node == null) return null;
        if (key < node.key) {
            node.left = deleteRecursive(node.left, key);
        } else if (key > node.key) {
            node.right = deleteRecursive(node.right, key);
        } else {
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;
            TreeNode successor = node.right;
            while (successor.left != null) {
                successor = successor.left;
            }
            node.key = successor.key;
            node.right = deleteRecursive(node.right, successor.key);
        }
        return node;
    }

    public static void main(String[] args) {
        BinarySearchTree bst = new BinarySearchTree();
        int[] values = {50, 30, 70, 20, 40, 60, 80, 10, 25, 35};
        for (int v : values) {
            bst.insert(v);
        }
        bst.inorderTraversal();
        bst.preorderTraversal();
        System.out.println("Contains 40: " + bst.contains(40));
        System.out.println("Contains 99: " + bst.contains(99));
        System.out.println("Min: " + bst.findMin());
        System.out.println("Max: " + bst.findMax());
        System.out.println("Height: " + bst.height());
        System.out.println("Nodes: " + bst.countNodes());
        bst.delete(30);
        System.out.println("After deleting 30:");
        bst.inorderTraversal();
    }
}
