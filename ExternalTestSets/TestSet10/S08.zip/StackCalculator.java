public class StackCalculator {
    private int[] stack;
    private int top;
    private int capacity;

    public StackCalculator(int capacity) {
        this.capacity = capacity;
        this.stack = new int[capacity];
        this.top = -1;
    }

    public void push(int value) {
        if (top >= capacity - 1) {
            throw new RuntimeException("Stack overflow");
        }
        stack[++top] = value;
    }

    public int pop() {
        if (top < 0) {
            throw new RuntimeException("Stack underflow");
        }
        return stack[top--];
    }

    public int peek() {
        if (top < 0) {
            throw new RuntimeException("Stack is empty");
        }
        return stack[top];
    }

    public boolean isEmpty() {
        return top < 0;
    }

    public int size() {
        return top + 1;
    }

    public static int precedence(char op) {
        switch (op) {
            case '+': case '-': return 1;
            case '*': case '/': return 2;
            case '^': return 3;
            default: return 0;
        }
    }

    public static boolean isOperator(char ch) {
        return ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '^';
    }

    public static int applyOp(int left, int right, char op) {
        switch (op) {
            case '+': return left + right;
            case '-': return left - right;
            case '*': return left * right;
            case '/':
                if (right == 0) throw new ArithmeticException("Division by zero");
                return left / right;
            case '^': return (int) Math.pow(left, right);
            default: throw new IllegalArgumentException("Unknown operator: " + op);
        }
    }

    public static int evaluatePostfix(String expression) {
        StackCalculator evalStack = new StackCalculator(100);
        String[] tokens = expression.trim().split("\\s+");
        for (String token : tokens) {
            if (token.length() == 1 && isOperator(token.charAt(0))) {
                int right = evalStack.pop();
                int left = evalStack.pop();
                int result = applyOp(left, right, token.charAt(0));
                evalStack.push(result);
            } else {
                evalStack.push(Integer.parseInt(token));
            }
        }
        return evalStack.pop();
    }

    public static String infixToPostfix(String expression) {
        StringBuilder output = new StringBuilder();
        StackCalculator opStack = new StackCalculator(100);
        String[] tokens = expression.trim().split("\\s+");
        for (String token : tokens) {
            if (token.equals("(")) {
                opStack.push('(');
            } else if (token.equals(")")) {
                while (!opStack.isEmpty() && (char) opStack.peek() != '(') {
                    output.append((char) opStack.pop()).append(' ');
                }
                if (!opStack.isEmpty()) opStack.pop();
            } else if (token.length() == 1 && isOperator(token.charAt(0))) {
                char op = token.charAt(0);
                while (!opStack.isEmpty() && precedence((char) opStack.peek()) >= precedence(op)) {
                    output.append((char) opStack.pop()).append(' ');
                }
                opStack.push(op);
            } else {
                output.append(token).append(' ');
            }
        }
        while (!opStack.isEmpty()) {
            output.append((char) opStack.pop()).append(' ');
        }
        return output.toString().trim();
    }

    public void printStack() {
        System.out.print("Stack [bottom -> top]: ");
        for (int i = 0; i <= top; i++) {
            System.out.print(stack[i] + " ");
        }
        System.out.println();
    }

    public static void main(String[] args) {
        StackCalculator sc = new StackCalculator(20);
        for (int i = 1; i <= 8; i++) {
            sc.push(i * 10);
        }
        sc.printStack();
        System.out.println("Pop: " + sc.pop());
        System.out.println("Peek: " + sc.peek());
        System.out.println("Size: " + sc.size());
        String postfix = "3 4 + 2 * 7 /";
        System.out.println("Postfix '" + postfix + "' = " + evaluatePostfix(postfix));
        String infix = "3 + 4 * 2 / ( 1 - 5 )";
        String converted = infixToPostfix(infix);
        System.out.println("Infix: " + infix);
        System.out.println("Postfix: " + converted);
    }
}
