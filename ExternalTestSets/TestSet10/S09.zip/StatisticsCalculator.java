public class StatisticsCalculator {
    private double[] data;
    private int count;
    private int capacity;

    public StatisticsCalculator(int capacity) {
        this.capacity = capacity;
        this.data = new double[capacity];
        this.count = 0;
    }

    public void addValue(double value) {
        if (count >= capacity) {
            int newCap = capacity * 2;
            double[] newData = new double[newCap];
            for (int i = 0; i < count; i++) {
                newData[i] = data[i];
            }
            data = newData;
            capacity = newCap;
        }
        data[count++] = value;
    }

    public double mean() {
        if (count == 0) throw new IllegalStateException("No data");
        double sum = 0;
        for (int i = 0; i < count; i++) {
            sum += data[i];
        }
        return sum / count;
    }

    public double median() {
        if (count == 0) throw new IllegalStateException("No data");
        double[] sorted = getSorted();
        if (count % 2 == 0) {
            return (sorted[count / 2 - 1] + sorted[count / 2]) / 2.0;
        }
        return sorted[count / 2];
    }

    public double variance() {
        if (count < 2) throw new IllegalStateException("Need at least 2 values");
        double avg = mean();
        double sumSqDiff = 0;
        for (int i = 0; i < count; i++) {
            double diff = data[i] - avg;
            sumSqDiff += diff * diff;
        }
        return sumSqDiff / (count - 1);
    }

    public double standardDeviation() {
        return Math.sqrt(variance());
    }

    public double min() {
        if (count == 0) throw new IllegalStateException("No data");
        double minVal = data[0];
        for (int i = 1; i < count; i++) {
            if (data[i] < minVal) minVal = data[i];
        }
        return minVal;
    }

    public double max() {
        if (count == 0) throw new IllegalStateException("No data");
        double maxVal = data[0];
        for (int i = 1; i < count; i++) {
            if (data[i] > maxVal) maxVal = data[i];
        }
        return maxVal;
    }

    public double range() {
        return max() - min();
    }

    public double percentile(double p) {
        if (p < 0 || p > 100) throw new IllegalArgumentException("Percentile must be 0-100");
        if (count == 0) throw new IllegalStateException("No data");
        double[] sorted = getSorted();
        double rank = (p / 100.0) * (count - 1);
        int lower = (int) Math.floor(rank);
        int upper = (int) Math.ceil(rank);
        if (lower == upper) return sorted[lower];
        double fraction = rank - lower;
        return sorted[lower] + fraction * (sorted[upper] - sorted[lower]);
    }

    private double[] getSorted() {
        double[] sorted = new double[count];
        for (int i = 0; i < count; i++) {
            sorted[i] = data[i];
        }
        for (int i = 0; i < count - 1; i++) {
            for (int j = 0; j < count - i - 1; j++) {
                if (sorted[j] > sorted[j + 1]) {
                    double temp = sorted[j];
                    sorted[j] = sorted[j + 1];
                    sorted[j + 1] = temp;
                }
            }
        }
        return sorted;
    }

    public int getCount() {
        return count;
    }

    public void printSummary() {
        System.out.println("=== Statistical Summary ===");
        System.out.println("Count: " + count);
        System.out.printf("Mean: %.4f%n", mean());
        System.out.printf("Median: %.4f%n", median());
        System.out.printf("Std Dev: %.4f%n", standardDeviation());
        System.out.printf("Variance: %.4f%n", variance());
        System.out.printf("Min: %.4f%n", min());
        System.out.printf("Max: %.4f%n", max());
        System.out.printf("Range: %.4f%n", range());
        System.out.printf("25th Percentile: %.4f%n", percentile(25));
        System.out.printf("75th Percentile: %.4f%n", percentile(75));
    }

    public static void main(String[] args) {
        StatisticsCalculator calc = new StatisticsCalculator(10);
        double[] values = {23.5, 45.1, 12.8, 67.3, 34.9, 56.7, 28.4, 41.2, 39.6, 51.0,
                           18.3, 62.1, 44.7, 31.5, 55.8, 20.9, 48.3, 37.6, 59.2, 26.1};
        for (double v : values) {
            calc.addValue(v);
        }
        calc.printSummary();
    }
}
