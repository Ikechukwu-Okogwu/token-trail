public class GraphTraversal {
    private int vertices;
    private int[][] adjacency;
    private boolean directed;

    public GraphTraversal(int vertices, boolean directed) {
        this.vertices = vertices;
        this.directed = directed;
        this.adjacency = new int[vertices][vertices];
    }

    public void addEdge(int from, int to) {
        if (from < 0 || from >= vertices || to < 0 || to >= vertices) {
            throw new IllegalArgumentException("Invalid vertex");
        }
        adjacency[from][to] = 1;
        if (!directed) {
            adjacency[to][from] = 1;
        }
    }

    public void bfs(int start) {
        if (start < 0 || start >= vertices) {
            throw new IllegalArgumentException("Invalid start vertex");
        }
        boolean[] visited = new boolean[vertices];
        int[] queue = new int[vertices];
        int front = 0, rear = 0;
        visited[start] = true;
        queue[rear++] = start;
        System.out.print("BFS from " + start + ": ");
        while (front < rear) {
            int current = queue[front++];
            System.out.print(current + " ");
            for (int neighbor = 0; neighbor < vertices; neighbor++) {
                if (adjacency[current][neighbor] == 1 && !visited[neighbor]) {
                    visited[neighbor] = true;
                    queue[rear++] = neighbor;
                }
            }
        }
        System.out.println();
    }

    public void dfs(int start) {
        if (start < 0 || start >= vertices) {
            throw new IllegalArgumentException("Invalid start vertex");
        }
        boolean[] visited = new boolean[vertices];
        System.out.print("DFS from " + start + ": ");
        dfsHelper(start, visited);
        System.out.println();
    }

    private void dfsHelper(int vertex, boolean[] visited) {
        visited[vertex] = true;
        System.out.print(vertex + " ");
        for (int neighbor = 0; neighbor < vertices; neighbor++) {
            if (adjacency[vertex][neighbor] == 1 && !visited[neighbor]) {
                dfsHelper(neighbor, visited);
            }
        }
    }

    public boolean hasPath(int from, int to) {
        if (from < 0 || from >= vertices || to < 0 || to >= vertices) {
            return false;
        }
        boolean[] visited = new boolean[vertices];
        return hasPathDFS(from, to, visited);
    }

    private boolean hasPathDFS(int current, int target, boolean[] visited) {
        if (current == target) return true;
        visited[current] = true;
        for (int neighbor = 0; neighbor < vertices; neighbor++) {
            if (adjacency[current][neighbor] == 1 && !visited[neighbor]) {
                if (hasPathDFS(neighbor, target, visited)) {
                    return true;
                }
            }
        }
        return false;
    }

    public int countConnectedComponents() {
        boolean[] visited = new boolean[vertices];
        int components = 0;
        for (int v = 0; v < vertices; v++) {
            if (!visited[v]) {
                dfsMarkComponent(v, visited);
                components++;
            }
        }
        return components;
    }

    private void dfsMarkComponent(int vertex, boolean[] visited) {
        visited[vertex] = true;
        for (int neighbor = 0; neighbor < vertices; neighbor++) {
            if (adjacency[vertex][neighbor] == 1 && !visited[neighbor]) {
                dfsMarkComponent(neighbor, visited);
            }
        }
    }

    public int[] shortestPath(int start) {
        int[] dist = new int[vertices];
        boolean[] visited = new boolean[vertices];
        for (int i = 0; i < vertices; i++) {
            dist[i] = Integer.MAX_VALUE;
        }
        dist[start] = 0;
        int[] queue = new int[vertices];
        int front = 0, rear = 0;
        visited[start] = true;
        queue[rear++] = start;
        while (front < rear) {
            int current = queue[front++];
            for (int neighbor = 0; neighbor < vertices; neighbor++) {
                if (adjacency[current][neighbor] == 1 && !visited[neighbor]) {
                    visited[neighbor] = true;
                    dist[neighbor] = dist[current] + 1;
                    queue[rear++] = neighbor;
                }
            }
        }
        return dist;
    }

    public void printAdjacencyMatrix() {
        System.out.println("Adjacency Matrix:");
        for (int i = 0; i < vertices; i++) {
            for (int j = 0; j < vertices; j++) {
                System.out.print(adjacency[i][j] + " ");
            }
            System.out.println();
        }
    }

    public static void main(String[] args) {
        GraphTraversal graph = new GraphTraversal(8, false);
        graph.addEdge(0, 1);
        graph.addEdge(0, 2);
        graph.addEdge(1, 3);
        graph.addEdge(1, 4);
        graph.addEdge(2, 5);
        graph.addEdge(3, 6);
        graph.addEdge(4, 7);
        graph.printAdjacencyMatrix();
        graph.bfs(0);
        graph.dfs(0);
        System.out.println("Path 0->7: " + graph.hasPath(0, 7));
        System.out.println("Path 5->6: " + graph.hasPath(5, 6));
        System.out.println("Components: " + graph.countConnectedComponents());
        int[] distances = graph.shortestPath(0);
        System.out.print("Distances from 0: ");
        for (int d : distances) {
            System.out.print((d == Integer.MAX_VALUE ? "INF" : d) + " ");
        }
        System.out.println();
    }
}
