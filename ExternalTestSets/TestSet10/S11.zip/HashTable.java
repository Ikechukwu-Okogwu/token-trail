public class HashTable {
    private int[] keys;
    private int[] values;
    private boolean[] occupied;
    private int capacity;
    private int size;

    public HashTable(int capacity) {
        this.capacity = capacity;
        this.keys = new int[capacity];
        this.values = new int[capacity];
        this.occupied = new boolean[capacity];
        this.size = 0;
    }

    private int hash(int key) {
        int h = key % capacity;
        if (h < 0) h += capacity;
        return h;
    }

    public void put(int key, int value) {
        if (size >= capacity * 3 / 4) {
            resize();
        }
        int index = hash(key);
        int startIndex = index;
        while (occupied[index]) {
            if (keys[index] == key) {
                values[index] = value;
                return;
            }
            index = (index + 1) % capacity;
            if (index == startIndex) {
                resize();
                put(key, value);
                return;
            }
        }
        keys[index] = key;
        values[index] = value;
        occupied[index] = true;
        size++;
    }

    public int get(int key) {
        int index = hash(key);
        int startIndex = index;
        while (occupied[index]) {
            if (keys[index] == key) {
                return values[index];
            }
            index = (index + 1) % capacity;
            if (index == startIndex) break;
        }
        throw new RuntimeException("Key not found: " + key);
    }

    public boolean containsKey(int key) {
        int index = hash(key);
        int startIndex = index;
        while (occupied[index]) {
            if (keys[index] == key) {
                return true;
            }
            index = (index + 1) % capacity;
            if (index == startIndex) break;
        }
        return false;
    }

    public boolean remove(int key) {
        int index = hash(key);
        int startIndex = index;
        while (occupied[index]) {
            if (keys[index] == key) {
                occupied[index] = false;
                size--;
                rehashCluster(index);
                return true;
            }
            index = (index + 1) % capacity;
            if (index == startIndex) break;
        }
        return false;
    }

    private void rehashCluster(int removedIndex) {
        int index = (removedIndex + 1) % capacity;
        while (occupied[index]) {
            int k = keys[index];
            int v = values[index];
            occupied[index] = false;
            size--;
            put(k, v);
            index = (index + 1) % capacity;
        }
    }

    private void resize() {
        int oldCap = capacity;
        int[] oldKeys = keys;
        int[] oldValues = values;
        boolean[] oldOccupied = occupied;
        capacity = capacity * 2;
        keys = new int[capacity];
        values = new int[capacity];
        occupied = new boolean[capacity];
        size = 0;
        for (int i = 0; i < oldCap; i++) {
            if (oldOccupied[i]) {
                put(oldKeys[i], oldValues[i]);
            }
        }
    }

    public int getSize() {
        return size;
    }

    public double loadFactor() {
        return (double) size / capacity;
    }

    public void printTable() {
        System.out.println("Hash Table (capacity=" + capacity + ", size=" + size + "):");
        for (int i = 0; i < capacity; i++) {
            if (occupied[i]) {
                System.out.println("  [" + i + "] " + keys[i] + " => " + values[i]);
            }
        }
    }

    public int[] getAllKeys() {
        int[] result = new int[size];
        int idx = 0;
        for (int i = 0; i < capacity; i++) {
            if (occupied[i]) {
                result[idx++] = keys[i];
            }
        }
        return result;
    }

    public static void main(String[] args) {
        HashTable table = new HashTable(16);
        for (int i = 0; i < 20; i++) {
            table.put(i * 7, i * 100);
        }
        table.printTable();
        System.out.println("Size: " + table.getSize());
        System.out.printf("Load factor: %.2f%n", table.loadFactor());
        System.out.println("Get key 14: " + table.get(14));
        System.out.println("Contains 21: " + table.containsKey(21));
        System.out.println("Contains 999: " + table.containsKey(999));
        table.remove(14);
        System.out.println("After removing 14, contains 14: " + table.containsKey(14));
        System.out.println("Size: " + table.getSize());
    }
}
