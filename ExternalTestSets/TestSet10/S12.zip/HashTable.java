public class HashTable {
    private Entry[] buckets;
    private int capacity;
    private int size;

    private static class Entry {
        int key;
        int value;
        Entry next;
        Entry(int key, int value) {
            this.key = key;
            this.value = value;
            this.next = null;
        }
    }

    public HashTable(int capacity) {
        this.capacity = capacity;
        this.buckets = new Entry[capacity];
        this.size = 0;
    }

    private int hash(int key) {
        int h = key % capacity;
        if (h < 0) h += capacity;
        return h;
    }

    public void put(int key, int value) {
        if (size >= capacity * 3 / 4) {
            resize();
        }
        int index = hash(key);
        Entry current = buckets[index];
        while (current != null) {
            if (current.key == key) {
                current.value = value;
                return;
            }
            current = current.next;
        }
        Entry newEntry = new Entry(key, value);
        newEntry.next = buckets[index];
        buckets[index] = newEntry;
        size++;
    }

    public int get(int key) {
        int index = hash(key);
        Entry current = buckets[index];
        while (current != null) {
            if (current.key == key) {
                return current.value;
            }
            current = current.next;
        }
        throw new RuntimeException("Key not found: " + key);
    }

    public boolean containsKey(int key) {
        int index = hash(key);
        Entry current = buckets[index];
        while (current != null) {
            if (current.key == key) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    public boolean remove(int key) {
        int index = hash(key);
        Entry prev = null;
        Entry current = buckets[index];
        while (current != null) {
            if (current.key == key) {
                if (prev == null) {
                    buckets[index] = current.next;
                } else {
                    prev.next = current.next;
                }
                size--;
                return true;
            }
            prev = current;
            current = current.next;
        }
        return false;
    }

    private void resize() {
        int oldCap = capacity;
        Entry[] oldBuckets = buckets;
        capacity = capacity * 2;
        buckets = new Entry[capacity];
        size = 0;
        for (int i = 0; i < oldCap; i++) {
            Entry current = oldBuckets[i];
            while (current != null) {
                put(current.key, current.value);
                current = current.next;
            }
        }
    }

    public int getSize() {
        return size;
    }

    public double loadFactor() {
        return (double) size / capacity;
    }

    public void printTable() {
        System.out.println("Hash Table (capacity=" + capacity + ", size=" + size + "):");
        for (int i = 0; i < capacity; i++) {
            if (buckets[i] != null) {
                System.out.print("  [" + i + "] ");
                Entry current = buckets[i];
                while (current != null) {
                    System.out.print(current.key + "=>" + current.value);
                    if (current.next != null) System.out.print(" -> ");
                    current = current.next;
                }
                System.out.println();
            }
        }
    }

    public int[] getAllKeys() {
        int[] result = new int[size];
        int idx = 0;
        for (int i = 0; i < capacity; i++) {
            Entry current = buckets[i];
            while (current != null) {
                result[idx++] = current.key;
                current = current.next;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        HashTable table = new HashTable(16);
        for (int i = 0; i < 20; i++) {
            table.put(i * 7, i * 100);
        }
        table.printTable();
        System.out.println("Size: " + table.getSize());
        System.out.printf("Load factor: %.2f%n", table.loadFactor());
        System.out.println("Get key 14: " + table.get(14));
        System.out.println("Contains 21: " + table.containsKey(21));
        System.out.println("Contains 999: " + table.containsKey(999));
        table.remove(14);
        System.out.println("After removing 14, contains 14: " + table.containsKey(14));
        System.out.println("Size: " + table.getSize());
    }
}
