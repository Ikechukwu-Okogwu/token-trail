public class StringProcessor {
    private char[] buffer;
    private int length;

    public StringProcessor(String input) {
        this.buffer = input.toCharArray();
        this.length = buffer.length;
    }

    public String reverse() {
        char[] result = new char[length];
        for (int i = 0; i < length; i++) {
            result[i] = buffer[length - 1 - i];
        }
        return new String(result);
    }

    public boolean isPalindrome() {
        int left = 0;
        int right = length - 1;
        while (left < right) {
            char lc = Character.toLowerCase(buffer[left]);
            char rc = Character.toLowerCase(buffer[right]);
            if (!Character.isLetterOrDigit(lc)) { left++; continue; }
            if (!Character.isLetterOrDigit(rc)) { right--; continue; }
            if (lc != rc) return false;
            left++;
            right--;
        }
        return true;
    }

    public int countOccurrences(char target) {
        int count = 0;
        for (int i = 0; i < length; i++) {
            if (buffer[i] == target) count++;
        }
        return count;
    }

    public String compress() {
        if (length == 0) return "";
        StringBuilder sb = new StringBuilder();
        char current = buffer[0];
        int count = 1;
        for (int i = 1; i < length; i++) {
            if (buffer[i] == current) {
                count++;
            } else {
                sb.append(current);
                if (count > 1) sb.append(count);
                current = buffer[i];
                count = 1;
            }
        }
        sb.append(current);
        if (count > 1) sb.append(count);
        String compressed = sb.toString();
        return compressed.length() < length ? compressed : new String(buffer);
    }

    public int indexOf(String pattern) {
        char[] pat = pattern.toCharArray();
        int patLen = pat.length;
        if (patLen > length) return -1;
        for (int i = 0; i <= length - patLen; i++) {
            boolean match = true;
            for (int j = 0; j < patLen; j++) {
                if (buffer[i + j] != pat[j]) {
                    match = false;
                    break;
                }
            }
            if (match) return i;
        }
        return -1;
    }

    public String caesarEncrypt(int shift) {
        char[] result = new char[length];
        for (int i = 0; i < length; i++) {
            char ch = buffer[i];
            if (Character.isUpperCase(ch)) {
                result[i] = (char) ((ch - 'A' + shift) % 26 + 'A');
            } else if (Character.isLowerCase(ch)) {
                result[i] = (char) ((ch - 'a' + shift) % 26 + 'a');
            } else {
                result[i] = ch;
            }
        }
        return new String(result);
    }

    public String caesarDecrypt(int shift) {
        return new StringProcessor(new String(buffer)).caesarEncrypt(26 - (shift % 26));
    }

    public int[] charFrequency() {
        int[] freq = new int[128];
        for (int i = 0; i < length; i++) {
            if (buffer[i] < 128) {
                freq[buffer[i]]++;
            }
        }
        return freq;
    }

    public String toUpperCase() {
        char[] result = new char[length];
        for (int i = 0; i < length; i++) {
            result[i] = Character.toUpperCase(buffer[i]);
        }
        return new String(result);
    }

    public static void main(String[] args) {
        StringProcessor sp = new StringProcessor("Hello, World!");
        System.out.println("Original: Hello, World!");
        System.out.println("Reversed: " + sp.reverse());
        System.out.println("Uppercase: " + sp.toUpperCase());
        System.out.println("Count 'l': " + sp.countOccurrences('l'));
        System.out.println("Index of 'World': " + sp.indexOf("World"));
        System.out.println("Caesar +3: " + sp.caesarEncrypt(3));
        StringProcessor sp2 = new StringProcessor("aabcccccaaa");
        System.out.println("Compressed: " + sp2.compress());
        StringProcessor sp3 = new StringProcessor("A man a plan a canal Panama");
        System.out.println("Palindrome: " + sp3.isPalindrome());
    }
}
