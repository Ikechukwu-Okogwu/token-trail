public class CircularQueue {
    private int[] data;
    private int front;
    private int rear;
    private int size;
    private int capacity;

    public CircularQueue(int capacity) {
        this.capacity = capacity;
        this.data = new int[capacity];
        this.front = 0;
        this.rear = -1;
        this.size = 0;
    }

    public void enqueue(int value) {
        if (size >= capacity) {
            resize();
        }
        rear = (rear + 1) % capacity;
        data[rear] = value;
        size++;
    }

    public int dequeue() {
        if (size == 0) {
            throw new RuntimeException("Queue is empty");
        }
        int value = data[front];
        front = (front + 1) % capacity;
        size--;
        return value;
    }

    public int peek() {
        if (size == 0) {
            throw new RuntimeException("Queue is empty");
        }
        return data[front];
    }

    public int peekRear() {
        if (size == 0) {
            throw new RuntimeException("Queue is empty");
        }
        return data[rear];
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public boolean isFull() {
        return size == capacity;
    }

    public int getSize() {
        return size;
    }

    private void resize() {
        int newCapacity = capacity * 2;
        int[] newData = new int[newCapacity];
        for (int i = 0; i < size; i++) {
            newData[i] = data[(front + i) % capacity];
        }
        data = newData;
        front = 0;
        rear = size - 1;
        capacity = newCapacity;
    }

    public boolean contains(int value) {
        for (int i = 0; i < size; i++) {
            if (data[(front + i) % capacity] == value) {
                return true;
            }
        }
        return false;
    }

    public int[] toArray() {
        int[] result = new int[size];
        for (int i = 0; i < size; i++) {
            result[i] = data[(front + i) % capacity];
        }
        return result;
    }

    public void clear() {
        front = 0;
        rear = -1;
        size = 0;
    }

    public void printQueue() {
        System.out.print("Queue [front -> rear]: ");
        for (int i = 0; i < size; i++) {
            System.out.print(data[(front + i) % capacity]);
            if (i < size - 1) System.out.print(", ");
        }
        System.out.println();
    }

    public static int[] simulateJosephus(int n, int k) {
        CircularQueue circle = new CircularQueue(n);
        for (int i = 1; i <= n; i++) {
            circle.enqueue(i);
        }
        int[] elimination = new int[n];
        int idx = 0;
        while (!circle.isEmpty()) {
            for (int step = 1; step < k; step++) {
                circle.enqueue(circle.dequeue());
            }
            elimination[idx++] = circle.dequeue();
        }
        return elimination;
    }

    public static void main(String[] args) {
        CircularQueue queue = new CircularQueue(4);
        for (int i = 10; i <= 80; i += 10) {
            queue.enqueue(i);
        }
        queue.printQueue();
        System.out.println("Size: " + queue.getSize());
        System.out.println("Front: " + queue.peek());
        System.out.println("Rear: " + queue.peekRear());
        System.out.println("Dequeue: " + queue.dequeue());
        System.out.println("Dequeue: " + queue.dequeue());
        queue.printQueue();
        System.out.println("Contains 50: " + queue.contains(50));
        System.out.println("Contains 10: " + queue.contains(10));
        System.out.print("Josephus(7,3): ");
        int[] order = simulateJosephus(7, 3);
        for (int v : order) System.out.print(v + " ");
        System.out.println();
    }
}
