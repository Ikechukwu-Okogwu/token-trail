public class PriorityHeap {
    private int[] heap;
    private int size;
    private int capacity;
    private boolean isMinHeap;

    public PriorityHeap(int capacity, boolean isMinHeap) {
        this.capacity = capacity;
        this.heap = new int[capacity];
        this.size = 0;
        this.isMinHeap = isMinHeap;
    }

    private int parent(int i) { return (i - 1) / 2; }
    private int leftChild(int i) { return 2 * i + 1; }
    private int rightChild(int i) { return 2 * i + 2; }

    private boolean compare(int a, int b) {
        return isMinHeap ? a < b : a > b;
    }

    private void swap(int i, int j) {
        int temp = heap[i];
        heap[i] = heap[j];
        heap[j] = temp;
    }

    public void insert(int value) {
        if (size >= capacity) {
            int newCap = capacity * 2;
            int[] newHeap = new int[newCap];
            for (int i = 0; i < size; i++) {
                newHeap[i] = heap[i];
            }
            heap = newHeap;
            capacity = newCap;
        }
        heap[size] = value;
        siftUp(size);
        size++;
    }

    private void siftUp(int index) {
        while (index > 0 && compare(heap[index], heap[parent(index)])) {
            swap(index, parent(index));
            index = parent(index);
        }
    }

    public int extractTop() {
        if (size == 0) {
            throw new RuntimeException("Heap is empty");
        }
        int top = heap[0];
        heap[0] = heap[size - 1];
        size--;
        if (size > 0) {
            siftDown(0);
        }
        return top;
    }

    private void siftDown(int index) {
        while (true) {
            int best = index;
            int left = leftChild(index);
            int right = rightChild(index);
            if (left < size && compare(heap[left], heap[best])) {
                best = left;
            }
            if (right < size && compare(heap[right], heap[best])) {
                best = right;
            }
            if (best == index) break;
            swap(index, best);
            index = best;
        }
    }

    public int peekTop() {
        if (size == 0) {
            throw new RuntimeException("Heap is empty");
        }
        return heap[0];
    }

    public int getSize() { return size; }
    public boolean isEmpty() { return size == 0; }

    public static int[] heapSort(int[] arr) {
        PriorityHeap minHeap = new PriorityHeap(arr.length, true);
        for (int val : arr) {
            minHeap.insert(val);
        }
        int[] sorted = new int[arr.length];
        for (int i = 0; i < arr.length; i++) {
            sorted[i] = minHeap.extractTop();
        }
        return sorted;
    }

    public static int kthSmallest(int[] arr, int k) {
        PriorityHeap maxHeap = new PriorityHeap(k + 1, false);
        for (int val : arr) {
            maxHeap.insert(val);
            if (maxHeap.getSize() > k) {
                maxHeap.extractTop();
            }
        }
        return maxHeap.peekTop();
    }

    public void printHeap() {
        System.out.print("Heap: [");
        for (int i = 0; i < size; i++) {
            System.out.print(heap[i]);
            if (i < size - 1) System.out.print(", ");
        }
        System.out.println("]");
    }

    public static void main(String[] args) {
        PriorityHeap minHeap = new PriorityHeap(10, true);
        int[] values = {45, 20, 14, 12, 31, 7, 11, 28, 33, 17};
        for (int v : values) {
            minHeap.insert(v);
        }
        minHeap.printHeap();
        System.out.println("Top: " + minHeap.peekTop());
        System.out.println("Extract: " + minHeap.extractTop());
        System.out.println("Extract: " + minHeap.extractTop());
        minHeap.printHeap();
        int[] data = {64, 34, 25, 12, 22, 11, 90, 1};
        int[] sorted = heapSort(data);
        System.out.print("Heap sorted: ");
        for (int v : sorted) System.out.print(v + " ");
        System.out.println();
        System.out.println("3rd smallest: " + kthSmallest(data, 3));
    }
}
