#include <stdlib.h>
#include <stdio.h>

int main() {
    char arr[200];
    int n = atoi(getenv("CONTENT_LENGTH"));
    fgets(arr,n+1,stdin);

    // FILE *fptr;

    // fptr = fopen("users.csv", "r");

    printf("Content-Type:text/html\n\n");

	printf("<html><body>");
	printf("<h1>%s</h1>", arr);
	printf("</body></html>");

    // fclose(fptr);

	return 0;
}