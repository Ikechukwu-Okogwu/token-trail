#include <stdlib.h>
#include <stdio.h>

int main() {
    char string[200];
    char original[200];
    char c, first, second;
    int a = 0, b = 0, result;
    int n = atoi(getenv("CONTENT_LENGTH"));

    while ((c = getchar()) != EOF && a<n) {
        original[b] = c;
        b++;
        if (a < n) {
            if (c=='+') string[a]=' '; 
            else if (c=='%') {
                first = getchar();
                original[b] = first;
                b++;
                second= getchar();
                original[b] = second;
                b++;

                result = 0;
                if (first>='A'&&first<='F') result = 16 * (10+first-'A');
                else result=16*(first-'0');

                if (second>='A'&&second<='F') result+=(10+second-'A');
                else result += (second-'0');

                string[a] = (char) result;
            } else {
                string[a]=c;
            }
            
            a++;
        }
    }

    string[a] = '\0';
    original[b] = '\0';

    printf("Content-Type: text/html\n\n");
    printf("%s<br>", original);
    printf("%s<br>", string);
    printf("%c %c %d", first, second, result);

    return 0;
}
