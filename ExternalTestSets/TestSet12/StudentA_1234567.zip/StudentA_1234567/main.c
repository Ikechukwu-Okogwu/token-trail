#include <stdio.h>
#include <stdlib.h>

#define LIMIT 100

int read_numbers(int values[], int limit);
void print_numbers(int values[], int count);
void print_separator(void);
void print_title(void);
void print_summary_banner(void);

int compute_sum(int values[], int count);
int compute_minimum(int values[], int count);
int compute_maximum(int values[], int count);
int compute_even_count(int values[], int count);
int compute_odd_count(int values[], int count);
double compute_average(int values[], int count);
int compute_range_value(int values[], int count);

void print_intro_message(void);
void print_exit_message(void);
void print_result_block(
    int values[],
    int count
);

int main(void) {
    int values[LIMIT];
    int count;
    int status;

    print_title();
    print_intro_message();
    print_separator();

    count = read_numbers(values, LIMIT);

    if (count < 0) {
        printf("Input error encountered.\n");
        return 1;
    }

    if (count == 0) {
        printf("No numbers were provided.\n");
        print_exit_message();
        return 0;
    }

    print_separator();
    printf("Numbers entered:\n");
    print_numbers(values, count);

    print_separator();
    print_summary_banner();
    print_result_block(values, count);

    print_separator();
    status = 0;

    if (status == 0) {
        print_exit_message();
    }

    return status;
}

void print_title(void) {
    printf("Integer Statistics Program\n");
}

void print_intro_message(void) {
    printf("This program reads integers and prints several statistics.\n");
    printf("You may enter between 1 and %d values.\n", LIMIT);
}

void print_exit_message(void) {
    printf("Program finished.\n");
}

void print_separator(void) {
    printf("----------------------------------------\n");
}

void print_summary_banner(void) {
    printf("Computed Results\n");
}

int read_numbers(int values[], int limit) {
    int count;
    int index;
    int scan_result;

    printf("How many integers would you like to enter? ");
    scan_result = scanf("%d", &count);

    if (scan_result != 1) {
        return -1;
    }

    if (count < 0 || count > limit) {
        return -1;
    }

    if (count == 0) {
        return 0;
    }

    for (index = 0; index < count; index++) {
        printf("Enter integer %d: ", index + 1);
        scan_result = scanf("%d", &values[index]);

        if (scan_result != 1) {
            return -1;
        }
    }

    return count;
}

void print_numbers(int values[], int count) {
    int index;

    for (index = 0; index < count; index++) {
        printf("values[%d] = %d\n", index, values[index]);
    }
}

void print_result_block(int values[], int count) {
    int sum_value;
    int min_value;
    int max_value;
    int range_value;
    int even_total;
    int odd_total;
    double average_value;

    sum_value = compute_sum(values, count);
    min_value = compute_minimum(values, count);
    max_value = compute_maximum(values, count);
    range_value = compute_range_value(values, count);
    even_total = compute_even_count(values, count);
    odd_total = compute_odd_count(values, count);
    average_value = compute_average(values, count);

    printf("Count: %d\n", count);
    printf("Sum: %d\n", sum_value);
    printf("Average: %.2f\n", average_value);
    printf("Minimum: %d\n", min_value);
    printf("Maximum: %d\n", max_value);
    printf("Range: %d\n", range_value);
    printf("Even numbers: %d\n", even_total);
    printf("Odd numbers: %d\n", odd_total);

    if (count > 0) {
        printf("Result block printed successfully.\n");
    }

    if (sum_value == 0) {
        printf("Note: the total sum is zero.\n");
    } else {
        printf("Note: the total sum is non-zero.\n");
    }
}