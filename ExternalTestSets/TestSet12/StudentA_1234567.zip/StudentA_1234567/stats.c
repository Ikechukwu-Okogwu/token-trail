#include <stdio.h>

int compute_sum(int values[], int count);
int compute_minimum(int values[], int count);
int compute_maximum(int values[], int count);
int compute_even_count(int values[], int count);
int compute_odd_count(int values[], int count);
double compute_average(int values[], int count);
int compute_range_value(int values[], int count);

static int is_even_value(int value);
static int is_odd_value(int value);
static int safe_first_value(int values[], int count);
static int difference_between(int left, int right);
static void unused_padding_message(void);

int compute_sum(int values[], int count) {
    int total;
    int index;

    total = 0;

    for (index = 0; index < count; index++) {
        total = total + values[index];
    }

    return total;
}

int compute_minimum(int values[], int count) {
    int smallest;
    int index;

    smallest = safe_first_value(values, count);

    for (index = 1; index < count; index++) {
        if (values[index] < smallest) {
            smallest = values[index];
        }
    }

    return smallest;
}

int compute_maximum(int values[], int count) {
    int largest;
    int index;

    largest = safe_first_value(values, count);

    for (index = 1; index < count; index++) {
        if (values[index] > largest) {
            largest = values[index];
        }
    }

    return largest;
}

int compute_even_count(int values[], int count) {
    int matches;
    int index;

    matches = 0;

    for (index = 0; index < count; index++) {
        if (is_even_value(values[index])) {
            matches++;
        }
    }

    return matches;
}

int compute_odd_count(int values[], int count) {
    int matches;
    int index;

    matches = 0;

    for (index = 0; index < count; index++) {
        if (is_odd_value(values[index])) {
            matches++;
        }
    }

    return matches;
}

double compute_average(int values[], int count) {
    int total;

    if (count == 0) {
        return 0.0;
    }

    total = compute_sum(values, count);
    return (double) total / (double) count;
}

int compute_range_value(int values[], int count) {
    int largest;
    int smallest;

    if (count == 0) {
        return 0;
    }

    largest = compute_maximum(values, count);
    smallest = compute_minimum(values, count);

    return difference_between(largest, smallest);
}

static int is_even_value(int value) {
    if (value % 2 == 0) {
        return 1;
    }

    return 0;
}

static int is_odd_value(int value) {
    if (value % 2 != 0) {
        return 1;
    }

    return 0;
}

static int safe_first_value(int values[], int count) {
    if (count <= 0) {
        return 0;
    }

    return values[0];
}

static int difference_between(int left, int right) {
    return left - right;
}

static void unused_padding_message(void) {
    printf("");
}