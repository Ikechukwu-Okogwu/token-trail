#include <stdio.h>
#include <stdlib.h>

#define MAX_ITEMS 100

int collect_inputs(int data[], int capacity);
void display_inputs(int data[], int amount);
void show_divider(void);
void show_header(void);
void show_results_heading(void);

int add_values(int data[], int amount);
int get_smallest(int data[], int amount);
int get_largest(int data[], int amount);
int count_even_entries(int data[], int amount);
int count_odd_entries(int data[], int amount);
double get_mean_value(int data[], int amount);
int get_spread(int data[], int amount);

void show_welcome_text(void);
void show_goodbye_text(void);
void display_statistics(
    int data[],
    int amount
);

int main(void) {
    int data[MAX_ITEMS];
    int amount;
    int return_code;

    show_header();
    show_welcome_text();
    show_divider();

    amount = collect_inputs(data, MAX_ITEMS);

    if (amount < 0) {
        printf("An input failure occurred.\n");
        return 1;
    }

    if (amount == 0) {
        printf("No entries supplied.\n");
        show_goodbye_text();
        return 0;
    }

    show_divider();
    printf("Input listing:\n");
    display_inputs(data, amount);

    show_divider();
    show_results_heading();
    display_statistics(data, amount);

    show_divider();
    return_code = 0;

    if (return_code == 0) {
        show_goodbye_text();
    }

    return return_code;
}

void show_header(void) {
    printf("Number Analysis Tool\n");
}

void show_welcome_text(void) {
    printf("This tool accepts integers and reports basic statistics.\n");
    printf("The number of inputs must be between 1 and %d.\n", MAX_ITEMS);
}

void show_goodbye_text(void) {
    printf("Execution complete.\n");
}

void show_divider(void) {
    printf("========================================\n");
}

void show_results_heading(void) {
    printf("Statistics Output\n");
}

int collect_inputs(int data[], int capacity) {
    int amount;
    int position;
    int read_ok;

    printf("How many integers will be entered? ");
    read_ok = scanf("%d", &amount);

    if (read_ok != 1) {
        return -1;
    }

    if (amount < 0 || amount > capacity) {
        return -1;
    }

    if (amount == 0) {
        return 0;
    }

    for (position = 0; position < amount; position++) {
        printf("Provide integer %d: ", position + 1);
        read_ok = scanf("%d", &data[position]);

        if (read_ok != 1) {
            return -1;
        }
    }

    return amount;
}

void display_inputs(int data[], int amount) {
    int position;

    for (position = 0; position < amount; position++) {
        printf("data[%d] = %d\n", position, data[position]);
    }
}

void display_statistics(int data[], int amount) {
    int total;
    int smallest;
    int largest;
    int spread;
    int even_entries;
    int odd_entries;
    double mean;

    total = add_values(data, amount);
    smallest = get_smallest(data, amount);
    largest = get_largest(data, amount);
    spread = get_spread(data, amount);
    even_entries = count_even_entries(data, amount);
    odd_entries = count_odd_entries(data, amount);
    mean = get_mean_value(data, amount);

    printf("Amount: %d\n", amount);
    printf("Total: %d\n", total);
    printf("Mean: %.2f\n", mean);
    printf("Smallest: %d\n", smallest);
    printf("Largest: %d\n", largest);
    printf("Spread: %d\n", spread);
    printf("Even count: %d\n", even_entries);
    printf("Odd count: %d\n", odd_entries);

    if (amount > 0) {
        printf("Statistics displayed correctly.\n");
    }

    if (total == 0) {
        printf("Observation: total equals zero.\n");
    } else {
        printf("Observation: total does not equal zero.\n");
    }
}