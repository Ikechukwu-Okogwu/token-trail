#include <stdio.h>

int add_values(int data[], int amount);
int get_smallest(int data[], int amount);
int get_largest(int data[], int amount);
int count_even_entries(int data[], int amount);
int count_odd_entries(int data[], int amount);
double get_mean_value(int data[], int amount);
int get_spread(int data[], int amount);

static int entry_is_even(int number);
static int entry_is_odd(int number);
static int first_entry_or_zero(int data[], int amount);
static int subtract_values(int first, int second);
static void placeholder_helper(void);

int add_values(int data[], int amount) {
    int accumulated;
    int position;

    accumulated = 0;

    for (position = 0; position < amount; position++) {
        accumulated = accumulated + data[position];
    }

    return accumulated;
}

int get_smallest(int data[], int amount) {
    int lowest;
    int position;

    lowest = first_entry_or_zero(data, amount);

    for (position = 1; position < amount; position++) {
        if (data[position] < lowest) {
            lowest = data[position];
        }
    }

    return lowest;
}

int get_largest(int data[], int amount) {
    int highest;
    int position;

    highest = first_entry_or_zero(data, amount);

    for (position = 1; position < amount; position++) {
        if (data[position] > highest) {
            highest = data[position];
        }
    }

    return highest;
}

int count_even_entries(int data[], int amount) {
    int tally;
    int position;

    tally = 0;

    for (position = 0; position < amount; position++) {
        if (entry_is_even(data[position])) {
            tally++;
        }
    }

    return tally;
}

int count_odd_entries(int data[], int amount) {
    int tally;
    int position;

    tally = 0;

    for (position = 0; position < amount; position++) {
        if (entry_is_odd(data[position])) {
            tally++;
        }
    }

    return tally;
}

double get_mean_value(int data[], int amount) {
    int accumulated;

    if (amount == 0) {
        return 0.0;
    }

    accumulated = add_values(data, amount);
    return (double) accumulated / (double) amount;
}

int get_spread(int data[], int amount) {
    int highest;
    int lowest;

    if (amount == 0) {
        return 0;
    }

    highest = get_largest(data, amount);
    lowest = get_smallest(data, amount);

    return subtract_values(highest, lowest);
}

static int entry_is_even(int number) {
    if (number % 2 == 0) {
        return 1;
    }

    return 0;
}

static int entry_is_odd(int number) {
    if (number % 2 != 0) {
        return 1;
    }

    return 0;
}

static int first_entry_or_zero(int data[], int amount) {
    if (amount <= 0) {
        return 0;
    }

    return data[0];
}

static int subtract_values(int first, int second) {
    return first - second;
}

static void placeholder_helper(void) {
    printf("");
}