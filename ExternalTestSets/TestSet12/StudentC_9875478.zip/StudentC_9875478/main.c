#include <stdio.h>
#include <stdlib.h>

#define ARRAY_CAP 100

int fetch_values(int nums[], int max_size);
void output_values(int nums[], int used);
void output_line(void);
void output_name(void);
void output_results_label(void);

int sum_all(int nums[], int used);
int min_of_all(int nums[], int used);
int max_of_all(int nums[], int used);
int number_of_evens(int nums[], int used);
int number_of_odds(int nums[], int used);
double average_of_all(int nums[], int used);
int range_of_all(int nums[], int used);

void output_intro(void);
void output_end(void);
void output_report(
    int nums[],
    int used
);

int main(void) {
    int nums[ARRAY_CAP];
    int used;
    int code;

    output_name();
    output_intro();
    output_line();

    used = fetch_values(nums, ARRAY_CAP);

    if (used < 0) {
        printf("Failed to read valid input.\n");
        return 1;
    }

    if (used == 0) {
        printf("There were no integers entered.\n");
        output_end();
        return 0;
    }

    output_line();
    printf("Stored integers:\n");
    output_values(nums, used);

    output_line();
    output_results_label();
    output_report(nums, used);

    output_line();
    code = 0;

    if (code == 0) {
        output_end();
    }

    return code;
}

void output_name(void) {
    printf("Integer Report Generator\n");
}

void output_intro(void) {
    printf("Enter a set of integers and receive a computed report.\n");
    printf("Allowed amount of integers: 1 to %d.\n", ARRAY_CAP);
}

void output_end(void) {
    printf("Done.\n");
}

void output_line(void) {
    printf("****************************************\n");
}

void output_results_label(void) {
    printf("Generated Report\n");
}

int fetch_values(int nums[], int max_size) {
    int used;
    int i;
    int ok;

    printf("How many integers do you want to store? ");
    ok = scanf("%d", &used);

    if (ok != 1) {
        return -1;
    }

    if (used < 0 || used > max_size) {
        return -1;
    }

    if (used == 0) {
        return 0;
    }

    for (i = 0; i < used; i++) {
        printf("Type integer %d: ", i + 1);
        ok = scanf("%d", &nums[i]);

        if (ok != 1) {
            return -1;
        }
    }

    return used;
}

void output_values(int nums[], int used) {
    int i;

    for (i = 0; i < used; i++) {
        printf("nums[%d] = %d\n", i, nums[i]);
    }
}

void output_report(int nums[], int used) {
    int total_sum;
    int lowest_value;
    int highest_value;
    int range_value;
    int evens;
    int odds;
    double avg_value;

    total_sum = sum_all(nums, used);
    lowest_value = min_of_all(nums, used);
    highest_value = max_of_all(nums, used);
    range_value = range_of_all(nums, used);
    evens = number_of_evens(nums, used);
    odds = number_of_odds(nums, used);
    avg_value = average_of_all(nums, used);

    printf("Used: %d\n", used);
    printf("Sum total: %d\n", total_sum);
    printf("Average value: %.2f\n", avg_value);
    printf("Lowest value: %d\n", lowest_value);
    printf("Highest value: %d\n", highest_value);
    printf("Range value: %d\n", range_value);
    printf("Even entries: %d\n", evens);
    printf("Odd entries: %d\n", odds);

    if (used > 0) {
        printf("Report generation successful.\n");
    }

    if (total_sum == 0) {
        printf("Status: the sum equals zero.\n");
    } else {
        printf("Status: the sum differs from zero.\n");
    }
}