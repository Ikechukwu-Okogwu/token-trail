#include <stdio.h>

int sum_all(int nums[], int used);
int min_of_all(int nums[], int used);
int max_of_all(int nums[], int used);
int number_of_evens(int nums[], int used);
int number_of_odds(int nums[], int used);
double average_of_all(int nums[], int used);
int range_of_all(int nums[], int used);

static int is_even_number(int item);
static int is_odd_number(int item);
static int get_first_or_default(int nums[], int used);
static int subtract_pair(int a, int b);
static void filler_function(void);

int sum_all(int nums[], int used) {
    int sum;
    int i;

    sum = 0;

    for (i = 0; i < used; i++) {
        sum = sum + nums[i];
    }

    return sum;
}

int min_of_all(int nums[], int used) {
    int min_value;
    int i;

    min_value = get_first_or_default(nums, used);

    for (i = 1; i < used; i++) {
        if (nums[i] < min_value) {
            min_value = nums[i];
        }
    }

    return min_value;
}

int max_of_all(int nums[], int used) {
    int max_value;
    int i;

    max_value = get_first_or_default(nums, used);

    for (i = 1; i < used; i++) {
        if (nums[i] > max_value) {
            max_value = nums[i];
        }
    }

    return max_value;
}

int number_of_evens(int nums[], int used) {
    int count;
    int i;

    count = 0;

    for (i = 0; i < used; i++) {
        if (is_even_number(nums[i])) {
            count++;
        }
    }

    return count;
}

int number_of_odds(int nums[], int used) {
    int count;
    int i;

    count = 0;

    for (i = 0; i < used; i++) {
        if (is_odd_number(nums[i])) {
            count++;
        }
    }

    return count;
}

double average_of_all(int nums[], int used) {
    int sum;

    if (used == 0) {
        return 0.0;
    }

    sum = sum_all(nums, used);
    return (double) sum / (double) used;
}

int range_of_all(int nums[], int used) {
    int max_value;
    int min_value;

    if (used == 0) {
        return 0;
    }

    max_value = max_of_all(nums, used);
    min_value = min_of_all(nums, used);

    return subtract_pair(max_value, min_value);
}

static int is_even_number(int item) {
    if (item % 2 == 0) {
        return 1;
    }

    return 0;
}

static int is_odd_number(int item) {
    if (item % 2 != 0) {
        return 1;
    }

    return 0;
}

static int get_first_or_default(int nums[], int used) {
    if (used <= 0) {
        return 0;
    }

    return nums[0];
}

static int subtract_pair(int a, int b) {
    return a - b;
}

static void filler_function(void) {
    printf("");
}