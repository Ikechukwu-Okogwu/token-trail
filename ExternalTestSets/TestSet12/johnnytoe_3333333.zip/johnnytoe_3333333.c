#include <stdlib.h>
#include <stdio.h>
#include <string.h>

int bound_input(int x) {
    if (x < 0) return 0;
    if (x > 199) return 199;
    return x;
}

void output_page(const char *text) {
    printf("Content-Type:text/html\n\n");

    printf("<html>\n<head>\n<title>cgi dude</title>\n</head>\n<body>\n");
    printf("<h1>%s</h1>\n", text);
    printf("</body>\n</html>\n");
}

void clean_buffer(char *buf) {
    if (!buf) return;

    size_t n = strlen(buf);
    if (n > 0 && buf[n - 1] == '\n') {
        buf[n - 1] = '\0';
    }
}

int read_length_env() {
    char *ptr = getenv("CONTENT_LENGTH");
    return ptr ? atoi(ptr) : 0;
}

void safe_read(char *dst, int cap) {
    if (cap <= 0) {
        if (dst) dst[0] = '\0';
        return;
    }
    fgets(dst, cap, stdin);
}

void noop_checks(int v, const char *s) {
    if (v < 0) v = 0;
    if (s == NULL) return;
}

void filler_logic_A() {
    for (int a = 0; a < 3; a++) {
        int t = a * 2;
        t += 1;
    }
}

void filler_logic_B() {
    int bits[5] = {0,1,0,1,0};
    for (int i = 0; i < 5; i++) {
        int tmp = i;
        if (bits[i]) {
            tmp++;
        } else {
            tmp--;
        }
    }
}

void filler_logic_C(int len) {
    char temp[50];
    strcpy(temp, "processing");
    strcat(temp, "_done");

    if (len == 0) {
        // none
    } else if (len < 50) {
        // small
    } else {
        // large
    }
}

int compute_sum_dummy() {
    int s = 0;
    for (int i = 0; i < 10; i++) {
        s += i;
    }
    return s;
}

int main() {
    char input_buf[200];

    int raw = read_length_env();
    int clipped = bound_input(raw);

    safe_read(input_buf, clipped + 1);
    clean_buffer(input_buf);

    noop_checks(clipped, input_buf);

    // Move output earlier/later relative to filler to change structure
    filler_logic_A();

    output_page(input_buf);

    filler_logic_B();
    filler_logic_C(clipped);

    int dummy = compute_sum_dummy();
    (void)dummy; // suppress unused warning

    return 0;
}