// Student Name: Abraham Griffith | Student Number : 72345
import java.util.ArrayList;

/*
 * Weather Analyzer Program
 *
 * This program stores a small set of weather records,
 * prints each record, and computes summary statistics.
 *
 * It is intentionally written as a single-file Java submission.
 */
public class Main {

    /*
     * Inner class representing one weather record.
     */
    static class WeatherDay {
        private String dayName;
        private int highTemp;
        private int lowTemp;
        private int rainfall;
        private boolean windy;

        /*
         * Constructor for a weather record.
         */
        public WeatherDay(String dayName, int highTemp, int lowTemp, int rainfall, boolean windy) {
            this.dayName = dayName;
            this.highTemp = highTemp;
            this.lowTemp = lowTemp;
            this.rainfall = rainfall;
            this.windy = windy;
        }

        /*
         * Returns the day name.
         */
        public String getDayName() {
            return dayName;
        }

        /*
         * Returns the high temperature.
         */
        public int getHighTemp() {
            return highTemp;
        }

        /*
         * Returns the low temperature.
         */
        public int getLowTemp() {
            return lowTemp;
        }

        /*
         * Returns rainfall in mm.
         */
        public int getRainfall() {
            return rainfall;
        }

        /*
         * Returns whether the day was windy.
         */
        public boolean isWindy() {
            return windy;
        }

        /*
         * Computes the temperature spread.
         */
        public int getSpread() {
            return highTemp - lowTemp;
        }

        /*
         * Formats a single weather record.
         */
        public String formatRecord() {
            return "Day: " + dayName
                    + ", High: " + highTemp
                    + ", Low: " + lowTemp
                    + ", Rainfall: " + rainfall
                    + ", Windy: " + windy
                    + ", Spread: " + getSpread();
        }
    }

    /*
     * Adds a sample week of weather data.
     */
    public static ArrayList<WeatherDay> loadSampleWeek() {
        ArrayList<WeatherDay> week = new ArrayList<>();

        week.add(new WeatherDay("Monday", 19, 8, 0, false));
        week.add(new WeatherDay("Tuesday", 22, 11, 3, true));
        week.add(new WeatherDay("Wednesday", 17, 7, 12, true));
        week.add(new WeatherDay("Thursday", 24, 13, 0, false));
        week.add(new WeatherDay("Friday", 20, 10, 1, false));
        week.add(new WeatherDay("Saturday", 15, 6, 18, true));
        week.add(new WeatherDay("Sunday", 18, 9, 4, false));

        return week;
    }

    /*
     * Computes average high temperature.
     */
    public static double averageHigh(ArrayList<WeatherDay> week) {
        if (week.isEmpty()) {
            return 0.0;
        }

        int total = 0;
        for (WeatherDay day : week) {
            total += day.getHighTemp();
        }

        return (double) total / week.size();
    }

    /*
     * Computes average low temperature.
     */
    public static double averageLow(ArrayList<WeatherDay> week) {
        if (week.isEmpty()) {
            return 0.0;
        }

        int total = 0;
        for (WeatherDay day : week) {
            total += day.getLowTemp();
        }

        return (double) total / week.size();
    }

    /*
     * Computes total rainfall.
     */
    public static int totalRainfall(ArrayList<WeatherDay> week) {
        int total = 0;

        for (WeatherDay day : week) {
            total += day.getRainfall();
        }

        return total;
    }

    /*
     * Counts how many days were windy.
     */
    public static int countWindyDays(ArrayList<WeatherDay> week) {
        int count = 0;

        for (WeatherDay day : week) {
            if (day.isWindy()) {
                count++;
            }
        }

        return count;
    }

    /*
     * Finds the hottest day.
     */
    public static WeatherDay findHottestDay(ArrayList<WeatherDay> week) {
        if (week.isEmpty()) {
            return null;
        }

        WeatherDay hottest = week.get(0);

        for (WeatherDay day : week) {
            if (day.getHighTemp() > hottest.getHighTemp()) {
                hottest = day;
            }
        }

        return hottest;
    }

    /*
     * Finds the rainiest day.
     */
    public static WeatherDay findRainiestDay(ArrayList<WeatherDay> week) {
        if (week.isEmpty()) {
            return null;
        }

        WeatherDay rainiest = week.get(0);

        for (WeatherDay day : week) {
            if (day.getRainfall() > rainiest.getRainfall()) {
                rainiest = day;
            }
        }

        return rainiest;
    }

    /*
     * Returns days with rainfall above a threshold.
     */
    public static ArrayList<WeatherDay> rainyDaysOver(ArrayList<WeatherDay> week, int threshold) {
        ArrayList<WeatherDay> result = new ArrayList<>();

        for (WeatherDay day : week) {
            if (day.getRainfall() > threshold) {
                result.add(day);
            }
        }

        return result;
    }

    /*
     * Main method.
     */
    public static void main(String[] args) {

        // Load a sample week of weather data
        ArrayList<WeatherDay> week = loadSampleWeek();

        // Print all records
        System.out.println("=== Weekly Weather Report ===");
        for (WeatherDay day : week) {
            System.out.println(day.formatRecord());
        }

        System.out.println();

        // Print summary data
        System.out.println("=== Weather Summary ===");
        System.out.println("Average High: " + averageHigh(week));
        System.out.println("Average Low: " + averageLow(week));
        System.out.println("Total Rainfall: " + totalRainfall(week));
        System.out.println("Windy Days: " + countWindyDays(week));

        // Find and print specific notable days
        WeatherDay hottest = findHottestDay(week);
        WeatherDay rainiest = findRainiestDay(week);

        if (hottest != null) {
            System.out.println("Hottest Day: " + hottest.getDayName());
        }

        if (rainiest != null) {
            System.out.println("Rainiest Day: " + rainiest.getDayName());
        }

        System.out.println();

        // Print rainy days over threshold
        System.out.println("=== Heavy Rain Days ===");
        ArrayList<WeatherDay> rainyDays = rainyDaysOver(week, 5);
        for (WeatherDay day : rainyDays) {
            System.out.println(day.getDayName() + " had " + day.getRainfall() + " mm of rain");
        }
    }
}
