public class VectorImp implements Vector {
    private int size;
    private double[] v;
    VectorImp() {
        this.size = 0;
        this.v = new double[size];
    }

    VectorImp(int size, double D) {
        //elements = D
        if (size < 0) throw new IllegalArgumentException();
        this.size = size;
        v = new double[size];
        for (int i = 0; i < size; i++) {
            v[i] = D;
        }
    }

    VectorImp(double[] D)  {
        //init to array
        this.size = D.length;
        v = D.clone();
    }

    VectorImp(int[] I) {
        size = I.length;
        v = new double[size];
        for (int i = 0; i < size; i++) {
            v[i] = I[i];
        }
    }

    public Vector append(double[] doubleArray) {
        if (doubleArray == null) { throw new IllegalArgumentException("Array musn't be null"); }
        double[] d = new double[this.size + doubleArray.length];

        for (int i = 0; i < this.size; i++) {
            d[i] = this.getValue(i);
        }
        for  (int i = 0; i < doubleArray.length; i++) {
            d[i + this.size] = doubleArray[i];
        }
        return new VectorImp(d);
        //returning new vector instead of just modifying this
    }

    public Vector append(int[] intArray) {
        if (intArray == null) { throw new IllegalArgumentException("Array musn't be null"); }

        double[] newArray = new double[this.size + intArray.length];
        for (int i = 0; i < v.length; i++) {
            newArray[i] = this.getValue(i);
        }
        for  (int i = 0; i < intArray.length; i++) {
            newArray[this.size+ i] = intArray[i];
        }
        return new VectorImp(newArray);
    }

    public Vector append(Vector V) {
        if (V == null) { throw new IllegalArgumentException("Vector musn't be null"); }

        double[] d = new double[this.size + V.getLength()];
        for (int i = 0; i < this.size; i++) {
            d[i] = this.getValue(i);
        }
        for  (int i = 0; i < V.getLength(); i++) {
            d[this.size + i] = V.getValue(i);
        }
        return new VectorImp(d);
    }

    public Vector append(double aDouble) {
        double[] d = new double[this.size + 1];
        for (int i = 0; i < this.size; i++) {
            d[i] = this.getValue(i);
        }

        d[this.size] = aDouble;
        return new VectorImp(d);
    }

    public Vector clone() {
        double[] d = new double[this.size];
        for (int i = 0; i < v.length; i++) {
            d[i] = this.getValue(i);
        }
        return new VectorImp(d);
    }

    public Boolean equal(Vector V) {
        if (this.size != V.getLength()) {
            return false;
        }

        for (int i = 0; i < this.size; i++) {
            if (Math.abs(this.getValue(i) - V.getValue(i)) > 1e-9) {//a very small amount of difference (ieee rep. imprecision)
                return false;
            }
        }
        return true;
    }

    public int getLength() {
        return this.size;
    }

    public Double getValue(int i) {
        return this.v[i];
    }

    public Vector add(Vector V) {
        if (this.size == V.getLength()) {
            for (int i = 0; i < this.size; i++) {
                this.v[i] = this.v[i] + V.getValue(i);
            }
        }
        return this;
    }

    public Vector add(double aDouble) {
        for  (int i = 0; i < this.size; i++) {
            this.v[i] = this.v[i] + aDouble;
        }
        return this;
    }


    public Vector sub(Vector V) {
        if  (this.size == V.getLength()) {
            for (int i = 0; i < this.size; i++) {
                this.v[i] = this.v[i] - V.getValue(i);
            }
        }
        return this;
    }

    public Vector subV(int l, int r) {

        if (l < 0 || r >= this.size || l > r) {
            throw new IndexOutOfBoundsException("Invalid range");
        }

        int length = r - l + 1;
        double[] d = new double[length];

        for (int i = 0; i < length; i++) {
            d[i] = this.getValue(l + i);
        }
        return new VectorImp(d);
    }

    public Vector Mult(Vector V) {
        if (V == null) {
            throw new IllegalArgumentException("Vector must not be null");
        }

        double[] d = new double[this.size];

        if (this.size != V.getLength()) {
            throw new IllegalArgumentException("Vectors must have the same length");
        }

        for (int i = 0; i < this.size; i++) {
            d[i] = this.getValue(i) * V.getValue(i);
        }
        return new VectorImp(d);
    }


    public Vector Mult(double aDouble) {
        double[] d = new double[this.size];
        for (int i = 0; i < this.size; i++) {
            d[i] = this.getValue(i) * aDouble;
        }
        return new VectorImp(d);
    }

    public Vector Normalize() {
        if (this.size == 0) {return new VectorImp();}

        int bestIndex = 0;
        double max = Math.abs(this.getValue(0)); //assume first is best
        for (int i = 0; i < this.size; i++) {
            double abs =  Math.abs(this.getValue(i));//abs value comparison to include negatives
            if  (abs > max) {
                max = abs;
            }
        }

        if (max == 0) return this.clone();

        double[] d = new double[this.size];
        double scaling = 1.0/max;
        for (int i = 0; i < this.size; i++) {
            d[i] = this.getValue(i) * scaling;
        }
        return new VectorImp(d);
    }

    public Double EuclidianDistance(Vector V) {
        if (V == null) {
            throw new IllegalArgumentException("Vector must not be null");
        }
        if (this.size != V.getLength()) {
            throw new IllegalArgumentException("Vectors must have the same length");
        }

        double sum = 0.0;
        for (int i = 0; i < this.size; i++) {
            sum += Math.pow(this.getValue(i) - V.getValue(i), 2);
        }
        return Math.sqrt(sum);
    }
}
