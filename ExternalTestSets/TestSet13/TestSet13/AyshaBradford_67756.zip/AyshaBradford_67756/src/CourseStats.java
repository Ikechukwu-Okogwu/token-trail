// Student Name: Aysha Bradford | Student Number: 67756

import java.util.ArrayList;

/*
 * Utility class for computing course-wide statistics.
 */
public class CourseStats {

    /*
     * Computes overall class average
     */
    public static double calculateAverage(ArrayList<StudentRecord> students) {

        if (students.isEmpty()) {
            return 0.0;
        }

        double total = 0.0;

        // Sum averages of all students
        for (StudentRecord student : students) {
            total += student.getAverage();
        }

        return total / students.size();
    }

    /*
     * Finds student with highest average
     */
    public static StudentRecord findHighestStudent(ArrayList<StudentRecord> students) {

        if (students.isEmpty()) {
            return null;
        }

        StudentRecord highestStudent = students.get(0);

        for (StudentRecord student : students) {
            if (student.getAverage() > highestStudent.getAverage()) {
                highestStudent = student;
            }
        }

        return highestStudent;
    }

    /*
     * Finds student with lowest average
     */
    public static StudentRecord findLowestStudent(ArrayList<StudentRecord> students) {

        if (students.isEmpty()) {
            return null;
        }

        StudentRecord lowestStudent = students.get(0);

        for (StudentRecord student : students) {
            if (student.getAverage() < lowestStudent.getAverage()) {
                lowestStudent = student;
            }
        }

        return lowestStudent;
    }

    /*
     * Returns list of students above threshold
     */
    public static ArrayList<StudentRecord> getPassingStudents(ArrayList<StudentRecord> students, int passingMark) {

        ArrayList<StudentRecord> passingStudents = new ArrayList<>();

        // Filter students
        for (StudentRecord student : students) {
            if (student.getAverage() >= passingMark) {
                passingStudents.add(student);
            }
        }

        return passingStudents;
    }
}