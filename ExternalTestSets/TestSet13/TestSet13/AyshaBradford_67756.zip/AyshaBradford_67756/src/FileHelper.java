// Student Name: Aysha Bradford | Student Number: 67756

import java.util.ArrayList;

/*
 * Helper class for loading test data.
 */
public class FileHelper {

    /*
     * Creates sample student dataset
     */
    public static ArrayList<StudentRecord> loadSampleStudents() {

        ArrayList<StudentRecord> students = new ArrayList<>();

        // Create student 1
        StudentRecord s1 = new StudentRecord("Alice", 1001);
        s1.addGrade(78);
        s1.addGrade(85);
        s1.addGrade(91);

        // Create student 2
        StudentRecord s2 = new StudentRecord("Bob", 1002);
        s2.addGrade(56);
        s2.addGrade(62);
        s2.addGrade(59);

        // Create student 3
        StudentRecord s3 = new StudentRecord("Charlie", 1003);
        s3.addGrade(88);
        s3.addGrade(90);
        s3.addGrade(84);

        // Create student 4
        StudentRecord s4 = new StudentRecord("Diana", 1004);
        s4.addGrade(41);
        s4.addGrade(53);
        s4.addGrade(47);

        // Add all to list
        students.add(s1);
        students.add(s2);
        students.add(s3);
        students.add(s4);

        return students;
    }
}