// Student Name: Aysha Bradford | Student Number: 67756
import java.util.ArrayList;

/*
 * Main driver class for the program.
 *
 * This program simulates a simple student grading system.
 * It loads sample students, prints their records,
 * and computes overall statistics.
 */
public class Main {

    public static void main(String[] args) {

        // Load a list of students from helper class
        ArrayList<StudentRecord> students = FileHelper.loadSampleStudents();

        // Print header for student report
        System.out.println("=== Student Report ===");

        // Loop through each student and print formatted record
        for (StudentRecord student : students) {
            System.out.println(student.formatRecord());
        }

        // Print spacing for readability
        System.out.println();

        // Print summary section
        System.out.println("=== Summary ===");

        // Calculate and print class average
        System.out.println("Class Average: " + CourseStats.calculateAverage(students));

        // Find and print highest scoring student
        System.out.println("Highest Student: " + CourseStats.findHighestStudent(students).getName());

        // Find and print lowest scoring student
        System.out.println("Lowest Student: " + CourseStats.findLowestStudent(students).getName());

        // Print spacing again
        System.out.println();

        // Print passing students section
        System.out.println("=== Passing Students ===");

        // Get list of students who passed threshold
        ArrayList<StudentRecord> passing = CourseStats.getPassingStudents(students, 50);

        // Loop and print passing students
        for (StudentRecord student : passing) {
            System.out.println(student.getName() + " passed with " + student.getAverage());
        }
    }
}