// Student Name: Aysha Bradford | Student Number: 67756 
import java.util.ArrayList;

/*
 * This class represents a student record.
 *
 * It stores:
 * - Name
 * - Student ID
 * - List of grades
 *
 * It also provides methods to compute statistics.
 */
public class StudentRecord {

    // Name of student
    private String name;

    // Unique student identifier
    private int studentId;

    // List of grades
    private ArrayList<Integer> grades;

    /*
     * Constructor to initialize student object
     */
    public StudentRecord(String name, int studentId) {
        this.name = name;
        this.studentId = studentId;
        this.grades = new ArrayList<>();
    }

    /*
     * Adds a grade to the list
     */
    public void addGrade(int grade) {
        grades.add(grade);
    }

    /*
     * Returns student name
     */
    public String getName() {
        return name;
    }

    /*
     * Returns student ID
     */
    public int getStudentId() {
        return studentId;
    }

    /*
     * Returns list of grades
     */
    public ArrayList<Integer> getGrades() {
        return grades;
    }

    /*
     * Computes average grade
     */
    public double getAverage() {

        // Edge case: no grades
        if (grades.isEmpty()) {
            return 0.0;
        }

        // Sum all grades
        int total = 0;
        for (int grade : grades) {
            total += grade;
        }

        // Return average
        return (double) total / grades.size();
    }

    /*
     * Finds highest grade
     */
    public int getHighestGrade() {

        if (grades.isEmpty()) {
            return 0;
        }

        int highest = grades.get(0);

        // Iterate through grades
        for (int grade : grades) {
            if (grade > highest) {
                highest = grade;
            }
        }

        return highest;
    }

    /*
     * Finds lowest grade
     */
    public int getLowestGrade() {

        if (grades.isEmpty()) {
            return 0;
        }

        int lowest = grades.get(0);

        // Iterate through grades
        for (int grade : grades) {
            if (grade < lowest) {
                lowest = grade;
            }
        }

        return lowest;
    }

    /*
     * Formats student record into string
     */
    public String formatRecord() {
        return "Name: " + name +
                ", ID: " + studentId +
                ", Average: " + getAverage() +
                ", Highest: " + getHighestGrade() +
                ", Lowest: " + getLowestGrade();
    }
}