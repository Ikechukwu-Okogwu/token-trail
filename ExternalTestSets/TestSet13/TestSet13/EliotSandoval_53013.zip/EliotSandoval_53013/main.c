// Student Name: Eliot Sandoval | Student Number :53013  
#include <stdio.h>
#include <string.h>

// Maximum capacity of items
#define MAX_ITEMS 100

// Max length for names
#define NAME_LEN 100

/*
 * Structure for library item
 */
typedef struct {
    int code;               // Identifier
    char name[NAME_LEN];    // Book name
    int stock;              // Total copies
    int checkedOut;         // Borrowed count
} LibraryItem;

/*
 * Inserts a new item
 */
void insertItem(LibraryItem shelf[], int *size, int code, const char name[], int stock) {

    // Prevent overflow
    if (*size >= MAX_ITEMS) {
        printf("Library is full.\n");
        return;
    }

    shelf[*size].code = code;
    strcpy(shelf[*size].name, name);
    shelf[*size].stock = stock;
    shelf[*size].checkedOut = 0;

    (*size)++;
}

/*
 * Finds index of item
 */
int searchIndex(LibraryItem shelf[], int size, int code) {

    int pos;

    for (pos = 0; pos < size; pos++) {
        if (shelf[pos].code == code) {
            return pos;
        }
    }

    return -1;
}

/*
 * Borrow item
 */
void issueItem(LibraryItem shelf[], int size, int code) {

    int pos = searchIndex(shelf, size, code);

    if (pos == -1) {
        printf("Book with ID %d not found.\n", code);
        return;
    }

    if (shelf[pos].checkedOut < shelf[pos].stock) {
        shelf[pos].checkedOut++;
        printf("Borrowed: %s\n", shelf[pos].name);
    } else {
        printf("No available copies for %s\n", shelf[pos].name);
    }
}

/*
 * Return item
 */
void receiveItem(LibraryItem shelf[], int size, int code) {

    int pos = searchIndex(shelf, size, code);

    if (pos == -1) {
        printf("Book with ID %d not found.\n", code);
        return;
    }

    if (shelf[pos].checkedOut > 0) {
        shelf[pos].checkedOut--;
        printf("Returned: %s\n", shelf[pos].name);
    } else {
        printf("No borrowed copies to return for %s\n", shelf[pos].name);
    }
}

/*
 * Print one entry
 */
void displayOne(LibraryItem item) {
    printf("ID: %d, Title: %s, Copies: %d, Borrowed: %d, Available: %d\n",
           item.code,
           item.name,
           item.stock,
           item.checkedOut,
           item.stock - item.checkedOut);
}

/*
 * Print all entries
 */
void displayAll(LibraryItem shelf[], int size) {

    int pos;

    printf("\n=== Library Inventory ===\n");

    for (pos = 0; pos < size; pos++) {
        displayOne(shelf[pos]);
    }
}

/*
 * Total stock
 */
int countStock(LibraryItem shelf[], int size) {

    int pos, sum = 0;

    for (pos = 0; pos < size; pos++) {
        sum += shelf[pos].stock;
    }

    return sum;
}

/*
 * Total borrowed
 */
int countCheckedOut(LibraryItem shelf[], int size) {

    int pos, sum = 0;

    for (pos = 0; pos < size; pos++) {
        sum += shelf[pos].checkedOut;
    }

    return sum;
}

/*
 * Most borrowed index
 */
int topBorrowedIndex(LibraryItem shelf[], int size) {

    if (size == 0) return -1;

    int pos, bestPos = 0;

    for (pos = 1; pos < size; pos++) {
        if (shelf[pos].checkedOut > shelf[bestPos].checkedOut) {
            bestPos = pos;
        }
    }

    return bestPos;
}

/*
 * Summary output
 */
void showStats(LibraryItem shelf[], int size) {

    int topPos = topBorrowedIndex(shelf, size);

    printf("\n=== Summary ===\n");
    printf("Total Titles: %d\n", size);
    printf("Total Copies: %d\n", countStock(shelf, size));
    printf("Total Borrowed: %d\n", countCheckedOut(shelf, size));

    if (topPos != -1) {
        printf("Most Borrowed Book: %s\n", shelf[topPos].name);
    }
}

/*
 * Entry point
 */
int main() {

    LibraryItem shelf[MAX_ITEMS];
    int size = 0;

    insertItem(shelf, &size, 101, "C Programming", 4);
    insertItem(shelf, &size, 102, "Data Structures", 3);
    insertItem(shelf, &size, 103, "Operating Systems", 5);
    insertItem(shelf, &size, 104, "Algorithms", 2);
    insertItem(shelf, &size, 105, "Databases", 6);

    issueItem(shelf, size, 101);
    issueItem(shelf, size, 101);
    issueItem(shelf, size, 103);
    issueItem(shelf, size, 104);
    issueItem(shelf, size, 104);
    issueItem(shelf, size, 104);

    receiveItem(shelf, size, 101);
    receiveItem(shelf, size, 105);

    displayAll(shelf, size);
    showStats(shelf, size);

    return 0;
}