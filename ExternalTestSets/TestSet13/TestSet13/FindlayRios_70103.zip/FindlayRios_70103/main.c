// Student Name: Findlay Rios | Student Number : 70103  
#include <stdio.h>
#include <string.h>

// Upper bound of records
#define LIMIT 100

// String buffer size
#define TEXT 100

/*
 * Structure for record
 */
typedef struct {
    int bookId;                // ID
    char bookTitle[TEXT];      // Title
    int totalCount;            // Total copies
    int loanedCount;           // Borrowed copies
} Record;

/*
 * Creates a new record
 */
void createRecord(Record list[], int *used, int bookId, const char bookTitle[], int totalCount) {

    if (*used >= LIMIT) {
        printf("Library is full.\n");
        return;
    }

    list[*used].bookId = bookId;
    strcpy(list[*used].bookTitle, bookTitle);
    list[*used].totalCount = totalCount;
    list[*used].loanedCount = 0;

    (*used)++;
}

/*
 * Finds record index
 */
int locateRecord(Record list[], int used, int bookId) {

    int index;

    for (index = 0; index < used; index++) {
        if (list[index].bookId == bookId) {
            return index;
        }
    }

    return -1;
}

/*
 * Checkout operation
 */
void checkoutRecord(Record list[], int used, int bookId) {

    int index = locateRecord(list, used, bookId);

    if (index == -1) {
        printf("Book with ID %d not found.\n", bookId);
        return;
    }

    if (list[index].loanedCount < list[index].totalCount) {
        list[index].loanedCount++;
        printf("Borrowed: %s\n", list[index].bookTitle);
    } else {
        printf("No available copies for %s\n", list[index].bookTitle);
    }
}

/*
 * Checkin operation
 */
void checkinRecord(Record list[], int used, int bookId) {

    int index = locateRecord(list, used, bookId);

    if (index == -1) {
        printf("Book with ID %d not found.\n", bookId);
        return;
    }

    if (list[index].loanedCount > 0) {
        list[index].loanedCount--;
        printf("Returned: %s\n", list[index].bookTitle);
    } else {
        printf("No borrowed copies to return for %s\n", list[index].bookTitle);
    }
}

/*
 * Print one record
 */
void printRecord(Record entry) {
    printf("ID: %d, Title: %s, Copies: %d, Borrowed: %d, Available: %d\n",
           entry.bookId,
           entry.bookTitle,
           entry.totalCount,
           entry.loanedCount,
           entry.totalCount - entry.loanedCount);
}

/*
 * Print all records
 */
void printRecords(Record list[], int used) {

    int index;

    printf("\n=== Library Inventory ===\n");

    for (index = 0; index < used; index++) {
        printRecord(list[index]);
    }
}

/*
 * Sum copies
 */
int sumCopies(Record list[], int used) {

    int index, result = 0;

    for (index = 0; index < used; index++) {
        result += list[index].totalCount;
    }

    return result;
}

/*
 * Sum borrowed
 */
int sumBorrowed(Record list[], int used) {

    int index, result = 0;

    for (index = 0; index < used; index++) {
        result += list[index].loanedCount;
    }

    return result;
}

/*
 * Find most borrowed
 */
int maxBorrowedPosition(Record list[], int used) {

    if (used == 0) return -1;

    int index, answer = 0;

    for (index = 1; index < used; index++) {
        if (list[index].loanedCount > list[answer].loanedCount) {
            answer = index;
        }
    }

    return answer;
}

/*
 * Print summary
 */
void printTotals(Record list[], int used) {

    int answer = maxBorrowedPosition(list, used);

    printf("\n=== Summary ===\n");
    printf("Total Titles: %d\n", used);
    printf("Total Copies: %d\n", sumCopies(list, used));
    printf("Total Borrowed: %d\n", sumBorrowed(list, used));

    if (answer != -1) {
        printf("Most Borrowed Book: %s\n", list[answer].bookTitle);
    }
}

/*
 * Main program
 */
int main() {

    Record list[LIMIT];
    int used = 0;

    createRecord(list, &used, 101, "C Programming", 4);
    createRecord(list, &used, 102, "Data Structures", 3);
    createRecord(list, &used, 103, "Operating Systems", 5);
    createRecord(list, &used, 104, "Algorithms", 2);
    createRecord(list, &used, 105, "Databases", 6);

    checkoutRecord(list, used, 101);
    checkoutRecord(list, used, 101);
    checkoutRecord(list, used, 103);
    checkoutRecord(list, used, 104);
    checkoutRecord(list, used, 104);
    checkoutRecord(list, used, 104);

    checkinRecord(list, used, 101);
    checkinRecord(list, used, 105);

    printRecords(list, used);
    printTotals(list, used);

    return 0;
}