// Student Name: Flora Mays | Student Number :71655
import java.util.ArrayList;

/*
 * Main class for testing the task scheduler.
 *
 * This program creates a list of tasks,
 * prints them, sorts them by priority,
 * and shows a summary of completed work.
 */
public class Main {

    public static void main(String[] args) {

        // Load sample tasks
        ArrayList<Task> tasks = TaskLoader.loadSampleTasks();

        // Print all tasks before sorting
        System.out.println("=== Original Tasks ===");
        for (Task task : tasks) {
            System.out.println(task.formatTask());
        }

        System.out.println();

        // Sort tasks by priority
        TaskManager.sortByPriority(tasks);

        // Print sorted tasks
        System.out.println("=== Sorted By Priority ===");
        for (Task task : tasks) {
            System.out.println(task.formatTask());
        }

        System.out.println();

        // Print summary information
        System.out.println("=== Task Summary ===");
        System.out.println("Completed Tasks: " + TaskManager.countCompleted(tasks));
        System.out.println("Pending Tasks: " + TaskManager.countPending(tasks));
        System.out.println("Highest Priority Task: " + TaskManager.findHighestPriority(tasks).getTitle());

        System.out.println();

        // Print only completed tasks
        System.out.println("=== Completed Task List ===");
        ArrayList<Task> completed = TaskManager.getCompletedTasks(tasks);
        for (Task task : completed) {
            System.out.println(task.getTitle() + " finished in " + task.getEstimatedHours() + " hours");
        }
    }
}