// Student Name: Flora Mays | Student Number :71655
/*
 * Represents a single task in a task scheduler.
 *
 * Stores:
 * - title
 * - category
 * - priority
 * - estimated hours
 * - completion status
 */
public class Task {

    // Title of task
    private String title;

    // Category such as school, work, or personal
    private String category;

    // Priority level, larger means more important
    private int priority;

    // Estimated time required
    private int estimatedHours;

    // Whether task is complete
    private boolean completed;

    /*
     * Constructor to initialize task data
     */
    public Task(String title, String category, int priority, int estimatedHours, boolean completed) {
        this.title = title;
        this.category = category;
        this.priority = priority;
        this.estimatedHours = estimatedHours;
        this.completed = completed;
    }

    /*
     * Returns title
     */
    public String getTitle() {
        return title;
    }

    /*
     * Returns category
     */
    public String getCategory() {
        return category;
    }

    /*
     * Returns priority
     */
    public int getPriority() {
        return priority;
    }

    /*
     * Returns estimated hours
     */
    public int getEstimatedHours() {
        return estimatedHours;
    }

    /*
     * Returns whether task is completed
     */
    public boolean isCompleted() {
        return completed;
    }

    /*
     * Marks task as completed
     */
    public void markCompleted() {
        completed = true;
    }

    /*
     * Formats task into a readable string
     */
    public String formatTask() {
        return "Title: " + title +
                ", Category: " + category +
                ", Priority: " + priority +
                ", Hours: " + estimatedHours +
                ", Completed: " + completed;
    }
}