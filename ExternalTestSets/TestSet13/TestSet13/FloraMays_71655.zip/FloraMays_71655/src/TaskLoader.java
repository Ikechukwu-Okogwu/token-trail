// Student Name: Flora Mays | Student Number :71655
import java.util.ArrayList;

/*
 * Responsible for building sample task data.
 */
public class TaskLoader {

    /*
     * Creates a list of example tasks
     */
    public static ArrayList<Task> loadSampleTasks() {
        ArrayList<Task> tasks = new ArrayList<>();

        // Add different sample tasks
        tasks.add(new Task("Write essay", "School", 4, 5, false));
        tasks.add(new Task("Buy groceries", "Personal", 2, 1, true));
        tasks.add(new Task("Study for exam", "School", 5, 6, false));
        tasks.add(new Task("Clean room", "Personal", 1, 2, true));
        tasks.add(new Task("Finish lab report", "School", 3, 4, false));

        return tasks;
    }
}