// Student Name: Flora Mays | Student Number :71655
import java.util.ArrayList;

/*
 * Utility class for task operations.
 *
 * Includes:
 * - sorting tasks
 * - counting completed/pending tasks
 * - finding highest priority task
 * - filtering completed tasks
 */
public class TaskManager {

    /*
     * Sorts tasks in descending priority order
     * using a simple bubble sort.
     */
    public static void sortByPriority(ArrayList<Task> tasks) {
        int n = tasks.size();

        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (tasks.get(j).getPriority() < tasks.get(j + 1).getPriority()) {
                    Task temp = tasks.get(j);
                    tasks.set(j, tasks.get(j + 1));
                    tasks.set(j + 1, temp);
                }
            }
        }
    }

    /*
     * Counts completed tasks
     */
    public static int countCompleted(ArrayList<Task> tasks) {
        int count = 0;

        for (Task task : tasks) {
            if (task.isCompleted()) {
                count++;
            }
        }

        return count;
    }

    /*
     * Counts pending tasks
     */
    public static int countPending(ArrayList<Task> tasks) {
        int count = 0;

        for (Task task : tasks) {
            if (!task.isCompleted()) {
                count++;
            }
        }

        return count;
    }

    /*
     * Finds task with highest priority
     */
    public static Task findHighestPriority(ArrayList<Task> tasks) {
        if (tasks.isEmpty()) {
            return null;
        }

        Task highest = tasks.get(0);

        for (Task task : tasks) {
            if (task.getPriority() > highest.getPriority()) {
                highest = task;
            }
        }

        return highest;
    }

    /*
     * Returns all completed tasks
     */
    public static ArrayList<Task> getCompletedTasks(ArrayList<Task> tasks) {
        ArrayList<Task> completedTasks = new ArrayList<>();

        for (Task task : tasks) {
            if (task.isCompleted()) {
                completedTasks.add(task);
            }
        }

        return completedTasks;
    }
}
