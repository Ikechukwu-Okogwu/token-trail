// Student Name: Francesco Stewart | Student Number: 83414
#include <iostream>
#include <vector>
#include <string>
#include <iomanip>

using namespace std;

/*
 * This program models a small city transit system.
 * It stores bus routes, prints route information,
 * computes summary statistics, and finds useful subsets.
 */

struct BusRoute {
    int routeNumber;
    string routeName;
    int totalStops;
    int activeBuses;
    double averageDelay;
    bool express;
};

/*
 * Adds a route to the list of routes.
 */
void addRoute(vector<BusRoute>& routes,
              int routeNumber,
              const string& routeName,
              int totalStops,
              int activeBuses,
              double averageDelay,
              bool express) {
    BusRoute route;
    route.routeNumber = routeNumber;
    route.routeName = routeName;
    route.totalStops = totalStops;
    route.activeBuses = activeBuses;
    route.averageDelay = averageDelay;
    route.express = express;
    routes.push_back(route);
}

/*
 * Prints one route in a readable format.
 */
void printRoute(const BusRoute& route) {
    cout << "Route #" << route.routeNumber
         << ", Name: " << route.routeName
         << ", Stops: " << route.totalStops
         << ", Active Buses: " << route.activeBuses
         << ", Avg Delay: " << fixed << setprecision(1) << route.averageDelay
         << ", Express: " << (route.express ? "Yes" : "No")
         << endl;
}

/*
 * Prints all routes in the system.
 */
void printAllRoutes(const vector<BusRoute>& routes) {
    cout << "=== Transit Routes ===" << endl;
    for (const BusRoute& route : routes) {
        printRoute(route);
    }
}

/*
 * Returns total number of stops across all routes.
 */
int totalStopsAcrossRoutes(const vector<BusRoute>& routes) {
    int total = 0;
    for (const BusRoute& route : routes) {
        total += route.totalStops;
    }
    return total;
}

/*
 * Returns total number of active buses.
 */
int totalActiveBuses(const vector<BusRoute>& routes) {
    int total = 0;
    for (const BusRoute& route : routes) {
        total += route.activeBuses;
    }
    return total;
}

/*
 * Computes the average delay across all routes.
 */
double averageSystemDelay(const vector<BusRoute>& routes) {
    if (routes.empty()) {
        return 0.0;
    }

    double total = 0.0;
    for (const BusRoute& route : routes) {
        total += route.averageDelay;
    }

    return total / routes.size();
}

/*
 * Finds the route with the most stops.
 */
BusRoute findLongestRoute(const vector<BusRoute>& routes) {
    BusRoute best = routes.at(0);

    for (const BusRoute& route : routes) {
        if (route.totalStops > best.totalStops) {
            best = route;
        }
    }

    return best;
}

/*
 * Finds the route with the highest delay.
 */
BusRoute findMostDelayedRoute(const vector<BusRoute>& routes) {
    BusRoute worst = routes.at(0);

    for (const BusRoute& route : routes) {
        if (route.averageDelay > worst.averageDelay) {
            worst = route;
        }
    }

    return worst;
}

/*
 * Counts how many routes are express.
 */
int countExpressRoutes(const vector<BusRoute>& routes) {
    int count = 0;

    for (const BusRoute& route : routes) {
        if (route.express) {
            count++;
        }
    }

    return count;
}

/*
 * Returns all routes with delay above a threshold.
 */
vector<BusRoute> getDelayedRoutes(const vector<BusRoute>& routes, double threshold) {
    vector<BusRoute> result;

    for (const BusRoute& route : routes) {
        if (route.averageDelay > threshold) {
            result.push_back(route);
        }
    }

    return result;
}

/*
 * Returns all express routes.
 */
vector<BusRoute> getExpressRoutes(const vector<BusRoute>& routes) {
    vector<BusRoute> result;

    for (const BusRoute& route : routes) {
        if (route.express) {
            result.push_back(route);
        }
    }

    return result;
}

/*
 * Sorts routes by route number using a simple bubble sort.
 * This is intentionally written out fully for clarity.
 */
void sortByRouteNumber(vector<BusRoute>& routes) {
    for (size_t i = 0; i < routes.size(); i++) {
        for (size_t j = 0; j + 1 < routes.size() - i; j++) {
            if (routes[j].routeNumber > routes[j + 1].routeNumber) {
                BusRoute temp = routes[j];
                routes[j] = routes[j + 1];
                routes[j + 1] = temp;
            }
        }
    }
}

/*
 * Prints summary information about the transit system.
 */
void printSummary(const vector<BusRoute>& routes) {
    cout << endl;
    cout << "=== Transit Summary ===" << endl;
    cout << "Total Routes: " << routes.size() << endl;
    cout << "Total Stops: " << totalStopsAcrossRoutes(routes) << endl;
    cout << "Total Active Buses: " << totalActiveBuses(routes) << endl;
    cout << "Average System Delay: " << fixed << setprecision(2)
         << averageSystemDelay(routes) << endl;
    cout << "Express Routes: " << countExpressRoutes(routes) << endl;

    if (!routes.empty()) {
        BusRoute longest = findLongestRoute(routes);
        BusRoute delayed = findMostDelayedRoute(routes);

        cout << "Longest Route: " << longest.routeName
             << " (" << longest.totalStops << " stops)" << endl;

        cout << "Most Delayed Route: " << delayed.routeName
             << " (" << fixed << setprecision(1) << delayed.averageDelay << " min)" << endl;
    }
}

/*
 * Entry point for the program.
 */
int main() {
    vector<BusRoute> routes;

    // Add some sample transit data
    addRoute(routes, 12, "Downtown Connector", 18, 6, 3.4, false);
    addRoute(routes, 7, "North Express", 9, 4, 5.1, true);
    addRoute(routes, 25, "University Loop", 22, 7, 2.8, false);
    addRoute(routes, 3, "Lakeside Limited", 11, 3, 6.7, true);
    addRoute(routes, 18, "Airport Shuttle", 14, 5, 4.0, false);
    addRoute(routes, 30, "West End Crosstown", 26, 8, 7.2, false);

    // Print unsorted routes
    printAllRoutes(routes);

    // Show summary before sorting
    printSummary(routes);

    // Sort by route number
    sortByRouteNumber(routes);

    cout << endl;
    cout << "=== Routes Sorted By Number ===" << endl;
    for (const BusRoute& route : routes) {
        printRoute(route);
    }

    // Show delayed routes
    vector<BusRoute> delayedRoutes = getDelayedRoutes(routes, 5.0);
    cout << endl;
    cout << "=== Routes With Delay Over 5.0 Minutes ===" << endl;
    for (const BusRoute& route : delayedRoutes) {
        cout << route.routeName << " has average delay "
             << fixed << setprecision(1) << route.averageDelay << " minutes" << endl;
    }

    // Show express routes
    vector<BusRoute> expressRoutes = getExpressRoutes(routes);
    cout << endl;
    cout << "=== Express Routes ===" << endl;
    for (const BusRoute& route : expressRoutes) {
        cout << route.routeName << " (Route #" << route.routeNumber << ")" << endl;
    }

    return 0;
}