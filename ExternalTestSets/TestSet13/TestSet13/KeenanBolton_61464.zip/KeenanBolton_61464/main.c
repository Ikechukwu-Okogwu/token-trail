// Student Name: Keenan Bolton | Student Number: 61464 
#include <stdio.h>
#include <string.h>

// Maximum number of movies allowed
#define MAX_MOVIES 100

// Maximum title length
#define TITLE_LENGTH 100

/*
 * Structure representing one movie entry
 */
typedef struct {
    char title[TITLE_LENGTH];   // Movie title
    char genre[40];             // Genre name
    int year;                   // Release year
    int runtime;                // Runtime in minutes
    float rating;               // Rating out of 10
    int watched;                // 1 if watched, 0 otherwise
} Movie;

/*
 * Adds a movie to the collection
 */
void addMovie(Movie movies[], int *count, const char title[], const char genre[],
              int year, int runtime, float rating, int watched) {

    // Make sure array is not full
    if (*count >= MAX_MOVIES) {
        printf("Movie list is full.\n");
        return;
    }

    // Copy data into next slot
    strcpy(movies[*count].title, title);
    strcpy(movies[*count].genre, genre);
    movies[*count].year = year;
    movies[*count].runtime = runtime;
    movies[*count].rating = rating;
    movies[*count].watched = watched;

    // Increase movie count
    (*count)++;
}

/*
 * Prints one movie entry
 */
void printMovie(Movie movie) {
    printf("Title: %s, Genre: %s, Year: %d, Runtime: %d, Rating: %.1f, Watched: %s\n",
           movie.title,
           movie.genre,
           movie.year,
           movie.runtime,
           movie.rating,
           movie.watched ? "Yes" : "No");
}

/*
 * Prints all movies in the list
 */
void printAllMovies(Movie movies[], int count) {
    int i;

    printf("\n=== Movie Collection ===\n");

    for (i = 0; i < count; i++) {
        printMovie(movies[i]);
    }
}

/*
 * Counts watched movies
 */
int countWatched(Movie movies[], int count) {
    int i;
    int total = 0;

    for (i = 0; i < count; i++) {
        if (movies[i].watched) {
            total++;
        }
    }

    return total;
}

/*
 * Counts unwatched movies
 */
int countUnwatched(Movie movies[], int count) {
    int i;
    int total = 0;

    for (i = 0; i < count; i++) {
        if (!movies[i].watched) {
            total++;
        }
    }

    return total;
}

/*
 * Computes average rating
 */
float averageRating(Movie movies[], int count) {
    int i;
    float total = 0.0f;

    if (count == 0) {
        return 0.0f;
    }

    for (i = 0; i < count; i++) {
        total += movies[i].rating;
    }

    return total / count;
}

/*
 * Computes total runtime of all movies
 */
int totalRuntime(Movie movies[], int count) {
    int i;
    int total = 0;

    for (i = 0; i < count; i++) {
        total += movies[i].runtime;
    }

    return total;
}

/*
 * Finds the index of the highest-rated movie
 */
int highestRatedIndex(Movie movies[], int count) {
    int i;
    int best = 0;

    if (count == 0) {
        return -1;
    }

    for (i = 1; i < count; i++) {
        if (movies[i].rating > movies[best].rating) {
            best = i;
        }
    }

    return best;
}

/*
 * Finds the index of the oldest movie
 */
int oldestMovieIndex(Movie movies[], int count) {
    int i;
    int oldest = 0;

    if (count == 0) {
        return -1;
    }

    for (i = 1; i < count; i++) {
        if (movies[i].year < movies[oldest].year) {
            oldest = i;
        }
    }

    return oldest;
}

/*
 * Prints a summary of the collection
 */
void printSummary(Movie movies[], int count) {
    int bestIndex = highestRatedIndex(movies, count);
    int oldestIndex = oldestMovieIndex(movies, count);

    printf("\n=== Collection Summary ===\n");
    printf("Total Movies: %d\n", count);
    printf("Watched Movies: %d\n", countWatched(movies, count));
    printf("Unwatched Movies: %d\n", countUnwatched(movies, count));
    printf("Average Rating: %.2f\n", averageRating(movies, count));
    printf("Total Runtime: %d minutes\n", totalRuntime(movies, count));

    if (bestIndex != -1) {
        printf("Highest Rated Movie: %s\n", movies[bestIndex].title);
    }

    if (oldestIndex != -1) {
        printf("Oldest Movie: %s\n", movies[oldestIndex].title);
    }
}

/*
 * Prints only movies above a rating threshold
 */
void printHighlyRated(Movie movies[], int count, float threshold) {
    int i;

    printf("\n=== Highly Rated Movies ===\n");

    for (i = 0; i < count; i++) {
        if (movies[i].rating >= threshold) {
            printf("%s (%.1f)\n", movies[i].title, movies[i].rating);
        }
    }
}

/*
 * Main function
 */
int main() {
    Movie movies[MAX_MOVIES];
    int count = 0;

    // Add sample movies
    addMovie(movies, &count, "Inception", "Sci-Fi", 2010, 148, 8.8f, 1);
    addMovie(movies, &count, "The Godfather", "Crime", 1972, 175, 9.2f, 1);
    addMovie(movies, &count, "Interstellar", "Sci-Fi", 2014, 169, 8.6f, 1);
    addMovie(movies, &count, "Spirited Away", "Animation", 2001, 125, 8.5f, 0);
    addMovie(movies, &count, "The Batman", "Action", 2022, 176, 7.9f, 0);

    // Print all movie data
    printAllMovies(movies, count);

    // Print summary statistics
    printSummary(movies, count);

    // Print highly rated movies
    printHighlyRated(movies, count, 8.5f);

    return 0;
}