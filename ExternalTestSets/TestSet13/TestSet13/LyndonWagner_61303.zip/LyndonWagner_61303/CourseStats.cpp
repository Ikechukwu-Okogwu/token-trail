// Student Name: Lyndon Wagner | Student Number : 61303
#include "CourseStats.h"

double CourseStats::calculateAverage(const std::vector<StudentRecord>& students) {
    if (students.empty()) {
        return 0.0;
    }

    double total = 0.0;
    for (const StudentRecord& student : students) {
        total += student.getAverage();
    }

    return total / students.size();
}

StudentRecord CourseStats::findHighestStudent(const std::vector<StudentRecord>& students) {
    StudentRecord highestStudent = students[0];

    for (const StudentRecord& student : students) {
        if (student.getAverage() > highestStudent.getAverage()) {
            highestStudent = student;
        }
    }

    return highestStudent;
}

StudentRecord CourseStats::findLowestStudent(const std::vector<StudentRecord>& students) {
    StudentRecord lowestStudent = students[0];

    for (const StudentRecord& student : students) {
        if (student.getAverage() < lowestStudent.getAverage()) {
            lowestStudent = student;
        }
    }

    return lowestStudent;
}

std::vector<StudentRecord> CourseStats::getPassingStudents(const std::vector<StudentRecord>& students, int passingMark) {
    std::vector<StudentRecord> passingStudents;

    for (const StudentRecord& student : students) {
        if (student.getAverage() >= passingMark) {
            passingStudents.push_back(student);
        }
    }

    return passingStudents;
}