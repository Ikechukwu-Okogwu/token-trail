// Student Name: Lyndon Wagner | Student Number : 61303
#ifndef COURSESTATS_H
#define COURSESTATS_H

#include <vector>
#include "StudentRecord.h"

class CourseStats {
public:
    static double calculateAverage(const std::vector<StudentRecord>& students);
    static StudentRecord findHighestStudent(const std::vector<StudentRecord>& students);
    static StudentRecord findLowestStudent(const std::vector<StudentRecord>& students);
    static std::vector<StudentRecord> getPassingStudents(const std::vector<StudentRecord>& students, int passingMark);
};

#endif