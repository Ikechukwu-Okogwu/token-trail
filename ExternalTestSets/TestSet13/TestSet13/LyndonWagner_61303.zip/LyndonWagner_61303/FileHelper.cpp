// Student Name: Lyndon Wagner | Student Number : 61303
#include "FileHelper.h"

std::vector<StudentRecord> FileHelper::loadSampleStudents() {
    std::vector<StudentRecord> students;

    StudentRecord s1("Alice", 1001);
    s1.addGrade(78);
    s1.addGrade(85);
    s1.addGrade(91);

    StudentRecord s2("Bob", 1002);
    s2.addGrade(56);
    s2.addGrade(62);
    s2.addGrade(59);

    StudentRecord s3("Charlie", 1003);
    s3.addGrade(88);
    s3.addGrade(90);
    s3.addGrade(84);

    StudentRecord s4("Diana", 1004);
    s4.addGrade(41);
    s4.addGrade(53);
    s4.addGrade(47);

    students.push_back(s1);
    students.push_back(s2);
    students.push_back(s3);
    students.push_back(s4);

    return students;
}