// Student Name: Lyndon Wagner | Student Number : 61303
#ifndef FILEHELPER_H
#define FILEHELPER_H

#include <vector>
#include "StudentRecord.h"

class FileHelper {
public:
    static std::vector<StudentRecord> loadSampleStudents();
};

#endif