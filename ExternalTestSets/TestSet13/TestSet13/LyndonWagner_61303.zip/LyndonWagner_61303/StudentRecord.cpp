// Student Name: Lyndon Wagner | Student Number : 61303
#include "StudentRecord.h"
#include <sstream>

StudentRecord::StudentRecord(std::string name, int studentId) {
    this->name = name;
    this->studentId = studentId;
}

void StudentRecord::addGrade(int grade) {
    grades.push_back(grade);
}

std::string StudentRecord::getName() const {
    return name;
}

int StudentRecord::getStudentId() const {
    return studentId;
}

std::vector<int> StudentRecord::getGrades() const {
    return grades;
}

double StudentRecord::getAverage() const {
    if (grades.empty()) {
        return 0.0;
    }

    int total = 0;
    for (int grade : grades) {
        total += grade;
    }

    return static_cast<double>(total) / grades.size();
}

int StudentRecord::getHighestGrade() const {
    if (grades.empty()) {
        return 0;
    }

    int highest = grades[0];
    for (int grade : grades) {
        if (grade > highest) {
            highest = grade;
        }
    }

    return highest;
}

int StudentRecord::getLowestGrade() const {
    if (grades.empty()) {
        return 0;
    }

    int lowest = grades[0];
    for (int grade : grades) {
        if (grade < lowest) {
            lowest = grade;
        }
    }

    return lowest;
}

std::string StudentRecord::formatRecord() const {
    std::ostringstream out;
    out << "Name: " << name
        << ", ID: " << studentId
        << ", Average: " << getAverage()
        << ", Highest: " << getHighestGrade()
        << ", Lowest: " << getLowestGrade();
    return out.str();
}