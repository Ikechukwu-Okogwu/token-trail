// Student Name: Lyndon Wagner | Student Number : 61303
#ifndef STUDENTRECORD_H
#define STUDENTRECORD_H

#include <string>
#include <vector>

class StudentRecord {
private:
    std::string name;
    int studentId;
    std::vector<int> grades;

public:
    StudentRecord(std::string name, int studentId);

    void addGrade(int grade);

    std::string getName() const;
    int getStudentId() const;
    std::vector<int> getGrades() const;

    double getAverage() const;
    int getHighestGrade() const;
    int getLowestGrade() const;

    std::string formatRecord() const;
};

#endif