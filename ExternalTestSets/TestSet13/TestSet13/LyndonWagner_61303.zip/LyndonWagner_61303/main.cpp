// Student Name: Lyndon Wagner | Student Number : 61303
#include <iostream>
#include <vector>
#include "StudentRecord.h"
#include "CourseStats.h"
#include "FileHelper.h"

int main() {
    std::vector<StudentRecord> students = FileHelper::loadSampleStudents();

    std::cout << "=== Student Report ===" << std::endl;
    for (const StudentRecord& student : students) {
        std::cout << student.formatRecord() << std::endl;
    }

    std::cout << std::endl;
    std::cout << "=== Summary ===" << std::endl;
    std::cout << "Class Average: " << CourseStats::calculateAverage(students) << std::endl;
    std::cout << "Highest Student: " << CourseStats::findHighestStudent(students).getName() << std::endl;
    std::cout << "Lowest Student: " << CourseStats::findLowestStudent(students).getName() << std::endl;

    std::cout << std::endl;
    std::cout << "=== Passing Students ===" << std::endl;
    std::vector<StudentRecord> passing = CourseStats::getPassingStudents(students, 50);

    for (const StudentRecord& student : passing) {
        std::cout << student.getName() << " passed with " << student.getAverage() << std::endl;
    }

    return 0;
}