// Student Name: May Williamson | Student Number: 63440
import java.util.ArrayList;

/*
 * Utility class for handling course-level calculations.
 *
 * Includes:
 * - class average
 * - highest student
 * - lowest student
 * - passing students
 */
public class CourseStats {

    /*
     * Calculates average across all students
     */
    public static double calculateAverage(ArrayList<StudentRecord> roster) {

        if (roster.isEmpty()) {
            return 0.0;
        }

        double combined = 0.0;

        // Sum student averages
        for (StudentRecord entry : roster) {
            combined += entry.getAverage();
        }

        return combined / roster.size();
    }

    /*
     * Finds student with highest average
     */
    public static StudentRecord findHighestStudent(ArrayList<StudentRecord> roster) {

        if (roster.isEmpty()) {
            return null;
        }

        StudentRecord topEntry = roster.get(0);

        // Compare each student
        for (StudentRecord entry : roster) {
            if (entry.getAverage() > topEntry.getAverage()) {
                topEntry = entry;
            }
        }

        return topEntry;
    }

    /*
     * Finds student with lowest average
     */
    public static StudentRecord findLowestStudent(ArrayList<StudentRecord> roster) {

        if (roster.isEmpty()) {
            return null;
        }

        StudentRecord bottomEntry = roster.get(0);

        // Compare each student
        for (StudentRecord entry : roster) {
            if (entry.getAverage() < bottomEntry.getAverage()) {
                bottomEntry = entry;
            }
        }

        return bottomEntry;
    }

    /*
     * Returns list of students meeting cutoff
     */
    public static ArrayList<StudentRecord> getPassingStudents(ArrayList<StudentRecord> roster, int cutoff) {

        ArrayList<StudentRecord> accepted = new ArrayList<>();

        // Filter logic
        for (StudentRecord entry : roster) {
            if (entry.getAverage() >= cutoff) {
                accepted.add(entry);
            }
        }

        return accepted;
    }
}