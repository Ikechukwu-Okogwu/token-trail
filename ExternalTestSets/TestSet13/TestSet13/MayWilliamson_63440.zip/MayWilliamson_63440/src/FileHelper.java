// Student Name: May Williamson | Student Number: 63440
import java.util.ArrayList;

/*
 * Responsible for generating or loading sample data.
 */
public class FileHelper {

    /*
     * Creates a fixed dataset of students
     */
    public static ArrayList<StudentRecord> loadSampleStudents() {

        ArrayList<StudentRecord> roster = new ArrayList<>();

        // Student A
        StudentRecord a = new StudentRecord("Alice", 1001);
        a.addGrade(78);
        a.addGrade(85);
        a.addGrade(91);

        // Student B
        StudentRecord b = new StudentRecord("Bob", 1002);
        b.addGrade(56);
        b.addGrade(62);
        b.addGrade(59);

        // Student C
        StudentRecord c = new StudentRecord("Charlie", 1003);
        c.addGrade(88);
        c.addGrade(90);
        c.addGrade(84);

        // Student D
        StudentRecord d = new StudentRecord("Diana", 1004);
        d.addGrade(41);
        d.addGrade(53);
        d.addGrade(47);

        // Add all students
        roster.add(a);
        roster.add(b);
        roster.add(c);
        roster.add(d);

        return roster;
    }
}