// Student Name: May Williamson | Student Number: 63440
import java.util.ArrayList;

/*
 * Entry point for application.
 *
 * Performs:
 * - loading student data
 * - printing records
 * - computing statistics
 */
public class Main {

    public static void main(String[] args) {

        // Load roster
        ArrayList<StudentRecord> roster = FileHelper.loadSampleStudents();

        System.out.println("=== Student Report ===");

        // Print each entry
        for (StudentRecord entry : roster) {
            System.out.println(entry.formatRecord());
        }

        System.out.println();

        System.out.println("=== Summary ===");

        // Compute stats
        System.out.println("Class Average: " + CourseStats.calculateAverage(roster));
        System.out.println("Highest Student: " + CourseStats.findHighestStudent(roster).getName());
        System.out.println("Lowest Student: " + CourseStats.findLowestStudent(roster).getName());

        System.out.println();

        System.out.println("=== Passing Students ===");

        // Filter passing
        ArrayList<StudentRecord> successful = CourseStats.getPassingStudents(roster, 50);

        for (StudentRecord entry : successful) {
            System.out.println(entry.getName() + " passed with " + entry.getAverage());
        }
    }
}