// Student Name: May Williamson | Student Number: 63440
import java.util.ArrayList;

/*
 * Represents a student entity.
 *
 * Stores:
 * - full name
 * - ID number
 * - list of marks
 *
 * Provides methods for computing statistics on marks.
 */
public class StudentRecord {

    // Student full name
    private String fullName;

    // Student ID number
    private int idNumber;

    // List of marks
    private ArrayList<Integer> marks;

    /*
     * Constructor to initialize student data
     */
    public StudentRecord(String fullName, int idNumber) {
        this.fullName = fullName;
        this.idNumber = idNumber;
        this.marks = new ArrayList<>();
    }

    /*
     * Adds a new mark to the list
     */
    public void addGrade(int mark) {
        marks.add(mark);
    }

    /*
     * Returns student name
     */
    public String getName() {
        return fullName;
    }

    /*
     * Returns student ID
     */
    public int getStudentId() {
        return idNumber;
    }

    /*
     * Returns all marks
     */
    public ArrayList<Integer> getGrades() {
        return marks;
    }

    /*
     * Computes average of marks
     */
    public double getAverage() {

        // Handle empty list
        if (marks.isEmpty()) {
            return 0.0;
        }

        int sum = 0;

        // Sum all marks
        for (int mark : marks) {
            sum += mark;
        }

        // Return average
        return (double) sum / marks.size();
    }

    /*
     * Finds maximum mark
     */
    public int getHighestGrade() {

        if (marks.isEmpty()) {
            return 0;
        }

        int maxValue = marks.get(0);

        // Compare all marks
        for (int mark : marks) {
            if (mark > maxValue) {
                maxValue = mark;
            }
        }

        return maxValue;
    }

    /*
     * Finds minimum mark
     */
    public int getLowestGrade() {

        if (marks.isEmpty()) {
            return 0;
        }

        int minValue = marks.get(0);

        // Compare all marks
        for (int mark : marks) {
            if (mark < minValue) {
                minValue = mark;
            }
        }

        return minValue;
    }

    /*
     * Formats student record as string
     */
    public String formatRecord() {
        return "Name: " + fullName +
                ", ID: " + idNumber +
                ", Average: " + getAverage() +
                ", Highest: " + getHighestGrade() +
                ", Lowest: " + getLowestGrade();
    }
}