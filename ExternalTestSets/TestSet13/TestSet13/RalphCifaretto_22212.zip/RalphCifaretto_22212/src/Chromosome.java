public class Chromosome {
    private char[] genes;
    private double fitness;
    private boolean fitnessCalculated;

    public Chromosome(int length) {
        this.genes = new char[length];
        this.fitness = Double.MAX_VALUE; //init at large, fitness is smaller is better
        this.fitnessCalculated = false;
    }

    public Chromosome(char[] genes) {
        this.genes = genes.clone();
        this.fitness = Double.MAX_VALUE;
        this.fitnessCalculated = false;
    }

    public int length() {
        return this.genes.length;
    }

    public char getGene(int index) {
        return this.genes[index];
    }

    public void setGene(int index, char value) {
        genes[index] = value;
        this.fitnessCalculated = false;
    }

    public char[] getGenes() {
        return this.genes.clone();
    }

    public double getFitness() {
        return fitness;
    }

    public void setFitness(double fitness) {
        this.fitness = fitness;
    }

    public boolean isFitnessCalculated() {
        return this.fitnessCalculated;
    }

    public Chromosome copy() {//allows us to provide a copy and not point to this chromosome
        Chromosome c = new Chromosome(this.genes);
        c.fitness = this.fitness;
        c.fitnessCalculated = this.fitnessCalculated;
        return c;
    }

    public String getKey() {//this gets the key ignoring empty spaces
        StringBuilder sb = new StringBuilder();
        for (char c : this.genes) {
            if (c != '-') {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return new String(this.genes) + "(key: " + getKey() + ")";
    }
}
