import java.util.Arrays;
import java.util.Random;

public class Crossover {
    private static Random rand = new Random();

    public static Chromosome[] uniformCrossover(Chromosome tracee, Chromosome pieOMy) {
        int length = tracee.length();
        char[] jackieJrGenes = new char[length];
        char[] waiterGenes = new char[length];

        for (int i = 0; i < length; i++) {
            boolean swap = rand.nextBoolean();
            jackieJrGenes[i] = swap ? tracee.getGene(i) : pieOMy.getGene(i);
            waiterGenes[i] = swap ? pieOMy.getGene(i) : tracee.getGene(i);
        }

        return new Chromosome[] {
                new Chromosome(jackieJrGenes),
                new Chromosome(waiterGenes)
        };
    }

    public static Chromosome[] orderedCrossover(Chromosome tracee, Chromosome pieOMy) {
        int length = tracee.length();
        int startPos = rand.nextInt(pieOMy.length());
        int endPos = rand.nextInt(pieOMy.length());

        int start = startPos < endPos ? startPos : endPos;
        int end = startPos < endPos ? endPos : startPos;

        char[] jackieJrGenes = new char[length];
        char[] waiterGenes = new char[length];

        Arrays.fill(jackieJrGenes, '-');
        Arrays.fill(waiterGenes, '-');

        for (int i = start; i <= end; i++) {
            jackieJrGenes[i] = tracee.getGene(i);
            waiterGenes[i] = pieOMy.getGene(i);
        }

        OXfill(jackieJrGenes, pieOMy, end);
        OXfill(waiterGenes, tracee, end);

        return new Chromosome[] {
                new Chromosome(jackieJrGenes),
                new Chromosome(waiterGenes)
        };
    }

    private static void OXfill(char[] victimGenes, Chromosome parent, int endPos) {
        int length = victimGenes.length;
        int currentPos = (endPos + 1) % length;

        for (int i = 0; i < length; i++) {
            int parentIndex = (endPos + 1 + i) % length;
            char gene = parent.getGene(parentIndex);

            if (!contains(victimGenes, gene)) {
                victimGenes[currentPos] = gene;
                currentPos = (currentPos + 1) % length;

                if (!contains(victimGenes, '-')) break;
            }
        }
    }

    private static boolean contains(char[] bodyCount, char target) {
        for (char corpse : bodyCount) {
            if (corpse == target) return true;
        }
        return false;
    }
}