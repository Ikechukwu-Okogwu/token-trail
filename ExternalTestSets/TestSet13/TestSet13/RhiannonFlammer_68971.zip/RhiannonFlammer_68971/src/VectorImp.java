public class VectorImp implements Vector {
    private int n;
    private double[] data;

    VectorImp() {
        this.n = 0;
        this.data = new double[0];
    }

    VectorImp(int size, double val) {
        if (size < 0) throw new IllegalArgumentException();
        this.n = size;
        this.data = new double[size];
        for (int i = 0; i < size; i++) this.data[i] = val;
    }

    VectorImp(double[] arr) {
        this.n = arr.length;
        this.data = arr.clone();
    }

    VectorImp(int[] arr) {
        this.n = arr.length;
        this.data = new double[n];
        for (int i = 0; i < n; i++) this.data[i] = arr[i];
    }

    public Vector append(double[] arr) {
        if (arr == null) throw new IllegalArgumentException("Array mustn't be null");
        double[] res = new double[this.n + arr.length];
        System.arraycopy(this.data, 0, res, 0, this.n);
        System.arraycopy(arr, 0, res, this.n, arr.length);
        return new VectorImp(res);
    }

    public Vector append(int[] arr) {
        if (arr == null) throw new IllegalArgumentException("Array mustn't be null");
        double[] res = new double[this.n + arr.length];
        System.arraycopy(this.data, 0, res, 0, this.n);
        for (int i = 0; i < arr.length; i++) res[this.n + i] = arr[i];
        return new VectorImp(res);
    }

    public Vector append(Vector v) {
        if (v == null) throw new IllegalArgumentException("Vector mustn't be null");
        double[] res = new double[this.n + v.getLength()];
        System.arraycopy(this.data, 0, res, 0, this.n);
        for (int i = 0; i < v.getLength(); i++) res[this.n + i] = v.getValue(i);
        return new VectorImp(res);
    }

    public Vector append(double x) {
        double[] res = new double[this.n + 1];
        System.arraycopy(this.data, 0, res, 0, this.n);
        res[this.n] = x;
        return new VectorImp(res);
    }

    public Vector clone() {
        return new VectorImp(this.data.clone());
    }

    public Boolean equal(Vector v) {
        if (this.n != v.getLength()) return false;
        for (int i = 0; i < this.n; i++)
            if (Math.abs(this.data[i] - v.getValue(i)) > 1e-9) return false;
        return true;
    }

    public int getLength() { return this.n; }

    public Double getValue(int i) { return this.data[i]; }

    public Vector add(Vector v) {
        if (this.n == v.getLength())
            for (int i = 0; i < this.n; i++) this.data[i] += v.getValue(i);
        return this;
    }

    public Vector add(double x) {
        for (int i = 0; i < this.n; i++) this.data[i] += x;
        return this;
    }

    public Vector sub(Vector v) {
        if (this.n == v.getLength())
            for (int i = 0; i < this.n; i++) this.data[i] -= v.getValue(i);
        return this;
    }

    public Vector subV(int l, int r) {
        if (l < 0 || r >= this.n || l > r) throw new IndexOutOfBoundsException("Invalid range");
        double[] res = new double[r - l + 1];
        System.arraycopy(this.data, l, res, 0, res.length);
        return new VectorImp(res);
    }

    public Vector Mult(Vector v) {
        if (v == null) throw new IllegalArgumentException("Vector must not be null");
        if (this.n != v.getLength()) throw new IllegalArgumentException("Vectors must have same length");
        double[] res = new double[this.n];
        for (int i = 0; i < this.n; i++) res[i] = this.data[i] * v.getValue(i);
        return new VectorImp(res);
    }

    public Vector Mult(double x) {
        double[] res = new double[this.n];
        for (int i = 0; i < this.n; i++) res[i] = this.data[i] * x;
        return new VectorImp(res);
    }

    public Vector Normalize() {
        if (this.n == 0) return new VectorImp();
        double max = 0;
        for (int i = 0; i < this.n; i++) max = Math.max(max, Math.abs(this.data[i]));
        if (max == 0) return this.clone();
        double[] res = new double[this.n];
        for (int i = 0; i < this.n; i++) res[i] = this.data[i] / max;
        return new VectorImp(res);
    }

    public Double EuclidianDistance(Vector v) {
        if (v == null) throw new IllegalArgumentException("Vector must not be null");
        if (this.n != v.getLength()) throw new IllegalArgumentException("Vectors must have same length");
        double sum = 0;
        for (int i = 0; i < this.n; i++) sum += Math.pow(this.data[i] - v.getValue(i), 2);
        return Math.sqrt(sum);
    }
}