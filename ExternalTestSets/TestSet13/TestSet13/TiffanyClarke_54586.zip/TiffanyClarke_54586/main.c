// Student Name: Tiffany Clarke | Student Number :54586 
#include <stdio.h>
#include <string.h>

// Maximum number of books allowed
#define MAX_BOOKS 100

// Maximum length for title
#define TITLE_SIZE 100

/*
 * Structure representing a book in the library
 */
typedef struct {
    int id;                     // Unique book ID
    char title[TITLE_SIZE];     // Title of the book
    int copies;                // Total copies available
    int borrowed;              // Number of copies currently borrowed
} Book;

/*
 * Adds a new book into the system
 */
void addBook(Book books[], int *count, int id, const char title[], int copies) {

    // Check if library is full
    if (*count >= MAX_BOOKS) {
        printf("Library is full.\n");
        return;
    }

    // Assign values
    books[*count].id = id;
    strcpy(books[*count].title, title);
    books[*count].copies = copies;
    books[*count].borrowed = 0;

    // Increment total count
    (*count)++;
}

/*
 * Finds index of a book by ID
 */
int findBookIndex(Book books[], int count, int id) {
    int i;

    // Loop through all books
    for (i = 0; i < count; i++) {

        // If ID matches, return index
        if (books[i].id == id) {
            return i;
        }
    }

    // Not found
    return -1;
}

/*
 * Borrow a book
 */
void borrowBook(Book books[], int count, int id) {

    // Locate book
    int index = findBookIndex(books, count, id);

    // If not found
    if (index == -1) {
        printf("Book with ID %d not found.\n", id);
        return;
    }

    // Check availability
    if (books[index].borrowed < books[index].copies) {
        books[index].borrowed++;
        printf("Borrowed: %s\n", books[index].title);
    } else {
        printf("No available copies for %s\n", books[index].title);
    }
}

/*
 * Return a book
 */
void returnBook(Book books[], int count, int id) {

    int index = findBookIndex(books, count, id);

    if (index == -1) {
        printf("Book with ID %d not found.\n", id);
        return;
    }

    // Ensure at least one borrowed
    if (books[index].borrowed > 0) {
        books[index].borrowed--;
        printf("Returned: %s\n", books[index].title);
    } else {
        printf("No borrowed copies to return for %s\n", books[index].title);
    }
}

/*
 * Prints a single book
 */
void printBook(Book book) {
    printf("ID: %d, Title: %s, Copies: %d, Borrowed: %d, Available: %d\n",
           book.id,
           book.title,
           book.copies,
           book.borrowed,
           book.copies - book.borrowed);
}

/*
 * Prints all books
 */
void printAllBooks(Book books[], int count) {
    int i;

    printf("\n=== Library Inventory ===\n");

    for (i = 0; i < count; i++) {
        printBook(books[i]);
    }
}

/*
 * Total number of copies
 */
int totalCopies(Book books[], int count) {
    int i, total = 0;

    for (i = 0; i < count; i++) {
        total += books[i].copies;
    }

    return total;
}

/*
 * Total borrowed books
 */
int totalBorrowed(Book books[], int count) {
    int i, total = 0;

    for (i = 0; i < count; i++) {
        total += books[i].borrowed;
    }

    return total;
}

/*
 * Finds most borrowed book index
 */
int mostBorrowedIndex(Book books[], int count) {

    if (count == 0) {
        return -1;
    }

    int i, best = 0;

    for (i = 1; i < count; i++) {
        if (books[i].borrowed > books[best].borrowed) {
            best = i;
        }
    }

    return best;
}

/*
 * Prints summary statistics
 */
void printSummary(Book books[], int count) {

    int topIndex = mostBorrowedIndex(books, count);

    printf("\n=== Summary ===\n");
    printf("Total Titles: %d\n", count);
    printf("Total Copies: %d\n", totalCopies(books, count));
    printf("Total Borrowed: %d\n", totalBorrowed(books, count));

    if (topIndex != -1) {
        printf("Most Borrowed Book: %s\n", books[topIndex].title);
    }
}

/*
 * Main driver
 */
int main() {

    Book books[MAX_BOOKS];
    int count = 0;

    // Add sample books
    addBook(books, &count, 101, "C Programming", 4);
    addBook(books, &count, 102, "Data Structures", 3);
    addBook(books, &count, 103, "Operating Systems", 5);
    addBook(books, &count, 104, "Algorithms", 2);
    addBook(books, &count, 105, "Databases", 6);

    // Simulate borrowing
    borrowBook(books, count, 101);
    borrowBook(books, count, 101);
    borrowBook(books, count, 103);
    borrowBook(books, count, 104);
    borrowBook(books, count, 104);
    borrowBook(books, count, 104);

    // Simulate returns
    returnBook(books, count, 101);
    returnBook(books, count, 105);

    // Output
    printAllBooks(books, count);
    printSummary(books, count);

    return 0;
}