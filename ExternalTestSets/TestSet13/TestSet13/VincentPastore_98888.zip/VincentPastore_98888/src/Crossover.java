import java.util.Arrays;
import java.util.Random;

public class Crossover {
    private static Random rand = new Random();

    public static Chromosome[] uniformCrossover(Chromosome a, Chromosome b) {
        int length = a.length();
        char[] c1Genes = new char[length];
        char[] c2Genes = new char[length];

        for (int i = 0; i < length; i++) {
            if (rand.nextBoolean()) {// 50/50 random on whether we crossover
                c1Genes[i] = a.getGene(i);
                c2Genes[i] = b.getGene(i);
            } else {
                c1Genes[i] = b.getGene(i);
                c2Genes[i] = a.getGene(i);
            }
        }

        return new Chromosome[] {
                new Chromosome(c1Genes),
                new Chromosome(c2Genes)
        };
    }

    public static Chromosome[] orderedCrossover(Chromosome a, Chromosome b) {
        int length = a.length();
        int p1 = rand.nextInt(b.length());
        int p2 = rand.nextInt(b.length());

        if (p1 > p2) {
            int temp = p1;
            p1 = p2;
            p2 = temp;
        }
        //gen two emptychildren
        char[] c1Genes = new char[length];
        char[] c2Genes = new char[length];

        Arrays.fill(c1Genes, '-');
        Arrays.fill(c2Genes, '-');

        for (int i = p1; i <= p2; i++) {// here we copy/swap over a sequence
            c1Genes[i] = a.getGene(i);
            c2Genes[i] = b.getGene(i);
        }

        OXfill(c1Genes, b, p2);//call to fill the rest of the array given the parts that we want to keep
        OXfill(c2Genes, a, p2);

        return new Chromosome[] {
                new Chromosome(c1Genes),
                new Chromosome(c2Genes)
        };
    }

    private static void OXfill(char[] c1Genes, Chromosome a,  int e) {
        int length = c1Genes.length;
        int currentPos = (e + 1) % length;

        for (int i = 0; i < length; i++) {
            int parentIndex = (e + 1 + i) % length;
            char gene = a.getGene(parentIndex);

            if (!contains(c1Genes, gene)) {//fill with parents gene if this is empty
                c1Genes[currentPos] = gene;
                currentPos = (currentPos + 1) % length;

                if (!contains(c1Genes, '-')) { // does not contain any empty spaces
                    break;
                }
            }
        }
    }

    private static boolean contains(char[] array, char target) {
        for (char c : array) {
            if (c == target) {
                return true;
            }
        }
        return false;
    }
}
