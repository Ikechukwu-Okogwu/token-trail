import java.util.Scanner;
import java.util.Random;

public class MatrixOperations {

    private int rows;
    private int cols;
    private double[][] data;

    public MatrixOperations(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.data = new double[rows][cols];
    }

    public MatrixOperations(double[][] values) {
        this.rows = values.length;
        this.cols = values[0].length;
        this.data = new double[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                this.data[i][j] = values[i][j];
            }
        }
    }

    public void fillRandom(int maxValue) {
        Random random = new Random();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                data[i][j] = random.nextInt(maxValue) + 1;
            }
        }
    }

    public MatrixOperations multiply(MatrixOperations other) {
        if (this.cols != other.rows) {
            System.out.println("Error: incompatible matrix dimensions for multiplication.");
            return null;
        }
        MatrixOperations result = new MatrixOperations(this.rows, other.cols);
        for (int i = 0; i < this.rows; i++) {
            for (int j = 0; j < other.cols; j++) {
                double sum = 0.0;
                for (int k = 0; k < this.cols; k++) {
                    sum += this.data[i][k] * other.data[k][j];
                }
                result.data[i][j] = sum;
            }
        }
        return result;
    }

    public MatrixOperations add(MatrixOperations other) {
        if (this.rows != other.rows || this.cols != other.cols) {
            System.out.println("Error: incompatible matrix dimensions for addition.");
            return null;
        }
        MatrixOperations result = new MatrixOperations(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.data[i][j] = this.data[i][j] + other.data[i][j];
            }
        }
        return result;
    }

    public MatrixOperations subtract(MatrixOperations other) {
        if (this.rows != other.rows || this.cols != other.cols) {
            System.out.println("Error: incompatible matrix dimensions for subtraction.");
            return null;
        }
        MatrixOperations result = new MatrixOperations(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.data[i][j] = this.data[i][j] - other.data[i][j];
            }
        }
        return result;
    }

    public MatrixOperations transpose() {
        MatrixOperations result = new MatrixOperations(cols, rows);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.data[j][i] = this.data[i][j];
            }
        }
        return result;
    }

    public double determinant() {
        if (rows != cols) {
            System.out.println("Error: determinant only defined for square matrices.");
            return 0;
        }
        return computeDeterminant(data, rows);
    }

    private double computeDeterminant(double[][] matrix, int n) {
        if (n == 1) {
            return matrix[0][0];
        }
        if (n == 2) {
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        }
        double det = 0.0;
        for (int col = 0; col < n; col++) {
            double[][] subMatrix = new double[n - 1][n - 1];
            for (int i = 1; i < n; i++) {
                int subCol = 0;
                for (int j = 0; j < n; j++) {
                    if (j == col) continue;
                    subMatrix[i - 1][subCol] = matrix[i][j];
                    subCol++;
                }
            }
            double sign = (col % 2 == 0) ? 1.0 : -1.0;
            det += sign * matrix[0][col] * computeDeterminant(subMatrix, n - 1);
        }
        return det;
    }

    public void display() {
        System.out.println("Matrix (" + rows + "x" + cols + "):");
        for (int i = 0; i < rows; i++) {
            StringBuilder sb = new StringBuilder("  ");
            for (int j = 0; j < cols; j++) {
                sb.append(String.format("%8.2f", data[i][j]));
                if (j < cols - 1) sb.append(" ");
            }
            System.out.println(sb.toString());
        }
        System.out.println();
    }

    public double getElement(int row, int col) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            System.out.println("Error: index out of bounds.");
            return 0;
        }
        return data[row][col];
    }

    public void setElement(int row, int col, double value) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            System.out.println("Error: index out of bounds.");
            return;
        }
        data[row][col] = value;
    }

    public MatrixOperations scalarMultiply(double scalar) {
        MatrixOperations result = new MatrixOperations(rows, cols);
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                result.data[i][j] = this.data[i][j] * scalar;
            }
        }
        return result;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Matrix Operations Tool ===");
        System.out.print("Enter rows for Matrix A: ");
        int rowsA = scanner.nextInt();
        System.out.print("Enter cols for Matrix A: ");
        int colsA = scanner.nextInt();

        MatrixOperations matA = new MatrixOperations(rowsA, colsA);
        matA.fillRandom(10);
        System.out.println("\nMatrix A:");
        matA.display();

        System.out.print("Enter rows for Matrix B: ");
        int rowsB = scanner.nextInt();
        System.out.print("Enter cols for Matrix B: ");
        int colsB = scanner.nextInt();

        MatrixOperations matB = new MatrixOperations(rowsB, colsB);
        matB.fillRandom(10);
        System.out.println("Matrix B:");
        matB.display();

        System.out.println("--- Multiplication Result ---");
        MatrixOperations product = matA.multiply(matB);
        if (product != null) {
            product.display();
        }

        System.out.println("--- Transpose of A ---");
        MatrixOperations transA = matA.transpose();
        transA.display();

        if (rowsA == colsA) {
            System.out.println("--- Determinant of A ---");
            double det = matA.determinant();
            System.out.printf("det(A) = %.4f%n", det);
        }

        System.out.println("--- Scalar Multiply A * 2.5 ---");
        MatrixOperations scaled = matA.scalarMultiply(2.5);
        scaled.display();

        scanner.close();
        System.out.println("Done.");
    }
}
