import java.util.Scanner;
import java.util.Random;

public class GridMath {

    private int numRows;
    private int numCols;
    private double[][] grid;

    public GridMath(int numRows, int numCols) {
        this.numRows = numRows;
        this.numCols = numCols;
        this.grid = new double[numRows][numCols];
    }

    public GridMath(double[][] input) {
        this.numRows = input.length;
        this.numCols = input[0].length;
        this.grid = new double[numRows][numCols];
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                this.grid[r][c] = input[r][c];
            }
        }
    }

    public void populateRandom(int upperBound) {
        Random rng = new Random();
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                grid[r][c] = rng.nextInt(upperBound) + 1;
            }
        }
    }

    public GridMath multiply(GridMath second) {
        if (this.numCols != second.numRows) {
            System.out.println("Error: incompatible matrix dimensions for multiplication.");
            return null;
        }
        GridMath output = new GridMath(this.numRows, second.numCols);
        for (int r = 0; r < this.numRows; r++) {
            for (int c = 0; c < second.numCols; c++) {
                double total = 0.0;
                for (int idx = 0; idx < this.numCols; idx++) {
                    total += this.grid[r][idx] * second.grid[idx][c];
                }
                output.grid[r][c] = total;
            }
        }
        return output;
    }

    public GridMath add(GridMath second) {
        if (this.numRows != second.numRows || this.numCols != second.numCols) {
            System.out.println("Error: incompatible matrix dimensions for addition.");
            return null;
        }
        GridMath output = new GridMath(numRows, numCols);
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                output.grid[r][c] = this.grid[r][c] + second.grid[r][c];
            }
        }
        return output;
    }

    public GridMath subtract(GridMath second) {
        if (this.numRows != second.numRows || this.numCols != second.numCols) {
            System.out.println("Error: incompatible matrix dimensions for subtraction.");
            return null;
        }
        GridMath output = new GridMath(numRows, numCols);
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                output.grid[r][c] = this.grid[r][c] - second.grid[r][c];
            }
        }
        return output;
    }

    public GridMath transpose() {
        GridMath output = new GridMath(numCols, numRows);
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                output.grid[c][r] = this.grid[r][c];
            }
        }
        return output;
    }

    public double determinant() {
        if (numRows != numCols) {
            System.out.println("Error: determinant only defined for square matrices.");
            return 0;
        }
        return calcDeterminant(grid, numRows);
    }

    private double calcDeterminant(double[][] mat, int size) {
        if (size == 1) {
            return mat[0][0];
        }
        if (size == 2) {
            return mat[0][0] * mat[1][1] - mat[0][1] * mat[1][0];
        }
        double det = 0.0;
        for (int c = 0; c < size; c++) {
            double[][] minor = new double[size - 1][size - 1];
            for (int r = 1; r < size; r++) {
                int minorCol = 0;
                for (int j = 0; j < size; j++) {
                    if (j == c) continue;
                    minor[r - 1][minorCol] = mat[r][j];
                    minorCol++;
                }
            }
            double factor = (c % 2 == 0) ? 1.0 : -1.0;
            det += factor * mat[0][c] * calcDeterminant(minor, size - 1);
        }
        return det;
    }

    public void print() {
        System.out.println("Matrix (" + numRows + "x" + numCols + "):");
        for (int r = 0; r < numRows; r++) {
            StringBuilder line = new StringBuilder("  ");
            for (int c = 0; c < numCols; c++) {
                line.append(String.format("%8.2f", grid[r][c]));
                if (c < numCols - 1) line.append(" ");
            }
            System.out.println(line.toString());
        }
        System.out.println();
    }

    public double getValue(int row, int col) {
        if (row < 0 || row >= numRows || col < 0 || col >= numCols) {
            System.out.println("Error: index out of bounds.");
            return 0;
        }
        return grid[row][col];
    }

    public void setValue(int row, int col, double val) {
        if (row < 0 || row >= numRows || col < 0 || col >= numCols) {
            System.out.println("Error: index out of bounds.");
            return;
        }
        grid[row][col] = val;
    }

    public GridMath scalarMultiply(double factor) {
        GridMath output = new GridMath(numRows, numCols);
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                output.grid[r][c] = this.grid[r][c] * factor;
            }
        }
        return output;
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("=== Matrix Operations Tool ===");
        System.out.print("Enter rows for Matrix A: ");
        int rA = input.nextInt();
        System.out.print("Enter cols for Matrix A: ");
        int cA = input.nextInt();

        GridMath first = new GridMath(rA, cA);
        first.populateRandom(10);
        System.out.println("\nMatrix A:");
        first.print();

        System.out.print("Enter rows for Matrix B: ");
        int rB = input.nextInt();
        System.out.print("Enter cols for Matrix B: ");
        int cB = input.nextInt();

        GridMath second = new GridMath(rB, cB);
        second.populateRandom(10);
        System.out.println("Matrix B:");
        second.print();

        System.out.println("--- Multiplication Result ---");
        GridMath prod = first.multiply(second);
        if (prod != null) {
            prod.print();
        }

        System.out.println("--- Transpose of A ---");
        GridMath flipped = first.transpose();
        flipped.print();

        if (rA == cA) {
            System.out.println("--- Determinant of A ---");
            double detVal = first.determinant();
            System.out.printf("det(A) = %.4f%n", detVal);
        }

        System.out.println("--- Scalar Multiply A * 2.5 ---");
        GridMath magnified = first.scalarMultiply(2.5);
        magnified.print();

        input.close();
        System.out.println("Done.");
    }
}
