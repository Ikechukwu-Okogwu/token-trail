#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Node {
    int data;
    struct Node* next;
} Node;

typedef struct LinkedList {
    Node* head;
    int size;
} LinkedList;

LinkedList* createList() {
    LinkedList* list = (LinkedList*)malloc(sizeof(LinkedList));
    list->head = NULL;
    list->size = 0;
    return list;
}

Node* createNode(int value) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (newNode == NULL) {
        printf("Error: memory allocation failed.\n");
        return NULL;
    }
    newNode->data = value;
    newNode->next = NULL;
    return newNode;
}

void insertAtHead(LinkedList* list, int value) {
    Node* newNode = createNode(value);
    if (newNode == NULL) return;
    newNode->next = list->head;
    list->head = newNode;
    list->size++;
    printf("Inserted %d at head.\n", value);
}

void insertAtTail(LinkedList* list, int value) {
    Node* newNode = createNode(value);
    if (newNode == NULL) return;
    if (list->head == NULL) {
        list->head = newNode;
    } else {
        Node* current = list->head;
        while (current->next != NULL) {
            current = current->next;
        }
        current->next = newNode;
    }
    list->size++;
    printf("Inserted %d at tail.\n", value);
}

void insertAtPosition(LinkedList* list, int value, int position) {
    if (position < 0 || position > list->size) {
        printf("Error: invalid position %d.\n", position);
        return;
    }
    if (position == 0) {
        insertAtHead(list, value);
        return;
    }
    Node* newNode = createNode(value);
    if (newNode == NULL) return;
    Node* current = list->head;
    for (int i = 0; i < position - 1; i++) {
        current = current->next;
    }
    newNode->next = current->next;
    current->next = newNode;
    list->size++;
    printf("Inserted %d at position %d.\n", value, position);
}

int deleteAtHead(LinkedList* list) {
    if (list->head == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    Node* temp = list->head;
    int value = temp->data;
    list->head = temp->next;
    free(temp);
    list->size--;
    printf("Deleted %d from head.\n", value);
    return value;
}

int deleteAtTail(LinkedList* list) {
    if (list->head == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    if (list->head->next == NULL) {
        int value = list->head->data;
        free(list->head);
        list->head = NULL;
        list->size--;
        printf("Deleted %d from tail.\n", value);
        return value;
    }
    Node* current = list->head;
    while (current->next->next != NULL) {
        current = current->next;
    }
    int value = current->next->data;
    free(current->next);
    current->next = NULL;
    list->size--;
    printf("Deleted %d from tail.\n", value);
    return value;
}

int deleteByValue(LinkedList* list, int value) {
    if (list->head == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    if (list->head->data == value) {
        return deleteAtHead(list);
    }
    Node* current = list->head;
    while (current->next != NULL && current->next->data != value) {
        current = current->next;
    }
    if (current->next == NULL) {
        printf("Error: value %d not found.\n", value);
        return -1;
    }
    Node* temp = current->next;
    current->next = temp->next;
    free(temp);
    list->size--;
    printf("Deleted %d from list.\n", value);
    return value;
}

int search(LinkedList* list, int value) {
    Node* current = list->head;
    int index = 0;
    while (current != NULL) {
        if (current->data == value) {
            return index;
        }
        current = current->next;
        index++;
    }
    return -1;
}

void reverse(LinkedList* list) {
    Node* prev = NULL;
    Node* current = list->head;
    Node* next = NULL;
    while (current != NULL) {
        next = current->next;
        current->next = prev;
        prev = current;
        current = next;
    }
    list->head = prev;
    printf("List reversed.\n");
}

void display(LinkedList* list) {
    if (list->head == NULL) {
        printf("List is empty.\n");
        return;
    }
    printf("List (%d elements): ", list->size);
    Node* current = list->head;
    while (current != NULL) {
        printf("%d", current->data);
        if (current->next != NULL) {
            printf(" -> ");
        }
        current = current->next;
    }
    printf("\n");
}

void destroyList(LinkedList* list) {
    Node* current = list->head;
    while (current != NULL) {
        Node* temp = current;
        current = current->next;
        free(temp);
    }
    free(list);
    printf("List destroyed.\n");
}

void sortList(LinkedList* list) {
    if (list->head == NULL || list->head->next == NULL) return;
    int swapped;
    do {
        swapped = 0;
        Node* current = list->head;
        while (current->next != NULL) {
            if (current->data > current->next->data) {
                int temp = current->data;
                current->data = current->next->data;
                current->next->data = temp;
                swapped = 1;
            }
            current = current->next;
        }
    } while (swapped);
    printf("List sorted.\n");
}

int main() {
    LinkedList* list = createList();
    int choice, value, position;

    printf("=== Linked List Manager ===\n");
    do {
        printf("\n1. Insert at head\n");
        printf("2. Insert at tail\n");
        printf("3. Insert at position\n");
        printf("4. Delete from head\n");
        printf("5. Delete from tail\n");
        printf("6. Delete by value\n");
        printf("7. Search\n");
        printf("8. Reverse\n");
        printf("9. Sort\n");
        printf("10. Display\n");
        printf("0. Exit\n");
        printf("Choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            printf("Value: ");
            scanf("%d", &value);
            insertAtHead(list, value);
        } else if (choice == 2) {
            printf("Value: ");
            scanf("%d", &value);
            insertAtTail(list, value);
        } else if (choice == 3) {
            printf("Value: ");
            scanf("%d", &value);
            printf("Position: ");
            scanf("%d", &position);
            insertAtPosition(list, value, position);
        } else if (choice == 4) {
            deleteAtHead(list);
        } else if (choice == 5) {
            deleteAtTail(list);
        } else if (choice == 6) {
            printf("Value: ");
            scanf("%d", &value);
            deleteByValue(list, value);
        } else if (choice == 7) {
            printf("Value: ");
            scanf("%d", &value);
            int idx = search(list, value);
            if (idx >= 0) {
                printf("Found at index %d.\n", idx);
            } else {
                printf("Not found.\n");
            }
        } else if (choice == 8) {
            reverse(list);
        } else if (choice == 9) {
            sortList(list);
        } else if (choice == 10) {
            display(list);
        }
    } while (choice != 0);

    destroyList(list);
    printf("Goodbye.\n");
    return 0;
}
