#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct Element {
    int val;
    struct Element* nxt;
} Element;

typedef struct Chain {
    Element* front;
    int count;
} Chain;

Chain* initChain() {
    Chain* ch = (Chain*)malloc(sizeof(Chain));
    ch->front = NULL;
    ch->count = 0;
    return ch;
}

Element* makeElement(int v) {
    Element* el = (Element*)malloc(sizeof(Element));
    if (el == NULL) {
        printf("Error: memory allocation failed.\n");
        return NULL;
    }
    el->val = v;
    el->nxt = NULL;
    return el;
}

void addFront(Chain* ch, int v) {
    Element* el = makeElement(v);
    if (el == NULL) return;
    el->nxt = ch->front;
    ch->front = el;
    ch->count++;
    printf("Inserted %d at head.\n", v);
}

void addBack(Chain* ch, int v) {
    Element* el = makeElement(v);
    if (el == NULL) return;
    if (ch->front == NULL) {
        ch->front = el;
    } else {
        Element* ptr = ch->front;
        while (ptr->nxt != NULL) {
            ptr = ptr->nxt;
        }
        ptr->nxt = el;
    }
    ch->count++;
    printf("Inserted %d at tail.\n", v);
}

void addAt(Chain* ch, int v, int pos) {
    if (pos < 0 || pos > ch->count) {
        printf("Error: invalid position %d.\n", pos);
        return;
    }
    if (pos == 0) {
        addFront(ch, v);
        return;
    }
    Element* el = makeElement(v);
    if (el == NULL) return;
    Element* ptr = ch->front;
    for (int i = 0; i < pos - 1; i++) {
        ptr = ptr->nxt;
    }
    el->nxt = ptr->nxt;
    ptr->nxt = el;
    ch->count++;
    printf("Inserted %d at position %d.\n", v, pos);
}

int removeFront(Chain* ch) {
    if (ch->front == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    Element* tmp = ch->front;
    int v = tmp->val;
    ch->front = tmp->nxt;
    free(tmp);
    ch->count--;
    printf("Deleted %d from head.\n", v);
    return v;
}

int removeBack(Chain* ch) {
    if (ch->front == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    if (ch->front->nxt == NULL) {
        int v = ch->front->val;
        free(ch->front);
        ch->front = NULL;
        ch->count--;
        printf("Deleted %d from tail.\n", v);
        return v;
    }
    Element* ptr = ch->front;
    while (ptr->nxt->nxt != NULL) {
        ptr = ptr->nxt;
    }
    int v = ptr->nxt->val;
    free(ptr->nxt);
    ptr->nxt = NULL;
    ch->count--;
    printf("Deleted %d from tail.\n", v);
    return v;
}

int removeByVal(Chain* ch, int v) {
    if (ch->front == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    if (ch->front->val == v) {
        return removeFront(ch);
    }
    Element* ptr = ch->front;
    while (ptr->nxt != NULL && ptr->nxt->val != v) {
        ptr = ptr->nxt;
    }
    if (ptr->nxt == NULL) {
        printf("Error: value %d not found.\n", v);
        return -1;
    }
    Element* tmp = ptr->nxt;
    ptr->nxt = tmp->nxt;
    free(tmp);
    ch->count--;
    printf("Deleted %d from list.\n", v);
    return v;
}

int find(Chain* ch, int v) {
    Element* ptr = ch->front;
    int idx = 0;
    while (ptr != NULL) {
        if (ptr->val == v) {
            return idx;
        }
        ptr = ptr->nxt;
        idx++;
    }
    return -1;
}

void flip(Chain* ch) {
    Element* prev = NULL;
    Element* ptr = ch->front;
    Element* nxt = NULL;
    while (ptr != NULL) {
        nxt = ptr->nxt;
        ptr->nxt = prev;
        prev = ptr;
        ptr = nxt;
    }
    ch->front = prev;
    printf("List reversed.\n");
}

void show(Chain* ch) {
    if (ch->front == NULL) {
        printf("List is empty.\n");
        return;
    }
    printf("List (%d elements): ", ch->count);
    Element* ptr = ch->front;
    while (ptr != NULL) {
        printf("%d", ptr->val);
        if (ptr->nxt != NULL) {
            printf(" -> ");
        }
        ptr = ptr->nxt;
    }
    printf("\n");
}

void freeChain(Chain* ch) {
    Element* ptr = ch->front;
    while (ptr != NULL) {
        Element* tmp = ptr;
        ptr = ptr->nxt;
        free(tmp);
    }
    free(ch);
    printf("List destroyed.\n");
}

void orderChain(Chain* ch) {
    if (ch->front == NULL || ch->front->nxt == NULL) return;
    int changed;
    do {
        changed = 0;
        Element* ptr = ch->front;
        while (ptr->nxt != NULL) {
            if (ptr->val > ptr->nxt->val) {
                int tmp = ptr->val;
                ptr->val = ptr->nxt->val;
                ptr->nxt->val = tmp;
                changed = 1;
            }
            ptr = ptr->nxt;
        }
    } while (changed);
    printf("List sorted.\n");
}

int main() {
    Chain* ch = initChain();
    int opt, v, pos;

    printf("=== Linked List Manager ===\n");
    do {
        printf("\n1. Insert at head\n");
        printf("2. Insert at tail\n");
        printf("3. Insert at position\n");
        printf("4. Delete from head\n");
        printf("5. Delete from tail\n");
        printf("6. Delete by value\n");
        printf("7. Search\n");
        printf("8. Reverse\n");
        printf("9. Sort\n");
        printf("10. Display\n");
        printf("0. Exit\n");
        printf("Choice: ");
        scanf("%d", &opt);

        if (opt == 1) {
            printf("Value: ");
            scanf("%d", &v);
            addFront(ch, v);
        } else if (opt == 2) {
            printf("Value: ");
            scanf("%d", &v);
            addBack(ch, v);
        } else if (opt == 3) {
            printf("Value: ");
            scanf("%d", &v);
            printf("Position: ");
            scanf("%d", &pos);
            addAt(ch, v, pos);
        } else if (opt == 4) {
            removeFront(ch);
        } else if (opt == 5) {
            removeBack(ch);
        } else if (opt == 6) {
            printf("Value: ");
            scanf("%d", &v);
            removeByVal(ch, v);
        } else if (opt == 7) {
            printf("Value: ");
            scanf("%d", &v);
            int idx = find(ch, v);
            if (idx >= 0) {
                printf("Found at index %d.\n", idx);
            } else {
                printf("Not found.\n");
            }
        } else if (opt == 8) {
            flip(ch);
        } else if (opt == 9) {
            orderChain(ch);
        } else if (opt == 10) {
            show(ch);
        }
    } while (opt != 0);

    freeChain(ch);
    printf("Goodbye.\n");
    return 0;
}
