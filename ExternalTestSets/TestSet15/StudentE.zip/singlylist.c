#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct ListNode {
    int item;
    struct ListNode* following;
} ListNode;

typedef struct SinglyList {
    ListNode* first;
    int length;
} SinglyList;

SinglyList* newSinglyList() {
    SinglyList* sl = (SinglyList*)malloc(sizeof(SinglyList));
    sl->first = NULL;
    sl->length = 0;
    return sl;
}

ListNode* newListNode(int x) {
    ListNode* nd = (ListNode*)malloc(sizeof(ListNode));
    if (nd == NULL) {
        printf("Error: memory allocation failed.\n");
        return NULL;
    }
    nd->item = x;
    nd->following = NULL;
    return nd;
}

void prependItem(SinglyList* sl, int x) {
    ListNode* nd = newListNode(x);
    if (nd == NULL) return;
    nd->following = sl->first;
    sl->first = nd;
    sl->length++;
    printf("Inserted %d at head.\n", x);
}

void appendItem(SinglyList* sl, int x) {
    ListNode* nd = newListNode(x);
    if (nd == NULL) return;
    if (sl->first == NULL) {
        sl->first = nd;
    } else {
        ListNode* walker = sl->first;
        while (walker->following != NULL) {
            walker = walker->following;
        }
        walker->following = nd;
    }
    sl->length++;
    printf("Inserted %d at tail.\n", x);
}

void insertItemAt(SinglyList* sl, int x, int loc) {
    if (loc < 0 || loc > sl->length) {
        printf("Error: invalid position %d.\n", loc);
        return;
    }
    if (loc == 0) {
        prependItem(sl, x);
        return;
    }
    ListNode* nd = newListNode(x);
    if (nd == NULL) return;
    ListNode* walker = sl->first;
    for (int i = 0; i < loc - 1; i++) {
        walker = walker->following;
    }
    nd->following = walker->following;
    walker->following = nd;
    sl->length++;
    printf("Inserted %d at position %d.\n", x, loc);
}

int removeFirst(SinglyList* sl) {
    if (sl->first == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    ListNode* doomed = sl->first;
    int x = doomed->item;
    sl->first = doomed->following;
    free(doomed);
    sl->length--;
    printf("Deleted %d from head.\n", x);
    return x;
}

int removeLast(SinglyList* sl) {
    if (sl->first == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    if (sl->first->following == NULL) {
        int x = sl->first->item;
        free(sl->first);
        sl->first = NULL;
        sl->length--;
        printf("Deleted %d from tail.\n", x);
        return x;
    }
    ListNode* walker = sl->first;
    while (walker->following->following != NULL) {
        walker = walker->following;
    }
    int x = walker->following->item;
    free(walker->following);
    walker->following = NULL;
    sl->length--;
    printf("Deleted %d from tail.\n", x);
    return x;
}

int removeItem(SinglyList* sl, int x) {
    if (sl->first == NULL) {
        printf("Error: list is empty.\n");
        return -1;
    }
    if (sl->first->item == x) {
        return removeFirst(sl);
    }
    ListNode* walker = sl->first;
    while (walker->following != NULL && walker->following->item != x) {
        walker = walker->following;
    }
    if (walker->following == NULL) {
        printf("Error: value %d not found.\n", x);
        return -1;
    }
    ListNode* doomed = walker->following;
    walker->following = doomed->following;
    free(doomed);
    sl->length--;
    printf("Deleted %d from list.\n", x);
    return x;
}

int locateItem(SinglyList* sl, int x) {
    ListNode* walker = sl->first;
    int pos = 0;
    while (walker != NULL) {
        if (walker->item == x) {
            return pos;
        }
        walker = walker->following;
        pos++;
    }
    return -1;
}

void reverseList(SinglyList* sl) {
    ListNode* behind = NULL;
    ListNode* walker = sl->first;
    ListNode* ahead = NULL;
    while (walker != NULL) {
        ahead = walker->following;
        walker->following = behind;
        behind = walker;
        walker = ahead;
    }
    sl->first = behind;
    printf("List reversed.\n");
}

void printList(SinglyList* sl) {
    if (sl->first == NULL) {
        printf("List is empty.\n");
        return;
    }
    printf("List (%d elements): ", sl->length);
    ListNode* walker = sl->first;
    while (walker != NULL) {
        printf("%d", walker->item);
        if (walker->following != NULL) {
            printf(" -> ");
        }
        walker = walker->following;
    }
    printf("\n");
}

void destroySinglyList(SinglyList* sl) {
    ListNode* walker = sl->first;
    while (walker != NULL) {
        ListNode* doomed = walker;
        walker = walker->following;
        free(doomed);
    }
    free(sl);
    printf("List destroyed.\n");
}

void bubbleSortList(SinglyList* sl) {
    if (sl->first == NULL || sl->first->following == NULL) return;
    int didSwap;
    do {
        didSwap = 0;
        ListNode* walker = sl->first;
        while (walker->following != NULL) {
            if (walker->item > walker->following->item) {
                int hold = walker->item;
                walker->item = walker->following->item;
                walker->following->item = hold;
                didSwap = 1;
            }
            walker = walker->following;
        }
    } while (didSwap);
    printf("List sorted.\n");
}

int main() {
    SinglyList* sl = newSinglyList();
    int cmd, x, loc;

    printf("=== Linked List Manager ===\n");
    do {
        printf("\n1. Insert at head\n");
        printf("2. Insert at tail\n");
        printf("3. Insert at position\n");
        printf("4. Delete from head\n");
        printf("5. Delete from tail\n");
        printf("6. Delete by value\n");
        printf("7. Search\n");
        printf("8. Reverse\n");
        printf("9. Sort\n");
        printf("10. Display\n");
        printf("0. Exit\n");
        printf("Choice: ");
        scanf("%d", &cmd);

        if (cmd == 1) {
            printf("Value: ");
            scanf("%d", &x);
            prependItem(sl, x);
        } else if (cmd == 2) {
            printf("Value: ");
            scanf("%d", &x);
            appendItem(sl, x);
        } else if (cmd == 3) {
            printf("Value: ");
            scanf("%d", &x);
            printf("Position: ");
            scanf("%d", &loc);
            insertItemAt(sl, x, loc);
        } else if (cmd == 4) {
            removeFirst(sl);
        } else if (cmd == 5) {
            removeLast(sl);
        } else if (cmd == 6) {
            printf("Value: ");
            scanf("%d", &x);
            removeItem(sl, x);
        } else if (cmd == 7) {
            printf("Value: ");
            scanf("%d", &x);
            int pos = locateItem(sl, x);
            if (pos >= 0) {
                printf("Found at index %d.\n", pos);
            } else {
                printf("Not found.\n");
            }
        } else if (cmd == 8) {
            reverseList(sl);
        } else if (cmd == 9) {
            bubbleSortList(sl);
        } else if (cmd == 10) {
            printList(sl);
        }
    } while (cmd != 0);

    destroySinglyList(sl);
    printf("Goodbye.\n");
    return 0;
}
