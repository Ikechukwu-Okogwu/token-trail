#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <string>

using namespace std;

class SortingToolkit {
private:
    vector<int> data;

    void swap(int& a, int& b) {
        int temp = a;
        a = b;
        b = temp;
    }

    int partition(vector<int>& arr, int low, int high) {
        int pivot = arr[high];
        int i = low - 1;
        for (int j = low; j < high; j++) {
            if (arr[j] <= pivot) {
                i++;
                swap(arr[i], arr[j]);
            }
        }
        swap(arr[i + 1], arr[high]);
        return i + 1;
    }

    void quickSortHelper(vector<int>& arr, int low, int high) {
        if (low < high) {
            int pivotIndex = partition(arr, low, high);
            quickSortHelper(arr, low, pivotIndex - 1);
            quickSortHelper(arr, pivotIndex + 1, high);
        }
    }

    void merge(vector<int>& arr, int left, int mid, int right) {
        int n1 = mid - left + 1;
        int n2 = right - mid;
        vector<int> leftArr(n1), rightArr(n2);

        for (int i = 0; i < n1; i++) leftArr[i] = arr[left + i];
        for (int i = 0; i < n2; i++) rightArr[i] = arr[mid + 1 + i];

        int i = 0, j = 0, k = left;
        while (i < n1 && j < n2) {
            if (leftArr[i] <= rightArr[j]) {
                arr[k++] = leftArr[i++];
            } else {
                arr[k++] = rightArr[j++];
            }
        }
        while (i < n1) arr[k++] = leftArr[i++];
        while (j < n2) arr[k++] = rightArr[j++];
    }

    void mergeSortHelper(vector<int>& arr, int left, int right) {
        if (left < right) {
            int mid = left + (right - left) / 2;
            mergeSortHelper(arr, left, mid);
            mergeSortHelper(arr, mid + 1, right);
            merge(arr, left, mid, right);
        }
    }

public:
    SortingToolkit() {
        srand(time(nullptr));
    }

    void generateRandom(int count, int maxVal) {
        data.clear();
        for (int i = 0; i < count; i++) {
            data.push_back(rand() % maxVal + 1);
        }
        cout << "Generated " << count << " random values (max=" << maxVal << ")." << endl;
    }

    void bubbleSort() {
        vector<int> arr = data;
        int n = arr.size();
        for (int i = 0; i < n - 1; i++) {
            bool swapped = false;
            for (int j = 0; j < n - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    swap(arr[j], arr[j + 1]);
                    swapped = true;
                }
            }
            if (!swapped) break;
        }
        data = arr;
        cout << "Bubble sort complete." << endl;
    }

    void selectionSort() {
        vector<int> arr = data;
        int n = arr.size();
        for (int i = 0; i < n - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < n; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            if (minIndex != i) {
                swap(arr[i], arr[minIndex]);
            }
        }
        data = arr;
        cout << "Selection sort complete." << endl;
    }

    void insertionSort() {
        vector<int> arr = data;
        int n = arr.size();
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
        data = arr;
        cout << "Insertion sort complete." << endl;
    }

    void quickSort() {
        vector<int> arr = data;
        if (!arr.empty()) {
            quickSortHelper(arr, 0, arr.size() - 1);
        }
        data = arr;
        cout << "Quick sort complete." << endl;
    }

    void mergeSort() {
        vector<int> arr = data;
        if (!arr.empty()) {
            mergeSortHelper(arr, 0, arr.size() - 1);
        }
        data = arr;
        cout << "Merge sort complete." << endl;
    }

    void display(int limit = 20) {
        cout << "Data (" << data.size() << " elements): ";
        int showCount = min((int)data.size(), limit);
        for (int i = 0; i < showCount; i++) {
            cout << data[i];
            if (i < showCount - 1) cout << ", ";
        }
        if ((int)data.size() > limit) cout << " ...";
        cout << endl;
    }

    void benchmark(int count, int maxVal) {
        generateRandom(count, maxVal);
        vector<int> backup = data;

        cout << "\n--- Benchmarking with " << count << " elements ---" << endl;

        data = backup;
        auto start = chrono::high_resolution_clock::now();
        bubbleSort();
        auto end = chrono::high_resolution_clock::now();
        auto duration = chrono::duration_cast<chrono::microseconds>(end - start);
        cout << "  Bubble sort:    " << duration.count() << " us" << endl;

        data = backup;
        start = chrono::high_resolution_clock::now();
        selectionSort();
        end = chrono::high_resolution_clock::now();
        duration = chrono::duration_cast<chrono::microseconds>(end - start);
        cout << "  Selection sort:  " << duration.count() << " us" << endl;

        data = backup;
        start = chrono::high_resolution_clock::now();
        insertionSort();
        end = chrono::high_resolution_clock::now();
        duration = chrono::duration_cast<chrono::microseconds>(end - start);
        cout << "  Insertion sort:  " << duration.count() << " us" << endl;

        data = backup;
        start = chrono::high_resolution_clock::now();
        quickSort();
        end = chrono::high_resolution_clock::now();
        duration = chrono::duration_cast<chrono::microseconds>(end - start);
        cout << "  Quick sort:     " << duration.count() << " us" << endl;

        data = backup;
        start = chrono::high_resolution_clock::now();
        mergeSort();
        end = chrono::high_resolution_clock::now();
        duration = chrono::duration_cast<chrono::microseconds>(end - start);
        cout << "  Merge sort:     " << duration.count() << " us" << endl;
    }

    bool isSorted() {
        for (int i = 1; i < (int)data.size(); i++) {
            if (data[i] < data[i - 1]) return false;
        }
        return true;
    }
};

int main() {
    SortingToolkit toolkit;
    int choice;

    cout << "=== Sorting Toolkit ===" << endl;
    do {
        cout << "\n1. Generate random data" << endl;
        cout << "2. Bubble sort" << endl;
        cout << "3. Selection sort" << endl;
        cout << "4. Insertion sort" << endl;
        cout << "5. Quick sort" << endl;
        cout << "6. Merge sort" << endl;
        cout << "7. Display data" << endl;
        cout << "8. Check if sorted" << endl;
        cout << "9. Benchmark all" << endl;
        cout << "0. Exit" << endl;
        cout << "Choice: ";
        cin >> choice;

        if (choice == 1) {
            int count, maxVal;
            cout << "Count: ";
            cin >> count;
            cout << "Max value: ";
            cin >> maxVal;
            toolkit.generateRandom(count, maxVal);
            toolkit.display();
        } else if (choice == 2) {
            toolkit.bubbleSort();
            toolkit.display();
        } else if (choice == 3) {
            toolkit.selectionSort();
            toolkit.display();
        } else if (choice == 4) {
            toolkit.insertionSort();
            toolkit.display();
        } else if (choice == 5) {
            toolkit.quickSort();
            toolkit.display();
        } else if (choice == 6) {
            toolkit.mergeSort();
            toolkit.display();
        } else if (choice == 7) {
            toolkit.display();
        } else if (choice == 8) {
            cout << (toolkit.isSorted() ? "Data is sorted." : "Data is NOT sorted.") << endl;
        } else if (choice == 9) {
            int count, maxVal;
            cout << "Count: ";
            cin >> count;
            cout << "Max value: ";
            cin >> maxVal;
            toolkit.benchmark(count, maxVal);
        }
    } while (choice != 0);

    cout << "Goodbye." << endl;
    return 0;
}
