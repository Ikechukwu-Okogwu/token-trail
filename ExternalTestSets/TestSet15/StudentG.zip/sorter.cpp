#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <ctime>
#include <chrono>
#include <string>
#include <functional>
#include <map>

using namespace std;

typedef vector<int> Seq;
typedef function<void(Seq&)> SortFn;

namespace Algo {
    void xch(int& p, int& q) { int z = p; p = q; q = z; }

    void _bs(Seq& s) {
        int sz = s.size();
        for (int pass = 0; pass < sz - 1; pass++) {
            bool done = true;
            for (int k = 0; k < sz - pass - 1; k++) {
                if (s[k] > s[k + 1]) {
                    xch(s[k], s[k + 1]);
                    done = false;
                }
            }
            if (done) return;
        }
    }

    void _ss(Seq& s) {
        int sz = s.size();
        for (int cur = 0; cur < sz - 1; cur++) {
            int best = cur;
            for (int scan = cur + 1; scan < sz; scan++) {
                if (s[scan] < s[best]) best = scan;
            }
            if (best != cur) xch(s[cur], s[best]);
        }
    }

    void _is(Seq& s) {
        int sz = s.size();
        for (int pos = 1; pos < sz; pos++) {
            int hold = s[pos];
            int back = pos - 1;
            while (back >= 0 && s[back] > hold) {
                s[back + 1] = s[back];
                back--;
            }
            s[back + 1] = hold;
        }
    }

    int _qp(Seq& s, int lo, int hi) {
        int pv = s[hi];
        int wall = lo - 1;
        for (int scan = lo; scan < hi; scan++) {
            if (s[scan] <= pv) {
                wall++;
                xch(s[wall], s[scan]);
            }
        }
        xch(s[wall + 1], s[hi]);
        return wall + 1;
    }

    void _qr(Seq& s, int lo, int hi) {
        if (lo >= hi) return;
        int pi = _qp(s, lo, hi);
        _qr(s, lo, pi - 1);
        _qr(s, pi + 1, hi);
    }

    void _qs(Seq& s) {
        if (!s.empty()) _qr(s, 0, s.size() - 1);
    }

    void _mm(Seq& s, int a, int m, int b) {
        Seq L(s.begin() + a, s.begin() + m + 1);
        Seq R(s.begin() + m + 1, s.begin() + b + 1);
        int i = 0, j = 0, w = a;
        while (i < (int)L.size() && j < (int)R.size()) {
            if (L[i] <= R[j]) s[w++] = L[i++];
            else s[w++] = R[j++];
        }
        while (i < (int)L.size()) s[w++] = L[i++];
        while (j < (int)R.size()) s[w++] = R[j++];
    }

    void _mr(Seq& s, int a, int b) {
        if (a >= b) return;
        int m = a + (b - a) / 2;
        _mr(s, a, m);
        _mr(s, m + 1, b);
        _mm(s, a, m, b);
    }

    void _ms(Seq& s) {
        if (!s.empty()) _mr(s, 0, s.size() - 1);
    }
}

class Engine {
    Seq buf;
    map<string, SortFn> registry;

    Seq gen(int n, int mx) {
        Seq out(n);
        for (int i = 0; i < n; i++) out[i] = rand() % mx + 1;
        return out;
    }

    void dump(const Seq& s, int cap = 20) {
        cout << "Data (" << s.size() << " elements): ";
        int lim = min((int)s.size(), cap);
        for (int i = 0; i < lim; i++) {
            cout << s[i];
            if (i < lim - 1) cout << ", ";
        }
        if ((int)s.size() > cap) cout << " ...";
        cout << endl;
    }

    long long timed(SortFn fn, Seq& s) {
        auto t0 = chrono::high_resolution_clock::now();
        fn(s);
        auto t1 = chrono::high_resolution_clock::now();
        return chrono::duration_cast<chrono::microseconds>(t1 - t0).count();
    }

    bool ordered(const Seq& s) {
        for (int i = 1; i < (int)s.size(); i++) {
            if (s[i] < s[i - 1]) return false;
        }
        return true;
    }

public:
    Engine() {
        srand(time(nullptr));
        registry["bubble"]    = Algo::_bs;
        registry["selection"] = Algo::_ss;
        registry["insertion"] = Algo::_is;
        registry["quick"]     = Algo::_qs;
        registry["merge"]     = Algo::_ms;
    }

    void fill(int n, int mx) {
        buf = gen(n, mx);
        cout << "Generated " << n << " random values (max=" << mx << ")." << endl;
    }

    void run(const string& which) {
        auto it = registry.find(which);
        if (it == registry.end()) { cout << "Unknown algorithm." << endl; return; }
        it->second(buf);
        cout << which << " sort complete." << endl;
    }

    void show() { dump(buf); }

    void check() {
        cout << (ordered(buf) ? "Data is sorted." : "Data is NOT sorted.") << endl;
    }

    void bench(int n, int mx) {
        fill(n, mx);
        Seq snap = buf;
        cout << "\n--- Benchmarking with " << n << " elements ---" << endl;
        string names[] = {"bubble", "selection", "insertion", "quick", "merge"};
        string labels[] = {"Bubble sort:   ", "Selection sort: ", "Insertion sort: ",
                           "Quick sort:    ", "Merge sort:    "};
        for (int i = 0; i < 5; i++) {
            buf = snap;
            long long us = timed(registry[names[i]], buf);
            cout << "  " << labels[i] << us << " us" << endl;
        }
    }
};

int main() {
    Engine eng;
    int op;
    string algos[] = {"bubble", "selection", "insertion", "quick", "merge"};

    cout << "=== Sorting Toolkit ===" << endl;
    do {
        cout << "\n1. Generate random data" << endl;
        cout << "2. Bubble sort" << endl;
        cout << "3. Selection sort" << endl;
        cout << "4. Insertion sort" << endl;
        cout << "5. Quick sort" << endl;
        cout << "6. Merge sort" << endl;
        cout << "7. Display data" << endl;
        cout << "8. Check if sorted" << endl;
        cout << "9. Benchmark all" << endl;
        cout << "0. Exit" << endl;
        cout << "Choice: ";
        cin >> op;

        if (op == 1) {
            int n, mx;
            cout << "Count: ";
            cin >> n;
            cout << "Max value: ";
            cin >> mx;
            eng.fill(n, mx);
            eng.show();
        } else if (op >= 2 && op <= 6) {
            eng.run(algos[op - 2]);
            eng.show();
        } else if (op == 7) {
            eng.show();
        } else if (op == 8) {
            eng.check();
        } else if (op == 9) {
            int n, mx;
            cout << "Count: ";
            cin >> n;
            cout << "Max value: ";
            cin >> mx;
            eng.bench(n, mx);
        }
    } while (op != 0);

    cout << "Goodbye." << endl;
    return 0;
}
