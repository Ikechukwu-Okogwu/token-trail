import java.util.Scanner;

public class Calculator {
    private ExpressionParser parser;

    public Calculator() {
        this.parser = new ExpressionParser();
    }

    public double evaluate(String expression) {
        expression = expression.replaceAll("\\s+", "");
        if (expression.isEmpty()) {
            throw new IllegalArgumentException("Empty expression");
        }
        return parser.parse(expression);
    }

    public void printHistory() {
        parser.printHistory();
    }

    public void clearHistory() {
        parser.clearHistory();
    }

    public static void main(String[] args) {
        Calculator calc = new Calculator();
        Scanner scanner = new Scanner(System.in);

        System.out.println("=== Expression Calculator ===");
        System.out.println("Supports: +, -, *, /, ^, parentheses");
        System.out.println("Commands: history, clear, quit");
        System.out.println();

        while (true) {
            System.out.print("> ");
            String input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("quit") || input.equalsIgnoreCase("exit")) {
                break;
            }
            if (input.equalsIgnoreCase("history")) {
                calc.printHistory();
                continue;
            }
            if (input.equalsIgnoreCase("clear")) {
                calc.clearHistory();
                System.out.println("History cleared.");
                continue;
            }
            if (input.isEmpty()) continue;

            try {
                double result = calc.evaluate(input);
                System.out.printf("  = %.6f%n", result);
            } catch (Exception e) {
                System.out.println("  Error: " + e.getMessage());
            }
        }

        scanner.close();
        System.out.println("Goodbye.");
    }
}
