import java.util.ArrayList;
import java.util.Stack;

public class ExpressionParser {
    private ArrayList<String> history;
    private int position;
    private String expression;

    public ExpressionParser() {
        this.history = new ArrayList<>();
    }

    public double parse(String expr) {
        this.expression = expr;
        this.position = 0;
        double result = parseExpression();
        if (position < expression.length()) {
            throw new IllegalArgumentException("Unexpected character: " + expression.charAt(position));
        }
        history.add(expr + " = " + result);
        return result;
    }

    private double parseExpression() {
        double result = parseTerm();
        while (position < expression.length()) {
            char op = expression.charAt(position);
            if (op == '+') {
                position++;
                result += parseTerm();
            } else if (op == '-') {
                position++;
                result -= parseTerm();
            } else {
                break;
            }
        }
        return result;
    }

    private double parseTerm() {
        double result = parsePower();
        while (position < expression.length()) {
            char op = expression.charAt(position);
            if (op == '*') {
                position++;
                result *= parsePower();
            } else if (op == '/') {
                position++;
                double divisor = parsePower();
                if (divisor == 0) {
                    throw new ArithmeticException("Division by zero");
                }
                result /= divisor;
            } else {
                break;
            }
        }
        return result;
    }

    private double parsePower() {
        double base = parseFactor();
        if (position < expression.length() && expression.charAt(position) == '^') {
            position++;
            double exponent = parsePower();
            return Math.pow(base, exponent);
        }
        return base;
    }

    private double parseFactor() {
        if (position >= expression.length()) {
            throw new IllegalArgumentException("Unexpected end of expression");
        }

        char ch = expression.charAt(position);

        if (ch == '-') {
            position++;
            return -parseFactor();
        }

        if (ch == '(') {
            position++;
            double result = parseExpression();
            if (position >= expression.length() || expression.charAt(position) != ')') {
                throw new IllegalArgumentException("Missing closing parenthesis");
            }
            position++;
            return result;
        }

        if (Character.isDigit(ch) || ch == '.') {
            return parseNumber();
        }

        if (Character.isLetter(ch)) {
            return parseFunction();
        }

        throw new IllegalArgumentException("Unexpected character: " + ch);
    }

    private double parseNumber() {
        int start = position;
        boolean hasDecimal = false;
        while (position < expression.length()) {
            char ch = expression.charAt(position);
            if (Character.isDigit(ch)) {
                position++;
            } else if (ch == '.' && !hasDecimal) {
                hasDecimal = true;
                position++;
            } else {
                break;
            }
        }
        String numStr = expression.substring(start, position);
        return Double.parseDouble(numStr);
    }

    private double parseFunction() {
        int start = position;
        while (position < expression.length() && Character.isLetter(expression.charAt(position))) {
            position++;
        }
        String funcName = expression.substring(start, position).toLowerCase();

        if (position >= expression.length() || expression.charAt(position) != '(') {
            throw new IllegalArgumentException("Expected '(' after function " + funcName);
        }
        position++;
        double arg = parseExpression();
        if (position >= expression.length() || expression.charAt(position) != ')') {
            throw new IllegalArgumentException("Missing ')' in function " + funcName);
        }
        position++;

        if (funcName.equals("sqrt")) {
            return Math.sqrt(arg);
        } else if (funcName.equals("sin")) {
            return Math.sin(Math.toRadians(arg));
        } else if (funcName.equals("cos")) {
            return Math.cos(Math.toRadians(arg));
        } else if (funcName.equals("tan")) {
            return Math.tan(Math.toRadians(arg));
        } else if (funcName.equals("abs")) {
            return Math.abs(arg);
        } else if (funcName.equals("log")) {
            return Math.log10(arg);
        } else if (funcName.equals("ln")) {
            return Math.log(arg);
        } else {
            throw new IllegalArgumentException("Unknown function: " + funcName);
        }
    }

    public void printHistory() {
        if (history.isEmpty()) {
            System.out.println("No history.");
            return;
        }
        System.out.println("--- History ---");
        for (int i = 0; i < history.size(); i++) {
            System.out.println("  " + (i + 1) + ". " + history.get(i));
        }
    }

    public void clearHistory() {
        history.clear();
    }
}
