#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_WORD_LEN 256
#define MAX_UNIQUE 10000
#define MAX_LINE_LEN 4096

typedef struct {
    char word[MAX_WORD_LEN];
    int count;
} WordEntry;

typedef struct {
    WordEntry entries[MAX_UNIQUE];
    int numUnique;
    int totalWords;
    int totalLines;
    int totalChars;
    int longestLine;
} FileStats;

void initStats(FileStats* stats) {
    stats->numUnique = 0;
    stats->totalWords = 0;
    stats->totalLines = 0;
    stats->totalChars = 0;
    stats->longestLine = 0;
}

void toLowerStr(char* str) {
    for (int i = 0; str[i]; i++) {
        str[i] = tolower((unsigned char)str[i]);
    }
}

void stripPunctuation(char* str) {
    int len = strlen(str);
    while (len > 0 && ispunct((unsigned char)str[len - 1])) {
        str[len - 1] = '\0';
        len--;
    }
    while (*str && ispunct((unsigned char)*str)) {
        memmove(str, str + 1, strlen(str));
    }
}

int findWord(FileStats* stats, const char* word) {
    for (int i = 0; i < stats->numUnique; i++) {
        if (strcmp(stats->entries[i].word, word) == 0) {
            return i;
        }
    }
    return -1;
}

void addWord(FileStats* stats, const char* word) {
    if (strlen(word) == 0) return;

    stats->totalWords++;
    int idx = findWord(stats, word);
    if (idx >= 0) {
        stats->entries[idx].count++;
    } else if (stats->numUnique < MAX_UNIQUE) {
        strncpy(stats->entries[stats->numUnique].word, word, MAX_WORD_LEN - 1);
        stats->entries[stats->numUnique].word[MAX_WORD_LEN - 1] = '\0';
        stats->entries[stats->numUnique].count = 1;
        stats->numUnique++;
    }
}

void processLine(FileStats* stats, char* line, int caseSensitive) {
    int lineLen = strlen(line);
    if (lineLen > 0 && line[lineLen - 1] == '\n') {
        line[lineLen - 1] = '\0';
        lineLen--;
    }

    stats->totalChars += lineLen;
    if (lineLen > stats->longestLine) {
        stats->longestLine = lineLen;
    }

    char* token = strtok(line, " \t\r\n");
    while (token != NULL) {
        char cleaned[MAX_WORD_LEN];
        strncpy(cleaned, token, MAX_WORD_LEN - 1);
        cleaned[MAX_WORD_LEN - 1] = '\0';

        stripPunctuation(cleaned);
        if (!caseSensitive) {
            toLowerStr(cleaned);
        }

        if (strlen(cleaned) > 0) {
            addWord(stats, cleaned);
        }

        token = strtok(NULL, " \t\r\n");
    }
}

int compareByCount(const void* a, const void* b) {
    const WordEntry* wa = (const WordEntry*)a;
    const WordEntry* wb = (const WordEntry*)b;
    return wb->count - wa->count;
}

int compareByAlpha(const void* a, const void* b) {
    const WordEntry* wa = (const WordEntry*)a;
    const WordEntry* wb = (const WordEntry*)b;
    return strcmp(wa->word, wb->word);
}

void printSummary(FileStats* stats) {
    printf("\n=== File Statistics ===\n");
    printf("  Total lines:       %d\n", stats->totalLines);
    printf("  Total words:       %d\n", stats->totalWords);
    printf("  Total characters:  %d\n", stats->totalChars);
    printf("  Unique words:      %d\n", stats->numUnique);
    printf("  Longest line:      %d chars\n", stats->longestLine);
    if (stats->totalLines > 0) {
        printf("  Avg words/line:    %.2f\n",
               (double)stats->totalWords / stats->totalLines);
    }
    printf("\n");
}

void printTopWords(FileStats* stats, int topN) {
    qsort(stats->entries, stats->numUnique, sizeof(WordEntry), compareByCount);

    int limit = topN;
    if (limit > stats->numUnique) limit = stats->numUnique;

    printf("--- Top %d Words ---\n", limit);
    for (int i = 0; i < limit; i++) {
        printf("  %3d. %-20s  %d\n",
               i + 1, stats->entries[i].word, stats->entries[i].count);
    }
    printf("\n");
}

void searchWord(FileStats* stats, const char* target) {
    int idx = findWord(stats, target);
    if (idx >= 0) {
        printf("  '%s' appears %d time(s).\n", target, stats->entries[idx].count);
    } else {
        printf("  '%s' not found.\n", target);
    }
}

int processFile(const char* filename, FileStats* stats, int caseSensitive) {
    FILE* fp = fopen(filename, "r");
    if (fp == NULL) {
        printf("Error: cannot open file '%s'.\n", filename);
        return -1;
    }

    char line[MAX_LINE_LEN];
    while (fgets(line, MAX_LINE_LEN, fp) != NULL) {
        stats->totalLines++;
        processLine(stats, line, caseSensitive);
    }

    fclose(fp);
    return 0;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        printf("Usage: %s <filename> [options]\n", argv[0]);
        printf("Options:\n");
        printf("  -c    Case sensitive mode\n");
        printf("  -n N  Show top N words (default: 10)\n");
        return 1;
    }

    int caseSensitive = 0;
    int topN = 10;
    char* filename = argv[1];

    for (int i = 2; i < argc; i++) {
        if (strcmp(argv[i], "-c") == 0) {
            caseSensitive = 1;
        } else if (strcmp(argv[i], "-n") == 0 && i + 1 < argc) {
            topN = atoi(argv[i + 1]);
            i++;
        }
    }

    FileStats stats;
    initStats(&stats);

    printf("Analyzing '%s'...\n", filename);
    if (processFile(filename, &stats, caseSensitive) != 0) {
        return 1;
    }

    printSummary(&stats);
    printTopWords(&stats, topN);

    char searchBuf[MAX_WORD_LEN];
    printf("Search for a word (or 'quit' to exit):\n");
    while (1) {
        printf("  search> ");
        if (scanf("%255s", searchBuf) != 1) break;
        if (strcmp(searchBuf, "quit") == 0) break;
        if (!caseSensitive) toLowerStr(searchBuf);
        searchWord(&stats, searchBuf);
    }

    printf("Done.\n");
    return 0;
}
