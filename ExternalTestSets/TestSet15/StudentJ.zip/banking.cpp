#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <ctime>
#include <sstream>

using namespace std;

struct Transaction {
    string type;
    double amount;
    double balanceAfter;
    string timestamp;
    string description;
};

class BankAccount {
    string ownerName;
    string accountNumber;
    double balance;
    double interestRate;
    vector<Transaction> ledger;

    string getTimestamp() {
        time_t now = time(nullptr);
        char buf[64];
        strftime(buf, sizeof(buf), "%Y-%m-%d %H:%M:%S", localtime(&now));
        return string(buf);
    }

    void recordTransaction(const string& type, double amount, const string& desc) {
        Transaction txn;
        txn.type = type;
        txn.amount = amount;
        txn.balanceAfter = balance;
        txn.timestamp = getTimestamp();
        txn.description = desc;
        ledger.push_back(txn);
    }

public:
    BankAccount(const string& name, const string& accNum, double initialDeposit, double rate) {
        ownerName = name;
        accountNumber = accNum;
        balance = initialDeposit;
        interestRate = rate;
        if (initialDeposit > 0) {
            recordTransaction("DEPOSIT", initialDeposit, "Initial deposit");
        }
    }

    bool deposit(double amount, const string& desc = "Deposit") {
        if (amount <= 0) {
            cout << "Error: deposit amount must be positive." << endl;
            return false;
        }
        balance += amount;
        recordTransaction("DEPOSIT", amount, desc);
        cout << "Deposited $" << fixed << setprecision(2) << amount << ". ";
        cout << "New balance: $" << balance << endl;
        return true;
    }

    bool withdraw(double amount, const string& desc = "Withdrawal") {
        if (amount <= 0) {
            cout << "Error: withdrawal amount must be positive." << endl;
            return false;
        }
        if (amount > balance) {
            cout << "Error: insufficient funds. Balance: $" << fixed << setprecision(2) << balance << endl;
            return false;
        }
        balance -= amount;
        recordTransaction("WITHDRAWAL", amount, desc);
        cout << "Withdrew $" << fixed << setprecision(2) << amount << ". ";
        cout << "New balance: $" << balance << endl;
        return true;
    }

    bool transfer(BankAccount& recipient, double amount) {
        if (amount <= 0) {
            cout << "Error: transfer amount must be positive." << endl;
            return false;
        }
        if (amount > balance) {
            cout << "Error: insufficient funds for transfer." << endl;
            return false;
        }
        balance -= amount;
        recordTransaction("TRANSFER_OUT", amount, "Transfer to " + recipient.accountNumber);
        recipient.balance += amount;
        recipient.recordTransaction("TRANSFER_IN", amount, "Transfer from " + accountNumber);
        cout << "Transferred $" << fixed << setprecision(2) << amount;
        cout << " to account " << recipient.accountNumber << "." << endl;
        return true;
    }

    void applyInterest() {
        double interest = balance * (interestRate / 100.0);
        balance += interest;
        recordTransaction("INTEREST", interest, "Monthly interest at " + to_string(interestRate) + "%");
        cout << "Interest applied: $" << fixed << setprecision(2) << interest << ". ";
        cout << "New balance: $" << balance << endl;
    }

    void printStatement(int lastN = 0) {
        cout << "\n========================================" << endl;
        cout << "  Account Statement" << endl;
        cout << "  Owner: " << ownerName << endl;
        cout << "  Account: " << accountNumber << endl;
        cout << "  Balance: $" << fixed << setprecision(2) << balance << endl;
        cout << "  Interest Rate: " << interestRate << "%" << endl;
        cout << "========================================" << endl;

        int start = 0;
        if (lastN > 0 && lastN < (int)ledger.size()) {
            start = ledger.size() - lastN;
        }

        cout << left << setw(20) << "Timestamp"
             << setw(14) << "Type"
             << right << setw(12) << "Amount"
             << setw(14) << "Balance"
             << "  " << left << "Description" << endl;
        cout << string(76, '-') << endl;

        for (int i = start; i < (int)ledger.size(); i++) {
            const Transaction& t = ledger[i];
            cout << left << setw(20) << t.timestamp
                 << setw(14) << t.type
                 << right << setw(12) << fixed << setprecision(2) << t.amount
                 << setw(14) << t.balanceAfter
                 << "  " << left << t.description << endl;
        }
        cout << endl;
    }

    double getBalance() const { return balance; }
    string getAccountNumber() const { return accountNumber; }
    string getOwnerName() const { return ownerName; }
    int getTransactionCount() const { return ledger.size(); }
};

int main() {
    BankAccount checking("John Doe", "CHK-001", 1000.00, 0.5);
    BankAccount savings("John Doe", "SAV-001", 5000.00, 2.0);

    int choice;
    cout << "=== Bank Account Manager ===" << endl;

    do {
        cout << "\n1. Deposit to Checking" << endl;
        cout << "2. Withdraw from Checking" << endl;
        cout << "3. Deposit to Savings" << endl;
        cout << "4. Withdraw from Savings" << endl;
        cout << "5. Transfer Checking -> Savings" << endl;
        cout << "6. Transfer Savings -> Checking" << endl;
        cout << "7. Apply interest (both)" << endl;
        cout << "8. Checking statement" << endl;
        cout << "9. Savings statement" << endl;
        cout << "0. Exit" << endl;
        cout << "Choice: ";
        cin >> choice;

        double amount;
        if (choice == 1) {
            cout << "Amount: $";
            cin >> amount;
            checking.deposit(amount);
        } else if (choice == 2) {
            cout << "Amount: $";
            cin >> amount;
            checking.withdraw(amount);
        } else if (choice == 3) {
            cout << "Amount: $";
            cin >> amount;
            savings.deposit(amount);
        } else if (choice == 4) {
            cout << "Amount: $";
            cin >> amount;
            savings.withdraw(amount);
        } else if (choice == 5) {
            cout << "Amount: $";
            cin >> amount;
            checking.transfer(savings, amount);
        } else if (choice == 6) {
            cout << "Amount: $";
            cin >> amount;
            savings.transfer(checking, amount);
        } else if (choice == 7) {
            checking.applyInterest();
            savings.applyInterest();
        } else if (choice == 8) {
            checking.printStatement();
        } else if (choice == 9) {
            savings.printStatement();
        }
    } while (choice != 0);

    cout << "Goodbye." << endl;
    return 0;
}
