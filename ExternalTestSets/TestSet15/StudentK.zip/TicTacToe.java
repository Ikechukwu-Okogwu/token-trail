import java.util.Scanner;
import java.util.Random;

public class TicTacToe {
    private char[][] board;
    private char currentPlayer;
    private int movesPlayed;
    private int winsX;
    private int winsO;
    private int draws;
    private boolean vsComputer;
    private Random random;

    public TicTacToe() {
        board = new char[3][3];
        random = new Random();
        winsX = 0;
        winsO = 0;
        draws = 0;
        resetBoard();
    }

    private void resetBoard() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                board[i][j] = ' ';
            }
        }
        currentPlayer = 'X';
        movesPlayed = 0;
    }

    public void displayBoard() {
        System.out.println();
        System.out.println("  1   2   3");
        for (int i = 0; i < 3; i++) {
            System.out.print((i + 1) + " ");
            for (int j = 0; j < 3; j++) {
                System.out.print(board[i][j]);
                if (j < 2) System.out.print(" | ");
            }
            System.out.println();
            if (i < 2) System.out.println("  ---------");
        }
        System.out.println();
    }

    public boolean makeMove(int row, int col) {
        if (row < 0 || row >= 3 || col < 0 || col >= 3) {
            System.out.println("Invalid position. Use 1-3 for row and column.");
            return false;
        }
        if (board[row][col] != ' ') {
            System.out.println("That cell is already occupied.");
            return false;
        }
        board[row][col] = currentPlayer;
        movesPlayed++;
        return true;
    }

    public boolean checkWin() {
        for (int i = 0; i < 3; i++) {
            if (board[i][0] != ' ' && board[i][0] == board[i][1] && board[i][1] == board[i][2]) {
                return true;
            }
            if (board[0][i] != ' ' && board[0][i] == board[1][i] && board[1][i] == board[2][i]) {
                return true;
            }
        }
        if (board[0][0] != ' ' && board[0][0] == board[1][1] && board[1][1] == board[2][2]) {
            return true;
        }
        if (board[0][2] != ' ' && board[0][2] == board[1][1] && board[1][1] == board[2][0]) {
            return true;
        }
        return false;
    }

    public boolean isBoardFull() {
        return movesPlayed >= 9;
    }

    private void computerMove() {
        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') {
                    board[i][j] = 'O';
                    if (checkWin()) {
                        movesPlayed++;
                        System.out.println("Computer plays: row " + (i + 1) + ", col " + (j + 1));
                        return;
                    }
                    board[i][j] = ' ';
                }
            }
        }

        for (int i = 0; i < 3; i++) {
            for (int j = 0; j < 3; j++) {
                if (board[i][j] == ' ') {
                    board[i][j] = 'X';
                    if (checkWin()) {
                        board[i][j] = 'O';
                        movesPlayed++;
                        System.out.println("Computer plays: row " + (i + 1) + ", col " + (j + 1));
                        return;
                    }
                    board[i][j] = ' ';
                }
            }
        }

        if (board[1][1] == ' ') {
            board[1][1] = 'O';
            movesPlayed++;
            System.out.println("Computer plays: row 2, col 2");
            return;
        }

        while (true) {
            int r = random.nextInt(3);
            int c = random.nextInt(3);
            if (board[r][c] == ' ') {
                board[r][c] = 'O';
                movesPlayed++;
                System.out.println("Computer plays: row " + (r + 1) + ", col " + (c + 1));
                return;
            }
        }
    }

    private void switchPlayer() {
        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }

    public void printScoreboard() {
        System.out.println("\n--- Scoreboard ---");
        System.out.println("  X wins: " + winsX);
        System.out.println("  O wins: " + winsO);
        System.out.println("  Draws:  " + draws);
        System.out.println();
    }

    public void playGame(Scanner scanner) {
        resetBoard();
        System.out.println("\n=== New Game ===");
        displayBoard();

        while (true) {
            if (vsComputer && currentPlayer == 'O') {
                computerMove();
            } else {
                System.out.print("Player " + currentPlayer + " - Enter row col (e.g., 1 2): ");
                int row = scanner.nextInt() - 1;
                int col = scanner.nextInt() - 1;
                if (!makeMove(row, col)) {
                    continue;
                }
            }

            displayBoard();

            if (checkWin()) {
                System.out.println("Player " + currentPlayer + " wins!");
                if (currentPlayer == 'X') winsX++;
                else winsO++;
                return;
            }

            if (isBoardFull()) {
                System.out.println("It's a draw!");
                draws++;
                return;
            }

            switchPlayer();
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        TicTacToe game = new TicTacToe();

        System.out.println("=== Tic-Tac-Toe ===");
        System.out.print("Play against computer? (y/n): ");
        String mode = scanner.next();
        game.vsComputer = mode.equalsIgnoreCase("y");

        int menuChoice;
        do {
            System.out.println("\n1. Play a game");
            System.out.println("2. View scoreboard");
            System.out.println("0. Quit");
            System.out.print("Choice: ");
            menuChoice = scanner.nextInt();

            if (menuChoice == 1) {
                game.playGame(scanner);
            } else if (menuChoice == 2) {
                game.printScoreboard();
            }
        } while (menuChoice != 0);

        game.printScoreboard();
        scanner.close();
        System.out.println("Goodbye.");
    }
}
