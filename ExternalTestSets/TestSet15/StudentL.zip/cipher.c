#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define MAX_TEXT 4096
#define ALPHA_SIZE 26

void caesarEncrypt(char* text, int shift) {
    shift = ((shift % ALPHA_SIZE) + ALPHA_SIZE) % ALPHA_SIZE;
    for (int i = 0; text[i] != '\0'; i++) {
        if (isupper((unsigned char)text[i])) {
            text[i] = 'A' + (text[i] - 'A' + shift) % ALPHA_SIZE;
        } else if (islower((unsigned char)text[i])) {
            text[i] = 'a' + (text[i] - 'a' + shift) % ALPHA_SIZE;
        }
    }
}

void caesarDecrypt(char* text, int shift) {
    caesarEncrypt(text, ALPHA_SIZE - shift);
}

void frequencyAnalysis(const char* text) {
    int freq[ALPHA_SIZE] = {0};
    int totalLetters = 0;

    for (int i = 0; text[i] != '\0'; i++) {
        if (isalpha((unsigned char)text[i])) {
            freq[tolower((unsigned char)text[i]) - 'a']++;
            totalLetters++;
        }
    }

    printf("\n--- Frequency Analysis ---\n");
    printf("Total letters: %d\n\n", totalLetters);

    for (int i = 0; i < ALPHA_SIZE; i++) {
        if (freq[i] > 0) {
            double pct = (double)freq[i] / totalLetters * 100.0;
            printf("  %c: %4d (%5.2f%%) ", 'a' + i, freq[i], pct);
            int barLen = (int)(pct * 2);
            for (int j = 0; j < barLen; j++) printf("#");
            printf("\n");
        }
    }
    printf("\n");
}

void bruteForceDecrypt(const char* ciphertext) {
    printf("\n--- Brute Force Decryption ---\n");
    for (int shift = 1; shift < ALPHA_SIZE; shift++) {
        char attempt[MAX_TEXT];
        strncpy(attempt, ciphertext, MAX_TEXT - 1);
        attempt[MAX_TEXT - 1] = '\0';
        caesarDecrypt(attempt, shift);

        int previewLen = 50;
        if ((int)strlen(attempt) < previewLen) {
            previewLen = strlen(attempt);
        }

        printf("  Shift %2d: ", shift);
        for (int i = 0; i < previewLen; i++) {
            putchar(attempt[i]);
        }
        if ((int)strlen(attempt) > previewLen) {
            printf("...");
        }
        printf("\n");
    }
    printf("\n");
}

void vigenereEncrypt(char* text, const char* key) {
    int keyLen = strlen(key);
    if (keyLen == 0) {
        printf("Error: key cannot be empty.\n");
        return;
    }
    int keyIdx = 0;
    for (int i = 0; text[i] != '\0'; i++) {
        if (isalpha((unsigned char)text[i])) {
            int shift = tolower((unsigned char)key[keyIdx % keyLen]) - 'a';
            if (isupper((unsigned char)text[i])) {
                text[i] = 'A' + (text[i] - 'A' + shift) % ALPHA_SIZE;
            } else {
                text[i] = 'a' + (text[i] - 'a' + shift) % ALPHA_SIZE;
            }
            keyIdx++;
        }
    }
}

void vigenereDecrypt(char* text, const char* key) {
    int keyLen = strlen(key);
    if (keyLen == 0) {
        printf("Error: key cannot be empty.\n");
        return;
    }
    int keyIdx = 0;
    for (int i = 0; text[i] != '\0'; i++) {
        if (isalpha((unsigned char)text[i])) {
            int shift = tolower((unsigned char)key[keyIdx % keyLen]) - 'a';
            if (isupper((unsigned char)text[i])) {
                text[i] = 'A' + (text[i] - 'A' - shift + ALPHA_SIZE) % ALPHA_SIZE;
            } else {
                text[i] = 'a' + (text[i] - 'a' - shift + ALPHA_SIZE) % ALPHA_SIZE;
            }
            keyIdx++;
        }
    }
}

void encryptFile(const char* inFile, const char* outFile, int shift) {
    FILE* fin = fopen(inFile, "r");
    if (!fin) {
        printf("Error: cannot open input file '%s'.\n", inFile);
        return;
    }
    FILE* fout = fopen(outFile, "w");
    if (!fout) {
        printf("Error: cannot open output file '%s'.\n", outFile);
        fclose(fin);
        return;
    }

    char line[MAX_TEXT];
    int lineCount = 0;
    while (fgets(line, MAX_TEXT, fin) != NULL) {
        caesarEncrypt(line, shift);
        fputs(line, fout);
        lineCount++;
    }

    fclose(fin);
    fclose(fout);
    printf("Encrypted %d lines from '%s' to '%s'.\n", lineCount, inFile, outFile);
}

int main() {
    char text[MAX_TEXT];
    char key[256];
    int choice, shift;

    printf("=== Cipher Tool ===\n");
    do {
        printf("\n1. Caesar encrypt\n");
        printf("2. Caesar decrypt\n");
        printf("3. Brute force Caesar\n");
        printf("4. Frequency analysis\n");
        printf("5. Vigenere encrypt\n");
        printf("6. Vigenere decrypt\n");
        printf("7. Encrypt file (Caesar)\n");
        printf("0. Exit\n");
        printf("Choice: ");
        scanf("%d", &choice);
        getchar();

        if (choice == 1 || choice == 2) {
            printf("Enter text: ");
            fgets(text, MAX_TEXT, stdin);
            text[strcspn(text, "\n")] = '\0';
            printf("Enter shift: ");
            scanf("%d", &shift);
            getchar();
            if (choice == 1) {
                caesarEncrypt(text, shift);
                printf("Encrypted: %s\n", text);
            } else {
                caesarDecrypt(text, shift);
                printf("Decrypted: %s\n", text);
            }
        } else if (choice == 3) {
            printf("Enter ciphertext: ");
            fgets(text, MAX_TEXT, stdin);
            text[strcspn(text, "\n")] = '\0';
            bruteForceDecrypt(text);
        } else if (choice == 4) {
            printf("Enter text: ");
            fgets(text, MAX_TEXT, stdin);
            text[strcspn(text, "\n")] = '\0';
            frequencyAnalysis(text);
        } else if (choice == 5 || choice == 6) {
            printf("Enter text: ");
            fgets(text, MAX_TEXT, stdin);
            text[strcspn(text, "\n")] = '\0';
            printf("Enter key: ");
            fgets(key, 256, stdin);
            key[strcspn(key, "\n")] = '\0';
            if (choice == 5) {
                vigenereEncrypt(text, key);
                printf("Encrypted: %s\n", text);
            } else {
                vigenereDecrypt(text, key);
                printf("Decrypted: %s\n", text);
            }
        } else if (choice == 7) {
            char inFile[256], outFile[256];
            printf("Input file: ");
            fgets(inFile, 256, stdin);
            inFile[strcspn(inFile, "\n")] = '\0';
            printf("Output file: ");
            fgets(outFile, 256, stdin);
            outFile[strcspn(outFile, "\n")] = '\0';
            printf("Shift: ");
            scanf("%d", &shift);
            getchar();
            encryptFile(inFile, outFile, shift);
        }
    } while (choice != 0);

    printf("Goodbye.\n");
    return 0;
}
