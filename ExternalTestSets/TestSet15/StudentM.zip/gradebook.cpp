#include "gradebook.h"
#include <iostream>
#include <iomanip>
#include <algorithm>
#include <numeric>
#include <cmath>

using namespace std;

StudentRecord::StudentRecord(const string& name, const string& id)
    : studentName(name), studentId(id) {}

void StudentRecord::addAssignment(const string& name, double score, double maxScore, double weight) {
    Assignment a;
    a.name = name;
    a.score = score;
    a.maxScore = maxScore;
    a.weight = weight;
    assignments.push_back(a);
}

double StudentRecord::getWeightedAverage() const {
    if (assignments.empty()) return 0.0;
    double totalWeight = 0.0;
    double weightedSum = 0.0;
    for (const auto& a : assignments) {
        double pct = (a.score / a.maxScore) * 100.0;
        weightedSum += pct * a.weight;
        totalWeight += a.weight;
    }
    if (totalWeight == 0.0) return 0.0;
    return weightedSum / totalWeight;
}

double StudentRecord::getSimpleAverage() const {
    if (assignments.empty()) return 0.0;
    double sum = 0.0;
    for (const auto& a : assignments) {
        sum += (a.score / a.maxScore) * 100.0;
    }
    return sum / assignments.size();
}

char StudentRecord::getLetterGrade() const {
    double avg = getWeightedAverage();
    if (avg >= 90.0) return 'A';
    if (avg >= 80.0) return 'B';
    if (avg >= 70.0) return 'C';
    if (avg >= 60.0) return 'D';
    return 'F';
}

void StudentRecord::printReport() const {
    cout << "\n========================================" << endl;
    cout << "  Student Report: " << studentName << endl;
    cout << "  ID: " << studentId << endl;
    cout << "========================================" << endl;

    if (assignments.empty()) {
        cout << "  No assignments recorded." << endl;
        return;
    }

    cout << left << setw(20) << "Assignment"
         << right << setw(8) << "Score"
         << setw(8) << "Max"
         << setw(10) << "Percent"
         << setw(10) << "Weight" << endl;
    cout << string(56, '-') << endl;

    for (const auto& a : assignments) {
        double pct = (a.score / a.maxScore) * 100.0;
        cout << left << setw(20) << a.name
             << right << setw(8) << fixed << setprecision(1) << a.score
             << setw(8) << a.maxScore
             << setw(9) << pct << "%"
             << setw(9) << a.weight << "%" << endl;
    }

    cout << string(56, '-') << endl;
    cout << "  Weighted Average: " << fixed << setprecision(2) << getWeightedAverage() << "%" << endl;
    cout << "  Simple Average:   " << getSimpleAverage() << "%" << endl;
    cout << "  Letter Grade:     " << getLetterGrade() << endl;
    cout << endl;
}

string StudentRecord::getName() const { return studentName; }
string StudentRecord::getId() const { return studentId; }
int StudentRecord::getAssignmentCount() const { return assignments.size(); }

Gradebook::Gradebook(const string& name, const string& code)
    : courseName(name), courseCode(code) {}

void Gradebook::addStudent(const string& name, const string& id) {
    for (const auto& s : students) {
        if (s.getId() == id) {
            cout << "Error: student with ID " << id << " already exists." << endl;
            return;
        }
    }
    students.emplace_back(name, id);
    cout << "Added student: " << name << " (" << id << ")" << endl;
}

StudentRecord* Gradebook::findStudent(const string& id) {
    for (auto& s : students) {
        if (s.getId() == id) return &s;
    }
    return nullptr;
}

double Gradebook::getClassAverage() const {
    if (students.empty()) return 0.0;
    double total = 0.0;
    int counted = 0;
    for (const auto& s : students) {
        if (s.getAssignmentCount() > 0) {
            total += s.getWeightedAverage();
            counted++;
        }
    }
    if (counted == 0) return 0.0;
    return total / counted;
}

void Gradebook::printClassSummary() const {
    cout << "\n========================================" << endl;
    cout << "  Class Summary: " << courseName << " (" << courseCode << ")" << endl;
    cout << "  Students: " << students.size() << endl;
    cout << "  Class Average: " << fixed << setprecision(2) << getClassAverage() << "%" << endl;
    cout << "========================================" << endl;

    cout << left << setw(20) << "Student"
         << setw(12) << "ID"
         << right << setw(10) << "Average"
         << setw(8) << "Grade" << endl;
    cout << string(50, '-') << endl;

    for (const auto& s : students) {
        cout << left << setw(20) << s.getName()
             << setw(12) << s.getId()
             << right << setw(9) << fixed << setprecision(2) << s.getWeightedAverage() << "%"
             << setw(6) << s.getLetterGrade() << endl;
    }
    cout << endl;
}

void Gradebook::printGradeDistribution() const {
    int counts[5] = {0};
    for (const auto& s : students) {
        char g = s.getLetterGrade();
        if (g == 'A') counts[0]++;
        else if (g == 'B') counts[1]++;
        else if (g == 'C') counts[2]++;
        else if (g == 'D') counts[3]++;
        else counts[4]++;
    }

    cout << "\n--- Grade Distribution ---" << endl;
    char grades[] = {'A', 'B', 'C', 'D', 'F'};
    for (int i = 0; i < 5; i++) {
        cout << "  " << grades[i] << ": ";
        for (int j = 0; j < counts[i]; j++) cout << "#";
        cout << " (" << counts[i] << ")" << endl;
    }
    cout << endl;
}

int Gradebook::getStudentCount() const { return students.size(); }
