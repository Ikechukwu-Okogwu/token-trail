#ifndef GRADEBOOK_H
#define GRADEBOOK_H

#include <string>
#include <vector>
#include <map>

struct Assignment {
    std::string name;
    double score;
    double maxScore;
    double weight;
};

class StudentRecord {
    std::string studentName;
    std::string studentId;
    std::vector<Assignment> assignments;

public:
    StudentRecord(const std::string& name, const std::string& id);
    void addAssignment(const std::string& name, double score, double maxScore, double weight);
    double getWeightedAverage() const;
    double getSimpleAverage() const;
    char getLetterGrade() const;
    void printReport() const;
    std::string getName() const;
    std::string getId() const;
    int getAssignmentCount() const;
};

class Gradebook {
    std::string courseName;
    std::string courseCode;
    std::vector<StudentRecord> students;

public:
    Gradebook(const std::string& name, const std::string& code);
    void addStudent(const std::string& name, const std::string& id);
    StudentRecord* findStudent(const std::string& id);
    void printClassSummary() const;
    void printGradeDistribution() const;
    double getClassAverage() const;
    int getStudentCount() const;
};

#endif
