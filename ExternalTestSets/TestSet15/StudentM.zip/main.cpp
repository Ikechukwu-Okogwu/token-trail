#include "gradebook.h"
#include <iostream>
#include <string>

using namespace std;

int main() {
    string courseName, courseCode;
    cout << "=== Grade Tracker ===" << endl;
    cout << "Course name: ";
    getline(cin, courseName);
    cout << "Course code: ";
    getline(cin, courseCode);

    Gradebook book(courseName, courseCode);
    int choice;

    do {
        cout << "\n1. Add student" << endl;
        cout << "2. Add assignment grade" << endl;
        cout << "3. Student report" << endl;
        cout << "4. Class summary" << endl;
        cout << "5. Grade distribution" << endl;
        cout << "0. Exit" << endl;
        cout << "Choice: ";
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            string name, id;
            cout << "Student name: ";
            getline(cin, name);
            cout << "Student ID: ";
            getline(cin, id);
            book.addStudent(name, id);
        } else if (choice == 2) {
            string id, assignName;
            double score, maxScore, weight;
            cout << "Student ID: ";
            getline(cin, id);
            StudentRecord* rec = book.findStudent(id);
            if (rec == nullptr) {
                cout << "Student not found." << endl;
                continue;
            }
            cout << "Assignment name: ";
            getline(cin, assignName);
            cout << "Score: ";
            cin >> score;
            cout << "Max score: ";
            cin >> maxScore;
            cout << "Weight (%): ";
            cin >> weight;
            cin.ignore();
            rec->addAssignment(assignName, score, maxScore, weight);
            cout << "Grade recorded." << endl;
        } else if (choice == 3) {
            string id;
            cout << "Student ID: ";
            getline(cin, id);
            StudentRecord* rec = book.findStudent(id);
            if (rec == nullptr) {
                cout << "Student not found." << endl;
            } else {
                rec->printReport();
            }
        } else if (choice == 4) {
            book.printClassSummary();
        } else if (choice == 5) {
            book.printGradeDistribution();
        }
    } while (choice != 0);

    cout << "Goodbye." << endl;
    return 0;
}
