import java.util.Scanner;
import java.util.LinkedList;
import java.util.Queue;

public class BinarySearchTree {
    private int value;
    private BinarySearchTree left;
    private BinarySearchTree right;
    private int nodeCount;

    public BinarySearchTree(int value) {
        this.value = value;
        this.left = null;
        this.right = null;
        this.nodeCount = 1;
    }

    public BinarySearchTree insert(int newValue) {
        if (newValue < value) {
            if (left == null) {
                left = new BinarySearchTree(newValue);
            } else {
                left = left.insert(newValue);
            }
        } else if (newValue > value) {
            if (right == null) {
                right = new BinarySearchTree(newValue);
            } else {
                right = right.insert(newValue);
            }
        } else {
            System.out.println("  Duplicate value " + newValue + " ignored.");
            return this;
        }
        nodeCount++;
        return this;
    }

    public boolean search(int target) {
        if (target == value) {
            return true;
        } else if (target < value) {
            return left != null && left.search(target);
        } else {
            return right != null && right.search(target);
        }
    }

    public int findMin() {
        if (left == null) return value;
        return left.findMin();
    }

    public int findMax() {
        if (right == null) return value;
        return right.findMax();
    }

    public int height() {
        int leftHeight = (left != null) ? left.height() : -1;
        int rightHeight = (right != null) ? right.height() : -1;
        return 1 + Math.max(leftHeight, rightHeight);
    }

    public void inorder() {
        if (left != null) left.inorder();
        System.out.print(value + " ");
        if (right != null) right.inorder();
    }

    public void preorder() {
        System.out.print(value + " ");
        if (left != null) left.preorder();
        if (right != null) right.preorder();
    }

    public void postorder() {
        if (left != null) left.postorder();
        if (right != null) right.postorder();
        System.out.print(value + " ");
    }

    public void levelOrder() {
        Queue<BinarySearchTree> queue = new LinkedList<>();
        queue.add(this);
        while (!queue.isEmpty()) {
            BinarySearchTree current = queue.poll();
            System.out.print(current.value + " ");
            if (current.left != null) queue.add(current.left);
            if (current.right != null) queue.add(current.right);
        }
    }

    public BinarySearchTree delete(int target) {
        if (target < value) {
            if (left != null) left = left.delete(target);
        } else if (target > value) {
            if (right != null) right = right.delete(target);
        } else {
            if (left == null && right == null) {
                return null;
            } else if (left == null) {
                return right;
            } else if (right == null) {
                return left;
            } else {
                int successor = right.findMin();
                value = successor;
                right = right.delete(successor);
            }
        }
        return this;
    }

    public int countNodes() {
        int count = 1;
        if (left != null) count += left.countNodes();
        if (right != null) count += right.countNodes();
        return count;
    }

    public int countLeaves() {
        if (left == null && right == null) return 1;
        int count = 0;
        if (left != null) count += left.countLeaves();
        if (right != null) count += right.countLeaves();
        return count;
    }

    public boolean isBalanced() {
        int leftH = (left != null) ? left.height() : -1;
        int rightH = (right != null) ? right.height() : -1;
        if (Math.abs(leftH - rightH) > 1) return false;
        boolean leftBal = (left == null) || left.isBalanced();
        boolean rightBal = (right == null) || right.isBalanced();
        return leftBal && rightBal;
    }

    public void printTree(String prefix, boolean isLeft) {
        if (right != null) {
            right.printTree(prefix + (isLeft ? "|   " : "    "), false);
        }
        System.out.println(prefix + (isLeft ? "\\-- " : "/-- ") + value);
        if (left != null) {
            left.printTree(prefix + (isLeft ? "    " : "|   "), true);
        }
    }

    public void printInfo() {
        System.out.println("\n--- Tree Info ---");
        System.out.println("  Nodes:    " + countNodes());
        System.out.println("  Leaves:   " + countLeaves());
        System.out.println("  Height:   " + height());
        System.out.println("  Min:      " + findMin());
        System.out.println("  Max:      " + findMax());
        System.out.println("  Balanced: " + (isBalanced() ? "Yes" : "No"));
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BinarySearchTree tree = null;

        System.out.println("=== Binary Search Tree ===");
        int choice;

        do {
            System.out.println("\n1. Insert");
            System.out.println("2. Delete");
            System.out.println("3. Search");
            System.out.println("4. Traversals");
            System.out.println("5. Tree info");
            System.out.println("6. Print tree");
            System.out.println("0. Exit");
            System.out.print("Choice: ");
            choice = scanner.nextInt();

            if (choice == 1) {
                System.out.print("Value: ");
                int val = scanner.nextInt();
                if (tree == null) {
                    tree = new BinarySearchTree(val);
                    System.out.println("  Created tree with root " + val);
                } else {
                    tree = tree.insert(val);
                    System.out.println("  Inserted " + val);
                }
            } else if (choice == 2) {
                if (tree == null) {
                    System.out.println("  Tree is empty.");
                } else {
                    System.out.print("Value: ");
                    int val = scanner.nextInt();
                    tree = tree.delete(val);
                    System.out.println("  Deleted " + val);
                }
            } else if (choice == 3) {
                if (tree == null) {
                    System.out.println("  Tree is empty.");
                } else {
                    System.out.print("Value: ");
                    int val = scanner.nextInt();
                    System.out.println(tree.search(val) ? "  Found." : "  Not found.");
                }
            } else if (choice == 4) {
                if (tree == null) {
                    System.out.println("  Tree is empty.");
                } else {
                    System.out.print("  Inorder:    "); tree.inorder(); System.out.println();
                    System.out.print("  Preorder:   "); tree.preorder(); System.out.println();
                    System.out.print("  Postorder:  "); tree.postorder(); System.out.println();
                    System.out.print("  Level-order: "); tree.levelOrder(); System.out.println();
                }
            } else if (choice == 5) {
                if (tree == null) {
                    System.out.println("  Tree is empty.");
                } else {
                    tree.printInfo();
                }
            } else if (choice == 6) {
                if (tree == null) {
                    System.out.println("  Tree is empty.");
                } else {
                    System.out.println();
                    tree.printTree("", false);
                }
            }
        } while (choice != 0);

        scanner.close();
        System.out.println("Goodbye.");
    }
}
