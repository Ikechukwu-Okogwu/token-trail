#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

#define MAX_READINGS 1000

typedef struct {
    double celsius;
    double fahrenheit;
    double kelvin;
    char label[64];
} TempReading;

typedef struct {
    TempReading readings[MAX_READINGS];
    int count;
} TempLog;

void initLog(TempLog* log) {
    log->count = 0;
}

double celsiusToFahrenheit(double c) {
    return (c * 9.0 / 5.0) + 32.0;
}

double fahrenheitToCelsius(double f) {
    return (f - 32.0) * 5.0 / 9.0;
}

double celsiusToKelvin(double c) {
    return c + 273.15;
}

double kelvinToCelsius(double k) {
    return k - 273.15;
}

double fahrenheitToKelvin(double f) {
    return celsiusToKelvin(fahrenheitToCelsius(f));
}

double kelvinToFahrenheit(double k) {
    return celsiusToFahrenheit(kelvinToCelsius(k));
}

void convertAndDisplay(double value, char unit) {
    double c, f, k;
    if (unit == 'C' || unit == 'c') {
        c = value;
        f = celsiusToFahrenheit(value);
        k = celsiusToKelvin(value);
    } else if (unit == 'F' || unit == 'f') {
        c = fahrenheitToCelsius(value);
        f = value;
        k = fahrenheitToKelvin(value);
    } else if (unit == 'K' || unit == 'k') {
        c = kelvinToCelsius(value);
        f = kelvinToFahrenheit(value);
        k = value;
    } else {
        printf("Error: unknown unit '%c'. Use C, F, or K.\n", unit);
        return;
    }

    printf("  Celsius:    %10.4f C\n", c);
    printf("  Fahrenheit: %10.4f F\n", f);
    printf("  Kelvin:     %10.4f K\n", k);
}

int addReading(TempLog* log, double value, char unit, const char* label) {
    if (log->count >= MAX_READINGS) {
        printf("Error: log is full.\n");
        return -1;
    }
    TempReading* r = &log->readings[log->count];
    if (unit == 'C' || unit == 'c') {
        r->celsius = value;
        r->fahrenheit = celsiusToFahrenheit(value);
        r->kelvin = celsiusToKelvin(value);
    } else if (unit == 'F' || unit == 'f') {
        r->fahrenheit = value;
        r->celsius = fahrenheitToCelsius(value);
        r->kelvin = fahrenheitToKelvin(value);
    } else if (unit == 'K' || unit == 'k') {
        r->kelvin = value;
        r->celsius = kelvinToCelsius(value);
        r->fahrenheit = kelvinToFahrenheit(value);
    } else {
        printf("Error: unknown unit.\n");
        return -1;
    }
    strncpy(r->label, label, 63);
    r->label[63] = '\0';
    log->count++;
    printf("Reading added: %.2f %c (%s)\n", value, unit, label);
    return 0;
}

void printLog(TempLog* log) {
    if (log->count == 0) {
        printf("No readings recorded.\n");
        return;
    }
    printf("\n%-4s %-20s %10s %10s %10s\n", "#", "Label", "Celsius", "Fahrenheit", "Kelvin");
    printf("%s\n", "-----------------------------------------------------------");
    for (int i = 0; i < log->count; i++) {
        TempReading* r = &log->readings[i];
        printf("%-4d %-20s %10.2f %10.2f %10.2f\n",
               i + 1, r->label, r->celsius, r->fahrenheit, r->kelvin);
    }
    printf("\n");
}

void computeStats(TempLog* log) {
    if (log->count == 0) {
        printf("No readings to analyze.\n");
        return;
    }

    double sumC = 0, minC = log->readings[0].celsius, maxC = log->readings[0].celsius;
    int minIdx = 0, maxIdx = 0;

    for (int i = 0; i < log->count; i++) {
        double c = log->readings[i].celsius;
        sumC += c;
        if (c < minC) { minC = c; minIdx = i; }
        if (c > maxC) { maxC = c; maxIdx = i; }
    }

    double meanC = sumC / log->count;

    double variance = 0;
    for (int i = 0; i < log->count; i++) {
        double diff = log->readings[i].celsius - meanC;
        variance += diff * diff;
    }
    variance /= log->count;
    double stddev = sqrt(variance);

    double median;
    double sorted[MAX_READINGS];
    for (int i = 0; i < log->count; i++) sorted[i] = log->readings[i].celsius;
    for (int i = 0; i < log->count - 1; i++) {
        for (int j = 0; j < log->count - i - 1; j++) {
            if (sorted[j] > sorted[j + 1]) {
                double tmp = sorted[j];
                sorted[j] = sorted[j + 1];
                sorted[j + 1] = tmp;
            }
        }
    }
    if (log->count % 2 == 0) {
        median = (sorted[log->count / 2 - 1] + sorted[log->count / 2]) / 2.0;
    } else {
        median = sorted[log->count / 2];
    }

    printf("\n--- Temperature Statistics (Celsius) ---\n");
    printf("  Count:    %d\n", log->count);
    printf("  Mean:     %.4f C\n", meanC);
    printf("  Median:   %.4f C\n", median);
    printf("  Std Dev:  %.4f C\n", stddev);
    printf("  Min:      %.4f C (%s)\n", minC, log->readings[minIdx].label);
    printf("  Max:      %.4f C (%s)\n", maxC, log->readings[maxIdx].label);
    printf("  Range:    %.4f C\n", maxC - minC);
    printf("\n");
}

int main() {
    TempLog log;
    initLog(&log);

    int choice;
    printf("=== Temperature Tool ===\n");

    do {
        printf("\n1. Convert temperature\n");
        printf("2. Add reading to log\n");
        printf("3. View log\n");
        printf("4. Statistics\n");
        printf("0. Exit\n");
        printf("Choice: ");
        scanf("%d", &choice);

        if (choice == 1) {
            double value;
            char unit;
            printf("Value: ");
            scanf("%lf", &value);
            printf("Unit (C/F/K): ");
            scanf(" %c", &unit);
            convertAndDisplay(value, unit);
        } else if (choice == 2) {
            double value;
            char unit;
            char label[64];
            printf("Value: ");
            scanf("%lf", &value);
            printf("Unit (C/F/K): ");
            scanf(" %c", &unit);
            getchar();
            printf("Label: ");
            fgets(label, 64, stdin);
            label[strcspn(label, "\n")] = '\0';
            addReading(&log, value, unit, label);
        } else if (choice == 3) {
            printLog(&log);
        } else if (choice == 4) {
            computeStats(&log);
        }
    } while (choice != 0);

    printf("Goodbye.\n");
    return 0;
}
