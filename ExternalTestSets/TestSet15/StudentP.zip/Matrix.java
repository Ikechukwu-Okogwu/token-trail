import java.util.Random;

public class Matrix {

    private int rows;
    private int cols;
    private double[][] data;

    public Matrix(int rows, int cols) {
        this.rows = rows;
        this.cols = cols;
        this.data = new double[rows][cols];
    }

    public Matrix(double[][] values) {
        this.rows = values.length;
        this.cols = values[0].length;
        this.data = new double[rows][cols];
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                this.data[i][j] = values[i][j];
            }
        }
    }

    public int getRows() {
        return rows;
    }

    public int getCols() {
        return cols;
    }

    public double getElement(int row, int col) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            System.out.println("Error: index out of bounds.");
            return 0;
        }
        return data[row][col];
    }

    public void setElement(int row, int col, double value) {
        if (row < 0 || row >= rows || col < 0 || col >= cols) {
            System.out.println("Error: index out of bounds.");
            return;
        }
        data[row][col] = value;
    }

    public double[][] getData() {
        return data;
    }

    public void fillRandom(int maxValue) {
        Random random = new Random();
        for (int i = 0; i < rows; i++) {
            for (int j = 0; j < cols; j++) {
                data[i][j] = random.nextInt(maxValue) + 1;
            }
        }
    }

    public void display() {
        System.out.println("Matrix (" + rows + "x" + cols + "):");
        for (int i = 0; i < rows; i++) {
            StringBuilder sb = new StringBuilder("  ");
            for (int j = 0; j < cols; j++) {
                sb.append(String.format("%8.2f", data[i][j]));
                if (j < cols - 1) sb.append(" ");
            }
            System.out.println(sb.toString());
        }
        System.out.println();
    }
}
