import java.util.Scanner;

public class MatrixApp {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=== Matrix Operations Tool ===");

        System.out.print("Enter rows for Matrix A: ");
        int rowsA = scanner.nextInt();
        System.out.print("Enter cols for Matrix A: ");
        int colsA = scanner.nextInt();

        Matrix matA = new Matrix(rowsA, colsA);
        matA.fillRandom(10);
        System.out.println("\nMatrix A:");
        matA.display();

        System.out.print("Enter rows for Matrix B: ");
        int rowsB = scanner.nextInt();
        System.out.print("Enter cols for Matrix B: ");
        int colsB = scanner.nextInt();

        Matrix matB = new Matrix(rowsB, colsB);
        matB.fillRandom(10);
        System.out.println("Matrix B:");
        matB.display();

        int choice;
        do {
            System.out.println("1. Multiply A * B");
            System.out.println("2. Add A + B");
            System.out.println("3. Subtract A - B");
            System.out.println("4. Transpose A");
            System.out.println("5. Transpose B");
            System.out.println("6. Scalar multiply A");
            System.out.println("7. Determinant of A");
            System.out.println("8. Determinant of B");
            System.out.println("9. Trace of A");
            System.out.println("10. Check if A is symmetric");
            System.out.println("11. Display matrices");
            System.out.println("0. Exit");
            System.out.print("Choice: ");
            choice = scanner.nextInt();

            if (choice == 1) {
                System.out.println("--- A * B ---");
                Matrix product = MatrixOperations.multiply(matA, matB);
                if (product != null) product.display();
            } else if (choice == 2) {
                System.out.println("--- A + B ---");
                Matrix sum = MatrixOperations.add(matA, matB);
                if (sum != null) sum.display();
            } else if (choice == 3) {
                System.out.println("--- A - B ---");
                Matrix diff = MatrixOperations.subtract(matA, matB);
                if (diff != null) diff.display();
            } else if (choice == 4) {
                System.out.println("--- Transpose of A ---");
                Matrix transA = MatrixOperations.transpose(matA);
                transA.display();
            } else if (choice == 5) {
                System.out.println("--- Transpose of B ---");
                Matrix transB = MatrixOperations.transpose(matB);
                transB.display();
            } else if (choice == 6) {
                System.out.print("Enter scalar value: ");
                double scalar = scanner.nextDouble();
                System.out.println("--- A * " + scalar + " ---");
                Matrix scaled = MatrixOperations.scalarMultiply(matA, scalar);
                scaled.display();
            } else if (choice == 7) {
                if (rowsA == colsA) {
                    double det = MatrixOperations.determinant(matA);
                    System.out.printf("det(A) = %.4f%n%n", det);
                } else {
                    System.out.println("A is not square.\n");
                }
            } else if (choice == 8) {
                if (rowsB == colsB) {
                    double det = MatrixOperations.determinant(matB);
                    System.out.printf("det(B) = %.4f%n%n", det);
                } else {
                    System.out.println("B is not square.\n");
                }
            } else if (choice == 9) {
                if (rowsA == colsA) {
                    double tr = MatrixOperations.trace(matA);
                    System.out.printf("trace(A) = %.4f%n%n", tr);
                } else {
                    System.out.println("A is not square.\n");
                }
            } else if (choice == 10) {
                boolean sym = MatrixOperations.isSymmetric(matA);
                System.out.println("A is " + (sym ? "" : "not ") + "symmetric.\n");
            } else if (choice == 11) {
                System.out.println("Matrix A:");
                matA.display();
                System.out.println("Matrix B:");
                matB.display();
            }
        } while (choice != 0);

        scanner.close();
        System.out.println("Done.");
    }
}
