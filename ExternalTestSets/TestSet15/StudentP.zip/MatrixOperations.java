public class MatrixOperations {

    public static Matrix multiply(Matrix a, Matrix b) {
        if (a.getCols() != b.getRows()) {
            System.out.println("Error: incompatible matrix dimensions for multiplication.");
            return null;
        }
        Matrix result = new Matrix(a.getRows(), b.getCols());
        for (int i = 0; i < a.getRows(); i++) {
            for (int j = 0; j < b.getCols(); j++) {
                double sum = 0.0;
                for (int k = 0; k < a.getCols(); k++) {
                    sum += a.getElement(i, k) * b.getElement(k, j);
                }
                result.setElement(i, j, sum);
            }
        }
        return result;
    }

    public static Matrix add(Matrix a, Matrix b) {
        if (a.getRows() != b.getRows() || a.getCols() != b.getCols()) {
            System.out.println("Error: incompatible matrix dimensions for addition.");
            return null;
        }
        Matrix result = new Matrix(a.getRows(), a.getCols());
        for (int i = 0; i < a.getRows(); i++) {
            for (int j = 0; j < a.getCols(); j++) {
                result.setElement(i, j, a.getElement(i, j) + b.getElement(i, j));
            }
        }
        return result;
    }

    public static Matrix subtract(Matrix a, Matrix b) {
        if (a.getRows() != b.getRows() || a.getCols() != b.getCols()) {
            System.out.println("Error: incompatible matrix dimensions for subtraction.");
            return null;
        }
        Matrix result = new Matrix(a.getRows(), a.getCols());
        for (int i = 0; i < a.getRows(); i++) {
            for (int j = 0; j < a.getCols(); j++) {
                result.setElement(i, j, a.getElement(i, j) - b.getElement(i, j));
            }
        }
        return result;
    }

    public static Matrix transpose(Matrix a) {
        Matrix result = new Matrix(a.getCols(), a.getRows());
        for (int i = 0; i < a.getRows(); i++) {
            for (int j = 0; j < a.getCols(); j++) {
                result.setElement(j, i, a.getElement(i, j));
            }
        }
        return result;
    }

    public static Matrix scalarMultiply(Matrix a, double scalar) {
        Matrix result = new Matrix(a.getRows(), a.getCols());
        for (int i = 0; i < a.getRows(); i++) {
            for (int j = 0; j < a.getCols(); j++) {
                result.setElement(i, j, a.getElement(i, j) * scalar);
            }
        }
        return result;
    }

    public static double determinant(Matrix a) {
        if (a.getRows() != a.getCols()) {
            System.out.println("Error: determinant only defined for square matrices.");
            return 0;
        }
        return computeDeterminant(a.getData(), a.getRows());
    }

    private static double computeDeterminant(double[][] matrix, int n) {
        if (n == 1) {
            return matrix[0][0];
        }
        if (n == 2) {
            return matrix[0][0] * matrix[1][1] - matrix[0][1] * matrix[1][0];
        }
        double det = 0.0;
        for (int col = 0; col < n; col++) {
            double[][] subMatrix = new double[n - 1][n - 1];
            for (int i = 1; i < n; i++) {
                int subCol = 0;
                for (int j = 0; j < n; j++) {
                    if (j == col) continue;
                    subMatrix[i - 1][subCol] = matrix[i][j];
                    subCol++;
                }
            }
            double sign = (col % 2 == 0) ? 1.0 : -1.0;
            det += sign * matrix[0][col] * computeDeterminant(subMatrix, n - 1);
        }
        return det;
    }

    public static boolean isSymmetric(Matrix a) {
        if (a.getRows() != a.getCols()) return false;
        for (int i = 0; i < a.getRows(); i++) {
            for (int j = i + 1; j < a.getCols(); j++) {
                if (Math.abs(a.getElement(i, j) - a.getElement(j, i)) > 0.0001) {
                    return false;
                }
            }
        }
        return true;
    }

    public static double trace(Matrix a) {
        if (a.getRows() != a.getCols()) {
            System.out.println("Error: trace only defined for square matrices.");
            return 0;
        }
        double sum = 0.0;
        for (int i = 0; i < a.getRows(); i++) {
            sum += a.getElement(i, i);
        }
        return sum;
    }
}
