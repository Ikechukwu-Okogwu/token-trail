import java.util.Random;

public class Grid {

    private int numRows;
    private int numCols;
    private double[][] cells;

    public Grid(int numRows, int numCols) {
        this.numRows = numRows;
        this.numCols = numCols;
        this.cells = new double[numRows][numCols];
    }

    public Grid(double[][] input) {
        this.numRows = input.length;
        this.numCols = input[0].length;
        this.cells = new double[numRows][numCols];
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                this.cells[r][c] = input[r][c];
            }
        }
    }

    public int getNumRows() {
        return numRows;
    }

    public int getNumCols() {
        return numCols;
    }

    public double getValue(int row, int col) {
        if (row < 0 || row >= numRows || col < 0 || col >= numCols) {
            System.out.println("Error: index out of bounds.");
            return 0;
        }
        return cells[row][col];
    }

    public void setValue(int row, int col, double val) {
        if (row < 0 || row >= numRows || col < 0 || col >= numCols) {
            System.out.println("Error: index out of bounds.");
            return;
        }
        cells[row][col] = val;
    }

    public double[][] getCells() {
        return cells;
    }

    public void populateRandom(int upperBound) {
        Random rng = new Random();
        for (int r = 0; r < numRows; r++) {
            for (int c = 0; c < numCols; c++) {
                cells[r][c] = rng.nextInt(upperBound) + 1;
            }
        }
    }

    public void print() {
        System.out.println("Matrix (" + numRows + "x" + numCols + "):");
        for (int r = 0; r < numRows; r++) {
            StringBuilder line = new StringBuilder("  ");
            for (int c = 0; c < numCols; c++) {
                line.append(String.format("%8.2f", cells[r][c]));
                if (c < numCols - 1) line.append(" ");
            }
            System.out.println(line.toString());
        }
        System.out.println();
    }
}
