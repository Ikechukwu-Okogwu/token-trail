import java.util.Scanner;

public class GridApp {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("=== Matrix Operations Tool ===");

        System.out.print("Enter rows for Matrix A: ");
        int rA = input.nextInt();
        System.out.print("Enter cols for Matrix A: ");
        int cA = input.nextInt();

        Grid first = new Grid(rA, cA);
        first.populateRandom(10);
        System.out.println("\nMatrix A:");
        first.print();

        System.out.print("Enter rows for Matrix B: ");
        int rB = input.nextInt();
        System.out.print("Enter cols for Matrix B: ");
        int cB = input.nextInt();

        Grid second = new Grid(rB, cB);
        second.populateRandom(10);
        System.out.println("Matrix B:");
        second.print();

        int option;
        do {
            System.out.println("1. Multiply A * B");
            System.out.println("2. Add A + B");
            System.out.println("3. Subtract A - B");
            System.out.println("4. Transpose A");
            System.out.println("5. Transpose B");
            System.out.println("6. Scalar multiply A");
            System.out.println("7. Determinant of A");
            System.out.println("8. Determinant of B");
            System.out.println("9. Trace of A");
            System.out.println("10. Check if A is symmetric");
            System.out.println("11. Display matrices");
            System.out.println("0. Exit");
            System.out.print("Choice: ");
            option = input.nextInt();

            if (option == 1) {
                System.out.println("--- A * B ---");
                Grid prod = GridMath.multiply(first, second);
                if (prod != null) prod.print();
            } else if (option == 2) {
                System.out.println("--- A + B ---");
                Grid added = GridMath.add(first, second);
                if (added != null) added.print();
            } else if (option == 3) {
                System.out.println("--- A - B ---");
                Grid subtracted = GridMath.subtract(first, second);
                if (subtracted != null) subtracted.print();
            } else if (option == 4) {
                System.out.println("--- Transpose of A ---");
                Grid flippedA = GridMath.transpose(first);
                flippedA.print();
            } else if (option == 5) {
                System.out.println("--- Transpose of B ---");
                Grid flippedB = GridMath.transpose(second);
                flippedB.print();
            } else if (option == 6) {
                System.out.print("Enter scalar value: ");
                double factor = input.nextDouble();
                System.out.println("--- A * " + factor + " ---");
                Grid magnified = GridMath.scalarMultiply(first, factor);
                magnified.print();
            } else if (option == 7) {
                if (rA == cA) {
                    double detVal = GridMath.determinant(first);
                    System.out.printf("det(A) = %.4f%n%n", detVal);
                } else {
                    System.out.println("A is not square.\n");
                }
            } else if (option == 8) {
                if (rB == cB) {
                    double detVal = GridMath.determinant(second);
                    System.out.printf("det(B) = %.4f%n%n", detVal);
                } else {
                    System.out.println("B is not square.\n");
                }
            } else if (option == 9) {
                if (rA == cA) {
                    double trVal = GridMath.trace(first);
                    System.out.printf("trace(A) = %.4f%n%n", trVal);
                } else {
                    System.out.println("A is not square.\n");
                }
            } else if (option == 10) {
                boolean sym = GridMath.isSymmetric(first);
                System.out.println("A is " + (sym ? "" : "not ") + "symmetric.\n");
            } else if (option == 11) {
                System.out.println("Matrix A:");
                first.print();
                System.out.println("Matrix B:");
                second.print();
            }
        } while (option != 0);

        input.close();
        System.out.println("Done.");
    }
}
