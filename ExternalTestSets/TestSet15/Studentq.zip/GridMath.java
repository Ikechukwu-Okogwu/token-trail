public class GridMath {

    public static Grid multiply(Grid first, Grid second) {
        if (first.getNumCols() != second.getNumRows()) {
            System.out.println("Error: incompatible matrix dimensions for multiplication.");
            return null;
        }
        Grid output = new Grid(first.getNumRows(), second.getNumCols());
        for (int r = 0; r < first.getNumRows(); r++) {
            for (int c = 0; c < second.getNumCols(); c++) {
                double total = 0.0;
                for (int idx = 0; idx < first.getNumCols(); idx++) {
                    total += first.getValue(r, idx) * second.getValue(idx, c);
                }
                output.setValue(r, c, total);
            }
        }
        return output;
    }

    public static Grid add(Grid first, Grid second) {
        if (first.getNumRows() != second.getNumRows() || first.getNumCols() != second.getNumCols()) {
            System.out.println("Error: incompatible matrix dimensions for addition.");
            return null;
        }
        Grid output = new Grid(first.getNumRows(), first.getNumCols());
        for (int r = 0; r < first.getNumRows(); r++) {
            for (int c = 0; c < first.getNumCols(); c++) {
                output.setValue(r, c, first.getValue(r, c) + second.getValue(r, c));
            }
        }
        return output;
    }

    public static Grid subtract(Grid first, Grid second) {
        if (first.getNumRows() != second.getNumRows() || first.getNumCols() != second.getNumCols()) {
            System.out.println("Error: incompatible matrix dimensions for subtraction.");
            return null;
        }
        Grid output = new Grid(first.getNumRows(), first.getNumCols());
        for (int r = 0; r < first.getNumRows(); r++) {
            for (int c = 0; c < first.getNumCols(); c++) {
                output.setValue(r, c, first.getValue(r, c) - second.getValue(r, c));
            }
        }
        return output;
    }

    public static Grid transpose(Grid original) {
        Grid output = new Grid(original.getNumCols(), original.getNumRows());
        for (int r = 0; r < original.getNumRows(); r++) {
            for (int c = 0; c < original.getNumCols(); c++) {
                output.setValue(c, r, original.getValue(r, c));
            }
        }
        return output;
    }

    public static Grid scalarMultiply(Grid original, double factor) {
        Grid output = new Grid(original.getNumRows(), original.getNumCols());
        for (int r = 0; r < original.getNumRows(); r++) {
            for (int c = 0; c < original.getNumCols(); c++) {
                output.setValue(r, c, original.getValue(r, c) * factor);
            }
        }
        return output;
    }

    public static double determinant(Grid g) {
        if (g.getNumRows() != g.getNumCols()) {
            System.out.println("Error: determinant only defined for square matrices.");
            return 0;
        }
        return calcDeterminant(g.getCells(), g.getNumRows());
    }

    private static double calcDeterminant(double[][] mat, int size) {
        if (size == 1) {
            return mat[0][0];
        }
        if (size == 2) {
            return mat[0][0] * mat[1][1] - mat[0][1] * mat[1][0];
        }
        double det = 0.0;
        for (int c = 0; c < size; c++) {
            double[][] minor = new double[size - 1][size - 1];
            for (int r = 1; r < size; r++) {
                int minorCol = 0;
                for (int j = 0; j < size; j++) {
                    if (j == c) continue;
                    minor[r - 1][minorCol] = mat[r][j];
                    minorCol++;
                }
            }
            double factor = (c % 2 == 0) ? 1.0 : -1.0;
            det += factor * mat[0][c] * calcDeterminant(minor, size - 1);
        }
        return det;
    }

    public static boolean isSymmetric(Grid g) {
        if (g.getNumRows() != g.getNumCols()) return false;
        for (int r = 0; r < g.getNumRows(); r++) {
            for (int c = r + 1; c < g.getNumCols(); c++) {
                if (Math.abs(g.getValue(r, c) - g.getValue(c, r)) > 0.0001) {
                    return false;
                }
            }
        }
        return true;
    }

    public static double trace(Grid g) {
        if (g.getNumRows() != g.getNumCols()) {
            System.out.println("Error: trace only defined for square matrices.");
            return 0;
        }
        double total = 0.0;
        for (int r = 0; r < g.getNumRows(); r++) {
            total += g.getValue(r, r);
        }
        return total;
    }
}
