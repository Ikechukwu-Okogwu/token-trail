/**
 * Prime number checker — a STRICT SUBSET of the full number theory program (P09).
 *
 * The four core methods (sieve, isPrime, countPrimes, nthPrime) appear
 * verbatim and without modification in NumberTheory.java (P09).
 * P09 extends this with GCD, LCM, Goldbach, Euler totient, perfect numbers,
 * amicable pairs, Armstrong numbers, and the Collatz sequence.
 *
 * Subset relationship: every line of core logic in this file exists inside P09.
 */
public class PrimeChecker {

    /**
     * Sieve of Eratosthenes.
     * Returns a boolean array where composite[i] == true means i is NOT prime.
     * Runs in O(n log log n) time and O(n) space.
     *
     * @param limit  upper bound (inclusive) of the sieve
     * @return       composite[] flag array of length limit+1
     */
    static boolean[] sieve(int limit) {
        boolean[] composite = new boolean[limit + 1];
        composite[0] = composite[1] = true;
        for (int i = 2; i * i <= limit; i++) {
            if (!composite[i]) {
                for (int j = i * i; j <= limit; j += i) {
                    composite[j] = true;
                }
            }
        }
        return composite;
    }

    /**
     * Trial-division primality test.
     * Handles edge cases directly; tests odd divisors up to sqrt(n).
     *
     * @param n  integer to test
     * @return   true if n is prime
     */
    static boolean isPrime(int n) {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        for (int i = 3; i * i <= n; i += 2)
            if (n % i == 0) return false;
        return true;
    }

    /**
     * Counts prime numbers in [2, limit] using the sieve.
     *
     * @param limit  upper bound (inclusive)
     * @return       number of primes <= limit
     */
    static int countPrimes(int limit) {
        boolean[] composite = sieve(limit);
        int count = 0;
        for (int i = 2; i <= limit; i++)
            if (!composite[i]) count++;
        return count;
    }

    /**
     * Returns the n-th prime (1-indexed: nthPrime(1) == 2).
     * Uses trial division; suitable for small n.
     *
     * @param n  position in the prime sequence
     * @return   the n-th prime number
     */
    static int nthPrime(int n) {
        int count = 0, candidate = 1;
        while (count < n) {
            candidate++;
            if (isPrime(candidate)) count++;
        }
        return candidate;
    }

    /** Prints all primes up to limit on one line. */
    static void printPrimesUpTo(int limit) {
        boolean[] comp = sieve(limit);
        System.out.print("Primes up to " + limit + ": ");
        for (int i = 2; i <= limit; i++)
            if (!comp[i]) System.out.print(i + " ");
        System.out.println();
    }

    /** Returns true if both n and n+2 are prime (twin prime check). */
    static boolean isTwinPrime(int n) {
        return isPrime(n) && isPrime(n + 2);
    }

    /** Prints all twin prime pairs (p, p+2) where p <= limit. */
    static void printTwinPrimes(int limit) {
        System.out.print("Twin prime pairs up to " + limit + ": ");
        for (int i = 2; i <= limit - 2; i++)
            if (isTwinPrime(i)) System.out.print("(" + i + "," + (i + 2) + ") ");
        System.out.println();
    }

    public static void main(String[] args) {
        printPrimesUpTo(50);

        System.out.println("isPrime(97): "  + isPrime(97));
        System.out.println("isPrime(100): " + isPrime(100));
        System.out.println("isPrime(2):   " + isPrime(2));
        System.out.println("isPrime(1):   " + isPrime(1));

        System.out.println("Prime count up to 100:  " + countPrimes(100));
        System.out.println("Prime count up to 1000: " + countPrimes(1000));

        System.out.println("1st prime:  " + nthPrime(1));
        System.out.println("10th prime: " + nthPrime(10));
        System.out.println("20th prime: " + nthPrime(20));
        System.out.println("50th prime: " + nthPrime(50));

        printTwinPrimes(100);
    }
}
