/**
 * Caesar cipher and ROT13 utilities — Version B
 * Uses: char arithmetic, while loops, switch statements
 *
 * Multi-file program: CipherEngine.java + CipherRunner.java
 * Pair: P17 (int + for + if-else) and P18 (char arithmetic + while + switch)
 *
 * Detection challenges across the pair:
 *  - shiftChar() uses a switch on character band instead of if-else
 *  - All loops rewritten as while loops
 *  - crackShift() uses do-while for the 26-shift scan
 *  - vigenere methods use while loops tracking ki separately
 *  - All cipher mathematics are identical to P17
 */
public class CipherEngine {

    static char shiftChar(char c, int shift) {
        switch (Character.isUpperCase(c) ? 1 : Character.isLowerCase(c) ? 2 : 0) {
            case 1:  return (char) ('A' + (c - 'A' + shift + 26) % 26);
            case 2:  return (char) ('a' + (c - 'a' + shift + 26) % 26);
            default: return c;
        }
    }

    static String encrypt(String plaintext, int shift) {
        StringBuilder sb = new StringBuilder();
        int i = 0;
        while (i < plaintext.length()) {
            sb.append(shiftChar(plaintext.charAt(i), shift));
            i++;
        }
        return sb.toString();
    }

    static String decrypt(String ciphertext, int shift) {
        return encrypt(ciphertext, -shift);
    }

    static String rot13(String text) {
        return encrypt(text, 13);
    }

    static int[] letterFrequency(String text) {
        int[] freq = new int[26];
        int i = 0;
        while (i < text.length()) {
            char c = Character.toLowerCase(text.charAt(i));
            if (c >= 'a' && c <= 'z') freq[c - 'a']++;
            i++;
        }
        return freq;
    }

    static int crackShift(String ciphertext) {
        int bestShift = 0;
        int maxE = -1;
        int shift = 0;
        do {
            String candidate = decrypt(ciphertext, shift);
            int[] freq = letterFrequency(candidate);
            if (freq['e' - 'a'] > maxE) {
                maxE = freq['e' - 'a'];
                bestShift = shift;
            }
            shift++;
        } while (shift < 26);
        return bestShift;
    }

    static int countAlpha(String text) {
        int count = 0;
        int i = 0;
        while (i < text.length()) {
            if (Character.isLetter(text.charAt(i))) count++;
            i++;
        }
        return count;
    }

    static boolean isPangram(String text) {
        boolean[] seen = new boolean[26];
        int i = 0;
        while (i < text.length()) {
            char c = Character.toLowerCase(text.charAt(i));
            if (c >= 'a' && c <= 'z') seen[c - 'a'] = true;
            i++;
        }
        int j = 0;
        while (j < 26) {
            if (!seen[j]) return false;
            j++;
        }
        return true;
    }

    static String reverse(String text) {
        StringBuilder sb = new StringBuilder();
        int i = text.length() - 1;
        while (i >= 0) {
            sb.append(text.charAt(i));
            i--;
        }
        return sb.toString();
    }

    static String vigenereEncrypt(String plaintext, String keyword) {
        StringBuilder sb = new StringBuilder();
        int keyLen = keyword.length();
        int ki = 0;
        int i = 0;
        while (i < plaintext.length()) {
            char p = plaintext.charAt(i);
            if (Character.isLetter(p)) {
                int s = Character.toLowerCase(keyword.charAt(ki % keyLen)) - 'a';
                sb.append(shiftChar(p, s));
                ki++;
            } else {
                sb.append(p);
            }
            i++;
        }
        return sb.toString();
    }

    static String vigenereDecrypt(String ciphertext, String keyword) {
        StringBuilder sb = new StringBuilder();
        int keyLen = keyword.length();
        int ki = 0;
        int i = 0;
        while (i < ciphertext.length()) {
            char c = ciphertext.charAt(i);
            if (Character.isLetter(c)) {
                int s = Character.toLowerCase(keyword.charAt(ki % keyLen)) - 'a';
                sb.append(shiftChar(c, -s));
                ki++;
            } else {
                sb.append(c);
            }
            i++;
        }
        return sb.toString();
    }
}
