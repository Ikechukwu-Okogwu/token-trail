/**
 * Driver for CipherEngine — Version B
 * Part of P18 multi-file submission.
 * Mirrors CipherMain.java (P17) exactly; only class/method references differ.
 */
public class CipherRunner {

    static void printFrequency(int[] freq) {
        System.out.println("Letter frequencies:");
        int i = 0;
        while (i < 26) {
            if (freq[i] > 0) {
                char letter = (char) ('a' + i);
                System.out.printf("  %c: %d%n", letter, freq[i]);
            }
            i++;
        }
    }

    public static void main(String[] args) {
        String message = "The quick brown fox jumps over the lazy dog";
        int shift = 7;

        System.out.println("Original:  " + message);

        String encrypted = CipherEngine.encrypt(message, shift);
        System.out.println("Encrypted (shift=" + shift + "): " + encrypted);

        String decrypted = CipherEngine.decrypt(encrypted, shift);
        System.out.println("Decrypted: " + decrypted);

        String rot13ed = CipherEngine.rot13(message);
        System.out.println("ROT13:     " + rot13ed);
        System.out.println("ROT13 x2:  " + CipherEngine.rot13(rot13ed));

        System.out.println("Is pangram: " + CipherEngine.isPangram(message));
        System.out.println("Alpha count: " + CipherEngine.countAlpha(message));
        System.out.println("Reversed: " + CipherEngine.reverse(message));

        System.out.println();
        int cracked = CipherEngine.crackShift(encrypted);
        System.out.println("Cracked shift: " + cracked);
        System.out.println("Cracked text:  " + CipherEngine.decrypt(encrypted, cracked));

        System.out.println();
        printFrequency(CipherEngine.letterFrequency(message));

        System.out.println();
        String keyword = "secret";
        String vigEncrypted = CipherEngine.vigenereEncrypt(message, keyword);
        String vigDecrypted = CipherEngine.vigenereDecrypt(vigEncrypted, keyword);
        System.out.println("Vigenere key:       " + keyword);
        System.out.println("Vigenere encrypted: " + vigEncrypted);
        System.out.println("Vigenere decrypted: " + vigDecrypted);
    }
}
