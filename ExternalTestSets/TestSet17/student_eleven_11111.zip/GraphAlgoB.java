import java.util.*;

/**
 * =========================================================
 * Graph Algorithm Showcase — Heavily Commented Version
 * =========================================================
 * This file is IDENTICAL in logic to GraphAlgoA (P10).
 * The only difference is the addition of multi-line comments
 * explaining each algorithm in detail.
 *
 * Algorithms covered:
 *  - Breadth-First Search  (BFS)
 *  - Depth-First Search    (DFS)
 *  - Dijkstra's Shortest Path
 *  - Cycle Detection
 *  - Connectivity check
 * =========================================================
 */
public class GraphAlgoB {

    /* Sentinel for "unreachable" in shortest-path arrays.
     * We use INF/2 so that (INF + weight) doesn't overflow. */
    static final int INF = Integer.MAX_VALUE / 2;

    /**
     * Builds an adjacency list for an undirected weighted graph.
     * Each entry g.get(u) is a list of int[] pairs {neighbor, weight}.
     *
     * @param n  number of vertices (0-indexed)
     * @return   empty adjacency list of size n
     */
    static List<List<int[]>> buildGraph(int n) {
        List<List<int[]>> g = new ArrayList<>();
        for (int i = 0; i < n; i++) g.add(new ArrayList<>());
        return g;
    }

    /**
     * Adds an undirected edge between u and v with weight w.
     * Both directions are stored so that traversal works from either end.
     */
    static void addEdge(List<List<int[]>> g, int u, int v, int w) {
        g.get(u).add(new int[]{v, w});
        g.get(v).add(new int[]{u, w});
    }

    /**
     * Breadth-First Search starting from `start`.
     *
     * BFS explores all neighbors of the current level before
     * moving deeper. It uses a FIFO queue and tracks visited
     * nodes to avoid revisiting.
     *
     * Time complexity: O(V + E)
     * Space complexity: O(V)
     *
     * @return  vertices visited in BFS order
     */
    static List<Integer> bfs(List<List<int[]>> g, int start, int n) {
        List<Integer> order = new ArrayList<>();
        boolean[] visited = new boolean[n];
        Queue<Integer> queue = new LinkedList<>();
        visited[start] = true;
        queue.add(start);
        while (!queue.isEmpty()) {
            int node = queue.poll();
            order.add(node);
            for (int[] edge : g.get(node)) {
                if (!visited[edge[0]]) {
                    visited[edge[0]] = true;
                    queue.add(edge[0]);
                }
            }
        }
        return order;
    }

    /**
     * Depth-First Search starting from `start`.
     *
     * DFS dives as deep as possible along each branch before
     * backtracking. Implemented recursively via dfsHelper.
     *
     * Time complexity: O(V + E)
     */
    static List<Integer> dfs(List<List<int[]>> g, int start, int n) {
        List<Integer> order = new ArrayList<>();
        boolean[] visited = new boolean[n];
        dfsHelper(g, start, visited, order);
        return order;
    }

    /*
     * Recursive helper for DFS.
     * Marks the current node visited, records it, then recurses
     * into each unvisited neighbor.
     */
    static void dfsHelper(List<List<int[]>> g, int node, boolean[] visited, List<Integer> order) {
        visited[node] = true;
        order.add(node);
        for (int[] edge : g.get(node)) {
            if (!visited[edge[0]]) {
                dfsHelper(g, edge[0], visited, order);
            }
        }
    }

    /**
     * Dijkstra's single-source shortest-path algorithm.
     *
     * Uses a min-heap (priority queue) ordered by tentative distance.
     * At each step, the node with the smallest known distance is settled.
     * Lazy deletion handles stale entries: if d > dist[u], skip.
     *
     * Requires non-negative edge weights.
     * Time complexity: O((V + E) log V)
     *
     * @param src  source vertex
     * @return     dist[] where dist[v] = shortest distance from src to v
     */
    static int[] dijkstra(List<List<int[]>> g, int src, int n) {
        int[] dist = new int[n];
        Arrays.fill(dist, INF);
        dist[src] = 0;
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        pq.add(new int[]{src, 0});
        while (!pq.isEmpty()) {
            int[] curr = pq.poll();
            int u = curr[0], d = curr[1];
            if (d > dist[u]) continue;  /* stale entry — discard */
            for (int[] edge : g.get(u)) {
                int v = edge[0], w = edge[1];
                if (dist[u] + w < dist[v]) {
                    dist[v] = dist[u] + w;
                    pq.add(new int[]{v, dist[v]});
                }
            }
        }
        return dist;
    }

    /**
     * Detects whether the undirected graph contains any cycle.
     *
     * Iterates over all components (handles disconnected graphs).
     * Within each component, runs DFS and checks if any back-edge
     * leads to a node other than the direct parent.
     *
     * Time complexity: O(V + E)
     */
    static boolean hasCycle(List<List<int[]>> g, int n) {
        boolean[] visited = new boolean[n];
        for (int i = 0; i < n; i++) {
            if (!visited[i] && cycleHelper(g, i, -1, visited)) return true;
        }
        return false;
    }

    /*
     * DFS-based cycle helper.
     * `parent` is the node we came from; we skip it when checking
     * for back-edges so that the undirected edge (u,v) doesn't
     * falsely appear as a cycle (v -> u back to v).
     */
    static boolean cycleHelper(List<List<int[]>> g, int node, int parent, boolean[] visited) {
        visited[node] = true;
        for (int[] edge : g.get(node)) {
            int neighbor = edge[0];
            if (!visited[neighbor]) {
                if (cycleHelper(g, neighbor, node, visited)) return true;
            } else if (neighbor != parent) {
                return true;
            }
        }
        return false;
    }

    /** Returns an array where deg[u] = number of edges incident to u. */
    static int[] degrees(List<List<int[]>> g, int n) {
        int[] deg = new int[n];
        for (int u = 0; u < n; u++) deg[u] = g.get(u).size();
        return deg;
    }

    /**
     * Checks connectivity by running BFS from vertex 0 and
     * verifying that all n vertices were reached.
     */
    static boolean isConnected(List<List<int[]>> g, int n) {
        return bfs(g, 0, n).size() == n;
    }

    public static void main(String[] args) {
        /*
         * Build a small 7-node test graph:
         *
         *   0 --4-- 1 --1-- 3 --2-- 5
         *   |       |       |       |
         *   1       2       3       6
         *   |               |       |
         *   2 --5-- 4 ------+   1---+
         */
        int n = 7;
        List<List<int[]>> g = buildGraph(n);
        addEdge(g, 0, 1, 4);
        addEdge(g, 0, 2, 1);
        addEdge(g, 2, 1, 2);
        addEdge(g, 1, 3, 1);
        addEdge(g, 2, 4, 5);
        addEdge(g, 3, 4, 3);
        addEdge(g, 3, 5, 2);
        addEdge(g, 4, 6, 1);
        addEdge(g, 5, 6, 6);

        System.out.println("BFS from 0: " + bfs(g, 0, n));
        System.out.println("DFS from 0: " + dfs(g, 0, n));

        int[] dist = dijkstra(g, 0, n);
        System.out.println("Dijkstra from 0: " + Arrays.toString(dist));

        System.out.println("Has cycle: " + hasCycle(g, n));
        System.out.println("Is connected: " + isConnected(g, n));
        System.out.println("Degrees: " + Arrays.toString(degrees(g, n)));

        /* Test on a forest (two disconnected trees, no cycles) */
        List<List<int[]>> forest = buildGraph(5);
        addEdge(forest, 0, 1, 1);
        addEdge(forest, 1, 2, 1);
        addEdge(forest, 3, 4, 1);
        System.out.println("Forest connected: " + isConnected(forest, 5));
        System.out.println("Forest has cycle: " + hasCycle(forest, 5));
    }
}
