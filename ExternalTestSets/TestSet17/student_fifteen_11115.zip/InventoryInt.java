/**
 * Warehouse inventory manager — Version A
 * Uses: int quantities/prices, for loops, if-else for category dispatch
 *
 * Pair: P15 and P16 implement the same inventory logic.
 * P15 uses int, for loops, if-else chains.
 * P16 uses double, while/do-while loops, switch statements.
 */
public class InventoryInt {

    static final int NUM_ITEMS = 10;

    static final String[] names = {
        "Widget",  "Gadget",  "Doohickey", "Thingamajig", "Gizmo",
        "Knob",    "Bracket", "Fastener",  "Sprocket",     "Valve"
    };

    // categories: 0=Electronics, 1=Hardware, 2=Mechanical
    static final int[] category   = {0, 0, 1, 1, 0, 1, 1, 1, 2, 2};
    static final int[] quantity   = {120, 45, 200, 88, 30, 500, 310, 750, 60, 95};
    static final int[] unitPrice  = {15,  80,  3,  12, 200, 1,   4,   2,  25, 18};
    static final int   REORDER_PT = 50;

    static String categoryName(int cat) {
        if      (cat == 0) return "Electronics";
        else if (cat == 1) return "Hardware";
        else               return "Mechanical";
    }

    static int totalValue(int[] qty, int[] price) {
        int total = 0;
        for (int i = 0; i < qty.length; i++)
            total += qty[i] * price[i];
        return total;
    }

    static int totalValueByCategory(int[] qty, int[] price, int[] cat, int targetCat) {
        int total = 0;
        for (int i = 0; i < qty.length; i++)
            if (cat[i] == targetCat) total += qty[i] * price[i];
        return total;
    }

    static int countBelowReorder(int[] qty, int threshold) {
        int count = 0;
        for (int i = 0; i < qty.length; i++)
            if (qty[i] < threshold) count++;
        return count;
    }

    static int mostValuableIndex(int[] qty, int[] price) {
        int maxVal = -1, idx = 0;
        for (int i = 0; i < qty.length; i++) {
            int val = qty[i] * price[i];
            if (val > maxVal) { maxVal = val; idx = i; }
        }
        return idx;
    }

    static int leastStockIndex(int[] qty) {
        int minQty = Integer.MAX_VALUE, idx = 0;
        for (int i = 0; i < qty.length; i++) {
            if (qty[i] < minQty) { minQty = qty[i]; idx = i; }
        }
        return idx;
    }

    static double averageUnitPrice(int[] price) {
        int sum = 0;
        for (int i = 0; i < price.length; i++) sum += price[i];
        return (double) sum / price.length;
    }

    static void restock(int[] qty, int[] price, int threshold) {
        System.out.println("Items requiring restock (qty < " + threshold + "):");
        for (int i = 0; i < qty.length; i++) {
            if (qty[i] < threshold) {
                int reorderQty = threshold * 2 - qty[i];
                int cost = reorderQty * price[i];
                System.out.printf("  %-14s qty=%d  reorder=%d  cost=$%d%n",
                    names[i], qty[i], reorderQty, cost);
            }
        }
    }

    static void applyDiscount(int[] price, int[] cat, int targetCat, int pct) {
        System.out.println("Applying " + pct + "% discount to " + categoryName(targetCat) + ":");
        for (int i = 0; i < price.length; i++) {
            if (cat[i] == targetCat) {
                int discounted = price[i] - (price[i] * pct / 100);
                System.out.printf("  %-14s $%d -> $%d%n", names[i], price[i], discounted);
            }
        }
    }

    static void printReport(int[] qty, int[] price, int[] cat) {
        System.out.println("=== Inventory Report ===");
        System.out.printf("%-14s %-12s %-8s %-8s %-10s %-6s%n",
            "Name","Category","Qty","Price","Value","Reorder");
        System.out.println("-".repeat(62));
        for (int i = 0; i < NUM_ITEMS; i++) {
            System.out.printf("%-14s %-12s %-8d $%-7d $%-9d %-6s%n",
                names[i], categoryName(cat[i]), qty[i], price[i],
                qty[i] * price[i],
                qty[i] < REORDER_PT ? "YES" : "no");
        }
    }

    public static void main(String[] args) {
        printReport(quantity, unitPrice, category);

        System.out.println();
        System.out.printf("Total inventory value: $%d%n", totalValue(quantity, unitPrice));

        for (int c = 0; c <= 2; c++)
            System.out.printf("  %s value: $%d%n",
                categoryName(c), totalValueByCategory(quantity, unitPrice, category, c));

        System.out.printf("Items below reorder point: %d%n", countBelowReorder(quantity, REORDER_PT));
        System.out.printf("Average unit price: $%.2f%n", averageUnitPrice(unitPrice));

        int mvi = mostValuableIndex(quantity, unitPrice);
        System.out.printf("Most valuable item: %s ($%d)%n",
            names[mvi], quantity[mvi] * unitPrice[mvi]);

        int lsi = leastStockIndex(quantity);
        System.out.printf("Least stocked item: %s (%d units)%n", names[lsi], quantity[lsi]);

        System.out.println();
        restock(quantity, unitPrice, REORDER_PT);

        System.out.println();
        applyDiscount(unitPrice, category, 0, 10);
    }
}
