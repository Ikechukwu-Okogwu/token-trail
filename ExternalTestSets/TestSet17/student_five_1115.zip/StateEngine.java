import java.util.ArrayList;
import java.util.List;

/**
 * Financial state machine.
 * Pair group: P03, P04, P05 are the SAME with different variable names.
 * P05 is the OBFUSCATED version — designed to be difficult to detect as similar.
 *
 * Detection challenge: variable names are single letters or misleading nouns,
 * method names are unrelated to banking, and comments are stripped.
 * A token-based detector will struggle; an AST/CFG-based one should catch it.
 */
public class StateEngine {

    static double v = 0.0;
    static List<String> q = new ArrayList<>();

    static void push(double x) {
        if (x <= 0) {
            q.add("REJECTED deposit: " + x);
            return;
        }
        v += x;
        q.add("DEPOSIT: +" + x + " | balance=" + v);
    }

    static void pop(double x) {
        if (x <= 0 || x > v) {
            q.add("REJECTED withdrawal: " + x);
            return;
        }
        v -= x;
        q.add("WITHDRAW: -" + x + " | balance=" + v);
    }

    static void scale(double f) {
        double delta = v * f;
        v += delta;
        q.add("INTEREST: +" + delta + " | balance=" + v);
    }

    static double ratio(double f) {
        return v * f;
    }

    static int depth() {
        return q.size();
    }

    static double mean(List<Double> data) {
        double acc = 0;
        for (double d : data) acc += d;
        return acc / data.size();
    }

    static boolean ge(double threshold) {
        return v >= threshold;
    }

    static void route(double x, String tag) {
        if (x <= 0 || x > v) {
            q.add("TRANSFER FAILED to " + tag + ": " + x);
            return;
        }
        v -= x;
        q.add("TRANSFER: -" + x + " to " + tag + " | balance=" + v);
    }

    static void emit() {
        System.out.println("=== Transaction Log ===");
        for (String e : q) {
            System.out.println("  " + e);
        }
    }

    static void proc() {
        List<Double> data = new ArrayList<>();

        push(1000.0);
        data.add(v);
        push(500.0);
        data.add(v);
        pop(200.0);
        data.add(v);
        scale(0.02);
        data.add(v);
        push(750.0);
        data.add(v);
        pop(100.0);
        data.add(v);
        route(300.0, "ACC-9982");
        data.add(v);
        pop(99999.0);
        data.add(v);
        scale(0.015);
        data.add(v);
        push(-50.0);
        data.add(v);

        emit();

        System.out.println("\nFinal balance: " + v);
        System.out.println("Transactions processed: " + depth());
        System.out.println("Average balance across snapshots: " + mean(data));
        System.out.println("Tax at 15%: " + ratio(0.15));
        System.out.println("Can afford $1000 purchase? " + ge(1000.0));
        System.out.println("Can afford $5000 purchase? " + ge(5000.0));
    }

    public static void main(String[] args) {
        System.out.println("Starting bank simulation...");
        proc();
        System.out.println("Simulation complete.");
    }
}
