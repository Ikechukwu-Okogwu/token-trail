import java.util.ArrayList;
import java.util.List;

/**
 * Ledger account simulation.
 * Pair group: P03, P04, P05 are the SAME with different variable names.
 */
public class LedgerSimulation {

    static double funds = 0.0;
    static List<String> history = new ArrayList<>();

    static void addFunds(double qty) {
        if (qty <= 0) {
            history.add("REJECTED deposit: " + qty);
            return;
        }
        funds += qty;
        history.add("DEPOSIT: +" + qty + " | balance=" + funds);
    }

    static void removeFunds(double qty) {
        if (qty <= 0 || qty > funds) {
            history.add("REJECTED withdrawal: " + qty);
            return;
        }
        funds -= qty;
        history.add("WITHDRAW: -" + qty + " | balance=" + funds);
    }

    static void addInterest(double pct) {
        double earned = funds * pct;
        funds += earned;
        history.add("INTEREST: +" + earned + " | balance=" + funds);
    }

    static double getTax(double pct) {
        return funds * pct;
    }

    static int txCount() {
        return history.size();
    }

    static double meanBalance(List<Double> readings) {
        double total = 0;
        for (double r : readings) total += r;
        return total / readings.size();
    }

    static boolean hasSufficientFunds(double price) {
        return funds >= price;
    }

    static void sendFunds(double qty, String recipient) {
        if (qty <= 0 || qty > funds) {
            history.add("TRANSFER FAILED to " + recipient + ": " + qty);
            return;
        }
        funds -= qty;
        history.add("TRANSFER: -" + qty + " to " + recipient + " | balance=" + funds);
    }

    static void showHistory() {
        System.out.println("=== Transaction Log ===");
        for (String entry : history) {
            System.out.println("  " + entry);
        }
    }

    static void execute() {
        List<Double> readings = new ArrayList<>();

        addFunds(1000.0);
        readings.add(funds);
        addFunds(500.0);
        readings.add(funds);
        removeFunds(200.0);
        readings.add(funds);
        addInterest(0.02);
        readings.add(funds);
        addFunds(750.0);
        readings.add(funds);
        removeFunds(100.0);
        readings.add(funds);
        sendFunds(300.0, "ACC-9982");
        readings.add(funds);
        removeFunds(99999.0); // should be rejected
        readings.add(funds);
        addInterest(0.015);
        readings.add(funds);
        addFunds(-50.0); // should be rejected
        readings.add(funds);

        showHistory();

        System.out.println("\nFinal balance: " + funds);
        System.out.println("Transactions processed: " + txCount());
        System.out.println("Average balance across snapshots: " + meanBalance(readings));
        System.out.println("Tax at 15%: " + getTax(0.15));
        System.out.println("Can afford $1000 purchase? " + hasSufficientFunds(1000.0));
        System.out.println("Can afford $5000 purchase? " + hasSufficientFunds(5000.0));
    }

    public static void main(String[] args) {
        System.out.println("Starting bank simulation...");
        execute();
        System.out.println("Simulation complete.");
    }
}
