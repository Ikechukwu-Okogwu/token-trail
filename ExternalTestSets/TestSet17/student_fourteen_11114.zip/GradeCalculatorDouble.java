/**
 * Student grade calculator — Version B
 * Uses: double arithmetic, while loops, switch statements
 *
 * Pair: P13 and P14 implement identical grade-calculation logic.
 * P13 uses int scores, for loops, and if-else.
 * P14 uses double scores, while loops, and switch.
 *
 * Detection challenge:
 *  - All score fields are double instead of int (type change)
 *  - Every for loop is rewritten as a while loop (loop-type change)
 *  - Letter-to-GPA mapping uses switch instead of if-else (control-flow change)
 *  - The weighted average, grade boundaries, histogram bands, and
 *    statistical computations are otherwise identical.
 */
public class GradeCalculatorDouble {

    static final int NUM_STUDENTS = 8;

    // Weights: assignments 40%, midterm 25%, final 35%
    static final double WEIGHT_ASSIGN  = 0.40;
    static final double WEIGHT_MIDTERM = 0.25;
    static final double WEIGHT_FINAL   = 0.35;

    static double weightedScore(double assignments, double midterm, double finalExam) {
        return assignments * WEIGHT_ASSIGN
             + midterm     * WEIGHT_MIDTERM
             + finalExam   * WEIGHT_FINAL;
    }

    static String letterGrade(double score) {
        if      (score >= 90) return "A+";
        else if (score >= 85) return "A";
        else if (score >= 80) return "A-";
        else if (score >= 77) return "B+";
        else if (score >= 73) return "B";
        else if (score >= 70) return "B-";
        else if (score >= 67) return "C+";
        else if (score >= 63) return "C";
        else if (score >= 60) return "C-";
        else if (score >= 57) return "D+";
        else if (score >= 53) return "D";
        else if (score >= 50) return "D-";
        else                   return "F";
    }

    // switch replaces the if-else chain used in P13
    static double gradePoints(String letter) {
        switch (letter) {
            case "A+": return 4.0;
            case "A":  return 4.0;
            case "A-": return 3.7;
            case "B+": return 3.3;
            case "B":  return 3.0;
            case "B-": return 2.7;
            case "C+": return 2.3;
            case "C":  return 2.0;
            case "C-": return 1.7;
            case "D+": return 1.3;
            case "D":  return 1.0;
            case "D-": return 0.7;
            default:   return 0.0;
        }
    }

    static boolean isPassing(double score) {
        return score >= 50.0;
    }

    // while loop replaces for loop used in P13
    static double highest(double[] scores) {
        double max = scores[0];
        int i = 1;
        while (i < scores.length) {
            if (scores[i] > max) max = scores[i];
            i++;
        }
        return max;
    }

    static double lowest(double[] scores) {
        double min = scores[0];
        int i = 1;
        while (i < scores.length) {
            if (scores[i] < min) min = scores[i];
            i++;
        }
        return min;
    }

    static double average(double[] scores) {
        double sum = 0;
        int i = 0;
        while (i < scores.length) {
            sum += scores[i];
            i++;
        }
        return sum / scores.length;
    }

    static int countPassing(double[] scores) {
        int count = 0;
        int i = 0;
        while (i < scores.length) {
            if (isPassing(scores[i])) count++;
            i++;
        }
        return count;
    }

    static double standardDeviation(double[] scores, double avg) {
        double sumSq = 0;
        int i = 0;
        while (i < scores.length) {
            double diff = scores[i] - avg;
            sumSq += diff * diff;
            i++;
        }
        return Math.sqrt(sumSq / scores.length);
    }

    static void printHistogram(double[] scores) {
        System.out.println("Grade distribution:");
        String[] bands = {"90-100","80-89","70-79","60-69","50-59","0-49"};
        int[] counts   = new int[6];
        int i = 0;
        while (i < scores.length) {
            double s = scores[i];
            if      (s >= 90) counts[0]++;
            else if (s >= 80) counts[1]++;
            else if (s >= 70) counts[2]++;
            else if (s >= 60) counts[3]++;
            else if (s >= 50) counts[4]++;
            else              counts[5]++;
            i++;
        }
        int b = 0;
        while (b < bands.length) {
            System.out.print("  " + bands[b] + ": ");
            int stars = 0;
            while (stars < counts[b]) { System.out.print("*"); stars++; }
            System.out.println(" (" + counts[b] + ")");
            b++;
        }
    }

    public static void main(String[] args) {
        // [assignments, midterm, finalExam] per student — same values as P13
        double[][] raw = {
            {88, 76, 82},
            {95, 91, 93},
            {60, 55, 58},
            {72, 68, 71},
            {45, 50, 47},
            {83, 79, 85},
            {91, 88, 90},
            {63, 70, 66}
        };

        double[] finals = new double[NUM_STUDENTS];
        double totalGPA = 0;

        System.out.println("=== Student Grade Report ===");
        System.out.printf("%-6s %-8s %-8s %-8s %-8s %-6s %-5s%n",
            "ID", "Assign", "Midterm", "Final", "Weighted", "Grade", "GPA");
        System.out.println("-".repeat(53));

        int i = 0;
        while (i < NUM_STUDENTS) {
            double ws = weightedScore(raw[i][0], raw[i][1], raw[i][2]);
            String lg = letterGrade(ws);
            double gp = gradePoints(lg);
            finals[i] = ws;
            totalGPA += gp;
            System.out.printf("S%-5d %-8.0f %-8.0f %-8.0f %-8.1f %-6s %.1f%n",
                i + 1, raw[i][0], raw[i][1], raw[i][2], ws, lg, gp);
            i++;
        }

        System.out.println("-".repeat(53));
        double avg = average(finals);
        System.out.printf("Class average:     %.2f%n", avg);
        System.out.printf("Highest score:     %.1f%n", highest(finals));
        System.out.printf("Lowest score:      %.1f%n", lowest(finals));
        System.out.printf("Std deviation:     %.2f%n", standardDeviation(finals, avg));
        System.out.printf("Class GPA:         %.2f%n", totalGPA / NUM_STUDENTS);
        System.out.printf("Pass rate:         %d/%d%n", countPassing(finals), NUM_STUDENTS);
        System.out.println();
        printHistogram(finals);
    }
}
