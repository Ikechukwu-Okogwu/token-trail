import java.util.ArrayList;
import java.util.List;

/**
 * Comprehensive number theory toolkit.
 * P08 (PrimeChecker) is a STRICT SUBSET of this program —
 * sieve(), isPrime(), countPrimes(), nthPrime() are identical.
 * This file adds: GCD, LCM, Goldbach, totient, factorization,
 * perfect numbers, abundant/deficient, amicable pairs, and more.
 */
public class NumberTheory {

    // ═══════════════════════════════════════════════════════════
    // SUBSET: these four methods appear verbatim in P08
    // ═══════════════════════════════════════════════════════════

    static boolean[] sieve(int limit) {
        boolean[] composite = new boolean[limit + 1];
        composite[0] = composite[1] = true;
        for (int i = 2; i * i <= limit; i++) {
            if (!composite[i]) {
                for (int j = i * i; j <= limit; j += i) {
                    composite[j] = true;
                }
            }
        }
        return composite;
    }

    static boolean isPrime(int n) {
        if (n < 2) return false;
        if (n == 2) return true;
        if (n % 2 == 0) return false;
        for (int i = 3; i * i <= n; i += 2)
            if (n % i == 0) return false;
        return true;
    }

    static int countPrimes(int limit) {
        boolean[] composite = sieve(limit);
        int count = 0;
        for (int i = 2; i <= limit; i++)
            if (!composite[i]) count++;
        return count;
    }

    static int nthPrime(int n) {
        int count = 0, candidate = 1;
        while (count < n) {
            candidate++;
            if (isPrime(candidate)) count++;
        }
        return candidate;
    }

    // ═══════════════════════════════════════════════════════════
    // EXTENDED: methods only in P09
    // ═══════════════════════════════════════════════════════════

    static int gcd(int a, int b) {
        while (b != 0) { int t = b; b = a % b; a = t; }
        return a;
    }

    static int lcm(int a, int b) {
        return a / gcd(a, b) * b;
    }

    static List<Integer> primeFactors(int n) {
        List<Integer> factors = new ArrayList<>();
        for (int d = 2; d * d <= n; d++) {
            while (n % d == 0) { factors.add(d); n /= d; }
        }
        if (n > 1) factors.add(n);
        return factors;
    }

    static int eulerTotient(int n) {
        int result = n;
        for (int p = 2; p * p <= n; p++) {
            if (n % p == 0) {
                while (n % p == 0) n /= p;
                result -= result / p;
            }
        }
        if (n > 1) result -= result / n;
        return result;
    }

    static int sumOfDivisors(int n) {
        int sum = 1;
        for (int i = 2; i * i <= n; i++) {
            if (n % i == 0) {
                sum += i;
                if (i != n / i) sum += n / i;
            }
        }
        return n > 1 ? sum : 1;
    }

    static boolean isPerfect(int n) {
        return n > 1 && sumOfDivisors(n) == n;
    }

    static boolean isAbundant(int n) {
        return sumOfDivisors(n) > n;
    }

    static boolean isAmicable(int a) {
        int b = sumOfDivisors(a);
        return b != a && sumOfDivisors(b) == a;
    }

    static String goldbachConjecture(int n) {
        if (n <= 2 || n % 2 != 0) return "N/A";
        for (int p = 2; p <= n / 2; p++) {
            if (isPrime(p) && isPrime(n - p))
                return p + " + " + (n - p);
        }
        return "No pair found";
    }

    static boolean isKaprekar(int n) {
        long sq = (long) n * n;
        String s = Long.toString(sq);
        int len = s.length();
        for (int split = 1; split < len; split++) {
            long left  = Long.parseLong(s.substring(0, split));
            long right = Long.parseLong(s.substring(split));
            if (left + right == n && right > 0) return true;
        }
        return false;
    }

    static int digitalRoot(int n) {
        while (n >= 10) {
            int sum = 0;
            while (n > 0) { sum += n % 10; n /= 10; }
            n = sum;
        }
        return n;
    }

    static boolean isArmstrong(int n) {
        String s = Integer.toString(n);
        int len = s.length(), sum = 0;
        for (char c : s.toCharArray()) {
            int d = c - '0';
            int pow = 1;
            for (int i = 0; i < len; i++) pow *= d;
            sum += pow;
        }
        return sum == n;
    }

    static long collatzLength(int n) {
        long steps = 0;
        long x = n;
        while (x != 1) {
            x = (x % 2 == 0) ? x / 2 : 3 * x + 1;
            steps++;
        }
        return steps;
    }

    public static void main(String[] args) {
        // Subset section (identical to P08 main)
        System.out.println("Primes up to 50:");
        boolean[] comp = sieve(50);
        for (int i = 2; i <= 50; i++)
            if (!comp[i]) System.out.print(i + " ");
        System.out.println();

        System.out.println("isPrime(97): "  + isPrime(97));
        System.out.println("isPrime(100): " + isPrime(100));
        System.out.println("Prime count up to 100: " + countPrimes(100));
        System.out.println("10th prime: " + nthPrime(10));
        System.out.println("20th prime: " + nthPrime(20));

        // Extended section
        System.out.println("\n--- Extended Number Theory ---");
        System.out.println("GCD(48,18): " + gcd(48, 18));
        System.out.println("LCM(12,18): " + lcm(12, 18));
        System.out.println("Factors of 360: " + primeFactors(360));
        System.out.println("φ(36): " + eulerTotient(36));

        System.out.println("\nPerfect numbers up to 10000:");
        for (int i = 2; i <= 10000; i++)
            if (isPerfect(i)) System.out.print(i + " ");
        System.out.println();

        System.out.println("\nAbundant numbers up to 30:");
        for (int i = 2; i <= 30; i++)
            if (isAbundant(i)) System.out.print(i + " ");
        System.out.println();

        System.out.println("\nAmicable numbers up to 1500:");
        for (int i = 2; i <= 1500; i++)
            if (isAmicable(i)) System.out.print(i + " ");
        System.out.println();

        System.out.println("\nGoldbach for even numbers 4-20:");
        for (int i = 4; i <= 20; i += 2)
            System.out.println("  " + i + " = " + goldbachConjecture(i));

        System.out.println("\nArmstrong numbers up to 1000:");
        for (int i = 1; i <= 1000; i++)
            if (isArmstrong(i)) System.out.print(i + " ");
        System.out.println();

        System.out.println("\nCollatz length for n=27: " + collatzLength(27));
        System.out.println("Digital root of 9875: " + digitalRoot(9875));
        System.out.println("Is 9 a Kaprekar number? " + isKaprekar(9));
        System.out.println("Is 45 a Kaprekar number? " + isKaprekar(45));
    }
}
