/**
 * Driver for CipherUtils — Version A
 * Part of P17 multi-file submission.
 */
public class CipherMain {

    static void printFrequency(int[] freq) {
        System.out.println("Letter frequencies:");
        for (int i = 0; i < 26; i++) {
            if (freq[i] > 0) {
                char letter = (char) ('a' + i);
                System.out.printf("  %c: %d%n", letter, freq[i]);
            }
        }
    }

    public static void main(String[] args) {
        String message = "The quick brown fox jumps over the lazy dog";
        int shift = 7;

        System.out.println("Original:  " + message);

        String encrypted = CipherUtils.encrypt(message, shift);
        System.out.println("Encrypted (shift=" + shift + "): " + encrypted);

        String decrypted = CipherUtils.decrypt(encrypted, shift);
        System.out.println("Decrypted: " + decrypted);

        String rot13ed = CipherUtils.rot13(message);
        System.out.println("ROT13:     " + rot13ed);
        System.out.println("ROT13 x2:  " + CipherUtils.rot13(rot13ed));

        System.out.println("Is pangram: " + CipherUtils.isPangram(message));
        System.out.println("Alpha count: " + CipherUtils.countAlpha(message));
        System.out.println("Reversed: " + CipherUtils.reverse(message));

        System.out.println();
        int cracked = CipherUtils.crackShift(encrypted);
        System.out.println("Cracked shift: " + cracked);
        System.out.println("Cracked text:  " + CipherUtils.decrypt(encrypted, cracked));

        System.out.println();
        printFrequency(CipherUtils.letterFrequency(message));

        System.out.println();
        String keyword = "secret";
        String vigEncrypted = CipherUtils.vigenereEncrypt(message, keyword);
        String vigDecrypted = CipherUtils.vigenereDecrypt(vigEncrypted, keyword);
        System.out.println("Vigenere key:       " + keyword);
        System.out.println("Vigenere encrypted: " + vigEncrypted);
        System.out.println("Vigenere decrypted: " + vigDecrypted);
    }
}
