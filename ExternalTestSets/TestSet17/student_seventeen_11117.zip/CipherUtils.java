/**
 * Caesar cipher and ROT13 utilities — Version A
 * Uses: int offsets, for loops, if-else
 *
 * Multi-file program: CipherUtils.java + CipherMain.java
 * Pair: P17 (int + for + if-else) and P18 (char arithmetic + while + switch)
 * implement the same cipher logic across the same two-file structure.
 */
public class CipherUtils {

    /** Shifts a single character by `shift` positions within its case band. */
    static char shiftChar(char c, int shift) {
        if (c >= 'A' && c <= 'Z') {
            return (char) ('A' + (c - 'A' + shift + 26) % 26);
        } else if (c >= 'a' && c <= 'z') {
            return (char) ('a' + (c - 'a' + shift + 26) % 26);
        } else {
            return c;
        }
    }

    /** Encrypts plaintext with a Caesar cipher of the given shift. */
    static String encrypt(String plaintext, int shift) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < plaintext.length(); i++) {
            sb.append(shiftChar(plaintext.charAt(i), shift));
        }
        return sb.toString();
    }

    /** Decrypts ciphertext by applying the inverse shift. */
    static String decrypt(String ciphertext, int shift) {
        return encrypt(ciphertext, -shift);
    }

    /** ROT13: a self-inverse Caesar cipher with shift 13. */
    static String rot13(String text) {
        return encrypt(text, 13);
    }

    /** Returns the frequency count of each letter (case-insensitive, a=0..z=25). */
    static int[] letterFrequency(String text) {
        int[] freq = new int[26];
        for (int i = 0; i < text.length(); i++) {
            char c = Character.toLowerCase(text.charAt(i));
            if (c >= 'a' && c <= 'z') {
                freq[c - 'a']++;
            }
        }
        return freq;
    }

    /**
     * Brute-force crack: tries all 25 shifts, returns the one whose
     * letter frequencies best match English (uses 'e' as anchor — most common).
     */
    static int crackShift(String ciphertext) {
        int bestShift = 0;
        int maxE = -1;
        for (int shift = 0; shift < 26; shift++) {
            String candidate = decrypt(ciphertext, shift);
            int[] freq = letterFrequency(candidate);
            if (freq['e' - 'a'] > maxE) {
                maxE = freq['e' - 'a'];
                bestShift = shift;
            }
        }
        return bestShift;
    }

    /** Counts alphabetic characters in the text. */
    static int countAlpha(String text) {
        int count = 0;
        for (int i = 0; i < text.length(); i++) {
            if (Character.isLetter(text.charAt(i))) count++;
        }
        return count;
    }

    /** Returns true if the text is a pangram (contains every letter). */
    static boolean isPangram(String text) {
        boolean[] seen = new boolean[26];
        for (int i = 0; i < text.length(); i++) {
            char c = Character.toLowerCase(text.charAt(i));
            if (c >= 'a' && c <= 'z') seen[c - 'a'] = true;
        }
        for (int i = 0; i < 26; i++) {
            if (!seen[i]) return false;
        }
        return true;
    }

    /** Reverses the string. */
    static String reverse(String text) {
        StringBuilder sb = new StringBuilder();
        for (int i = text.length() - 1; i >= 0; i--) {
            sb.append(text.charAt(i));
        }
        return sb.toString();
    }

    /** Returns the Vigenere encryption of plaintext with the given keyword. */
    static String vigenereEncrypt(String plaintext, String keyword) {
        StringBuilder sb = new StringBuilder();
        int keyLen = keyword.length();
        int ki = 0;
        for (int i = 0; i < plaintext.length(); i++) {
            char p = plaintext.charAt(i);
            if (Character.isLetter(p)) {
                int shift = Character.toLowerCase(keyword.charAt(ki % keyLen)) - 'a';
                sb.append(shiftChar(p, shift));
                ki++;
            } else {
                sb.append(p);
            }
        }
        return sb.toString();
    }

    static String vigenereDecrypt(String ciphertext, String keyword) {
        StringBuilder sb = new StringBuilder();
        int keyLen = keyword.length();
        int ki = 0;
        for (int i = 0; i < ciphertext.length(); i++) {
            char c = ciphertext.charAt(i);
            if (Character.isLetter(c)) {
                int shift = Character.toLowerCase(keyword.charAt(ki % keyLen)) - 'a';
                sb.append(shiftChar(c, -shift));
                ki++;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
