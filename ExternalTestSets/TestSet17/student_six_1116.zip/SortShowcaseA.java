import java.util.Arrays;
import java.util.Random;

/**
 * Sorting algorithm showcase — version A.
 * Pair: P06 and P07 are SAME logic, different method ordering.
 */
public class SortShowcaseA {

    // ── Bubble sort ──────────────────────────────────────────────
    static int[] bubbleSort(int[] arr) {
        int[] a = arr.clone();
        int n = a.length;
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (a[j] > a[j + 1]) {
                    int tmp = a[j]; a[j] = a[j + 1]; a[j + 1] = tmp;
                }
            }
        }
        return a;
    }

    // ── Selection sort ───────────────────────────────────────────
    static int[] selectionSort(int[] arr) {
        int[] a = arr.clone();
        int n = a.length;
        for (int i = 0; i < n - 1; i++) {
            int minIdx = i;
            for (int j = i + 1; j < n; j++)
                if (a[j] < a[minIdx]) minIdx = j;
            int tmp = a[minIdx]; a[minIdx] = a[i]; a[i] = tmp;
        }
        return a;
    }

    // ── Insertion sort ───────────────────────────────────────────
    static int[] insertionSort(int[] arr) {
        int[] a = arr.clone();
        int n = a.length;
        for (int i = 1; i < n; i++) {
            int key = a[i];
            int j = i - 1;
            while (j >= 0 && a[j] > key) {
                a[j + 1] = a[j];
                j--;
            }
            a[j + 1] = key;
        }
        return a;
    }

    // ── Merge sort helpers ───────────────────────────────────────
    static void merge(int[] a, int l, int m, int r) {
        int n1 = m - l + 1, n2 = r - m;
        int[] L = new int[n1], R = new int[n2];
        System.arraycopy(a, l, L, 0, n1);
        System.arraycopy(a, m + 1, R, 0, n2);
        int i = 0, j = 0, k = l;
        while (i < n1 && j < n2) a[k++] = L[i] <= R[j] ? L[i++] : R[j++];
        while (i < n1) a[k++] = L[i++];
        while (j < n2) a[k++] = R[j++];
    }

    static void mergeSortHelper(int[] a, int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSortHelper(a, l, m);
            mergeSortHelper(a, m + 1, r);
            merge(a, l, m, r);
        }
    }

    static int[] mergeSort(int[] arr) {
        int[] a = arr.clone();
        mergeSortHelper(a, 0, a.length - 1);
        return a;
    }

    // ── Utility ──────────────────────────────────────────────────
    static int[] randomArray(int size, int bound, Random rng) {
        int[] a = new int[size];
        for (int i = 0; i < size; i++) a[i] = rng.nextInt(bound);
        return a;
    }

    static boolean isSorted(int[] a) {
        for (int i = 0; i < a.length - 1; i++)
            if (a[i] > a[i + 1]) return false;
        return true;
    }

    static void benchmark(String name, int[] arr) {
        long start = System.nanoTime();
        int[] sorted;
        switch (name) {
            case "Bubble":    sorted = bubbleSort(arr);    break;
            case "Selection": sorted = selectionSort(arr); break;
            case "Insertion": sorted = insertionSort(arr); break;
            default:          sorted = mergeSort(arr);     break;
        }
        long elapsed = System.nanoTime() - start;
        System.out.printf("%-12s sorted=%s  time=%dns%n",
            name, isSorted(sorted), elapsed);
    }

    public static void main(String[] args) {
        Random rng = new Random(7);
        int[] data = randomArray(500, 1000, rng);

        System.out.println("Input (first 10): " + Arrays.toString(Arrays.copyOf(data, 10)));
        System.out.println();

        benchmark("Bubble",    data);
        benchmark("Selection", data);
        benchmark("Insertion", data);
        benchmark("Merge",     data);

        int[] small = {9, 3, 7, 1, 5, 8, 2, 4, 6};
        System.out.println("\nSmall example: " + Arrays.toString(small));
        System.out.println("After bubble:  " + Arrays.toString(bubbleSort(small)));
        System.out.println("After merge:   " + Arrays.toString(mergeSort(small)));
    }
}
