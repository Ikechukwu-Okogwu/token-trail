/**
 * Warehouse inventory manager — Version B
 * Uses: double quantities/prices, while + do-while loops, switch for category dispatch
 *
 * Pair: P15 and P16 implement the same inventory logic.
 * P15 uses int, for loops, if-else chains.
 * P16 uses double, while/do-while loops, switch statements.
 *
 * Detection challenges:
 *  - int qty/price → double (type change throughout)
 *  - every for loop → while or do-while (loop-type change)
 *  - categoryName() uses switch instead of if-else
 *  - restock(), applyDiscount() restructured using do-while
 *  - All numeric logic, thresholds, and data are identical to P15.
 */
public class InventoryDouble {

    static final int NUM_ITEMS = 10;

    static final String[] names = {
        "Widget",  "Gadget",  "Doohickey", "Thingamajig", "Gizmo",
        "Knob",    "Bracket", "Fastener",  "Sprocket",     "Valve"
    };

    static final int[]    category  = {0, 0, 1, 1, 0, 1, 1, 1, 2, 2};
    static final double[] quantity  = {120, 45, 200, 88, 30, 500, 310, 750, 60, 95};
    static final double[] unitPrice = {15,  80,  3,  12, 200, 1,   4,   2,  25, 18};
    static final double   REORDER_PT = 50.0;

    // switch replaces if-else chain in P15
    static String categoryName(int cat) {
        switch (cat) {
            case 0:  return "Electronics";
            case 1:  return "Hardware";
            default: return "Mechanical";
        }
    }

    static double totalValue(double[] qty, double[] price) {
        double total = 0;
        int i = 0;
        while (i < qty.length) {
            total += qty[i] * price[i];
            i++;
        }
        return total;
    }

    static double totalValueByCategory(double[] qty, double[] price, int[] cat, int targetCat) {
        double total = 0;
        int i = 0;
        while (i < qty.length) {
            if (cat[i] == targetCat) total += qty[i] * price[i];
            i++;
        }
        return total;
    }

    static int countBelowReorder(double[] qty, double threshold) {
        int count = 0;
        int i = 0;
        while (i < qty.length) {
            if (qty[i] < threshold) count++;
            i++;
        }
        return count;
    }

    static int mostValuableIndex(double[] qty, double[] price) {
        double maxVal = -1;
        int idx = 0;
        int i = 0;
        while (i < qty.length) {
            double val = qty[i] * price[i];
            if (val > maxVal) { maxVal = val; idx = i; }
            i++;
        }
        return idx;
    }

    static int leastStockIndex(double[] qty) {
        double minQty = Double.MAX_VALUE;
        int idx = 0;
        int i = 0;
        while (i < qty.length) {
            if (qty[i] < minQty) { minQty = qty[i]; idx = i; }
            i++;
        }
        return idx;
    }

    static double averageUnitPrice(double[] price) {
        double sum = 0;
        int i = 0;
        while (i < price.length) { sum += price[i]; i++; }
        return sum / price.length;
    }

    static void restock(double[] qty, double[] price, double threshold) {
        System.out.println("Items requiring restock (qty < " + (int)threshold + "):");
        int i = 0;
        do {
            if (qty[i] < threshold) {
                double reorderQty = threshold * 2 - qty[i];
                double cost = reorderQty * price[i];
                System.out.printf("  %-14s qty=%.0f  reorder=%.0f  cost=$%.0f%n",
                    names[i], qty[i], reorderQty, cost);
            }
            i++;
        } while (i < qty.length);
    }

    static void applyDiscount(double[] price, int[] cat, int targetCat, double pct) {
        System.out.println("Applying " + (int)pct + "% discount to " + categoryName(targetCat) + ":");
        int i = 0;
        do {
            if (cat[i] == targetCat) {
                double discounted = price[i] - (price[i] * pct / 100.0);
                System.out.printf("  %-14s $%.0f -> $%.0f%n", names[i], price[i], discounted);
            }
            i++;
        } while (i < price.length);
    }

    static void printReport(double[] qty, double[] price, int[] cat) {
        System.out.println("=== Inventory Report ===");
        System.out.printf("%-14s %-12s %-8s %-8s %-10s %-6s%n",
            "Name","Category","Qty","Price","Value","Reorder");
        System.out.println("-".repeat(62));
        int i = 0;
        while (i < NUM_ITEMS) {
            System.out.printf("%-14s %-12s %-8.0f $%-7.0f $%-9.0f %-6s%n",
                names[i], categoryName(cat[i]), qty[i], price[i],
                qty[i] * price[i],
                qty[i] < REORDER_PT ? "YES" : "no");
            i++;
        }
    }

    public static void main(String[] args) {
        printReport(quantity, unitPrice, category);

        System.out.println();
        System.out.printf("Total inventory value: $%.0f%n", totalValue(quantity, unitPrice));

        int c = 0;
        while (c <= 2) {
            System.out.printf("  %s value: $%.0f%n",
                categoryName(c), totalValueByCategory(quantity, unitPrice, category, c));
            c++;
        }

        System.out.printf("Items below reorder point: %d%n", countBelowReorder(quantity, REORDER_PT));
        System.out.printf("Average unit price: $%.2f%n", averageUnitPrice(unitPrice));

        int mvi = mostValuableIndex(quantity, unitPrice);
        System.out.printf("Most valuable item: %s ($%.0f)%n",
            names[mvi], quantity[mvi] * unitPrice[mvi]);

        int lsi = leastStockIndex(quantity);
        System.out.printf("Least stocked item: %s (%.0f units)%n", names[lsi], quantity[lsi]);

        System.out.println();
        restock(quantity, unitPrice, REORDER_PT);

        System.out.println();
        applyDiscount(unitPrice, category, 0, 10);
    }
}
