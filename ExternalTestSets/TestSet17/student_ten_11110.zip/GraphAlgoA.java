import java.util.*;

/**
 * Graph algorithms: BFS, DFS, Dijkstra, cycle detection.
 * Pair: P10 (no multi-line comments) and P11 (same code, heavily commented).
 */
public class GraphAlgoA {

    static final int INF = Integer.MAX_VALUE / 2;

    static List<List<int[]>> buildGraph(int n) {
        List<List<int[]>> g = new ArrayList<>();
        for (int i = 0; i < n; i++) g.add(new ArrayList<>());
        return g;
    }

    static void addEdge(List<List<int[]>> g, int u, int v, int w) {
        g.get(u).add(new int[]{v, w});
        g.get(v).add(new int[]{u, w});
    }

    static List<Integer> bfs(List<List<int[]>> g, int start, int n) {
        List<Integer> order = new ArrayList<>();
        boolean[] visited = new boolean[n];
        Queue<Integer> queue = new LinkedList<>();
        visited[start] = true;
        queue.add(start);
        while (!queue.isEmpty()) {
            int node = queue.poll();
            order.add(node);
            for (int[] edge : g.get(node)) {
                if (!visited[edge[0]]) {
                    visited[edge[0]] = true;
                    queue.add(edge[0]);
                }
            }
        }
        return order;
    }

    static List<Integer> dfs(List<List<int[]>> g, int start, int n) {
        List<Integer> order = new ArrayList<>();
        boolean[] visited = new boolean[n];
        dfsHelper(g, start, visited, order);
        return order;
    }

    static void dfsHelper(List<List<int[]>> g, int node, boolean[] visited, List<Integer> order) {
        visited[node] = true;
        order.add(node);
        for (int[] edge : g.get(node)) {
            if (!visited[edge[0]]) {
                dfsHelper(g, edge[0], visited, order);
            }
        }
    }

    static int[] dijkstra(List<List<int[]>> g, int src, int n) {
        int[] dist = new int[n];
        Arrays.fill(dist, INF);
        dist[src] = 0;
        PriorityQueue<int[]> pq = new PriorityQueue<>(Comparator.comparingInt(a -> a[1]));
        pq.add(new int[]{src, 0});
        while (!pq.isEmpty()) {
            int[] curr = pq.poll();
            int u = curr[0], d = curr[1];
            if (d > dist[u]) continue;
            for (int[] edge : g.get(u)) {
                int v = edge[0], w = edge[1];
                if (dist[u] + w < dist[v]) {
                    dist[v] = dist[u] + w;
                    pq.add(new int[]{v, dist[v]});
                }
            }
        }
        return dist;
    }

    static boolean hasCycle(List<List<int[]>> g, int n) {
        boolean[] visited = new boolean[n];
        for (int i = 0; i < n; i++) {
            if (!visited[i] && cycleHelper(g, i, -1, visited)) return true;
        }
        return false;
    }

    static boolean cycleHelper(List<List<int[]>> g, int node, int parent, boolean[] visited) {
        visited[node] = true;
        for (int[] edge : g.get(node)) {
            int neighbor = edge[0];
            if (!visited[neighbor]) {
                if (cycleHelper(g, neighbor, node, visited)) return true;
            } else if (neighbor != parent) {
                return true;
            }
        }
        return false;
    }

    static int[] degrees(List<List<int[]>> g, int n) {
        int[] deg = new int[n];
        for (int u = 0; u < n; u++) deg[u] = g.get(u).size();
        return deg;
    }

    static boolean isConnected(List<List<int[]>> g, int n) {
        return bfs(g, 0, n).size() == n;
    }

    public static void main(String[] args) {
        int n = 7;
        List<List<int[]>> g = buildGraph(n);
        addEdge(g, 0, 1, 4);
        addEdge(g, 0, 2, 1);
        addEdge(g, 2, 1, 2);
        addEdge(g, 1, 3, 1);
        addEdge(g, 2, 4, 5);
        addEdge(g, 3, 4, 3);
        addEdge(g, 3, 5, 2);
        addEdge(g, 4, 6, 1);
        addEdge(g, 5, 6, 6);

        System.out.println("BFS from 0: " + bfs(g, 0, n));
        System.out.println("DFS from 0: " + dfs(g, 0, n));

        int[] dist = dijkstra(g, 0, n);
        System.out.println("Dijkstra from 0: " + Arrays.toString(dist));

        System.out.println("Has cycle: " + hasCycle(g, n));
        System.out.println("Is connected: " + isConnected(g, n));
        System.out.println("Degrees: " + Arrays.toString(degrees(g, n)));

        List<List<int[]>> forest = buildGraph(5);
        addEdge(forest, 0, 1, 1);
        addEdge(forest, 1, 2, 1);
        addEdge(forest, 3, 4, 1);
        System.out.println("Forest connected: " + isConnected(forest, 5));
        System.out.println("Forest has cycle: " + hasCycle(forest, 5));
    }
}
