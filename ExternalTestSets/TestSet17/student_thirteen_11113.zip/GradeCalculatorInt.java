/**
 * Student grade calculator — Version A
 * Uses: int arithmetic, for loops, if-else chains
 *
 * Pair: P13 and P14 implement identical grade-calculation logic.
 * P13 uses int scores, for loops, and if-else.
 * P14 uses double scores, while loops, and switch.
 *
 * Detection challenge: type widening (int → double), loop rewriting,
 * and if→switch substitution are all surface changes; the underlying
 * algorithm (weighted average → letter grade → GPA → stats) is unchanged.
 */
public class GradeCalculatorInt {

    static final int NUM_STUDENTS = 8;

    // Weights: assignments 40%, midterm 25%, final 35%
    static final int WEIGHT_ASSIGN  = 40;
    static final int WEIGHT_MIDTERM = 25;
    static final int WEIGHT_FINAL   = 35;

    static int weightedScore(int assignments, int midterm, int finalExam) {
        return (assignments * WEIGHT_ASSIGN
              + midterm    * WEIGHT_MIDTERM
              + finalExam  * WEIGHT_FINAL) / 100;
    }

    static String letterGrade(int score) {
        if      (score >= 90) return "A+";
        else if (score >= 85) return "A";
        else if (score >= 80) return "A-";
        else if (score >= 77) return "B+";
        else if (score >= 73) return "B";
        else if (score >= 70) return "B-";
        else if (score >= 67) return "C+";
        else if (score >= 63) return "C";
        else if (score >= 60) return "C-";
        else if (score >= 57) return "D+";
        else if (score >= 53) return "D";
        else if (score >= 50) return "D-";
        else                   return "F";
    }

    static double gradePoints(String letter) {
        if      (letter.equals("A+")) return 4.0;
        else if (letter.equals("A"))  return 4.0;
        else if (letter.equals("A-")) return 3.7;
        else if (letter.equals("B+")) return 3.3;
        else if (letter.equals("B"))  return 3.0;
        else if (letter.equals("B-")) return 2.7;
        else if (letter.equals("C+")) return 2.3;
        else if (letter.equals("C"))  return 2.0;
        else if (letter.equals("C-")) return 1.7;
        else if (letter.equals("D+")) return 1.3;
        else if (letter.equals("D"))  return 1.0;
        else if (letter.equals("D-")) return 0.7;
        else                          return 0.0;
    }

    static boolean isPassing(int score) {
        return score >= 50;
    }

    static int highest(int[] scores) {
        int max = scores[0];
        for (int i = 1; i < scores.length; i++)
            if (scores[i] > max) max = scores[i];
        return max;
    }

    static int lowest(int[] scores) {
        int min = scores[0];
        for (int i = 1; i < scores.length; i++)
            if (scores[i] < min) min = scores[i];
        return min;
    }

    static double average(int[] scores) {
        int sum = 0;
        for (int i = 0; i < scores.length; i++) sum += scores[i];
        return (double) sum / scores.length;
    }

    static int countPassing(int[] scores) {
        int count = 0;
        for (int i = 0; i < scores.length; i++)
            if (isPassing(scores[i])) count++;
        return count;
    }

    static double standardDeviation(int[] scores, double avg) {
        double sumSq = 0;
        for (int i = 0; i < scores.length; i++) {
            double diff = scores[i] - avg;
            sumSq += diff * diff;
        }
        return Math.sqrt(sumSq / scores.length);
    }

    static void printHistogram(int[] scores) {
        System.out.println("Grade distribution:");
        String[] bands = {"90-100","80-89","70-79","60-69","50-59","0-49"};
        int[] counts   = new int[6];
        for (int i = 0; i < scores.length; i++) {
            int s = scores[i];
            if      (s >= 90) counts[0]++;
            else if (s >= 80) counts[1]++;
            else if (s >= 70) counts[2]++;
            else if (s >= 60) counts[3]++;
            else if (s >= 50) counts[4]++;
            else              counts[5]++;
        }
        for (int i = 0; i < bands.length; i++) {
            System.out.print("  " + bands[i] + ": ");
            for (int j = 0; j < counts[i]; j++) System.out.print("*");
            System.out.println(" (" + counts[i] + ")");
        }
    }

    public static void main(String[] args) {
        // [assignments, midterm, finalExam] per student
        int[][] raw = {
            {88, 76, 82},
            {95, 91, 93},
            {60, 55, 58},
            {72, 68, 71},
            {45, 50, 47},
            {83, 79, 85},
            {91, 88, 90},
            {63, 70, 66}
        };

        int[] finals = new int[NUM_STUDENTS];
        double totalGPA = 0;

        System.out.println("=== Student Grade Report ===");
        System.out.printf("%-6s %-8s %-8s %-8s %-8s %-6s %-5s%n",
            "ID", "Assign", "Midterm", "Final", "Weighted", "Grade", "GPA");
        System.out.println("-".repeat(53));

        for (int i = 0; i < NUM_STUDENTS; i++) {
            int ws = weightedScore(raw[i][0], raw[i][1], raw[i][2]);
            String lg = letterGrade(ws);
            double gp = gradePoints(lg);
            finals[i] = ws;
            totalGPA += gp;
            System.out.printf("S%-5d %-8d %-8d %-8d %-8d %-6s %.1f%n",
                i + 1, raw[i][0], raw[i][1], raw[i][2], ws, lg, gp);
        }

        System.out.println("-".repeat(53));
        double avg = average(finals);
        System.out.printf("Class average:     %.2f%n", avg);
        System.out.printf("Highest score:     %d%n",   highest(finals));
        System.out.printf("Lowest score:      %d%n",   lowest(finals));
        System.out.printf("Std deviation:     %.2f%n", standardDeviation(finals, avg));
        System.out.printf("Class GPA:         %.2f%n", totalGPA / NUM_STUDENTS);
        System.out.printf("Pass rate:         %d/%d%n", countPassing(finals), NUM_STUDENTS);
        System.out.println();
        printHistogram(finals);
    }
}
