import java.util.ArrayList;
import java.util.List;

/**
 * Bank account simulation.
 * Pair group: P03, P04, P05 are the SAME with different variable names.
 */
public class BankSimulation {

    static double balance = 0.0;
    static List<String> log = new ArrayList<>();

    static void deposit(double amount) {
        if (amount <= 0) {
            log.add("REJECTED deposit: " + amount);
            return;
        }
        balance += amount;
        log.add("DEPOSIT: +" + amount + " | balance=" + balance);
    }

    static void withdraw(double amount) {
        if (amount <= 0 || amount > balance) {
            log.add("REJECTED withdrawal: " + amount);
            return;
        }
        balance -= amount;
        log.add("WITHDRAW: -" + amount + " | balance=" + balance);
    }

    static void applyInterest(double rate) {
        double interest = balance * rate;
        balance += interest;
        log.add("INTEREST: +" + interest + " | balance=" + balance);
    }

    static double computeTax(double rate) {
        return balance * rate;
    }

    static int countTransactions() {
        return log.size();
    }

    static double averageBalance(List<Double> snapshots) {
        double total = 0;
        for (double s : snapshots) total += s;
        return total / snapshots.size();
    }

    static boolean canAfford(double cost) {
        return balance >= cost;
    }

    static void transfer(double amount, String toAccount) {
        if (amount <= 0 || amount > balance) {
            log.add("TRANSFER FAILED to " + toAccount + ": " + amount);
            return;
        }
        balance -= amount;
        log.add("TRANSFER: -" + amount + " to " + toAccount + " | balance=" + balance);
    }

    static void printLog() {
        System.out.println("=== Transaction Log ===");
        for (String entry : log) {
            System.out.println("  " + entry);
        }
    }

    static void runSimulation() {
        List<Double> snapshots = new ArrayList<>();

        deposit(1000.0);
        snapshots.add(balance);
        deposit(500.0);
        snapshots.add(balance);
        withdraw(200.0);
        snapshots.add(balance);
        applyInterest(0.02);
        snapshots.add(balance);
        deposit(750.0);
        snapshots.add(balance);
        withdraw(100.0);
        snapshots.add(balance);
        transfer(300.0, "ACC-9982");
        snapshots.add(balance);
        withdraw(99999.0); // should be rejected
        snapshots.add(balance);
        applyInterest(0.015);
        snapshots.add(balance);
        deposit(-50.0); // should be rejected
        snapshots.add(balance);

        printLog();

        System.out.println("\nFinal balance: " + balance);
        System.out.println("Transactions processed: " + countTransactions());
        System.out.println("Average balance across snapshots: " + averageBalance(snapshots));
        System.out.println("Tax at 15%: " + computeTax(0.15));
        System.out.println("Can afford $1000 purchase? " + canAfford(1000.0));
        System.out.println("Can afford $5000 purchase? " + canAfford(5000.0));
    }

    public static void main(String[] args) {
        System.out.println("Starting bank simulation...");
        runSimulation();
        System.out.println("Simulation complete.");
    }
}
