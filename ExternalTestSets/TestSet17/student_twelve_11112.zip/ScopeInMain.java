/**
 * Statistics calculator — ALL LOGIC IN MAIN.
 *
 * Scope demonstration: the variable `sum` is declared and used in
 * multiple nested scopes within main. Each inner block declares its own
 * `sum`, shadowing the outer one. This is the "everything in main" twin
 * of ScopeWithFunctions.java (two-file companion).
 *
 * Pair: P12a (this file) and P12b (ScopeWithFunctions.java) share
 * identical logic but differ in structure.
 */
public class ScopeInMain {
    public static void main(String[] args) {
        double[] data = {4.0, 7.0, 2.0, 9.0, 1.0, 5.0, 8.0, 3.0, 6.0, 10.0};
        int n = data.length;

        // ── Mean ────────────────────────────────────────────────
        double sum = 0;          // outer `sum` — tracks the mean
        for (double v : data) sum += v;
        double mean = sum / n;
        System.out.println("Mean: " + mean);

        // ── Variance (sum is re-declared inside its own block) ──
        double variance;
        {
            double sum = 0;      // inner `sum` — shadows outer; tracks squared diffs
            for (double v : data) sum += (v - mean) * (v - mean);
            variance = sum / n;
        }
        double stddev = Math.sqrt(variance);
        System.out.println("Variance: " + variance);
        System.out.println("Std Dev: " + stddev);

        // ── Min / Max ────────────────────────────────────────────
        double min = data[0], max = data[0];
        for (double v : data) {
            if (v < min) min = v;
            if (v > max) max = v;
        }
        System.out.println("Min: " + min + "  Max: " + max);
        System.out.println("Range: " + (max - min));

        // ── Median (sort a copy) ─────────────────────────────────
        double[] sorted = data.clone();
        // bubble-sort in-place
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (sorted[j] > sorted[j + 1]) {
                    double tmp = sorted[j];
                    sorted[j] = sorted[j + 1];
                    sorted[j + 1] = tmp;
                }
            }
        }
        double median = (n % 2 == 0)
            ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0
            : sorted[n / 2];
        System.out.println("Median: " + median);

        // ── Geometric mean (sum re-declared again, now logs) ─────
        double geometricMean;
        {
            double sum = 0;      // another inner `sum` — shadows outer; tracks log-sum
            for (double v : data) sum += Math.log(v);
            geometricMean = Math.exp(sum / n);
        }
        System.out.println("Geometric Mean: " + geometricMean);

        // ── Z-scores ─────────────────────────────────────────────
        System.out.print("Z-scores: ");
        for (double v : data) {
            double z = (v - mean) / stddev;
            System.out.printf("%.2f ", z);
        }
        System.out.println();

        // ── Quartiles ────────────────────────────────────────────
        double q1 = sorted[n / 4];
        double q3 = sorted[3 * n / 4];
        System.out.println("Q1: " + q1 + "  Q3: " + q3);
        System.out.println("IQR: " + (q3 - q1));

        // ── Count above mean ─────────────────────────────────────
        {
            int sum = 0;         // int `sum` this time — different type, same name
            for (double v : data) if (v > mean) sum++;
            System.out.println("Count above mean: " + sum);
        }

        // ── Coefficient of variation ──────────────────────────────
        double cv = (stddev / mean) * 100.0;
        System.out.printf("Coefficient of Variation: %.2f%%%n", cv);

        // ── Skewness (Pearson's moment coefficient) ───────────────
        double skewness;
        {
            double sum = 0;      // inner `sum` — cubed deviations
            for (double v : data) {
                double diff = v - mean;
                sum += diff * diff * diff;
            }
            skewness = (sum / n) / (stddev * stddev * stddev);
        }
        System.out.printf("Skewness: %.4f%n", skewness);

        // ── Kurtosis ─────────────────────────────────────────────
        double kurtosis;
        {
            double sum = 0;      // inner `sum` — fourth-power deviations
            for (double v : data) {
                double diff = v - mean;
                sum += diff * diff * diff * diff;
            }
            kurtosis = (sum / n) / (variance * variance) - 3.0;
        }
        System.out.printf("Excess Kurtosis: %.4f%n", kurtosis);
    }
}
