/**
 * Statistics calculator — LOGIC SPLIT INTO FUNCTIONS.
 *
 * Scope demonstration: every function declares its own local `sum`
 * (or `count`, `tmp`, etc.), completely independent of each other
 * and of main. The SAME variable names appear in DIFFERENT scopes.
 *
 * This is the "uses functions" twin of ScopeInMain.java.
 * The two files compute identical results; the difference is
 * structural/stylistic, not semantic.
 *
 * Pair: P12a (ScopeInMain.java) and P12b (this file).
 */
public class ScopeWithFunctions {

    static double mean(double[] data) {
        double sum = 0;              // `sum` is local to mean()
        for (double v : data) sum += v;
        return sum / data.length;
    }

    static double variance(double[] data, double mean) {
        double sum = 0;              // `sum` is local to variance(); same name, different scope
        for (double v : data) sum += (v - mean) * (v - mean);
        return sum / data.length;
    }

    static double geometricMean(double[] data) {
        double sum = 0;              // `sum` again — now accumulates log values
        for (double v : data) sum += Math.log(v);
        return Math.exp(sum / data.length);
    }

    static double min(double[] data) {
        double min = data[0];
        for (double v : data) if (v < min) min = v;
        return min;
    }

    static double max(double[] data) {
        double max = data[0];
        for (double v : data) if (v > max) max = v;
        return max;
    }

    static double median(double[] data) {
        double[] sorted = data.clone();
        int n = sorted.length;
        // bubble-sort
        for (int i = 0; i < n - 1; i++) {
            for (int j = 0; j < n - i - 1; j++) {
                if (sorted[j] > sorted[j + 1]) {
                    double tmp = sorted[j];
                    sorted[j] = sorted[j + 1];
                    sorted[j + 1] = tmp;
                }
            }
        }
        return (n % 2 == 0)
            ? (sorted[n / 2 - 1] + sorted[n / 2]) / 2.0
            : sorted[n / 2];
    }

    static double[] zScores(double[] data, double mean, double stddev) {
        double[] z = new double[data.length];
        for (int i = 0; i < data.length; i++)
            z[i] = (data[i] - mean) / stddev;
        return z;
    }

    static double quartile(double[] data, int q) {
        double[] sorted = data.clone();
        int n = sorted.length;
        for (int i = 0; i < n - 1; i++)
            for (int j = 0; j < n - i - 1; j++)
                if (sorted[j] > sorted[j + 1]) {
                    double tmp = sorted[j]; sorted[j] = sorted[j+1]; sorted[j+1] = tmp;
                }
        return sorted[n * q / 4];
    }

    static int countAboveMean(double[] data, double mean) {
        int sum = 0;                 // `sum` as a counter (int) — same name, int type this time
        for (double v : data) if (v > mean) sum++;
        return sum;
    }

    static double skewness(double[] data, double mean, double stddev) {
        double sum = 0;              // `sum` of cubed deviations
        int n = data.length;
        for (double v : data) {
            double diff = v - mean;
            sum += diff * diff * diff;
        }
        return (sum / n) / (stddev * stddev * stddev);
    }

    static double kurtosis(double[] data, double mean, double variance) {
        double sum = 0;              // `sum` of fourth-power deviations
        int n = data.length;
        for (double v : data) {
            double diff = v - mean;
            sum += diff * diff * diff * diff;
        }
        return (sum / n) / (variance * variance) - 3.0;
    }

    public static void main(String[] args) {
        double[] data = {4.0, 7.0, 2.0, 9.0, 1.0, 5.0, 8.0, 3.0, 6.0, 10.0};

        double m    = mean(data);
        double var  = variance(data, m);
        double sd   = Math.sqrt(var);

        System.out.println("Mean: " + m);
        System.out.println("Variance: " + var);
        System.out.println("Std Dev: " + sd);

        double lo = min(data), hi = max(data);
        System.out.println("Min: " + lo + "  Max: " + hi);
        System.out.println("Range: " + (hi - lo));

        System.out.println("Median: " + median(data));
        System.out.println("Geometric Mean: " + geometricMean(data));

        double[] z = zScores(data, m, sd);
        System.out.print("Z-scores: ");
        for (double zv : z) System.out.printf("%.2f ", zv);
        System.out.println();

        double q1 = quartile(data, 1);
        double q3 = quartile(data, 3);
        System.out.println("Q1: " + q1 + "  Q3: " + q3);
        System.out.println("IQR: " + (q3 - q1));

        System.out.println("Count above mean: " + countAboveMean(data, m));

        double cv = (sd / m) * 100.0;
        System.out.printf("Coefficient of Variation: %.2f%%%n", cv);

        System.out.printf("Skewness: %.4f%n",       skewness(data, m, sd));
        System.out.printf("Excess Kurtosis: %.4f%n", kurtosis(data, m, var));
    }
}
