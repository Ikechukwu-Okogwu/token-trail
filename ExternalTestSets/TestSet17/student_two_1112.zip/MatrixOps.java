import java.util.Random;

/**
 * Matrix operations: multiply, transpose, trace.
 * Pair: P01 and P02 are EXACT copies.
 */
public class MatrixOps {

    static int[][] multiply(int[][] a, int[][] b, int n) {
        int[][] result = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    result[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return result;
    }

    static int[][] transpose(int[][] matrix, int n) {
        int[][] t = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                t[j][i] = matrix[i][j];
            }
        }
        return t;
    }

    static int trace(int[][] matrix, int n) {
        int sum = 0;
        for (int i = 0; i < n; i++) {
            sum += matrix[i][i];
        }
        return sum;
    }

    static int[][] generate(int n, Random rng) {
        int[][] m = new int[n][n];
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                m[i][j] = rng.nextInt(10);
            }
        }
        return m;
    }

    static void print(int[][] matrix, int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                System.out.printf("%4d", matrix[i][j]);
            }
            System.out.println();
        }
    }

    static boolean isSymmetric(int[][] matrix, int n) {
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                if (matrix[i][j] != matrix[j][i]) return false;
            }
        }
        return true;
    }

    static int rowSum(int[][] matrix, int row, int n) {
        int s = 0;
        for (int j = 0; j < n; j++) s += matrix[row][j];
        return s;
    }

    static int colSum(int[][] matrix, int col, int n) {
        int s = 0;
        for (int i = 0; i < n; i++) s += matrix[i][col];
        return s;
    }

    static int[][] add(int[][] a, int[][] b, int n) {
        int[][] result = new int[n][n];
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                result[i][j] = a[i][j] + b[i][j];
        return result;
    }

    static int frobenius(int[][] matrix, int n) {
        int sum = 0;
        for (int i = 0; i < n; i++)
            for (int j = 0; j < n; j++)
                sum += matrix[i][j] * matrix[i][j];
        return sum;
    }

    public static void main(String[] args) {
        int n = 4;
        Random rng = new Random(42);
        int[][] A = generate(n, rng);
        int[][] B = generate(n, rng);

        System.out.println("Matrix A:");
        print(A, n);

        System.out.println("Matrix B:");
        print(B, n);

        int[][] C = multiply(A, B, n);
        System.out.println("A * B:");
        print(C, n);

        int[][] T = transpose(A, n);
        System.out.println("Transpose of A:");
        print(T, n);

        System.out.println("Trace of A: " + trace(A, n));
        System.out.println("Trace of A*B: " + trace(C, n));

        int[][] S = add(A, B, n);
        System.out.println("A + B:");
        print(S, n);

        System.out.println("Is A symmetric? " + isSymmetric(A, n));
        System.out.println("Is T*A symmetric? " + isSymmetric(multiply(T, A, n), n));

        System.out.println("Row sums of A:");
        for (int i = 0; i < n; i++)
            System.out.println("  row " + i + ": " + rowSum(A, i, n));

        System.out.println("Col sums of B:");
        for (int j = 0; j < n; j++)
            System.out.println("  col " + j + ": " + colSum(B, j, n));

        System.out.println("Frobenius norm^2 of A: " + frobenius(A, n));
    }
}
