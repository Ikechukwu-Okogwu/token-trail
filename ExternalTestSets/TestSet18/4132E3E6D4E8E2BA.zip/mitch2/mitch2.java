// Submission: mitch2 — student number mitch2
// Assignment key: 49257edbbec5d913
// Template: setup / run / finish — weather telemetry pipeline (distinct from mitch1).

public class Mitch2 {

    private final String name;
    private int readingsProcessed;
    private double tempSum;

    public Mitch2(String name) {
        this.name = name;
        this.readingsProcessed = 0;
        this.tempSum = 0.0;
    }

    private boolean sanityCheck(double tempC, int humidity, int pressureHpa, int windKph) {
        if (humidity < 0 || humidity > 100) {
            return false;
        }
        if (pressureHpa < 870 || pressureHpa > 1090) {
            return false;
        }
        if (windKph < 0 || windKph > 200) {
            return false;
        }
        return tempC >= -55.0 && tempC <= 55.0;
    }

    private static double approximateDewPointC(double tempC, int rhPct) {
        double a = 17.27;
        double b = 237.7;
        double alpha = ((a * tempC) / (b + tempC)) + Math.log(Math.max(1, rhPct) / 100.0);
        return (b * alpha) / (a - alpha);
    }

    public void setup() {
        System.out.println("Weather Telemetry Service (Java — mitch2)");
        System.out.println("Assignment Key: 49257edbbec5d913");
        System.out.println("Operator: " + name);

        String[] stations = {"BUF", "TOR", "DET", "CHI", "MSP"};
        System.out.println("Registering " + stations.length + " stations...");
        for (String code : stations) {
            System.out.println("  Station " + code + " — calibration OK");
        }

        double[] lat = {42.89, 43.65, 42.33, 41.88, 44.98};
        double[] lon = {-78.87, -79.38, -83.05, -87.63, -93.27};
        for (int i = 0; i < stations.length; i++) {
            System.out.println("  " + stations[i] + " @ (" + lat[i] + ", " + lon[i] + ")");
        }

        System.out.println("Loading sensor schema: temp_C, humidity_pct, pressure_hPa, wind_kph");
        System.out.println("Allocating ring buffers (size 1440 per station)...");
        System.out.println("Handshake with archive backend (simulated): SUCCESS");
        System.out.println("mitch2 setup complete.");
    }

    public void run() {
        System.out.println("--- run(): ingest window ---");
        String[] samples = {
            "-2.1, 78, 1012, 14",
            "0.4, 71, 1008, 22",
            "-5.0, 82, 1015, 9",
            "12.3, 55, 1005, 31",
            "-11.2, 90, 1020, 6"
        };
        tempSum = 0.0;
        for (String row : samples) {
            String[] parts = row.split(",\\s*");
            double temp = Double.parseDouble(parts[0]);
            int hum = Integer.parseInt(parts[1]);
            int press = Integer.parseInt(parts[2]);
            int wind = Integer.parseInt(parts[3]);
            if (!sanityCheck(temp, hum, press, wind)) {
                System.out.println("SKIP malformed row: " + row);
                continue;
            }
            readingsProcessed++;
            tempSum += temp;
            double td = approximateDewPointC(temp, hum);
            System.out.println("Reading #" + readingsProcessed + " from " + name + ": "
                + "T=" + temp + "C RH=" + hum + "% P=" + press + " w=" + wind + "kph");
            System.out.println("  Approx dew point: " + String.format("%.2f", td) + "C");
            if (temp < -40 || temp > 50) {
                System.out.println("  FLAG: out-of-range temperature (would quarantine)");
            }
        }
        double mean = readingsProcessed > 0 ? tempSum / readingsProcessed : 0.0;
        System.out.println("Window mean temp: " + String.format("%.2f", mean) + "C");
        System.out.println("Ingest done; " + readingsProcessed + " rows accepted.");
    }

    public void finish() {
        System.out.println("--- finish(): archive & disconnect ---");
        System.out.println("Persisting aggregates for session owner " + name + "...");
        for (int step = 1; step <= 4; step++) {
            System.out.println("  Archive phase " + step + "/4 complete");
        }
        System.out.println("Total readings this session: " + readingsProcessed);
        if (readingsProcessed > 0) {
            System.out.println("Final mean temperature retained: "
                + String.format("%.2f", tempSum / readingsProcessed) + "C");
        }
        String[] channels = {"METAR", "ASOS", "MESONET"};
        for (String ch : channels) {
            System.out.println("  Channel " + ch + " listener stopped");
        }
        System.out.println("Closing station sockets (simulated).");
        System.out.println("mitch2 shutdown OK.");
    }

    public static void main(String[] args) {
        Mitch2 app = new Mitch2("mitch2");
        app.setup();
        app.run();
        app.finish();
    }
}
