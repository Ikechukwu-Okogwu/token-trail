import java.util.ArrayList;
import java.util.List;

public class SimpleClass {

    private final String name;
    private List<String> tasks;
    private boolean initialized;

    public SimpleClass(String name) {
        this.name = name;
        this.tasks = new ArrayList<>();
        this.initialized = false;
    }

    public void setup() {
        System.out.println("Initializing system for " + name);
        tasks.add("Load data");
        tasks.add("Process data");
        tasks.add("Generate report");
        initialized = true;
    }

    public void run() {
        if (!initialized) {
            System.out.println("System not initialized. Run setup() first.");
            return;
        }

        System.out.println("Executing tasks...");
        for (int i = 0; i < tasks.size(); i++) {
            System.out.println("Task " + (i + 1) + ": " + tasks.get(i));
        }
    }

    public void finish() {
        System.out.println("Clearing tasks and shutting down " + name);
        tasks.clear();
        initialized = false;
    }

    public static void main(String[] args) {
        SimpleClass system = new SimpleClass("TaskManager");
        system.setup();
        system.run();
        system.finish();
    }
}
