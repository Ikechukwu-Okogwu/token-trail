// Submission: mitch1 — student number mitch1
// Assignment key: 49257edbbec5d913
// Template: setup / run / finish — MLB-flavored static reference “collector” (console only).

public class Mitch1 {

    private final String name;
    private int teamsUpserted;

    public Mitch1(String name) {
        this.name = name;
        this.teamsUpserted = 0;
    }

    private static void logUpsert(String table, String key) {
        System.out.println("Upserting " + table + ": " + key);
    }

    private int countSubstring(String[] teams, String needle) {
        int c = 0;
        String n = needle.toLowerCase();
        for (String t : teams) {
            if (t != null && t.toLowerCase().contains(n)) {
                c++;
            }
        }
        return c;
    }

    public void setup() {
        System.out.println("MLB Static Data Collector (Java — mitch1)");
        System.out.println("Assignment Key: 49257edbbec5d913");
        System.out.println("Welcome, " + name + "!");

        String[] leagues = {"AL", "NL"};
        String[] divisions = {"East", "Central", "West"};
        String[] teams = {
            "Yankees", "Red Sox", "Blue Jays", "Rays", "Orioles",
            "White Sox", "Guardians", "Tigers", "Royals", "Twins",
            "Astros", "Mariners", "Rangers", "Angels", "Athletics",
            "Braves", "Mets", "Phillies", "Marlins", "Nationals",
            "Cubs", "Brewers", "Cardinals", "Reds", "Pirates",
            "Dodgers", "Padres", "Giants", "Rockies", "Diamondbacks"
        };

        System.out.println("Collected " + leagues.length + " leagues, "
            + divisions.length + " divisions, " + teams.length + " teams.");

        System.out.println("Updating database with static data...");
        for (String league : leagues) {
            logUpsert("league", league);
        }
        for (String division : divisions) {
            logUpsert("division", division);
        }
        int n = 0;
        for (String team : teams) {
            logUpsert("team", team);
            n++;
            teamsUpserted++;
            if (n % 10 == 0) {
                System.out.println("  ... checkpoint " + n + " teams");
            }
        }
        System.out.println("Teams with 'Sox' in name: " + countSubstring(teams, "Sox"));
        System.out.println("Static data update complete!");

        System.out.println("Collecting rosters...");
        int newPlayers = 20;
        int totalRosters = 30;
        System.out.println("Collected " + newPlayers + " new players, "
            + totalRosters + " roster entries.");

        System.out.println("Collecting leverage index lookup table...");
        int leverageEntries = 216;
        System.out.println("Collected " + leverageEntries + " leverage index values.");
        System.out.println("Leverage index table update complete!");
        System.out.println("All MLB static data updated (mitch1).");
    }

    public void run() {
        System.out.println("--- run(): simulated game-day batch ---");
        String[] matchups = {
            "NYY @ BOS", "LAD @ SD", "CHC @ STL", "SEA @ TEX", "ATL @ NYM"
        };
        int totalRuns = 0;
        for (String m : matchups) {
            System.out.println("Processing matchup: " + m);
            int runsHome = 2 + (int) (Math.random() * 7);
            int runsAway = 2 + (int) (Math.random() * 7);
            totalRuns += runsHome + runsAway;
            System.out.println("  Box: away " + runsAway + " — home " + runsHome);
            if (runsHome == runsAway) {
                System.out.println("  Note: tie (extra innings not simulated)");
            }
        }
        System.out.println("Runs scored (sample slate): " + totalRuns);
        System.out.println("Teams upserted earlier this session: " + teamsUpserted);
        System.out.println("Batch complete for " + name + ".");
    }

    public void finish() {
        System.out.println("--- finish(): teardown ---");
        System.out.println("Flushing log buffers for " + name + "...");
        System.out.println("Closing static data handles (simulated).");
        System.out.println("Writing session summary: OK");
        String[] audit = {"leagues", "divisions", "teams", "rosters", "leverage"};
        for (String slice : audit) {
            System.out.println("  Audit row sealed: " + slice);
        }
        for (int i = 3; i >= 1; i--) {
            System.out.println("Shutdown in " + i + "...");
        }
        System.out.println("mitch1 session ended cleanly.");
    }

    public static void main(String[] args) {
        Mitch1 app = new Mitch1("mitch1");
        app.setup();
        app.run();
        app.finish();
    }
}
