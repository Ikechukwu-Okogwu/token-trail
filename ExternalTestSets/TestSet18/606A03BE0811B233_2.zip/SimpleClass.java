public class SimpleClass {

    private final String name;
    private int runCount;
    private boolean isReady;

    public SimpleClass(String name) {
        this.name = name;
        this.runCount = 0;
        this.isReady = false;
    }

    public void setup() {
        System.out.println("Setting up for " + name);
        isReady = true;
    }

    public void run() {
        if (!isReady) {
            System.out.println("Please call setup() first.");
            return;
        }

        System.out.println("Running task for " + name);
        runCount++;
    }

    public void finish() {
        System.out.println("Finishing process for " + name);
        System.out.println("Total runs: " + runCount);
        isReady = false;
    }

    public static void main(String[] args) {
        SimpleClass app = new SimpleClass("Demo");
        app.setup();
        app.run();
        app.finish();
    }
}
