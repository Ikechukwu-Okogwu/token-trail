public enum Phase {
    CREATED,
    READY,
    EXECUTING,
    ENDED,
    FAILURE
}