import java.util.EnumSet;

public enum PhaseRule {

    PREP_ALLOWED(EnumSet.of(Phase.CREATED)),
    EXEC_ALLOWED(EnumSet.of(Phase.READY, Phase.EXECUTING)),
    END_ALLOWED(EnumSet.of(Phase.EXECUTING, Phase.READY));

    private final EnumSet<Phase> accepted;

    PhaseRule(EnumSet<Phase> accepted) {
        this.accepted = accepted;
    }

    public boolean allowed(Phase p) {
        return accepted.contains(p);
    }
}