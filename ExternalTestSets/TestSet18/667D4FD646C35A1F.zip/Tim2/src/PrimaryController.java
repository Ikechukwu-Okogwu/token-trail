import java.util.List;

public class PrimaryController {

    private final String id;
    private final WorkflowEngine engine;

    public PrimaryController(String id) {
        this.id = id;
        this.engine = new WorkflowEngine(id);
    }

    public void initialize() {
        engine.prepare();
    }

    public void execute() {
        engine.perform();
    }

    public void complete() {
        engine.wrapUp();
    }

    public List<String> events() {
        return engine.events();
    }

    public static void main(String[] args) {
        PrimaryController pc = new PrimaryController("VariantB");

        pc.initialize();
        pc.execute();
        pc.complete();

        for (String e : pc.events()) {
            System.out.println(e);
        }
    }
}