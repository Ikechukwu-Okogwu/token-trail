public final class StringTools {

    private StringTools() {
        // hidden constructor
    }

    public static String simplify(String input) {
        if (input == null) return "";
        return input.trim().toLowerCase();
    }

    public static boolean emptyOrSpaces(String value) {
        if (value == null) return true;

        for (int i = 0; i < value.length(); i++) {
            if (!Character.isWhitespace(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }
}