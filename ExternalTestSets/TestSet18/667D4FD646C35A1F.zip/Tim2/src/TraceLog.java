import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TraceLog {

    private final List<String> items;

    public TraceLog() {
        this.items = new ArrayList<>();
    }

    public void record(String msg) {
        items.add(format(msg));
    }

    private String format(String msg) {
        // Slightly different formatting for comparison testing
        return "[" + LocalDateTime.now() + "] >>> " + msg;
    }

    public List<String> entries() {
        return Collections.unmodifiableList(items);
    }
}