import java.util.ArrayList;
import java.util.List;

public class WorkflowEngine {

    private final String identifier;
    private final TraceLog trace;
    private Phase phase;
    private int cycles;

    public WorkflowEngine(String identifier) {
        this.identifier = identifier;
        this.trace = new TraceLog();
        this.phase = Phase.CREATED;
        this.cycles = 0;
    }

    public void prepare() {
        verify(PhaseRule.PREP_ALLOWED);
        trace.record("Preparing workflow for " + identifier);
        phase = Phase.READY;
        trace.record("Preparation done");
    }

    public void perform() {
        verify(PhaseRule.EXEC_ALLOWED);
        phase = Phase.EXECUTING;
        trace.record("Execution started");

        // Reordered internal logic: run descending instead of ascending
        for (int i = 4; i >= 0; i--) {
            cycles++;
            trace.record("Cycle index = " + i);
        }

        trace.record("Execution finished, total=" + cycles);
    }

    public void wrapUp() {
        verify(PhaseRule.END_ALLOWED);
        phase = Phase.ENDED;
        trace.record("Workflow finalized");
    }

    public List<String> events() {
        return new ArrayList<>(trace.entries());
    }

    private void verify(PhaseRule rule) {
        if (!rule.allowed(phase)) {
            throw new IllegalStateException(
                    "Phase " + phase + " not permitted for " + rule
            );
        }
    }
}