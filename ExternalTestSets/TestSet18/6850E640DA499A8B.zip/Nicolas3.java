import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BankAccount {

    private final String name; // account holder
    private double balance;
    private double savingsBalance;
    private List<String> transactionHistory;
    private Scanner scanner;
    private boolean isRunning;
    private int pinAttempts;
    private final int PIN = 1234;
    private boolean authenticated;
    private static final DateTimeFormatter FMT =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public BankAccount(String name) {
        this.name = name;
        this.balance = 1000.00;       // starting chequing balance
        this.savingsBalance = 500.00; // starting savings balance
        this.transactionHistory = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        this.isRunning = true;
        this.pinAttempts = 0;
        this.authenticated = false;
    }

    public void setup() {
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║       MAPLE LEAF BANK — ATM          ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.println("Welcome, " + name + ".");
        System.out.println();

        // PIN authentication loop
        while (!authenticated && pinAttempts < 3) {
            System.out.print("Please enter your 4-digit PIN: ");
            String input = scanner.nextLine().trim();
            try {
                int enteredPin = Integer.parseInt(input);
                if (enteredPin == PIN) {
                    authenticated = true;
                    System.out.println("PIN accepted. Access granted.");
                    logTransaction("LOGIN", 0, "Successful login");
                } else {
                    pinAttempts++;
                    int remaining = 3 - pinAttempts;
                    System.out.println("Incorrect PIN. " +
                        (remaining > 0 ? remaining + " attempt(s) remaining." : "Card locked."));
                }
            } catch (NumberFormatException e) {
                pinAttempts++;
                System.out.println("Invalid input. Please enter digits only.");
            }
        }

        if (!authenticated) {
            System.out.println("Too many failed attempts. Session terminated.");
            isRunning = false;
        } else {
            System.out.println();
            System.out.println("Available commands:");
            System.out.println("  balance                  — View all balances");
            System.out.println("  deposit <amount>         — Deposit to chequing");
            System.out.println("  withdraw <amount>        — Withdraw from chequing");
            System.out.println("  transfer <amount>        — Transfer chequing → savings");
            System.out.println("  history                  — View transaction history");
            System.out.println("  interest                 — Apply monthly interest to savings");
            System.out.println("  quit                     — Exit securely");
            System.out.println();
        }
    }

    public void run() {
        if (!isRunning) return;

        while (isRunning) {
            System.out.print("\n> ");
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) continue;

            String[] parts = input.split(" ", 2);
            String command = parts[0].toLowerCase();
            String argument = parts.length > 1 ? parts[1].trim() : "";

            switch (command) {
                case "balance"  -> showBalance();
                case "deposit"  -> deposit(argument);
                case "withdraw" -> withdraw(argument);
                case "transfer" -> transfer(argument);
                case "history"  -> showHistory();
                case "interest" -> applyInterest();
                case "quit"     -> isRunning = false;
                default         -> System.out.println("Unrecognized command. See the list above.");
            }
        }
    }

    private void showBalance() {
        System.out.println();
        System.out.println("  Account Holder : " + name);
        System.out.printf("  Chequing       : $%,.2f%n", balance);
        System.out.printf("  Savings        : $%,.2f%n", savingsBalance);
        System.out.printf("  Total          : $%,.2f%n", balance + savingsBalance);
    }

    private void deposit(String amountStr) {
        double amount = parseAmount(amountStr);
        if (amount <= 0) return;

        balance += amount;
        logTransaction("DEPOSIT", amount, "Chequing deposit");
        System.out.printf("  Deposited $%,.2f. New chequing balance: $%,.2f%n", amount, balance);
    }

    private void withdraw(String amountStr) {
        double amount = parseAmount(amountStr);
        if (amount <= 0) return;

        if (amount > balance) {
            System.out.printf("  Insufficient funds. Available: $%,.2f%n", balance);
            logTransaction("WITHDRAW_FAILED", amount, "Insufficient funds");
            return;
        }

        if (amount > 500) {
            System.out.println("  Withdrawals over $500 require confirmation.");
            System.out.print("  Confirm? (yes/no): ");
            String confirm = scanner.nextLine().trim().toLowerCase();
            if (!confirm.equals("yes")) {
                System.out.println("  Withdrawal cancelled.");
                return;
            }
        }

        balance -= amount;
        logTransaction("WITHDRAW", amount, "Chequing withdrawal");
        System.out.printf("  Withdrew $%,.2f. New chequing balance: $%,.2f%n", amount, balance);
    }

    private void transfer(String amountStr) {
        double amount = parseAmount(amountStr);
        if (amount <= 0) return;

        if (amount > balance) {
            System.out.printf("  Insufficient chequing funds. Available: $%,.2f%n", balance);
            return;
        }

        balance -= amount;
        savingsBalance += amount;
        logTransaction("TRANSFER", amount, "Chequing → Savings");
        System.out.printf("  Transferred $%,.2f to savings.%n", amount);
        System.out.printf("  Chequing: $%,.2f | Savings: $%,.2f%n", balance, savingsBalance);
    }

    private void applyInterest() {
        double rate = 0.02; // 2% monthly interest
        double interest = savingsBalance * rate;
        savingsBalance += interest;
        logTransaction("INTEREST", interest, "2%% monthly interest applied");
        System.out.printf("  Interest earned: $%,.2f. New savings balance: $%,.2f%n",
            interest, savingsBalance);
    }

    private void showHistory() {
        System.out.println();
        if (transactionHistory.isEmpty()) {
            System.out.println("  No transactions yet.");
            return;
        }
        System.out.println("  --- Transaction History ---");
        for (String entry : transactionHistory) {
            System.out.println("  " + entry);
        }
    }

    private void logTransaction(String type, double amount, String note) {
        String timestamp = LocalDateTime.now().format(FMT);
        String entry = amount > 0
            ? String.format("[%s] %-16s $%8.2f   (%s)", timestamp, type, amount, note)
            : String.format("[%s] %-16s %s", timestamp, type, note);
        transactionHistory.add(entry);
    }

    private double parseAmount(String amountStr) {
        if (amountStr.isEmpty()) {
            System.out.println("  Please provide an amount. Example: deposit 50");
            return -1;
        }
        try {
            double amount = Double.parseDouble(amountStr);
            if (amount <= 0) {
                System.out.println("  Amount must be greater than zero.");
                return -1;
            }
            // Round to 2 decimal places
            return Math.round(amount * 100.0) / 100.0;
        } catch (NumberFormatException e) {
            System.out.println("  Invalid amount: \"" + amountStr + "\". Enter a number like 50 or 12.99");
            return -1;
        }
    }

    public void finish() {
        logTransaction("LOGOUT", 0, "Session ended");

        System.out.println();
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║         SESSION SUMMARY              ║");
        System.out.println("╚══════════════════════════════════════╝");
        System.out.printf("  Account Holder : %s%n", name);
        System.out.printf("  Chequing       : $%,.2f%n", balance);
        System.out.printf("  Savings        : $%,.2f%n", savingsBalance);
        System.out.printf("  Total Assets   : $%,.2f%n", balance + savingsBalance);
        System.out.println("  Transactions   : " + transactionHistory.size());
        System.out.println();
        System.out.println("  Thank you for banking with Maple Leaf Bank.");
        System.out.println("  Please take your card and receipt. Goodbye!");
        scanner.close();
    }

    public static void main(String[] args) {
        BankAccount account = new BankAccount("Alex Johnson");
        account.setup();
        account.run();
        account.finish();
    }
}
