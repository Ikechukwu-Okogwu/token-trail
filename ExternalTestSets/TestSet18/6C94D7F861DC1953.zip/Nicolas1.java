import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class AdventureGame {

    private final String name;
    private int health;
    private int gold;
    private String currentRoom;
    private Map<String, String[]> rooms;
    private Map<String, Integer> inventory;
    private Scanner scanner;
    private boolean isRunning;

    public AdventureGame(String name) {
        this.name = name;
        this.health = 100;
        this.gold = 10;
        this.currentRoom = "entrance";
        this.isRunning = true;
        this.inventory = new HashMap<>();
        this.rooms = new HashMap<>();
        this.scanner = new Scanner(System.in);
    }

    public void setup() {
        System.out.println("========================================");
        System.out.println("   Welcome to the Dungeon, " + name + "!");
        System.out.println("========================================");
        System.out.println("You are an adventurer seeking treasure.");
        System.out.println("Commands: go [north/south/east/west], look, inventory, quit");
        System.out.println();

        // Define rooms: { description, north, south, east, west, item, enemy }
        rooms.put("entrance", new String[]{
            "You stand at the dungeon entrance. Torches flicker on the walls.",
            "hallway", null, null, null, "torch", null
        });
        rooms.put("hallway", new String[]{
            "A long hallway stretches before you. You hear dripping water.",
            "treasury", "entrance", "library", "armory", "key", null
        });
        rooms.put("library", new String[]{
            "Dusty bookshelves line the walls. A strange book glows faintly.",
            null, null, null, "hallway", "spellbook", "ghost"
        });
        rooms.put("armory", new String[]{
            "Weapons and armor hang on every wall. A sword catches your eye.",
            null, null, "hallway", null, "sword", "skeleton"
        });
        rooms.put("treasury", new String[]{
            "Gold coins glitter everywhere! This is what you came for!",
            null, "hallway", null, null, "treasure", "dragon"
        });

        System.out.println("You begin your adventure at the dungeon entrance...");
        System.out.println();
    }

    public void run() {
        while (isRunning && health > 0) {
            String[] roomData = rooms.get(currentRoom);
            System.out.println("[" + currentRoom.toUpperCase() + "] HP: " + health + " | Gold: " + gold);
            System.out.print("> ");

            String input = scanner.nextLine().trim().toLowerCase();
            String[] parts = input.split(" ");
            String command = parts[0];

            switch (command) {
                case "go":
                    if (parts.length < 2) {
                        System.out.println("Go where? Try: go north, go south, go east, go west");
                    } else {
                        move(parts[1], roomData);
                    }
                    break;

                case "look":
                    look(roomData);
                    break;

                case "take":
                    takeItem(roomData);
                    break;

                case "fight":
                    fight(roomData);
                    break;

                case "inventory":
                    showInventory();
                    break;

                case "quit":
                    System.out.println("You flee the dungeon. Farewell, " + name + "!");
                    isRunning = false;
                    break;

                default:
                    System.out.println("Unknown command. Try: go, look, take, fight, inventory, quit");
            }

            if (health <= 0) {
                System.out.println("You have been defeated! Game over.");
            }

            System.out.println();
        }
    }

    private void move(String direction, String[] roomData) {
        int dirIndex = switch (direction) {
            case "north" -> 1;
            case "south" -> 2;
            case "east"  -> 3;
            case "west"  -> 4;
            default      -> -1;
        };

        if (dirIndex == -1) {
            System.out.println("Unknown direction. Use: north, south, east, west");
            return;
        }

        String nextRoom = roomData[dirIndex];
        if (nextRoom == null) {
            System.out.println("You can't go that way — there's only a wall.");
        } else {
            currentRoom = nextRoom;
            String[] newRoomData = rooms.get(currentRoom);
            System.out.println("You move " + direction + ".");
            System.out.println(newRoomData[0]);

            if (newRoomData[6] != null) {
                System.out.println("WARNING: A " + newRoomData[6].toUpperCase() + " lurks here! Type 'fight' to battle.");
            }
        }
    }

    private void look(String[] roomData) {
        System.out.println(roomData[0]);
        if (roomData[5] != null) {
            System.out.println("You notice a " + roomData[5] + " on the ground.");
        }
        if (roomData[6] != null) {
            System.out.println("A " + roomData[6] + " eyes you menacingly.");
        }
        System.out.print("Exits: ");
        if (roomData[1] != null) System.out.print("North ");
        if (roomData[2] != null) System.out.print("South ");
        if (roomData[3] != null) System.out.print("East ");
        if (roomData[4] != null) System.out.print("West ");
        System.out.println();
    }

    private void takeItem(String[] roomData) {
        if (roomData[5] != null) {
            String item = roomData[5];
            inventory.merge(item, 1, Integer::sum);
            if (item.equals("treasure")) gold += 100;
            System.out.println("You picked up the " + item + "!");
            roomData[5] = null;
        } else {
            System.out.println("There's nothing to take here.");
        }
    }

    private void fight(String[] roomData) {
        if (roomData[6] == null) {
            System.out.println("There's nothing to fight here.");
            return;
        }

        String enemy = roomData[6];
        int enemyHP = switch (enemy) {
            case "ghost"    -> 30;
            case "skeleton" -> 50;
            case "dragon"   -> 120;
            default         -> 20;
        };

        int playerDamage = inventory.containsKey("sword") ? 25 : 10;
        System.out.println("You engage the " + enemy + " in combat!");

        while (enemyHP > 0 && health > 0) {
            enemyHP -= playerDamage;
            int enemyDamage = (int)(Math.random() * 20) + 5;
            health -= enemyDamage;
            System.out.println("You deal " + playerDamage + " damage. " +
                               enemy + " hits you for " + enemyDamage + ". " +
                               "(Enemy HP: " + Math.max(enemyHP, 0) + " | Your HP: " + Math.max(health, 0) + ")");
        }

        if (health > 0) {
            System.out.println("You defeated the " + enemy + "! Gold reward: 20");
            gold += 20;
            roomData[6] = null;
        }
    }

    private void showInventory() {
        if (inventory.isEmpty()) {
            System.out.println("Your inventory is empty.");
        } else {
            System.out.println("Inventory: " + inventory);
            System.out.println("Gold: " + gold);
        }
    }

    public void finish() {
        System.out.println();
        System.out.println("========================================");
        System.out.println("         GAME OVER — Final Stats");
        System.out.println("========================================");
        System.out.println("Adventurer : " + name);
        System.out.println("Health     : " + Math.max(health, 0));
        System.out.println("Gold       : " + gold);
        System.out.println("Items      : " + (inventory.isEmpty() ? "none" : inventory.keySet()));
        System.out.println("Thanks for playing!");
        scanner.close();
    }

    public static void main(String[] args) {
        AdventureGame game = new AdventureGame("Hero");
        game.setup();
        game.run();
        game.finish();
    }
}
