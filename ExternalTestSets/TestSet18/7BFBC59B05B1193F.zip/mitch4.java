public class SimpleClass {

    private final String name;
    private boolean isReady;
    private int stepCount;

    public SimpleClass(String name) {
        this.name = name;
        this.isReady = false;
        this.stepCount = 0;
    }

    public void setup() {
        System.out.println("Setting up for " + name + "...");
        isReady = true;
        stepCount = 0;
    }

    public void run() {
        if (!isReady) {
            System.out.println("Please call setup() first.");
            return;
        }

        System.out.println("Running process for " + name);
        for (int i = 1; i <= 5; i++) {
            System.out.println("Step " + i + " completed");
            stepCount++;
        }
    }

    public void finish() {
        if (!isReady) {
            System.out.println("Nothing to finish.");
            return;
        }

        System.out.println("Finished " + name + " with " + stepCount + " steps.");
        isReady = false;
    }

    public static void main(String[] args) {
        SimpleClass app = new SimpleClass("Josh");
        app.setup();
        app.run();
        app.finish();
    }
}
