import java.util.LinkedList;
import java.util.Queue;

public class SimpleClass {

    private final String name;
    private Queue<String> jobs;
    private boolean ready;
    private int completedJobs;

    public SimpleClass(String name) {
        this.name = name;
        this.jobs = new LinkedList<>();
        this.ready = false;
        this.completedJobs = 0;
    }

    public void setup() {
        System.out.println("Starting setup for " + name);
        jobs.offer("Connect to server");
        jobs.offer("Download records");
        jobs.offer("Validate records");
        jobs.offer("Save results");
        ready = true;
    }

    public void run() {
        if (!ready) {
            System.out.println("Call setup() before run().");
            return;
        }

        System.out.println("Running queued jobs...");
        while (!jobs.isEmpty()) {
            String currentJob = jobs.poll();
            System.out.println("Processing: " + currentJob);
            completedJobs++;
        }
    }

    public void finish() {
        System.out.println("Process finished for " + name);
        System.out.println("Completed jobs: " + completedJobs);
        ready = false;
    }

    public static void main(String[] args) {
        SimpleClass manager = new SimpleClass("QueueManager");
        manager.setup();
        manager.run();
        manager.finish();
    }
}
