import java.util.*;

/**
 * ACO-based agent skeleton
 */
public class Dan1 {

    private final String name;

    // === ACO PARAMETERS ===
    private final double alpha = 1.0; // importance of pheromone
    private final double beta = 2.0;  // importance of heuristic (distance / cost)
    private final double gamma = 2.0; // importance of availability (VERY important for your problem)

    private final double evaporationRate = 0.1;

    // Pheromone matrix: from -> to
    private Map<String, Map<String, Double>> pheromones = new HashMap<>();

    // Random for probabilistic decisions
    private Random random = new Random();

    public Dan1(String name) {
        this.name = name;
    }

    public void setup() {
        // Initialize pheromone values between "stations"
        // For now we mock station names — replace with real ones from your environment

        List<String> stations = Arrays.asList("A", "B", "C", "D");

        for (String from : stations) {
            pheromones.put(from, new HashMap<>());
            for (String to : stations) {
                if (!from.equals(to)) {
                    pheromones.get(from).put(to, 1.0); // initial pheromone
                }
            }
        }
    }

    public void run() {
        // Example: current position
        String currentStation = "A";

        // Choose next station using ACO probability
        String nextStation = chooseNextStation(currentStation);

        System.out.println(name + " moving from " + currentStation + " -> " + nextStation);

        // Simulate reward (LESS wait time = better)
        double reward = evaluateMove(currentStation, nextStation);

        // Update pheromone based on reward
        updatePheromone(currentStation, nextStation, reward);
    }

    public void finish() {
        // Optional: print pheromone map for debugging
        System.out.println("Final pheromones: " + pheromones);
    }

    /**
     * Core ACO decision function
     */
    private String chooseNextStation(String current) {

        Map<String, Double> neighbors = pheromones.get(current);

        double total = 0.0;
        Map<String, Double> probabilities = new HashMap<>();

        // Compute probabilities
        for (String next : neighbors.keySet()) {

            double tau = pheromones.get(current).get(next); // pheromone

            double heuristic = getHeuristic(current, next); // e.g. inverse distance
            double availability = getAvailability(next);    // LOW queue = HIGH value

            double value =
                    Math.pow(tau, alpha) *
                            Math.pow(heuristic, beta) *
                            Math.pow(availability, gamma);

            probabilities.put(next, value);
            total += value;
        }

        // Normalize + roulette wheel selection
        double rand = random.nextDouble() * total;
        double cumulative = 0.0;

        for (String next : probabilities.keySet()) {
            cumulative += probabilities.get(next);
            if (rand <= cumulative) {
                return next;
            }
        }

        // fallback
        return probabilities.keySet().iterator().next();
    }

    /**
     * Heuristic: prefer closer stations (you can modify this)
     */
    private double getHeuristic(String from, String to) {
        // TODO: replace with real distance
        return 1.0; // placeholder
    }

    /**
     * Availability: THIS is key for your competition
     * Less busy station = higher value
     */
    private double getAvailability(String station) {
        // TODO: replace with actual queue length
        int queueLength = random.nextInt(5) + 1;

        return 1.0 / queueLength; // smaller queue = better
    }

    /**
     * Reward function (lower wait time = better)
     */
    private double evaluateMove(String from, String to) {
        // Simulate wait time (lower is better)
        double waitTime = random.nextDouble() * 10;

        return 1.0 / (1.0 + waitTime);
    }

    /**
     * Update pheromone trail
     */
    private void updatePheromone(String from, String to, double reward) {

        double currentPheromone = pheromones.get(from).get(to);

        // Evaporation + reinforcement
        double updated =
                (1 - evaporationRate) * currentPheromone +
                        reward;

        pheromones.get(from).put(to, updated);
    }

    public static void main(String[] args) {

        Dan1 agent = new Dan1("Dan");

        agent.setup();

        // Simulate multiple steps (important for ACO learning)
        for (int i = 0; i < 20; i++) {
            agent.run();
        }

        agent.finish();
    }
}