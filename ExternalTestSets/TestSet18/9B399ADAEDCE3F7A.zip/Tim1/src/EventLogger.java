import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class EventLogger {

    private final List<String> events;

    public EventLogger() {
        this.events = new ArrayList<>();
    }

    public void log(String message) {
        events.add(format(message));
    }

    private String format(String message) {
        return LocalDateTime.now() + " :: " + message;
    }

    public List<String> getEvents() {
        return Collections.unmodifiableList(events);
    }
}