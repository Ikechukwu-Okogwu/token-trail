import java.util.ArrayList;
import java.util.List;

public class LifecycleController {

    private final String name;
    private final EventLogger logger;
    private Status status;
    private int runCount;

    public LifecycleController(String name) {
        this.name = name;
        this.logger = new EventLogger();
        this.status = Status.NEW;
        this.runCount = 0;
    }

    public void setup() {
        validate(StateRule.SETUP_ALLOWED);
        logger.log("Setup started for " + name);
        status = Status.SETUP;
        logger.log("Setup finished");
    }

    public void run() {
        validate(StateRule.RUN_ALLOWED);
        status = Status.RUNNING;
        logger.log("Run started");

        for (int i = 0; i < 5; i++) {
            runCount++;
            logger.log("Running iteration " + i);
        }

        logger.log("Run ended with count=" + runCount);
    }

    public void finish() {
        validate(StateRule.FINISH_ALLOWED);
        status = Status.FINISHED;
        logger.log("Finish completed");
    }

    public List<String> getEvents() {
        return new ArrayList<>(logger.getEvents());
    }

    private void validate(StateRule rule) {
        if (!rule.isAllowed(status)) {
            throw new IllegalStateException(
                    "Invalid state " + status + " for rule " + rule
            );
        }
    }
}