import java.util.List;

public class SimpleClass {

    private final String name;
    private final LifecycleController controller;

    public SimpleClass(String name) {
        this.name = name;
        this.controller = new LifecycleController(name);
    }

    public void setup() {
        controller.setup();
    }

    public void run() {
        controller.run();
    }

    public void finish() {
        controller.finish();
    }

    public List<String> getEvents() {
        return controller.getEvents();
    }

    public static void main(String[] args) {
        SimpleClass instance = new SimpleClass("MultiFileTest");

        instance.setup();
        instance.run();
        instance.finish();

        for (String event : instance.getEvents()) {
            System.out.println(event);
        }
    }
}