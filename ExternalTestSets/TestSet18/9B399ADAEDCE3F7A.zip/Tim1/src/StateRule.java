import java.util.EnumSet;

public enum StateRule {

    SETUP_ALLOWED(EnumSet.of(Status.NEW)),
    RUN_ALLOWED(EnumSet.of(Status.SETUP, Status.RUNNING)),
    FINISH_ALLOWED(EnumSet.of(Status.SETUP, Status.RUNNING));

    private final EnumSet<Status> allowedStates;

    StateRule(EnumSet<Status> allowedStates) {
        this.allowedStates = allowedStates;
    }

    public boolean isAllowed(Status status) {
        return allowedStates.contains(status);
    }
}