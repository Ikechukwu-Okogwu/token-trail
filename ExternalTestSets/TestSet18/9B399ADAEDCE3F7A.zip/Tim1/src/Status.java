public enum Status {
    NEW,
    SETUP,
    RUNNING,
    FINISHED,
    ERROR
}