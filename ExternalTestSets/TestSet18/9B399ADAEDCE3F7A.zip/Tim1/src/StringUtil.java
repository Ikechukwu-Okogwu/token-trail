public final class StringUtil {

    private StringUtil() {
        // utility class
    }

    public static boolean isBlank(String value) {
        if (value == null) {
            return true;
        }

        for (int i = 0; i < value.length(); i++) {
            if (!Character.isWhitespace(value.charAt(i))) {
                return false;
            }
        }
        return true;
    }

    public static String normalize(String input) {
        return input == null ? "" : input.trim().toLowerCase();
    }
}