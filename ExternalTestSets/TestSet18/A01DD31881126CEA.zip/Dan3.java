import java.util.*;

/**
 * Neural Network-based agent
 */
public class Dan3 {

    private final String name;
    private Random random = new Random();

    // === NETWORK STRUCTURE ===
    private final int inputSize = 4;    // e.g. queue sizes of 4 stations
    private final int hiddenSize = 8;
    private final int outputSize = 4;   // one output per station

    private final double learningRate = 0.01;

    // Weights
    private double[][] W1 = new double[inputSize][hiddenSize];
    private double[][] W2 = new double[hiddenSize][outputSize];

    public Dan3(String name) {
        this.name = name;
    }

    public void setup() {
        // Initialize weights randomly
        for (int i = 0; i < inputSize; i++) {
            for (int j = 0; j < hiddenSize; j++) {
                W1[i][j] = random.nextDouble() - 0.5;
            }
        }

        for (int i = 0; i < hiddenSize; i++) {
            for (int j = 0; j < outputSize; j++) {
                W2[i][j] = random.nextDouble() - 0.5;
            }
        }
    }

    public void run() {

        // === INPUT: current environment ===
        double[] input = getState(); // e.g. queue lengths

        // === FORWARD PASS ===
        double[] hidden = new double[hiddenSize];
        double[] output = new double[outputSize];

        // Input -> Hidden
        for (int j = 0; j < hiddenSize; j++) {
            double sum = 0;
            for (int i = 0; i < inputSize; i++) {
                sum += input[i] * W1[i][j];
            }
            hidden[j] = relu(sum);
        }

        // Hidden -> Output
        for (int j = 0; j < outputSize; j++) {
            double sum = 0;
            for (int i = 0; i < hiddenSize; i++) {
                sum += hidden[i] * W2[i][j];
            }
            output[j] = sum; // raw score
        }

        // === CHOOSE ACTION ===
        int chosenStation = argMax(output);

        System.out.println(name + " chooses station: " + chosenStation);

        // === GET REWARD ===
        double reward = getReward(chosenStation);

        // === TRAIN (simple backprop) ===
        train(input, hidden, output, chosenStation, reward);
    }

    public void finish() {
        System.out.println("Training complete.");
    }

    /**
     * Simulated environment input
     * Replace with real queue sizes
     */
    private double[] getState() {
        double[] state = new double[inputSize];

        for (int i = 0; i < inputSize; i++) {
            int queue = random.nextInt(5) + 1;
            state[i] = 1.0 / queue; // smaller queue = bigger value
        }

        return state;
    }

    /**
     * Reward function
     */
    private double getReward(int station) {
        double waitTime = random.nextDouble() * 10;
        return 1.0 / (1.0 + waitTime);
    }

    /**
     * Backpropagation (simple version)
     */
    private void train(double[] input, double[] hidden, double[] output, int action, double reward) {

        // Target: we want chosen action to match reward
        double[] target = new double[outputSize];
        target[action] = reward;

        // === OUTPUT LAYER ERROR ===
        double[] outputError = new double[outputSize];
        for (int i = 0; i < outputSize; i++) {
            outputError[i] = target[i] - output[i];
        }

        // === UPDATE W2 ===
        for (int i = 0; i < hiddenSize; i++) {
            for (int j = 0; j < outputSize; j++) {
                W2[i][j] += learningRate * outputError[j] * hidden[i];
            }
        }

        // === HIDDEN LAYER ERROR ===
        double[] hiddenError = new double[hiddenSize];

        for (int i = 0; i < hiddenSize; i++) {
            double sum = 0;
            for (int j = 0; j < outputSize; j++) {
                sum += outputError[j] * W2[i][j];
            }
            hiddenError[i] = sum * reluDerivative(hidden[i]);
        }

        // === UPDATE W1 ===
        for (int i = 0; i < inputSize; i++) {
            for (int j = 0; j < hiddenSize; j++) {
                W1[i][j] += learningRate * hiddenError[j] * input[i];
            }
        }
    }

    private double relu(double x) {
        return Math.max(0, x);
    }

    private double reluDerivative(double x) {
        return x > 0 ? 1 : 0;
    }

    private int argMax(double[] arr) {
        int best = 0;
        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > arr[best]) {
                best = i;
            }
        }
        return best;
    }

    public static void main(String[] args) {

        Dan3 agent = new Dan3("Dan");

        agent.setup();

        for (int i = 0; i < 100; i++) {
            agent.run();
        }

        agent.finish();
    }
}