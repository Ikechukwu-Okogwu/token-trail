import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class GradeTracker {

    private final String name; // teacher/course name
    private Map<String, List<Double>> studentGrades;
    private List<String> studentNames;
    private Scanner scanner;
    private boolean isRunning;
    private String[] categories;

    public GradeTracker(String name) {
        this.name = name;
        this.studentGrades = new HashMap<>();
        this.studentNames = new ArrayList<>();
        this.scanner = new Scanner(System.in);
        this.isRunning = true;
        this.categories = new String[]{"Assignments", "Midterm", "Final", "Participation"};
    }

    public void setup() {
        System.out.println("============================================");
        System.out.println("   Grade Tracker — Course: " + name);
        System.out.println("============================================");
        System.out.println("Grade categories (out of 100 each):");
        for (int i = 0; i < categories.length; i++) {
            System.out.println("  [" + i + "] " + categories[i]);
        }
        System.out.println();
        System.out.println("Commands:");
        System.out.println("  add <StudentName>         — Add a new student");
        System.out.println("  grade <StudentName>       — Enter grades for a student");
        System.out.println("  report <StudentName>      — View a student's full report");
        System.out.println("  list                      — List all students and averages");
        System.out.println("  top                       — Show highest-performing student");
        System.out.println("  failing                   — List students below 50%");
        System.out.println("  quit                      — Exit the tracker");
        System.out.println();
    }

    public void run() {
        System.out.println("Grade Tracker is ready. Enter a command:");
        while (isRunning) {
            System.out.print("\n> ");
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) continue;

            String[] parts = input.split(" ", 2);
            String command = parts[0].toLowerCase();
            String argument = parts.length > 1 ? parts[1].trim() : "";

            switch (command) {
                case "add"     -> addStudent(argument);
                case "grade"   -> enterGrades(argument);
                case "report"  -> printReport(argument);
                case "list"    -> listAll();
                case "top"     -> showTopStudent();
                case "failing" -> showFailingStudents();
                case "quit"    -> isRunning = false;
                default        -> System.out.println("Unknown command. See setup for available commands.");
            }
        }
    }

    private void addStudent(String studentName) {
        if (studentName.isEmpty()) {
            System.out.println("Please provide a name. Usage: add <StudentName>");
            return;
        }
        if (studentGrades.containsKey(studentName)) {
            System.out.println(studentName + " is already in the system.");
            return;
        }
        studentGrades.put(studentName, new ArrayList<>());
        studentNames.add(studentName);
        System.out.println("Added student: " + studentName);
    }

    private void enterGrades(String studentName) {
        if (!studentGrades.containsKey(studentName)) {
            System.out.println("Student not found: " + studentName + ". Use 'add' first.");
            return;
        }

        List<Double> grades = studentGrades.get(studentName);
        grades.clear();
        System.out.println("Enter grades for " + studentName + " (0–100):");

        for (String category : categories) {
            double grade = -1;
            while (grade < 0 || grade > 100) {
                System.out.print("  " + category + ": ");
                try {
                    grade = Double.parseDouble(scanner.nextLine().trim());
                    if (grade < 0 || grade > 100) {
                        System.out.println("  Please enter a value between 0 and 100.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("  Invalid input. Enter a number.");
                    grade = -1;
                }
            }
            grades.add(grade);
        }

        System.out.printf("Grades saved for %s. Average: %.1f%% (%s)%n",
            studentName, calculateAverage(grades), letterGrade(calculateAverage(grades)));
    }

    private void printReport(String studentName) {
        if (!studentGrades.containsKey(studentName)) {
            System.out.println("Student not found: " + studentName);
            return;
        }

        List<Double> grades = studentGrades.get(studentName);
        System.out.println();
        System.out.println("  --- Report for " + studentName + " ---");

        if (grades.isEmpty()) {
            System.out.println("  No grades recorded yet.");
            return;
        }

        for (int i = 0; i < categories.length; i++) {
            System.out.printf("  %-16s : %5.1f%%%n", categories[i], grades.get(i));
        }

        double avg = calculateAverage(grades);
        System.out.println("  --------------------------------");
        System.out.printf("  %-16s : %5.1f%%  (%s)%n", "AVERAGE", avg, letterGrade(avg));
        System.out.println();
    }

    private void listAll() {
        if (studentNames.isEmpty()) {
            System.out.println("No students added yet.");
            return;
        }

        System.out.println();
        System.out.printf("  %-20s %-10s %-6s%n", "Student", "Average", "Grade");
        System.out.println("  " + "-".repeat(38));
        for (String student : studentNames) {
            List<Double> grades = studentGrades.get(student);
            if (grades.isEmpty()) {
                System.out.printf("  %-20s %-10s %-6s%n", student, "N/A", "N/A");
            } else {
                double avg = calculateAverage(grades);
                System.out.printf("  %-20s %-10.1f %-6s%n", student, avg, letterGrade(avg));
            }
        }
    }

    private void showTopStudent() {
        String top = null;
        double topAvg = -1;

        for (String student : studentNames) {
            List<Double> grades = studentGrades.get(student);
            if (!grades.isEmpty()) {
                double avg = calculateAverage(grades);
                if (avg > topAvg) {
                    topAvg = avg;
                    top = student;
                }
            }
        }

        if (top == null) {
            System.out.println("No grades recorded yet.");
        } else {
            System.out.printf("Top student: %s with %.1f%% (%s)%n", top, topAvg, letterGrade(topAvg));
        }
    }

    private void showFailingStudents() {
        boolean found = false;
        System.out.println("Students below 50%:");
        for (String student : studentNames) {
            List<Double> grades = studentGrades.get(student);
            if (!grades.isEmpty() && calculateAverage(grades) < 50) {
                System.out.printf("  %s — %.1f%%%n", student, calculateAverage(grades));
                found = true;
            }
        }
        if (!found) System.out.println("  None — great work!");
    }

    private double calculateAverage(List<Double> grades) {
        double sum = 0;
        for (double g : grades) sum += g;
        return grades.isEmpty() ? 0 : sum / grades.size();
    }

    private String letterGrade(double avg) {
        if (avg >= 90) return "A";
        if (avg >= 80) return "B";
        if (avg >= 70) return "C";
        if (avg >= 60) return "D";
        return "F";
    }

    public void finish() {
        System.out.println();
        System.out.println("============================================");
        System.out.println("   End of Session — " + name);
        System.out.println("============================================");
        System.out.println("Total students tracked: " + studentNames.size());

        long graded = studentNames.stream()
            .filter(s -> !studentGrades.get(s).isEmpty())
            .count();
        System.out.println("Students with grades  : " + graded);

        if (graded > 0) {
            double classAvg = studentNames.stream()
                .filter(s -> !studentGrades.get(s).isEmpty())
                .mapToDouble(s -> calculateAverage(studentGrades.get(s)))
                .average()
                .orElse(0);
            System.out.printf("Class average         : %.1f%% (%s)%n", classAvg, letterGrade(classAvg));
        }

        System.out.println("Goodbye!");
        scanner.close();
    }

    public static void main(String[] args) {
        GradeTracker tracker = new GradeTracker("Introduction to Computer Science");
        tracker.setup();
        tracker.run();
        tracker.finish();
    }
}
