import java.util.ArrayList;
import java.util.List;

public class Engine {

    private final ExecutionContext context;
    private final List<Step> steps;

    public Engine(ExecutionContext context) {
        this.context = context;
        this.steps = new ArrayList<>();
    }

    public void addStep(Step step) {
        steps.add(step);
    }

    public void executeAll() {
        for (Step step : steps) {
            if (!step.allowed(context)) {
                throw new IllegalStateException(
                        "Step not allowed: " + step.name()
                );
            }
            step.run(context);
        }
    }
}