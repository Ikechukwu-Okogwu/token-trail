import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ExecutionContext {

    private final String identifier;
    private final List<String> logEntries;

    private boolean initialized;
    private boolean executed;
    private boolean completed;

    public ExecutionContext(String identifier) {
        this.identifier = identifier;
        this.logEntries = new ArrayList<>();
        this.initialized = false;
        this.executed = false;
        this.completed = false;
    }

    public void markInitialized() {
        initialized = true;
        log("Initialized");
    }

    public void markExecuted() {
        executed = true;
        log("Executed");
    }

    public void markCompleted() {
        completed = true;
        log("Completed");
    }

    public boolean isInitialized() {
        return initialized;
    }

    public boolean isExecuted() {
        return executed;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void log(String message) {
        logEntries.add(Instant.now() + " | " + identifier + " | " + message);
    }

    public List<String> logs() {
        return Collections.unmodifiableList(logEntries);
    }
}