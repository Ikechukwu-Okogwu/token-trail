public class InitStep implements Step {

    @Override
    public boolean allowed(ExecutionContext context) {
        return !context.isInitialized();
    }

    @Override
    public void run(ExecutionContext context) {
        context.log("Allocating resources");
        context.markInitialized();
    }

    @Override
    public String name() {
        return "InitializationStep";
    }
}