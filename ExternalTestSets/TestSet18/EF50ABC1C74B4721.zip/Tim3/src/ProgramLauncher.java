import java.util.List;

public class ProgramLauncher {

    public static void main(String[] args) {
        ExecutionContext context = new ExecutionContext("ExtremeVariant");

        Engine engine = new Engine(context);
        engine.addStep(new InitStep());
        engine.addStep(new WorkStep());
        engine.addStep(new ShutdownStep());

        engine.executeAll();

        for (String log : context.logs()) {
            System.out.println(log);
        }
    }
}