public class ShutdownStep implements Step {

    @Override
    public boolean allowed(ExecutionContext context) {
        return context.isExecuted() && !context.isCompleted();
    }

    @Override
    public void run(ExecutionContext context) {
        context.log("Releasing resources");
        context.markCompleted();
    }

    @Override
    public String name() {
        return "ShutdownStep";
    }
}