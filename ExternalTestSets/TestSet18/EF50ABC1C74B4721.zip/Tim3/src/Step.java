public interface Step {

    boolean allowed(ExecutionContext context);

    void run(ExecutionContext context);

    String name();
}