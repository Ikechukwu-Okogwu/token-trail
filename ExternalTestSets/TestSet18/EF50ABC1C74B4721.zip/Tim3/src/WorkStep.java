public class WorkStep implements Step {

    @Override
    public boolean allowed(ExecutionContext context) {
        return context.isInitialized() && !context.isExecuted();
    }

    @Override
    public void run(ExecutionContext context) {
        for (int i = 1; i <= 5; i++) {
            context.log("Processing unit " + i);
        }
        context.markExecuted();
    }

    @Override
    public String name() {
        return "ExecutionStep";
    }
}