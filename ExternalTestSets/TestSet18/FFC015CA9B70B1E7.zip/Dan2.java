import java.util.*;

/**
 * PSO-based agent
 */
public class Dan2 {

    private final String name;

    // === PSO PARAMETERS ===
    private final int numParticles = 10;
    private final int numStations = 4;

    private final double w = 0.5;   // inertia (momentum)
    private final double c1 = 1.5;  // cognitive (self best)
    private final double c2 = 1.5;  // social (global best)

    private Random random = new Random();

    // Particle structure
    class Particle {
        double[] position;     // preference for each station
        double[] velocity;

        double[] bestPosition;
        double bestFitness;

        Particle() {
            position = new double[numStations];
            velocity = new double[numStations];
            bestPosition = new double[numStations];

            for (int i = 0; i < numStations; i++) {
                position[i] = random.nextDouble();   // random preference
                velocity[i] = random.nextDouble() - 0.5;
                bestPosition[i] = position[i];
            }

            bestFitness = Double.NEGATIVE_INFINITY;
        }
    }

    private List<Particle> swarm = new ArrayList<>();
    private double[] globalBestPosition = new double[numStations];
    private double globalBestFitness = Double.NEGATIVE_INFINITY;

    public Dan2(String name) {
        this.name = name;
    }

    public void setup() {
        // Initialize swarm
        for (int i = 0; i < numParticles; i++) {
            swarm.add(new Particle());
        }
    }

    public void run() {

        // === Evaluate particles ===
        for (Particle p : swarm) {

            double fitness = evaluateParticle(p.position);

            // Update personal best
            if (fitness > p.bestFitness) {
                p.bestFitness = fitness;
                p.bestPosition = p.position.clone();
            }

            // Update global best
            if (fitness > globalBestFitness) {
                globalBestFitness = fitness;
                globalBestPosition = p.position.clone();
            }
        }

        // === Update velocities + positions ===
        for (Particle p : swarm) {
            for (int i = 0; i < numStations; i++) {

                double r1 = random.nextDouble();
                double r2 = random.nextDouble();

                p.velocity[i] =
                        w * p.velocity[i]
                                + c1 * r1 * (p.bestPosition[i] - p.position[i])
                                + c2 * r2 * (globalBestPosition[i] - p.position[i]);

                p.position[i] += p.velocity[i];
            }
        }

        // === Choose best station from global best ===
        int bestStation = argMax(globalBestPosition);

        System.out.println(name + " chooses station: " + bestStation);
    }

    public void finish() {
        System.out.println("Best solution found: " + Arrays.toString(globalBestPosition));
    }

    /**
     * Fitness = minimize wait time
     * (higher fitness = better)
     */
    private double evaluateParticle(double[] position) {

        // Convert position -> station choice
        int station = argMax(position);

        double waitTime = getWaitTime(station);

        // Lower wait = higher fitness
        return 1.0 / (1.0 + waitTime);
    }

    /**
     * Simulated wait time (REPLACE THIS)
     */
    private double getWaitTime(int station) {
        return random.nextDouble() * 10;
    }

    /**
     * Get index of max value
     */
    private int argMax(double[] arr) {
        int bestIndex = 0;
        double bestValue = arr[0];

        for (int i = 1; i < arr.length; i++) {
            if (arr[i] > bestValue) {
                bestValue = arr[i];
                bestIndex = i;
            }
        }

        return bestIndex;
    }

    public static void main(String[] args) {

        Dan1 agent = new Dan1("Dan");

        agent.setup();

        for (int i = 0; i < 20; i++) {
            agent.run();
        }

        agent.finish();
    }
}