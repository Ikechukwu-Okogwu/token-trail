package bfs;



import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Immutable result object produced by a BFS traversal.
 *
 * <p>Captures everything discovered during the search:
 * <ul>
 *   <li>The order in which vertices were first visited</li>
 *   <li>The BFS level (hop distance from source) of each vertex</li>
 *   <li>The BFS parent tree (predecessor of each vertex on the shortest unweighted path)</li>
 *   <li>Which vertices were unreachable from the source</li>
 * </ul>
 *
 * <p>Note: BFS levels represent <em>hop count</em> (number of edges), not weighted distance.
 * For weighted shortest paths, use Dijkstra's algorithm instead.
 */
public class BfsResult {

    private final Vertex source;
    private final List<Vertex> visitOrder;        // vertices in BFS discovery order
    private final Map<Integer, Integer> levels;   // vertexId -> BFS level (hop distance)
    private final Map<Integer, Vertex> parents;   // vertexId -> BFS tree parent
    private final List<Vertex> unreachable;       // vertices not reachable from source

    /**
     * Constructs a BfsResult. Called internally by {@link BreadthFirstSearch}.
     */
    BfsResult(Vertex source,
              List<Vertex> visitOrder,
              Map<Integer, Integer> levels,
              Map<Integer, Vertex> parents,
              List<Vertex> unreachable) {
        this.source     = source;
        this.visitOrder = Collections.unmodifiableList(new ArrayList<>(visitOrder));
        this.levels     = Collections.unmodifiableMap(new HashMap<>(levels));
        this.parents    = Collections.unmodifiableMap(new HashMap<>(parents));
        this.unreachable = Collections.unmodifiableList(new ArrayList<>(unreachable));
    }

    // ---------------------------------------------------------------
    // Core accessors
    // ---------------------------------------------------------------

    /** Returns the source vertex this BFS was run from. */
    public Vertex getSource() { return source; }

    /** Returns the vertices in the order they were first discovered by BFS. */
    public List<Vertex> getVisitOrder() { return visitOrder; }

    /** Returns the BFS level (hop distance) of the given vertex, or -1 if unreachable. */
    public int getLevel(int vertexId) {
        return levels.getOrDefault(vertexId, -1);
    }

    /** Returns the BFS tree parent of the given vertex, or null if it is the source/unreachable. */
    public Vertex getParent(int vertexId) {
        return parents.get(vertexId);
    }

    /** Returns all vertices that could not be reached from the source. */
    public List<Vertex> getUnreachable() { return unreachable; }

    /** Returns true if the given vertex was reached during this BFS. */
    public boolean isReachable(int vertexId) {
        return levels.containsKey(vertexId);
    }

    // ---------------------------------------------------------------
    // Path reconstruction
    // ---------------------------------------------------------------

    /**
     * Reconstructs the shortest unweighted path from the source to the target
     * by walking up the BFS parent tree.
     *
     * @param targetId destination vertex ID
     * @return ordered list of vertices from source to target, or empty if unreachable
     */
    public List<Vertex> getPathTo(int targetId) {
        if (!isReachable(targetId)) return Collections.emptyList();

        List<Vertex> path = new ArrayList<>();
        Vertex current = findInVisitOrder(targetId);
        if (current == null) return Collections.emptyList();

        // Walk up the parent chain
        while (current != null) {
            path.add(current);
            Vertex parent = parents.get(current.getId());
            current = parent;
        }

        Collections.reverse(path);
        return path;
    }

    /**
     * Returns a human-readable path string to the given vertex.
     * Example: "A -> C -> E  (2 hops)"
     */
    public String getPathString(int targetId) {
        List<Vertex> path = getPathTo(targetId);
        if (path.isEmpty()) {
            return source.getLabel() + " -> " + targetId + "  [UNREACHABLE]";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.size(); i++) {
            sb.append(path.get(i).getLabel());
            if (i < path.size() - 1) sb.append(" -> ");
        }
        int hops = path.size() - 1;
        sb.append("  (").append(hops).append(hops == 1 ? " hop)" : " hops)");
        return sb.toString();
    }

    // ---------------------------------------------------------------
    // Level grouping
    // ---------------------------------------------------------------

    /**
     * Returns all vertices at a specific BFS level (i.e., exactly {@code level} hops
     * from the source).
     *
     * @param level the hop distance from the source
     * @return list of vertices at that level, in visit order
     */
    public List<Vertex> getVerticesAtLevel(int level) {
        List<Vertex> result = new ArrayList<>();
        for (Vertex v : visitOrder) {
            if (levels.getOrDefault(v.getId(), -1) == level) {
                result.add(v);
            }
        }
        return result;
    }

    /**
     * Returns the maximum BFS level reached (i.e., the eccentricity of the source
     * with respect to reachable vertices).
     */
    public int getMaxLevel() {
        return levels.values().stream().mapToInt(Integer::intValue).max().orElse(0);
    }

    // ---------------------------------------------------------------
    // Helpers
    // ---------------------------------------------------------------

    private Vertex findInVisitOrder(int id) {
        for (Vertex v : visitOrder) {
            if (v.getId() == id) return v;
        }
        // Also check unreachable (shouldn't be needed but defensive)
        for (Vertex v : unreachable) {
            if (v.getId() == id) return v;
        }
        return null;
    }

    // ---------------------------------------------------------------
    // Summary printing
    // ---------------------------------------------------------------

    /**
     * Prints a compact summary of the BFS result to stdout.
     */
    public void printSummary() {
        System.out.println("--- BFS Result Summary ---");
        System.out.printf("Source   : %s%n", source.getLabel());
        System.out.printf("Reached  : %d vertices%n", visitOrder.size());
        System.out.printf("Max level: %d hops%n", getMaxLevel());

        System.out.println("\nVisit order:");
        for (int i = 0; i < visitOrder.size(); i++) {
            Vertex v = visitOrder.get(i);
            int lvl = levels.getOrDefault(v.getId(), -1);
            Vertex parent = parents.get(v.getId());
            String parentLabel = (parent == null) ? "—" : parent.getLabel();
            System.out.printf("  %2d. %-10s  level=%d  parent=%s%n",
                i + 1, v.getLabel(), lvl, parentLabel);
        }

        if (!unreachable.isEmpty()) {
            System.out.println("\nUnreachable vertices:");
            for (Vertex v : unreachable) {
                System.out.println("  - " + v.getLabel());
            }
        }
        System.out.println();
    }
}
