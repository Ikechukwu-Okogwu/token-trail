package bfs;





import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

/**
 * Breadth-First Search (BFS) on a {@link dijkstra.Graph}.
 *
 * <p>BFS explores a graph level by level, starting from a source vertex and
 * visiting all neighbours at the current hop distance before moving deeper.
 * It uses a FIFO queue as its frontier.
 *
 * <p>Key properties of BFS:
 * <ul>
 *   <li>Finds the <em>shortest path in terms of hop count</em> (not edge weight)</li>
 *   <li>Visits every reachable vertex exactly once</li>
 *   <li>Produces a BFS tree (spanning tree of reachable vertices)</li>
 *   <li>Time complexity:  O(V + E)</li>
 *   <li>Space complexity: O(V) for the queue and visited set</li>
 * </ul>
 *
 * <p>This class reuses {@link dijkstra.Graph}, {@link dijkstra.Vertex}, and
 * {@link dijkstra.Edge} directly from the Dijkstra package — no copying needed.
 */
public class BreadthFirstSearch {

    private final Graph graph;
    private final boolean verbose;

    /**
     * Constructs a BFS runner for the given graph.
     *
     * @param graph   the graph to traverse (from the dijkstra package)
     * @param verbose if true, prints each step to stdout during traversal
     */
    public BreadthFirstSearch(Graph graph, boolean verbose) {
        this.graph = graph;
        this.verbose = verbose;
    }

    /**
     * Runs BFS from the specified source vertex and returns a full {@link BfsResult}.
     *
     * @param sourceId the ID of the starting vertex
     * @return a BfsResult containing visit order, levels, parents, and unreachable vertices
     */
    public BfsResult run(int sourceId) {
        Vertex source = graph.getVertex(sourceId);

        // Data structures
        Queue<Vertex> queue       = new LinkedList<>();
        Set<Integer>  visited     = new HashSet<>();
        List<Vertex>  visitOrder  = new ArrayList<>();
        Map<Integer, Integer> levels  = new HashMap<>();
        Map<Integer, Vertex>  parents = new HashMap<>();

        // Initialise with source
        queue.offer(source);
        visited.add(source.getId());
        levels.put(source.getId(), 0);
        parents.put(source.getId(), null); // source has no parent

        if (verbose) {
            System.out.println("=== Breadth-First Search ===");
            System.out.printf("Source: %s%n", source.getLabel());
            System.out.println("----------------------------");
            System.out.printf("%-6s  %-12s  %-8s  %-12s  %s%n",
                "Step", "Dequeue", "Level", "Parent", "Enqueue neighbours");
            System.out.println("─".repeat(72));
        }

        int step = 0;

        while (!queue.isEmpty()) {
            Vertex current = queue.poll();
            visitOrder.add(current);
            step++;

            int currentLevel = levels.get(current.getId());
            List<String> enqueuedNames = new ArrayList<>();

            // Explore neighbours in adjacency-list order
            for (Edge edge : graph.getEdgesFrom(current.getId())) {
                Vertex neighbour = edge.getDestination();

                if (!visited.contains(neighbour.getId())) {
                    visited.add(neighbour.getId());
                    queue.offer(neighbour);
                    levels.put(neighbour.getId(), currentLevel + 1);
                    parents.put(neighbour.getId(), current);
                    enqueuedNames.add(neighbour.getLabel());
                }
            }

            if (verbose) {
                String enqueued = enqueuedNames.isEmpty() ? "(none)" : String.join(", ", enqueuedNames);
                Vertex parent = parents.get(current.getId());
                String parentLabel = (parent == null) ? "—" : parent.getLabel();
                System.out.printf("%-6d  %-12s  %-8d  %-12s  %s%n",
                    step,
                    current.getLabel(),
                    currentLevel,
                    parentLabel,
                    enqueued
                );
            }
        }

        // Collect unreachable vertices
        List<Vertex> unreachable = new ArrayList<>();
        for (Vertex v : graph.getVertices()) {
            if (!visited.contains(v.getId())) {
                unreachable.add(v);
            }
        }

        if (verbose) {
            System.out.println("─".repeat(72));
            System.out.printf("Complete. Visited %d/%d vertices.%n",
                visitOrder.size(), graph.getVertexCount());
            if (!unreachable.isEmpty()) {
                List<String> names = new ArrayList<>();
                for (Vertex v : unreachable) names.add(v.getLabel());
                System.out.println("Unreachable: " + String.join(", ", names));
            }
            System.out.println();
        }

        return new BfsResult(source, visitOrder, levels, parents, unreachable);
    }

    /**
     * Runs a multi-source BFS — all sources are placed on the queue at level 0
     * simultaneously. Useful for finding the closest source to every other vertex.
     *
     * @param sourceIds IDs of the starting vertices
     * @return a BfsResult using the first source ID as the nominal source
     */
    public BfsResult runMultiSource(int... sourceIds) {
        if (sourceIds.length == 0) {
            throw new IllegalArgumentException("At least one source ID required.");
        }

        Queue<Vertex>         queue      = new LinkedList<>();
        Set<Integer>          visited    = new HashSet<>();
        List<Vertex>          visitOrder = new ArrayList<>();
        Map<Integer, Integer> levels     = new HashMap<>();
        Map<Integer, Vertex>  parents    = new HashMap<>();

        // Seed all sources at level 0
        for (int id : sourceIds) {
            Vertex src = graph.getVertex(id);
            queue.offer(src);
            visited.add(src.getId());
            levels.put(src.getId(), 0);
            parents.put(src.getId(), null);
        }

        Vertex nominalSource = graph.getVertex(sourceIds[0]);

        if (verbose) {
            System.out.println("=== Multi-Source BFS ===");
            List<String> srcNames = new ArrayList<>();
            for (int id : sourceIds) srcNames.add(graph.getVertex(id).getLabel());
            System.out.println("Sources: " + String.join(", ", srcNames));
            System.out.println("------------------------");
        }

        int step = 0;
        while (!queue.isEmpty()) {
            Vertex current = queue.poll();
            visitOrder.add(current);
            step++;
            int currentLevel = levels.get(current.getId());

            for (Edge edge : graph.getEdgesFrom(current.getId())) {
                Vertex neighbour = edge.getDestination();
                if (!visited.contains(neighbour.getId())) {
                    visited.add(neighbour.getId());
                    queue.offer(neighbour);
                    levels.put(neighbour.getId(), currentLevel + 1);
                    parents.put(neighbour.getId(), current);
                }
            }

            if (verbose) {
                System.out.printf("Step %2d | Dequeue %-10s  level=%d%n",
                    step, current.getLabel(), currentLevel);
            }
        }

        List<Vertex> unreachable = new ArrayList<>();
        for (Vertex v : graph.getVertices()) {
            if (!visited.contains(v.getId())) unreachable.add(v);
        }

        if (verbose) System.out.println();

        return new BfsResult(nominalSource, visitOrder, levels, parents, unreachable);
    }
}
