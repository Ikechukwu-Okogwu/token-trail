package bfs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Represents a weighted directed graph using an adjacency list.
 * Supports both directed and undirected graphs.
 * Vertices are stored by ID for fast lookup.
 */
public class Graph {

    private final Map<Integer, Vertex> vertices;
    private final List<Edge> edges;

    // Adjacency list: vertexId -> list of outgoing edges
    private final Map<Integer, List<Edge>> adjacencyList;

    private final boolean directed;

    /**
     * Constructs an empty graph.
     *
     * @param directed true for a directed graph, false for undirected
     */
    public Graph(boolean directed) {
        this.directed = directed;
        this.vertices = new HashMap<>();
        this.edges = new ArrayList<>();
        this.adjacencyList = new HashMap<>();
    }

    /**
     * Adds a vertex to the graph.
     *
     * @param vertex the vertex to add
     * @throws IllegalArgumentException if a vertex with the same ID exists
     */
    public void addVertex(Vertex vertex) {
        if (vertices.containsKey(vertex.getId())) {
            throw new IllegalArgumentException(
                "Vertex with ID " + vertex.getId() + " already exists."
            );
        }
        vertices.put(vertex.getId(), vertex);
        adjacencyList.put(vertex.getId(), new ArrayList<>());
    }

    /**
     * Convenience method: creates and adds a vertex by ID.
     *
     * @param id    vertex ID
     * @param label vertex label
     * @return the newly created vertex
     */
    public Vertex addVertex(int id, String label) {
        Vertex v = new Vertex(id, label);
        addVertex(v);
        return v;
    }

    /**
     * Adds a weighted edge between two vertices.
     * For undirected graphs, adds edges in both directions.
     *
     * @param sourceId      ID of the source vertex
     * @param destId        ID of the destination vertex
     * @param weight        edge weight (must be non-negative)
     */
    public void addEdge(int sourceId, int destId, int weight) {
        Vertex src = getVertex(sourceId);
        Vertex dst = getVertex(destId);

        Edge forward = new Edge(src, dst, weight);
        edges.add(forward);
        adjacencyList.get(sourceId).add(forward);

        if (!directed) {
            Edge backward = new Edge(dst, src, weight);
            edges.add(backward);
            adjacencyList.get(destId).add(backward);
        }
    }

    /**
     * Retrieves a vertex by its ID.
     *
     * @param id the vertex ID
     * @return the corresponding Vertex
     * @throws IllegalArgumentException if not found
     */
    public Vertex getVertex(int id) {
        Vertex v = vertices.get(id);
        if (v == null) {
            throw new IllegalArgumentException("No vertex with ID: " + id);
        }
        return v;
    }

    /**
     * Returns all outgoing edges from the given vertex.
     *
     * @param vertexId the vertex ID
     * @return unmodifiable list of outgoing edges
     */
    public List<Edge> getEdgesFrom(int vertexId) {
        List<Edge> list = adjacencyList.get(vertexId);
        if (list == null) return Collections.emptyList();
        return Collections.unmodifiableList(list);
    }

    /**
     * Returns all vertices in the graph.
     *
     * @return unmodifiable collection of vertices
     */
    public java.util.Collection<Vertex> getVertices() {
        return Collections.unmodifiableCollection(vertices.values());
    }

    /**
     * Returns all edges in the graph.
     *
     * @return unmodifiable list of edges
     */
    public List<Edge> getEdges() {
        return Collections.unmodifiableList(edges);
    }

    public int getVertexCount() {
        return vertices.size();
    }

    public int getEdgeCount() {
        return edges.size();
    }

    public boolean isDirected() {
        return directed;
    }

    /**
     * Resets all vertices to their initial state.
     * Must be called before running Dijkstra's on a new source.
     */
    public void resetVertices() {
        for (Vertex v : vertices.values()) {
            v.reset();
        }
    }

    /**
     * Prints a simple textual representation of the graph.
     */
    public void printGraph() {
        System.out.println("Graph (" + (directed ? "directed" : "undirected") + ")");
        System.out.println("Vertices (" + getVertexCount() + "): ");
        List<Vertex> sorted = new ArrayList<>(vertices.values());
        sorted.sort((a, b) -> Integer.compare(a.getId(), b.getId()));
        for (Vertex v : sorted) {
            List<Edge> outgoing = adjacencyList.get(v.getId());
            System.out.print("  " + v.getLabel() + " -> ");
            if (outgoing.isEmpty()) {
                System.out.println("[no outgoing edges]");
            } else {
                List<String> parts = new ArrayList<>();
                for (Edge e : outgoing) {
                    parts.add(e.getDestination().getLabel() + "(" + e.getWeight() + ")");
                }
                System.out.println(String.join(", ", parts));
            }
        }
    }
}
