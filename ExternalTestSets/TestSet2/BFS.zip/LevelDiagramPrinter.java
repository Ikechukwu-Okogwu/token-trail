package bfs;



import java.util.ArrayList;
import java.util.List;

/**
 * Renders a BFS result as an ASCII level diagram.
 *
 * <p>Each row of the diagram represents one BFS level (hop distance from source).
 * Vertices at the same level are shown side by side, and edges to the next level
 * are drawn as arrows.
 *
 * <p>Example output for a small graph:
 * <pre>
 * Level 0 │  [A]
 *         │   |
 * Level 1 │  [B]  [C]
 *         │   |    |
 * Level 2 │  [D]  [E]  [F]
 * </pre>
 */
public class LevelDiagramPrinter {

    private static final int CELL_WIDTH = 12; // characters per vertex cell

    /**
     * Prints the full BFS level diagram for the given result.
     *
     * @param result the BfsResult to visualise
     */
    public void print(BfsResult result) {
        int maxLevel = result.getMaxLevel();

        System.out.println("=== BFS Level Diagram ===");
        System.out.println();

        for (int level = 0; level <= maxLevel; level++) {
            List<Vertex> atLevel = result.getVerticesAtLevel(level);

            // Print the level row
            System.out.printf("Level %-2d │ ", level);
            for (Vertex v : atLevel) {
                System.out.printf("%-" + CELL_WIDTH + "s", centreLabel(v.getLabel(), CELL_WIDTH - 2));
            }
            System.out.println();

            // Print connector row (except after the last level)
            if (level < maxLevel) {
                List<Vertex> nextLevel = result.getVerticesAtLevel(level + 1);
                printConnectors(atLevel, nextLevel, result);
            }
        }

        // Unreachable vertices
        List<Vertex> unreachable = result.getUnreachable();
        if (!unreachable.isEmpty()) {
            System.out.println();
            System.out.print("Unreachable │ ");
            for (Vertex v : unreachable) {
                System.out.printf("%-" + CELL_WIDTH + "s", centreLabel("?" + v.getLabel(), CELL_WIDTH - 2));
            }
            System.out.println();
        }

        System.out.println();
    }

    /**
     * Prints a connector row showing which current-level vertex is the BFS parent
     * of each next-level vertex.
     */
    private void printConnectors(List<Vertex> currentLevel,
                                  List<Vertex> nextLevel,
                                  BfsResult result) {
        // Build a mapping: parentId -> list of children labels at next level
        // We'll draw a simple "|" under each current-level vertex that has children
        System.out.printf("         │ ");

        for (Vertex v : currentLevel) {
            // Does this vertex have any children in the next level?
            boolean hasChild = false;
            for (Vertex child : nextLevel) {
                Vertex parent = result.getParent(child.getId());
                if (parent != null && parent.getId() == v.getId()) {
                    hasChild = true;
                    break;
                }
            }
            String connector = hasChild ? "|" : " ";
            System.out.printf("%-" + CELL_WIDTH + "s", centreLabel(connector, CELL_WIDTH - 2));
        }
        System.out.println();
    }

    /**
     * Centres a label within a field of the given width using bracket notation.
     * E.g. centreLabel("A", 8) -> "  [A]   "
     */
    private String centreLabel(String label, int width) {
        String bracketed = "[" + label + "]";
        int padding = Math.max(0, width - bracketed.length());
        int leftPad = padding / 2;
        int rightPad = padding - leftPad;
        return " ".repeat(leftPad) + bracketed + " ".repeat(rightPad);
    }

    /**
     * Prints a compact hop-distance table: from source to every reachable vertex.
     *
     * @param result the BfsResult to summarise
     */
    public void printHopTable(BfsResult result) {
        System.out.println("=== Hop Distance Table (from " + result.getSource().getLabel() + ") ===");
        System.out.printf("%-14s  %-6s  %s%n", "Destination", "Hops", "Path");
        System.out.println("─".repeat(60));

        for (Vertex v : result.getVisitOrder()) {
            int hops = result.getLevel(v.getId());
            String path = result.getPathString(v.getId());
            System.out.printf("%-14s  %-6d  %s%n", v.getLabel(), hops, path);
        }

        if (!result.getUnreachable().isEmpty()) {
            for (Vertex v : result.getUnreachable()) {
                System.out.printf("%-14s  %-6s  [unreachable]%n", v.getLabel(), "∞");
            }
        }

        System.out.println();
    }

    /**
     * Prints the BFS spanning tree — each vertex with its parent,
     * grouped by level.
     *
     * @param result the BfsResult to display
     */
    public void printSpanningTree(BfsResult result) {
        System.out.println("=== BFS Spanning Tree ===");
        int maxLevel = result.getMaxLevel();

        for (int level = 0; level <= maxLevel; level++) {
            List<Vertex> atLevel = result.getVerticesAtLevel(level);
            for (Vertex v : atLevel) {
                String indent = "  ".repeat(level);
                Vertex parent = result.getParent(v.getId());
                if (parent == null) {
                    System.out.println(indent + v.getLabel() + "  [root]");
                } else {
                    System.out.println(indent + v.getLabel()
                        + "  (via " + parent.getLabel() + ")");
                }
            }
        }
        System.out.println();
    }
}
