package bfs;




import java.util.List;

/**
 * Demonstrates Breadth-First Search reusing the Graph, Vertex, and Edge
 * classes from the dijkstra package — no modifications to those files.
 *
 * <p>Runs four scenarios:
 *   1. The exact same 6-node graph from Dijkstra Scenario 1 — compare BFS vs Dijkstra levels
 *   2. The city road network from Dijkstra Scenario 2 — BFS hop paths
 *   3. A disconnected graph — shows unreachable detection
 *   4. Multi-source BFS — simultaneous flood-fill from two sources
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║   Breadth-First Search — Demo Suite         ║");
        System.out.println("║   (reusing dijkstra.Graph / Vertex / Edge)  ║");
        System.out.println("╚══════════════════════════════════════════════╝");
        System.out.println();

        runScenario1_ClassicGraph();
        runScenario2_CityNetwork();
        runScenario3_DisconnectedGraph();
        runScenario4_MultiSource();
    }

    // -------------------------------------------------------------------
    // Scenario 1 — exact graph from Dijkstra demo, BFS from A
    // -------------------------------------------------------------------

    /**
     * Recreates the textbook graph used in Dijkstra Scenario 1.
     *
     * Edges (undirected): A-B:4, A-C:2, B-C:5, B-D:10, C-E:3, D-F:11, E-D:4, E-F:6
     *
     * BFS ignores weights — it finds the path with fewest hops, not lowest cost.
     * Compare with Dijkstra: A->D is 3 hops via BFS but cost-9 via Dijkstra (A->C->E->D).
     */
    private static void runScenario1_ClassicGraph() {
        printHeader("SCENARIO 1", "Classic Textbook Graph — BFS from A (same graph as Dijkstra demo)");

        Graph g = new Graph(false); // undirected
        g.addVertex(0, "A");
        g.addVertex(1, "B");
        g.addVertex(2, "C");
        g.addVertex(3, "D");
        g.addVertex(4, "E");
        g.addVertex(5, "F");

        g.addEdge(0, 1, 4);   // A-B
        g.addEdge(0, 2, 2);   // A-C
        g.addEdge(1, 2, 5);   // B-C
        g.addEdge(1, 3, 10);  // B-D
        g.addEdge(2, 4, 3);   // C-E
        g.addEdge(3, 5, 11);  // D-F
        g.addEdge(4, 3, 4);   // E-D
        g.addEdge(4, 5, 6);   // E-F

        g.printGraph();
        System.out.println();

        BreadthFirstSearch bfs = new BreadthFirstSearch(g, true);
        BfsResult result = bfs.run(0); // from A

        LevelDiagramPrinter printer = new LevelDiagramPrinter();
        printer.printHopTable(result);
        printer.printSpanningTree(result);
        printer.print(result);

        System.out.println("--- Path queries ---");
        System.out.println("A -> F : " + result.getPathString(5));
        System.out.println("A -> D : " + result.getPathString(3));
        System.out.println("A -> E : " + result.getPathString(4));
        System.out.println();

        System.out.println("Note: BFS finds fewest-hop paths; Dijkstra finds lowest-weight paths.");
        System.out.println("  BFS  A->D = " + result.getLevel(3) + " hops  (via " + result.getPathString(3) + ")");
        System.out.println("  Dijkstra A->D = weight 9  (A->C->E->D, 3 edges but lower total cost)");
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Scenario 2 — directed city road network from Dijkstra demo
    // -------------------------------------------------------------------

    /**
     * Recreates the directed city graph from Dijkstra Scenario 2.
     * BFS shows the minimum number of city-to-city hops, ignoring travel times.
     */
    private static void runScenario2_CityNetwork() {
        printHeader("SCENARIO 2", "City Road Network — BFS from Hamilton (directed graph)");

        Graph g = new Graph(true); // directed
        g.addVertex(0, "Hamilton");
        g.addVertex(1, "Ancaster");
        g.addVertex(2, "Dundas");
        g.addVertex(3, "Burlington");
        g.addVertex(4, "Waterdown");
        g.addVertex(5, "Oakville");
        g.addVertex(6, "Toronto");

        g.addEdge(0, 1, 12); // Hamilton -> Ancaster
        g.addEdge(0, 2, 18); // Hamilton -> Dundas
        g.addEdge(1, 3, 20); // Ancaster -> Burlington
        g.addEdge(1, 2, 7);  // Ancaster -> Dundas
        g.addEdge(2, 4, 15); // Dundas -> Waterdown
        g.addEdge(3, 5, 10); // Burlington -> Oakville
        g.addEdge(4, 3, 8);  // Waterdown -> Burlington
        g.addEdge(5, 6, 35); // Oakville -> Toronto
        g.addEdge(3, 6, 45); // Burlington -> Toronto

        g.printGraph();
        System.out.println();

        BreadthFirstSearch bfs = new BreadthFirstSearch(g, true);
        BfsResult result = bfs.run(0); // from Hamilton

        LevelDiagramPrinter printer = new LevelDiagramPrinter();
        printer.printHopTable(result);
        printer.print(result);

        System.out.println("--- Fewest-hop route to Toronto ---");
        System.out.println(result.getPathString(6));
        System.out.println();

        System.out.println("--- All BFS levels ---");
        for (int lvl = 0; lvl <= result.getMaxLevel(); lvl++) {
            List<Vertex> atLvl = result.getVerticesAtLevel(lvl);
            System.out.print("  Level " + lvl + ": ");
            for (int i = 0; i < atLvl.size(); i++) {
                System.out.print(atLvl.get(i).getLabel());
                if (i < atLvl.size() - 1) System.out.print(", ");
            }
            System.out.println();
        }
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Scenario 3 — disconnected graph from Dijkstra demo
    // -------------------------------------------------------------------

    /**
     * Recreates the disconnected directed graph from Dijkstra Scenario 3.
     * Vertex Z (id=4) has no path from S, so BFS correctly marks it unreachable.
     */
    private static void runScenario3_DisconnectedGraph() {
        printHeader("SCENARIO 3", "Disconnected Graph — BFS from S");

        Graph g = new Graph(true); // directed
        g.addVertex(0, "S");
        g.addVertex(1, "X");
        g.addVertex(2, "Y");
        g.addVertex(3, "T");
        g.addVertex(4, "Z"); // no edge from S-side to Z

        g.addEdge(0, 1, 5); // S -> X
        g.addEdge(0, 2, 9); // S -> Y
        g.addEdge(1, 3, 3); // X -> T
        g.addEdge(2, 3, 1); // Y -> T
        g.addEdge(4, 3, 2); // Z -> T  (Z not reachable from S)

        g.printGraph();
        System.out.println();

        BreadthFirstSearch bfs = new BreadthFirstSearch(g, true);
        BfsResult result = bfs.run(0); // from S

        LevelDiagramPrinter printer = new LevelDiagramPrinter();
        printer.printHopTable(result);
        printer.print(result);

        System.out.println("Attempting path to Z: " + result.getPathString(4));
        System.out.println("isReachable(Z): " + result.isReachable(4));
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Scenario 4 — multi-source BFS (new, not in Dijkstra demo)
    // -------------------------------------------------------------------

    /**
     * A larger undirected grid-like graph demonstrating multi-source BFS.
     * Two sources (A and K) flood-fill simultaneously. Each vertex is labelled
     * with the level from whichever source reached it first — showing the
     * "Voronoi regions" of each source.
     *
     * Graph:
     *   A - B - C - D
     *   |       |
     *   E - F - G
     *   |       |
     *   H - I - J - K
     */
    private static void runScenario4_MultiSource() {
        printHeader("SCENARIO 4", "Multi-Source BFS — flood fill from A and K simultaneously");

        Graph g = new Graph(false); // undirected
        g.addVertex(0,  "A");
        g.addVertex(1,  "B");
        g.addVertex(2,  "C");
        g.addVertex(3,  "D");
        g.addVertex(4,  "E");
        g.addVertex(5,  "F");
        g.addVertex(6,  "G");
        g.addVertex(7,  "H");
        g.addVertex(8,  "I");
        g.addVertex(9,  "J");
        g.addVertex(10, "K");

        // Top row
        g.addEdge(0, 1, 1);  // A-B
        g.addEdge(1, 2, 1);  // B-C
        g.addEdge(2, 3, 1);  // C-D
        // Middle row
        g.addEdge(4, 5, 1);  // E-F
        g.addEdge(5, 6, 1);  // F-G
        // Bottom row
        g.addEdge(7, 8, 1);  // H-I
        g.addEdge(8, 9, 1);  // I-J
        g.addEdge(9, 10, 1); // J-K
        // Verticals
        g.addEdge(0, 4, 1);  // A-E
        g.addEdge(2, 6, 1);  // C-G
        g.addEdge(4, 7, 1);  // E-H
        g.addEdge(6, 9, 1);  // G-J (note: was G-J, connecting middle to bottom-right area)

        g.printGraph();
        System.out.println();

        // Single-source from A first
        System.out.println("--- Single-source BFS from A ---");
        BreadthFirstSearch bfsA = new BreadthFirstSearch(g, false);
        BfsResult resultA = bfsA.run(0);
        resultA.printSummary();

        LevelDiagramPrinter printer = new LevelDiagramPrinter();
        printer.print(resultA);

        // Single-source from K
        System.out.println("--- Single-source BFS from K ---");
        BreadthFirstSearch bfsK = new BreadthFirstSearch(g, false);
        BfsResult resultK = bfsK.run(10);
        resultK.printSummary();

        // Multi-source from both A and K
        System.out.println("--- Multi-source BFS from A and K ---");
        BreadthFirstSearch bfsMulti = new BreadthFirstSearch(g, true);
        BfsResult multiResult = bfsMulti.runMultiSource(0, 10); // A=0, K=10
        multiResult.printSummary();
        printer.printHopTable(multiResult);

        System.out.println("Each vertex is labelled with distance to its nearest source (A or K).");
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Utility
    // -------------------------------------------------------------------

    private static void printHeader(String tag, String title) {
        System.out.println("══════════════════════════════════════════════════════");
        System.out.println(" " + tag + ": " + title);
        System.out.println("══════════════════════════════════════════════════════");
    }
}
