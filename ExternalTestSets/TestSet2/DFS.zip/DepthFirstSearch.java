package dfs;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Depth-First Search (DFS) on a {@link Graph}.
 *
 * <p>DFS explores as far as possible along each branch before backtracking.
 * It uses the call stack (recursive) or an explicit stack (iterative) as its frontier.
 *
 * <p>Key properties of DFS:
 * <ul>
 *   <li>Assigns discovery and finish timestamps to every vertex</li>
 *   <li>Classifies every edge as TREE, BACK, FORWARD, or CROSS</li>
 *   <li>Back edges indicate cycles</li>
 *   <li>Reverse finish order gives a topological sort (for DAGs)</li>
 *   <li>Time complexity:  O(V + E)</li>
 *   <li>Space complexity: O(V) for the recursion stack and colour map</li>
 * </ul>
 *
 * <p>{@link Graph}, {@link Vertex}, and {@link Edge} are used directly —
 * same files as the Dijkstra and BFS programs, just with {@code package dfs}.
 */
public class DepthFirstSearch {

    /** Vertex colouring used during DFS to classify edges. */
    private enum Color {
        WHITE,  // undiscovered
        GRAY,   // discovered, not yet finished (on the stack)
        BLACK   // finished
    }

    private final Graph graph;
    private final boolean verbose;

    // State shared across the recursive calls
    private int timer;
    private Map<Integer, Color>   color;
    private Map<Integer, Integer> discoveryTime;
    private Map<Integer, Integer> finishTime;
    private Map<Integer, Vertex>  parents;
    private List<Vertex>          discoveryOrder;
    private List<Vertex>          finishOrder;
    private List<DfsResult.ClassifiedEdge> classifiedEdges;
    private boolean               cycleDetected;

    /**
     * Constructs a DepthFirstSearch runner.
     *
     * @param graph   the graph to traverse
     * @param verbose if true, prints each step to stdout
     */
    public DepthFirstSearch(Graph graph, boolean verbose) {
        this.graph   = graph;
        this.verbose = verbose;
    }

    /**
     * Runs DFS from the specified source vertex.
     *
     * @param sourceId the ID of the starting vertex
     * @return a {@link DfsResult} with full traversal data
     */
    public DfsResult run(int sourceId) {
        initState();
        Vertex source = graph.getVertex(sourceId);

        if (verbose) {
            System.out.println("=== Depth-First Search ===");
            System.out.printf("Source: %s%n", source.getLabel());
            System.out.println("--------------------------");
        }

        visit(source, 0);

        // Collect unreachable vertices
        List<Vertex> unreachable = new ArrayList<>();
        for (Vertex v : graph.getVertices()) {
            if (color.get(v.getId()) == Color.WHITE) {
                unreachable.add(v);
            }
        }

        if (verbose) {
            System.out.println("--------------------------");
            System.out.printf("Complete. Visited %d/%d vertices.%n",
                discoveryOrder.size(), graph.getVertexCount());
            if (cycleDetected) System.out.println("Cycle detected (back edge found).");
            if (!unreachable.isEmpty()) {
                List<String> names = new ArrayList<>();
                for (Vertex v : unreachable) names.add(v.getLabel());
                System.out.println("Unreachable: " + String.join(", ", names));
            }
            System.out.println();
        }

        return new DfsResult(source, discoveryOrder, finishOrder,
            discoveryTime, finishTime, parents,
            classifiedEdges, unreachable, cycleDetected);
    }

    /**
     * Runs a full DFS forest — visits every vertex in the graph, starting new
     * DFS trees from any unvisited vertex after each tree is exhausted.
     * Useful for strongly-connected component analysis or full topological sort
     * over a graph that may not be fully connected from one source.
     *
     * @return a {@link DfsResult} using the lowest-ID vertex as nominal source
     */
    public DfsResult runFull() {
        initState();

        // Sort vertices by ID for deterministic ordering
        List<Vertex> sorted = new ArrayList<>(graph.getVertices());
        sorted.sort((a, b) -> Integer.compare(a.getId(), b.getId()));

        Vertex nominalSource = sorted.get(0);

        if (verbose) {
            System.out.println("=== Full DFS Forest ===");
            System.out.println("-----------------------");
        }

        for (Vertex v : sorted) {
            if (color.get(v.getId()) == Color.WHITE) {
                if (verbose) {
                    System.out.println("  [New DFS tree rooted at " + v.getLabel() + "]");
                }
                visit(v, 0);
            }
        }

        if (verbose) {
            System.out.println("-----------------------");
            System.out.printf("Complete. Visited %d/%d vertices.%n",
                discoveryOrder.size(), graph.getVertexCount());
            if (cycleDetected) System.out.println("Cycle detected (back edge found).");
            System.out.println();
        }

        return new DfsResult(nominalSource, discoveryOrder, finishOrder,
            discoveryTime, finishTime, parents,
            classifiedEdges, new ArrayList<>(), cycleDetected);
    }

    // ---------------------------------------------------------------
    // Core recursive DFS visit
    // ---------------------------------------------------------------

    /**
     * Recursively visits a vertex, assigning timestamps and classifying edges.
     *
     * @param u      the vertex to visit
     * @param depth  current recursion depth (used for indented verbose output)
     */
    private void visit(Vertex u, int depth) {
        color.put(u.getId(), Color.GRAY);
        int d = ++timer;
        discoveryTime.put(u.getId(), d);
        discoveryOrder.add(u);

        if (verbose) {
            String indent = "  ".repeat(depth);
            System.out.printf("%sDiscover %-10s  d=%2d%n", indent, u.getLabel(), d);
        }

        for (Edge edge : graph.getEdgesFrom(u.getId())) {
            Vertex v = edge.getDestination();
            Color vColor = color.get(v.getId());

            DfsResult.EdgeType type;

            if (vColor == Color.WHITE) {
                // Tree edge — v is undiscovered
                type = DfsResult.EdgeType.TREE;
                parents.put(v.getId(), u);
                classifiedEdges.add(new DfsResult.ClassifiedEdge(u, v, type));

                if (verbose) {
                    System.out.printf("%s  TREE edge  -> %s%n", "  ".repeat(depth), v.getLabel());
                }

                visit(v, depth + 1);

            } else if (vColor == Color.GRAY) {
                // Back edge — v is an ancestor (still on the stack)
                type = DfsResult.EdgeType.BACK;
                cycleDetected = true;
                classifiedEdges.add(new DfsResult.ClassifiedEdge(u, v, type));

                if (verbose) {
                    System.out.printf("%s  BACK  edge  -> %-10s  (cycle!)%n",
                        "  ".repeat(depth), v.getLabel());
                }

            } else {
                // v is BLACK (fully finished)
                int dV = discoveryTime.getOrDefault(v.getId(), -1);
                int dU = discoveryTime.getOrDefault(u.getId(), -1);

                if (graph.isDirected() && dU < dV) {
                    type = DfsResult.EdgeType.FORWARD;
                } else {
                    type = DfsResult.EdgeType.CROSS;
                }
                classifiedEdges.add(new DfsResult.ClassifiedEdge(u, v, type));

                if (verbose) {
                    System.out.printf("%s  %-7s edge  -> %s%n",
                        "  ".repeat(depth), type, v.getLabel());
                }
            }
        }

        color.put(u.getId(), Color.BLACK);
        int f = ++timer;
        finishTime.put(u.getId(), f);
        finishOrder.add(u);

        if (verbose) {
            String indent = "  ".repeat(depth);
            System.out.printf("%sFinish   %-10s  f=%2d%n", indent, u.getLabel(), f);
        }
    }

    // ---------------------------------------------------------------
    // State initialisation
    // ---------------------------------------------------------------

    private void initState() {
        timer          = 0;
        color          = new HashMap<>();
        discoveryTime  = new HashMap<>();
        finishTime     = new HashMap<>();
        parents        = new HashMap<>();
        discoveryOrder = new ArrayList<>();
        finishOrder    = new ArrayList<>();
        classifiedEdges = new ArrayList<>();
        cycleDetected  = false;

        // All vertices start WHITE
        for (Vertex v : graph.getVertices()) {
            color.put(v.getId(), Color.WHITE);
            parents.put(v.getId(), null);
        }
    }
}
