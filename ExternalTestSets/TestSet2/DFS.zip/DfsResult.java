package dfs;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Immutable result object produced by a DFS traversal.
 *
 * <p>Captures everything discovered during the search:
 * <ul>
 *   <li>The order in which vertices were first discovered (pre-order)</li>
 *   <li>The order in which vertices were fully finished (post-order)</li>
 *   <li>Discovery and finish timestamps for each vertex</li>
 *   <li>The DFS parent tree (predecessor of each vertex in the DFS forest)</li>
 *   <li>Edge classification: tree, back, forward, and cross edges</li>
 *   <li>Whether a cycle was detected</li>
 *   <li>Which vertices were unreachable from the source</li>
 * </ul>
 *
 * <p>Discovery/finish timestamps follow the standard "parenthesis theorem":
 * if vertex u is an ancestor of v in the DFS tree, then u's interval
 * strictly contains v's interval.
 */
public class DfsResult {

    /** Classification of a graph edge encountered during DFS. */
    public enum EdgeType {
        /** Leads to an unvisited vertex — part of the DFS spanning tree. */
        TREE,
        /** Leads to an ancestor still on the DFS stack — indicates a cycle. */
        BACK,
        /** Leads to a descendant already fully finished (directed graphs only). */
        FORWARD,
        /** Leads to a vertex in a different DFS subtree (directed graphs only). */
        CROSS
    }

    /** A labelled edge encountered during DFS, with its classification. */
    public static class ClassifiedEdge {
        public final Vertex from;
        public final Vertex to;
        public final EdgeType type;

        ClassifiedEdge(Vertex from, Vertex to, EdgeType type) {
            this.from = from;
            this.to   = to;
            this.type = type;
        }

        @Override
        public String toString() {
            return from.getLabel() + " -> " + to.getLabel() + "  [" + type + "]";
        }
    }

    private final Vertex source;
    private final List<Vertex> discoveryOrder;        // pre-order (when first visited)
    private final List<Vertex> finishOrder;           // post-order (when fully done)
    private final Map<Integer, Integer> discoveryTime; // vertexId -> discovery timestamp
    private final Map<Integer, Integer> finishTime;    // vertexId -> finish timestamp
    private final Map<Integer, Vertex>  parents;       // vertexId -> DFS tree parent
    private final List<ClassifiedEdge>  edges;         // all edges with type labels
    private final List<Vertex>          unreachable;
    private final boolean               cycleDetected;

    /** Package-private constructor — built by {@link DepthFirstSearch}. */
    DfsResult(Vertex source,
              List<Vertex> discoveryOrder,
              List<Vertex> finishOrder,
              Map<Integer, Integer> discoveryTime,
              Map<Integer, Integer> finishTime,
              Map<Integer, Vertex> parents,
              List<ClassifiedEdge> edges,
              List<Vertex> unreachable,
              boolean cycleDetected) {
        this.source        = source;
        this.discoveryOrder = Collections.unmodifiableList(new ArrayList<>(discoveryOrder));
        this.finishOrder    = Collections.unmodifiableList(new ArrayList<>(finishOrder));
        this.discoveryTime  = Collections.unmodifiableMap(new HashMap<>(discoveryTime));
        this.finishTime     = Collections.unmodifiableMap(new HashMap<>(finishTime));
        this.parents        = Collections.unmodifiableMap(new HashMap<>(parents));
        this.edges          = Collections.unmodifiableList(new ArrayList<>(edges));
        this.unreachable    = Collections.unmodifiableList(new ArrayList<>(unreachable));
        this.cycleDetected  = cycleDetected;
    }

    // ---------------------------------------------------------------
    // Core accessors
    // ---------------------------------------------------------------

    public Vertex getSource() { return source; }

    /** Vertices in the order they were first discovered (pre-order). */
    public List<Vertex> getDiscoveryOrder() { return discoveryOrder; }

    /** Vertices in the order they were fully finished (post-order / reverse topological). */
    public List<Vertex> getFinishOrder() { return finishOrder; }

    /** Discovery timestamp of the given vertex (-1 if unreachable). */
    public int getDiscoveryTime(int vertexId) {
        return discoveryTime.getOrDefault(vertexId, -1);
    }

    /** Finish timestamp of the given vertex (-1 if unreachable). */
    public int getFinishTime(int vertexId) {
        return finishTime.getOrDefault(vertexId, -1);
    }

    /** DFS tree parent of a vertex, or null if it is the root or unreachable. */
    public Vertex getParent(int vertexId) { return parents.get(vertexId); }

    /** All classified edges encountered during DFS. */
    public List<ClassifiedEdge> getEdges() { return edges; }

    /** Vertices not reachable from the source. */
    public List<Vertex> getUnreachable() { return unreachable; }

    /** True if at least one back edge was found (meaning the graph has a cycle). */
    public boolean isCycleDetected() { return cycleDetected; }

    /** True if the given vertex was reached during this DFS. */
    public boolean isReachable(int vertexId) { return discoveryTime.containsKey(vertexId); }

    // ---------------------------------------------------------------
    // Path reconstruction
    // ---------------------------------------------------------------

    /**
     * Reconstructs the DFS tree path from the source to the target
     * by walking up the parent chain.
     *
     * @param targetId destination vertex ID
     * @return ordered list from source to target, empty if unreachable
     */
    public List<Vertex> getPathTo(int targetId) {
        if (!isReachable(targetId)) return Collections.emptyList();

        List<Vertex> path = new ArrayList<>();
        // Walk up from target using parent pointers
        Integer current = targetId;
        while (current != null) {
            Vertex v = findById(current);
            if (v == null) break;
            path.add(v);
            Vertex par = parents.get(current);
            current = (par == null) ? null : par.getId();
        }
        Collections.reverse(path);
        return path;
    }

    /** Returns a human-readable DFS tree path string to the given vertex. */
    public String getPathString(int targetId) {
        List<Vertex> path = getPathTo(targetId);
        if (path.isEmpty()) return source.getLabel() + " -> " + targetId + "  [UNREACHABLE]";
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < path.size(); i++) {
            sb.append(path.get(i).getLabel());
            if (i < path.size() - 1) sb.append(" -> ");
        }
        return sb.toString();
    }

    // ---------------------------------------------------------------
    // Topological sort
    // ---------------------------------------------------------------

    /**
     * Returns a topological ordering of the reachable vertices.
     * Only meaningful for directed acyclic graphs (DAGs).
     * For graphs with cycles, returns an ordering anyway but it is not valid.
     *
     * <p>Topological order = reverse finish order.
     */
    public List<Vertex> getTopologicalOrder() {
        List<Vertex> topo = new ArrayList<>(finishOrder);
        Collections.reverse(topo);
        return topo;
    }

    // ---------------------------------------------------------------
    // Edge counts
    // ---------------------------------------------------------------

    public long countEdgesOfType(EdgeType type) {
        return edges.stream().filter(e -> e.type == type).count();
    }

    // ---------------------------------------------------------------
    // Summary printing
    // ---------------------------------------------------------------

    public void printSummary() {
        System.out.println("--- DFS Result Summary ---");
        System.out.printf("Source        : %s%n", source.getLabel());
        System.out.printf("Reached       : %d vertices%n", discoveryOrder.size());
        System.out.printf("Cycle detected: %s%n", cycleDetected ? "YES" : "no");
        System.out.println();

        System.out.println("Vertex timestamps  [d = discovery, f = finish]:");
        System.out.printf("  %-12s  %5s  %5s  %s%n", "Vertex", "d", "f", "Parent");
        System.out.println("  " + "─".repeat(38));
        for (Vertex v : discoveryOrder) {
            int d = discoveryTime.getOrDefault(v.getId(), -1);
            int f = finishTime.getOrDefault(v.getId(), -1);
            Vertex par = parents.get(v.getId());
            String parLabel = (par == null) ? "—" : par.getLabel();
            System.out.printf("  %-12s  %5d  %5d  %s%n", v.getLabel(), d, f, parLabel);
        }

        System.out.println();
        System.out.println("Edge classifications:");
        for (ClassifiedEdge e : edges) {
            System.out.println("  " + e);
        }

        if (!unreachable.isEmpty()) {
            System.out.println();
            System.out.println("Unreachable:");
            for (Vertex v : unreachable) System.out.println("  - " + v.getLabel());
        }
        System.out.println();
    }

    // ---------------------------------------------------------------
    // Helper
    // ---------------------------------------------------------------

    private Vertex findById(int id) {
        for (Vertex v : discoveryOrder) if (v.getId() == id) return v;
        for (Vertex v : unreachable)    if (v.getId() == id) return v;
        return null;
    }
}
