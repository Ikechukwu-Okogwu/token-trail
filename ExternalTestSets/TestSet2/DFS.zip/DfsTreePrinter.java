package dfs;

import java.util.ArrayList;
import java.util.List;

/**
 * Renders a DFS result in several ASCII formats:
 * <ul>
 *   <li>An indented DFS spanning tree with timestamps</li>
 *   <li>A bracket/interval diagram showing the parenthesis theorem</li>
 *   <li>An edge classification table</li>
 *   <li>A topological order listing (for DAGs)</li>
 * </ul>
 */
public class DfsTreePrinter {

    /**
     * Prints the DFS spanning tree, indented by depth, with discovery/finish times.
     *
     * <pre>
     * A  [d=1, f=12]  [root]
     *   B  [d=2, f=7]  (via A)
     *     D  [d=3, f=6]  (via B)
     *   C  [d=8, f=11]  (via A)
     * </pre>
     */
    public void printTree(DfsResult result) {
        System.out.println("=== DFS Spanning Tree ===");
        printTreeNode(result, result.getSource(), 0, new java.util.HashSet<>());
        System.out.println();
    }

    private void printTreeNode(DfsResult result, Vertex v, int depth, java.util.Set<Integer> printed) {
        if (printed.contains(v.getId())) return;
        printed.add(v.getId());

        String indent = "  ".repeat(depth);
        int d = result.getDiscoveryTime(v.getId());
        int f = result.getFinishTime(v.getId());
        Vertex parent = result.getParent(v.getId());
        String parentStr = (parent == null) ? "[root]" : "(via " + parent.getLabel() + ")";
        System.out.printf("%s%-12s  [d=%2d, f=%2d]  %s%n",
            indent, v.getLabel(), d, f, parentStr);

        // Find children: vertices whose parent is v, in discovery order
        for (Vertex child : result.getDiscoveryOrder()) {
            Vertex childParent = result.getParent(child.getId());
            if (childParent != null && childParent.getId() == v.getId()) {
                printTreeNode(result, child, depth + 1, printed);
            }
        }
    }

    /**
     * Prints a parenthesis-interval diagram — a visual representation of
     * the parenthesis theorem. Each vertex is shown as a labelled bar
     * spanning its [discovery, finish] interval on a time axis.
     *
     * <pre>
     * Time:  1  2  3  4  5  6  7  8  9 10 11 12
     * A      [─────────────────────────────────]
     * B         [──────────────]
     * D               [────]
     * C                           [───────────]
     * </pre>
     */
    public void printIntervalDiagram(DfsResult result) {
        List<Vertex> order = result.getDiscoveryOrder();
        if (order.isEmpty()) return;

        // Find max finish time
        int maxT = 0;
        for (Vertex v : order) maxT = Math.max(maxT, result.getFinishTime(v.getId()));

        System.out.println("=== Parenthesis Interval Diagram ===");
        System.out.println("(Each bar spans the [discovery, finish] window of a vertex)");
        System.out.println();

        // Header: time axis
        System.out.printf("%-12s", "Time:");
        for (int t = 1; t <= maxT; t++) System.out.printf(" %2d", t);
        System.out.println();

        System.out.printf("%-12s", "");
        for (int t = 1; t <= maxT; t++) System.out.print("───");
        System.out.println();

        // One row per vertex
        for (Vertex v : order) {
            int d = result.getDiscoveryTime(v.getId());
            int f = result.getFinishTime(v.getId());
            System.out.printf("%-12s", v.getLabel());
            for (int t = 1; t <= maxT; t++) {
                if (t == d)              System.out.print("  [");
                else if (t == f)         System.out.print("─]");
                else if (t > d && t < f) System.out.print("──");
                else                     System.out.print("   ");
            }
            System.out.printf("  d=%-2d f=%d%n", d, f);
        }
        System.out.println();
    }

    /**
     * Prints a table of all classified edges encountered during DFS.
     */
    public void printEdgeClassification(DfsResult result) {
        System.out.println("=== Edge Classification ===");
        System.out.printf("%-6s  %-12s  %-12s  %s%n", "No.", "From", "To", "Type");
        System.out.println("─".repeat(46));

        int i = 1;
        for (DfsResult.ClassifiedEdge e : result.getEdges()) {
            System.out.printf("%-6d  %-12s  %-12s  %s%n",
                i++, e.from.getLabel(), e.to.getLabel(), e.type);
        }

        System.out.println();
        System.out.printf("  Tree edges  : %d%n", result.countEdgesOfType(DfsResult.EdgeType.TREE));
        System.out.printf("  Back edges  : %d  %s%n",
            result.countEdgesOfType(DfsResult.EdgeType.BACK),
            result.isCycleDetected() ? "<-- cycle(s) present" : "");
        System.out.printf("  Forward     : %d%n", result.countEdgesOfType(DfsResult.EdgeType.FORWARD));
        System.out.printf("  Cross       : %d%n", result.countEdgesOfType(DfsResult.EdgeType.CROSS));
        System.out.println();
    }

    /**
     * Prints the topological ordering (reverse finish order).
     * Annotates output with a warning if the graph has cycles.
     */
    public void printTopologicalOrder(DfsResult result) {
        System.out.println("=== Topological Order (reverse finish order) ===");
        if (result.isCycleDetected()) {
            System.out.println("WARNING: cycle detected — this is not a valid topological sort.");
        }
        List<Vertex> topo = result.getTopologicalOrder();
        for (int i = 0; i < topo.size(); i++) {
            System.out.printf("  %2d. %s%n", i + 1, topo.get(i).getLabel());
        }
        System.out.println();
    }
}
