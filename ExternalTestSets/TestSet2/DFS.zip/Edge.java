package dfs;

/**
 * Represents a directed, weighted edge in a graph.
 * An edge connects a source vertex to a destination vertex
 * and carries a non-negative integer weight.
 */
public class Edge {

    private final Vertex source;
    private final Vertex destination;
    private final int weight;

    /**
     * Constructs a directed edge from source to destination with the given weight.
     *
     * @param source      the starting vertex
     * @param destination the ending vertex
     * @param weight      the non-negative cost of traversing this edge
     * @throws IllegalArgumentException if weight is negative
     */
    public Edge(Vertex source, Vertex destination, int weight) {
        if (weight < 0) {
            throw new IllegalArgumentException(
                "Dijkstra's algorithm does not support negative edge weights. "
                + "Edge (" + source.getLabel() + " -> " + destination.getLabel()
                + ") has weight: " + weight
            );
        }
        this.source = source;
        this.destination = destination;
        this.weight = weight;
    }

    // --- Getters ---

    public Vertex getSource() {
        return source;
    }

    public Vertex getDestination() {
        return destination;
    }

    public int getWeight() {
        return weight;
    }

    /**
     * Returns the other endpoint of the edge given one endpoint.
     * Useful for undirected traversal.
     *
     * @param v one endpoint
     * @return the other endpoint
     * @throws IllegalArgumentException if v is neither endpoint
     */
    public Vertex getOther(Vertex v) {
        if (v.equals(source)) return destination;
        if (v.equals(destination)) return source;
        throw new IllegalArgumentException(
            "Vertex " + v.getLabel() + " is not an endpoint of this edge."
        );
    }

    @Override
    public String toString() {
        return source.getLabel() + " --[" + weight + "]--> " + destination.getLabel();
    }
}
