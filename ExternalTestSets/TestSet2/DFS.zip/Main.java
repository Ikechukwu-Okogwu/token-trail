package dfs;

/**
 * Demonstrates Depth-First Search using Graph, Vertex, and Edge
 * — the same files as the Dijkstra and BFS programs, just with package dfs.
 *
 * <p>Four scenarios, each using the same graph as the corresponding BFS scenario:
 *   1. Classic textbook graph (undirected) — DFS tree, timestamps, interval diagram
 *   2. City road network (directed)        — edge classification, DFS vs BFS order
 *   3. Disconnected graph (directed)       — cycle detection, unreachable vertices
 *   4. DAG (directed acyclic graph)        — full DFS forest + topological sort
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║   Depth-First Search — Demo Suite           ║");
        System.out.println("║   (same Graph / Vertex / Edge as Dijkstra)  ║");
        System.out.println("╚══════════════════════════════════════════════╝");
        System.out.println();

        runScenario1_ClassicGraph();
        runScenario2_CityNetwork();
        runScenario3_CycleDetection();
        runScenario4_DagTopological();
    }

    // -------------------------------------------------------------------
    // Scenario 1 — classic textbook graph (undirected), same as Dijkstra/BFS
    // -------------------------------------------------------------------

    /**
     * Undirected 6-node graph. Edges: A-B:4, A-C:2, B-C:5, B-D:10, C-E:3, D-F:11, E-D:4, E-F:6.
     *
     * In an undirected graph DFS sees every non-tree edge as a BACK edge
     * (there are no forward or cross edges). The interval diagram shows how
     * ancestor/descendant intervals nest — the parenthesis theorem in action.
     */
    private static void runScenario1_ClassicGraph() {
        printHeader("SCENARIO 1", "Classic Textbook Graph — DFS from A (undirected)");

        Graph g = new Graph(false);
        g.addVertex(0, "A");
        g.addVertex(1, "B");
        g.addVertex(2, "C");
        g.addVertex(3, "D");
        g.addVertex(4, "E");
        g.addVertex(5, "F");

        g.addEdge(0, 1, 4);   // A-B
        g.addEdge(0, 2, 2);   // A-C
        g.addEdge(1, 2, 5);   // B-C
        g.addEdge(1, 3, 10);  // B-D
        g.addEdge(2, 4, 3);   // C-E
        g.addEdge(3, 5, 11);  // D-F
        g.addEdge(4, 3, 4);   // E-D
        g.addEdge(4, 5, 6);   // E-F

        g.printGraph();
        System.out.println();

        DepthFirstSearch dfs = new DepthFirstSearch(g, true);
        DfsResult result = dfs.run(0);

        DfsTreePrinter printer = new DfsTreePrinter();
        printer.printTree(result);
        printer.printIntervalDiagram(result);
        printer.printEdgeClassification(result);

        System.out.println("--- DFS tree path queries ---");
        System.out.println("A -> F : " + result.getPathString(5));
        System.out.println("A -> D : " + result.getPathString(3));
        System.out.println("A -> E : " + result.getPathString(4));
        System.out.println();

        System.out.println("--- DFS vs BFS discovery order comparison ---");
        System.out.print("DFS order: ");
        for (Vertex v : result.getDiscoveryOrder()) System.out.print(v.getLabel() + " ");
        System.out.println();
        System.out.println("BFS order: A B C D E F  (level-by-level)");
        System.out.println("DFS dives deep first; BFS spreads wide first.");
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Scenario 2 — directed city road network, same as Dijkstra/BFS
    // -------------------------------------------------------------------

    /**
     * Directed graph: Hamilton -> Ancaster -> Burlington -> Oakville -> Toronto, etc.
     * Directed graphs can produce FORWARD and CROSS edges in addition to TREE and BACK.
     */
    private static void runScenario2_CityNetwork() {
        printHeader("SCENARIO 2", "City Road Network — DFS from Hamilton (directed)");

        Graph g = new Graph(true);
        g.addVertex(0, "Hamilton");
        g.addVertex(1, "Ancaster");
        g.addVertex(2, "Dundas");
        g.addVertex(3, "Burlington");
        g.addVertex(4, "Waterdown");
        g.addVertex(5, "Oakville");
        g.addVertex(6, "Toronto");

        g.addEdge(0, 1, 12); // Hamilton  -> Ancaster
        g.addEdge(0, 2, 18); // Hamilton  -> Dundas
        g.addEdge(1, 3, 20); // Ancaster  -> Burlington
        g.addEdge(1, 2, 7);  // Ancaster  -> Dundas
        g.addEdge(2, 4, 15); // Dundas    -> Waterdown
        g.addEdge(3, 5, 10); // Burlington-> Oakville
        g.addEdge(4, 3, 8);  // Waterdown -> Burlington
        g.addEdge(5, 6, 35); // Oakville  -> Toronto
        g.addEdge(3, 6, 45); // Burlington-> Toronto

        g.printGraph();
        System.out.println();

        DepthFirstSearch dfs = new DepthFirstSearch(g, true);
        DfsResult result = dfs.run(0);

        DfsTreePrinter printer = new DfsTreePrinter();
        printer.printTree(result);
        printer.printIntervalDiagram(result);
        printer.printEdgeClassification(result);

        System.out.println("Cycle detected: " + result.isCycleDetected());
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Scenario 3 — directed graph with a cycle + disconnected vertex
    // -------------------------------------------------------------------

    /**
     * A directed graph containing a cycle (A->B->C->A) and an isolated vertex Z.
     * DFS correctly:
     *   - finds the back edge revealing the cycle
     *   - leaves Z unreachable when run from S
     * Also demonstrates running the full DFS forest so every vertex gets visited.
     */
    private static void runScenario3_CycleDetection() {
        printHeader("SCENARIO 3", "Cycle Detection + Disconnected Vertex — DFS from S");

        Graph g = new Graph(true);
        g.addVertex(0, "S");
        g.addVertex(1, "A");
        g.addVertex(2, "B");
        g.addVertex(3, "C");
        g.addVertex(4, "D");
        g.addVertex(5, "Z"); // isolated from S

        g.addEdge(0, 1, 1);  // S -> A
        g.addEdge(0, 4, 1);  // S -> D
        g.addEdge(1, 2, 1);  // A -> B
        g.addEdge(2, 3, 1);  // B -> C
        g.addEdge(3, 1, 1);  // C -> A  (back edge — cycle A->B->C->A)
        g.addEdge(4, 3, 1);  // D -> C
        g.addEdge(5, 2, 1);  // Z -> B  (Z not reachable from S)

        g.printGraph();
        System.out.println();

        // Single-source DFS from S
        System.out.println("--- Single-source DFS from S ---");
        DepthFirstSearch dfs = new DepthFirstSearch(g, true);
        DfsResult result = dfs.run(0);

        DfsTreePrinter printer = new DfsTreePrinter();
        printer.printEdgeClassification(result);

        System.out.println("Cycle detected from S: " + result.isCycleDetected());
        System.out.println("Unreachable from S: " + result.getUnreachable().size() + " vertex (Z)");
        System.out.println();

        // Full DFS forest — visits Z too
        System.out.println("--- Full DFS forest (visits every vertex) ---");
        DepthFirstSearch dfsFull = new DepthFirstSearch(g, false);
        DfsResult fullResult = dfsFull.runFull();
        fullResult.printSummary();
    }

    // -------------------------------------------------------------------
    // Scenario 4 — DAG with topological sort
    // -------------------------------------------------------------------

    /**
     * A directed acyclic graph representing a simplified build/task dependency chain.
     *
     *   Nodes: Install, Compile, Test, Package, Deploy, Notify
     *
     *   Edges (A -> B means "A must happen before B"):
     *     Install  -> Compile
     *     Install  -> Test
     *     Compile  -> Package
     *     Test     -> Package
     *     Package  -> Deploy
     *     Deploy   -> Notify
     *     Compile  -> Test      (Test also depends on Compile)
     *
     * DFS full forest + reverse finish order = valid topological sort.
     */
    private static void runScenario4_DagTopological() {
        printHeader("SCENARIO 4", "DAG — Full DFS Forest + Topological Sort");

        Graph g = new Graph(true);
        g.addVertex(0, "Install");
        g.addVertex(1, "Compile");
        g.addVertex(2, "Test");
        g.addVertex(3, "Package");
        g.addVertex(4, "Deploy");
        g.addVertex(5, "Notify");

        g.addEdge(0, 1, 1); // Install -> Compile
        g.addEdge(0, 2, 1); // Install -> Test
        g.addEdge(1, 3, 1); // Compile -> Package
        g.addEdge(1, 2, 1); // Compile -> Test
        g.addEdge(2, 3, 1); // Test    -> Package
        g.addEdge(3, 4, 1); // Package -> Deploy
        g.addEdge(4, 5, 1); // Deploy  -> Notify

        g.printGraph();
        System.out.println();

        DepthFirstSearch dfs = new DepthFirstSearch(g, true);
        DfsResult result = dfs.runFull();

        DfsTreePrinter printer = new DfsTreePrinter();
        printer.printTree(result);
        printer.printIntervalDiagram(result);
        printer.printEdgeClassification(result);
        printer.printTopologicalOrder(result);

        System.out.println("Cycle detected: " + result.isCycleDetected()
            + "  (this is a valid DAG — topological sort above is correct)");
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Utility
    // -------------------------------------------------------------------

    private static void printHeader(String tag, String title) {
        System.out.println("══════════════════════════════════════════════════════");
        System.out.println(" " + tag + ": " + title);
        System.out.println("══════════════════════════════════════════════════════");
    }
}
