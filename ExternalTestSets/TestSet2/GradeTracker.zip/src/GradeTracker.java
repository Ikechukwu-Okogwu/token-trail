import java.util.*;
import java.util.stream.*;

/**
 * Student Grade Tracker
 * Tracks students, courses, assignments, and GPA calculations.
 */
public class GradeTracker {

    public static void main(String[] args) {
        School school = new School("Maplewood Academy");

        // Create courses
        Course math   = new Course("MATH101", "Calculus I",       4);
        Course eng    = new Course("ENG201",  "English Lit",       3);
        Course cs     = new Course("CS110",   "Intro to Java",     3);
        Course bio    = new Course("BIO101",  "Biology Basics",    4);
        Course hist   = new Course("HIST150", "World History",     3);

        school.addCourse(math);
        school.addCourse(eng);
        school.addCourse(cs);
        school.addCourse(bio);
        school.addCourse(hist);

        // Create students
        Student alice = new Student("S001", "Alice Carter",   "alice@school.edu");
        Student bob   = new Student("S002", "Bob Nguyen",     "bob@school.edu");
        Student carol = new Student("S003", "Carol Martinez", "carol@school.edu");

        school.enrollStudent(alice);
        school.enrollStudent(bob);
        school.enrollStudent(carol);

        // Enroll students in courses
        alice.enroll(math); alice.enroll(cs);   alice.enroll(eng);
        bob.enroll(math);   bob.enroll(bio);    bob.enroll(hist);
        carol.enroll(cs);   carol.enroll(eng);  carol.enroll(bio);

        // Add grades for Alice
        math.addGrade(alice, new Grade("Midterm Exam",   88));
        math.addGrade(alice, new Grade("Homework Set 1", 95));
        math.addGrade(alice, new Grade("Final Exam",     91));
        cs.addGrade(alice,   new Grade("Lab 1",          100));
        cs.addGrade(alice,   new Grade("Project",        87));
        cs.addGrade(alice,   new Grade("Midterm",        93));
        eng.addGrade(alice,  new Grade("Essay 1",        78));
        eng.addGrade(alice,  new Grade("Essay 2",        84));

        // Add grades for Bob
        math.addGrade(bob,   new Grade("Midterm Exam",   72));
        math.addGrade(bob,   new Grade("Homework Set 1", 68));
        math.addGrade(bob,   new Grade("Final Exam",     75));
        bio.addGrade(bob,    new Grade("Lab Report 1",   90));
        bio.addGrade(bob,    new Grade("Midterm",        85));
        bio.addGrade(bob,    new Grade("Final Exam",     88));
        hist.addGrade(bob,   new Grade("Term Paper",     79));
        hist.addGrade(bob,   new Grade("Quiz 1",         83));

        // Add grades for Carol
        cs.addGrade(carol,   new Grade("Lab 1",          96));
        cs.addGrade(carol,   new Grade("Project",        99));
        cs.addGrade(carol,   new Grade("Midterm",        97));
        eng.addGrade(carol,  new Grade("Essay 1",        88));
        eng.addGrade(carol,  new Grade("Essay 2",        91));
        bio.addGrade(carol,  new Grade("Lab Report 1",   74));
        bio.addGrade(carol,  new Grade("Midterm",        70));
        bio.addGrade(carol,  new Grade("Final Exam",     77));

        // Display reports
        school.printHeader();
        school.printAllStudentReports();
        school.printCourseReport(cs);
        school.printTopStudents(2);
        school.printGradeDistribution();
    }
}

// ─── Grade ───────────────────────────────────────────────────────────────────

class Grade {
    private String assignmentName;
    private double score;

    public Grade(String assignmentName, double score) {
        this.assignmentName = assignmentName;
        this.score = Math.min(100, Math.max(0, score));
    }

    public String getAssignmentName() { return assignmentName; }
    public double getScore()          { return score; }

    public String getLetterGrade() {
        if (score >= 90) return "A";
        if (score >= 80) return "B";
        if (score >= 70) return "C";
        if (score >= 60) return "D";
        return "F";
    }

    @Override
    public String toString() {
        return String.format("    %-22s %5.1f  [%s]", assignmentName, score, getLetterGrade());
    }
}

// ─── Course ──────────────────────────────────────────────────────────────────

class Course {
    private String code;
    private String name;
    private int creditHours;
    private Map<Student, List<Grade>> gradeBook;

    public Course(String code, String name, int creditHours) {
        this.code = code;
        this.name = name;
        this.creditHours = creditHours;
        this.gradeBook = new LinkedHashMap<>();
    }

    public String getCode()    { return code; }
    public String getName()    { return name; }
    public int getCreditHours(){ return creditHours; }

    public void addGrade(Student student, Grade grade) {
        gradeBook.computeIfAbsent(student, k -> new ArrayList<>()).add(grade);
    }

    public List<Grade> getGrades(Student student) {
        return gradeBook.getOrDefault(student, Collections.emptyList());
    }

    public double getAverage(Student student) {
        List<Grade> grades = getGrades(student);
        if (grades.isEmpty()) return 0;
        return grades.stream().mapToDouble(Grade::getScore).average().orElse(0);
    }

    public Set<Student> getEnrolledStudents() {
        return gradeBook.keySet();
    }

    public double getCourseAverage() {
        return gradeBook.keySet().stream()
            .mapToDouble(this::getAverage)
            .average().orElse(0);
    }

    @Override
    public String toString() {
        return String.format("%s — %s (%d credits)", code, name, creditHours);
    }
}

// ─── Student ─────────────────────────────────────────────────────────────────

class Student {
    private String studentId;
    private String name;
    private String email;
    private List<Course> enrolledCourses;

    public Student(String studentId, String name, String email) {
        this.studentId = studentId;
        this.name = name;
        this.email = email;
        this.enrolledCourses = new ArrayList<>();
    }

    public String getStudentId()       { return studentId; }
    public String getName()            { return name; }
    public String getEmail()           { return email; }
    public List<Course> getCourses()   { return enrolledCourses; }

    public void enroll(Course course) {
        enrolledCourses.add(course);
    }

    public double calculateGPA() {
        double totalPoints  = 0;
        int    totalCredits = 0;
        for (Course c : enrolledCourses) {
            double avg = c.getAverage(this);
            totalPoints  += gradePointValue(avg) * c.getCreditHours();
            totalCredits += c.getCreditHours();
        }
        return totalCredits == 0 ? 0.0 : totalPoints / totalCredits;
    }

    private double gradePointValue(double score) {
        if (score >= 90) return 4.0;
        if (score >= 80) return 3.0;
        if (score >= 70) return 2.0;
        if (score >= 60) return 1.0;
        return 0.0;
    }

    public String getStanding() {
        double gpa = calculateGPA();
        if (gpa >= 3.7) return "Dean's List";
        if (gpa >= 3.0) return "Good Standing";
        if (gpa >= 2.0) return "Satisfactory";
        return "Academic Probation";
    }

    @Override
    public String toString() {
        return String.format("[%s] %s <%s>", studentId, name, email);
    }
}

// ─── School ──────────────────────────────────────────────────────────────────

class School {
    private String name;
    private List<Student> students;
    private List<Course>  courses;

    public School(String name) {
        this.name     = name;
        this.students = new ArrayList<>();
        this.courses  = new ArrayList<>();
    }

    public void addCourse(Course course)     { courses.add(course); }
    public void enrollStudent(Student s)     { students.add(s); }

    public void printHeader() {
        System.out.println("╔══════════════════════════════════════════╗");
        System.out.printf ("║  %-40s║%n", name + " — Grade Report");
        System.out.println("╚══════════════════════════════════════════╝");
    }

    public void printAllStudentReports() {
        System.out.println("\n══════════════ STUDENT REPORTS ══════════════");
        for (Student s : students) {
            System.out.printf("%n▶ %s%n", s);
            System.out.printf("  Standing : %s | GPA: %.2f%n", s.getStanding(), s.calculateGPA());
            for (Course c : s.getCourses()) {
                System.out.printf("  %-30s Avg: %5.1f%n", c.getName(), c.getAverage(s));
                c.getGrades(s).forEach(System.out::println);
            }
        }
    }

    public void printCourseReport(Course course) {
        System.out.println("\n══════════════ COURSE REPORT ══════════════");
        System.out.println("Course : " + course);
        System.out.printf("Class Average : %.1f%n", course.getCourseAverage());
        System.out.println("Enrolled Students:");
        course.getEnrolledStudents().forEach(s ->
            System.out.printf("  %-20s  Avg: %.1f  GPA Points: %.1f%n",
                s.getName(), course.getAverage(s), course.getAverage(s) / 25));
    }

    public void printTopStudents(int n) {
        System.out.println("\n══════════════ TOP STUDENTS ══════════════");
        students.stream()
            .sorted(Comparator.comparingDouble(Student::calculateGPA).reversed())
            .limit(n)
            .forEach(s -> System.out.printf("  #%d  %-20s  GPA: %.2f  (%s)%n",
                students.indexOf(s) + 1, s.getName(), s.calculateGPA(), s.getStanding()));
    }

    public void printGradeDistribution() {
        System.out.println("\n══════════════ GRADE DISTRIBUTION ══════════════");
        Map<String, Long> dist = new LinkedHashMap<>();
        dist.put("A (90-100)", 0L); dist.put("B (80-89)", 0L);
        dist.put("C (70-79)",  0L); dist.put("D (60-69)", 0L);
        dist.put("F (<60)",    0L);
        for (Student s : students) {
            for (Course c : s.getCourses()) {
                for (Grade g : c.getGrades(s)) {
                    String key = g.getScore() >= 90 ? "A (90-100)"
                               : g.getScore() >= 80 ? "B (80-89)"
                               : g.getScore() >= 70 ? "C (70-79)"
                               : g.getScore() >= 60 ? "D (60-69)" : "F (<60)";
                    dist.merge(key, 1L, Long::sum);
                }
            }
        }
        long total = dist.values().stream().mapToLong(Long::longValue).sum();
        dist.forEach((grade, count) -> {
            int bars = (int)((count * 20) / (total == 0 ? 1 : total));
            System.out.printf("  %s  [%-20s] %d%n", grade, "█".repeat(bars), count);
        });
    }
}
