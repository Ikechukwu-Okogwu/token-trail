public class Movie {
    private int id;
    private String title;
    private String director;
    private String genre;
    private int year;
    private int rating;
    private boolean watched;

    public Movie(int id, String title, String director, String genre, int year, int rating, boolean watched) {
        this.id = id;
        this.title = title;
        this.director = director;
        this.genre = genre;
        this.year = year;
        this.rating = rating;
        this.watched = watched;
    }

    public int getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getDirector() {
        return director;
    }

    public String getGenre() {
        return genre;
    }

    public int getYear() {
        return year;
    }

    public int getRating() {
        return rating;
    }

    public boolean isWatched() {
        return watched;
    }

    public void setRating(int rating) {
        this.rating = rating;
    }

    public void setWatched(boolean watched) {
        this.watched = watched;
    }

    @Override
    public String toString() {
        return "Movie #" + id
                + " | Title: " + title
                + " | Director: " + director
                + " | Genre: " + genre
                + " | Year: " + year
                + " | Rating: " + rating + "/5"
                + " | Status: " + (watched ? "Watched" : "Not Watched");
    }
}