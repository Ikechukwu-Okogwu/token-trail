import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MovieCollectionCLI {

    private static final Scanner scanner = new Scanner(System.in);
    private static final List<Movie> movies = new ArrayList<>();
    private static int nextId = 1;

    public static void main(String[] args) {
        loadSampleMovies();
        runProgram();
        scanner.close();
    }

    private static void runProgram() {
        boolean running = true;
        printBanner();

        while (running) {
            printMenu();
            String choice = readInput("Enter option: ");

            switch (choice) {
                case "1":
                    addMovie();
                    break;
                case "2":
                    viewMovies();
                    break;
                case "3":
                    markMovieAsWatched();
                    break;
                case "4":
                    deleteMovie();
                    break;
                case "5":
                    searchMovies();
                    break;
                case "6":
                    sortMovies();
                    break;
                case "7":
                    showStatistics();
                    break;
                case "8":
                    updateMovieRating();
                    break;
                case "9":
                    removeWatchedMovies();
                    break;
                case "10":
                    running = false;
                    System.out.println("Closing Movie Collection CLI.");
                    break;
                default:
                    System.out.println("Invalid option.");
            }

            if (running) {
                pause();
            }
        }
    }

    private static void printBanner() {
        System.out.println("======================================");
        System.out.println("         MOVIE COLLECTION CLI         ");
        System.out.println("======================================");
    }

    private static void printMenu() {
        System.out.println();
        System.out.println("1. Add movie");
        System.out.println("2. View all movies");
        System.out.println("3. Mark movie as watched");
        System.out.println("4. Delete movie");
        System.out.println("5. Search movies");
        System.out.println("6. Sort movies");
        System.out.println("7. Show statistics");
        System.out.println("8. Update movie rating");
        System.out.println("9. Remove watched movies");
        System.out.println("10. Exit");
        System.out.println();
    }

    private static void addMovie() {
        System.out.println("--- Add Movie ---");

        String title = readRequired("Title: ");
        String director = readRequired("Director: ");
        String genre = readRequired("Genre: ");
        int year = readYear();
        int rating = readRating();

        Movie movie = new Movie(nextId, title, director, genre, year, rating, false);
        nextId++;
        movies.add(movie);

        System.out.println("Movie added:");
        System.out.println(movie);
    }

    private static void viewMovies() {
        System.out.println("--- Movie List ---");

        if (movies.isEmpty()) {
            System.out.println("No movies in collection.");
            return;
        }

        for (Movie movie : movies) {
            System.out.println(movie);
        }
    }

    private static void markMovieAsWatched() {
        System.out.println("--- Mark as Watched ---");

        if (movies.isEmpty()) {
            System.out.println("No movies available.");
            return;
        }

        int id = readInt("Enter movie ID: ");
        Movie movie = findMovieById(id);

        if (movie == null) {
            System.out.println("Movie not found.");
            return;
        }

        if (movie.isWatched()) {
            System.out.println("Movie is already marked as watched.");
            return;
        }

        movie.setWatched(true);
        System.out.println("Movie updated:");
        System.out.println(movie);
    }

    private static void deleteMovie() {
        System.out.println("--- Delete Movie ---");

        if (movies.isEmpty()) {
            System.out.println("No movies available.");
            return;
        }

        int id = readInt("Enter movie ID to delete: ");
        Movie movie = findMovieById(id);

        if (movie == null) {
            System.out.println("Movie not found.");
            return;
        }

        movies.remove(movie);
        System.out.println("Deleted movie: " + movie.getTitle());
    }

    private static void searchMovies() {
        System.out.println("--- Search Movies ---");

        if (movies.isEmpty()) {
            System.out.println("No movies available.");
            return;
        }

        String keyword = readRequired("Enter keyword: ").toLowerCase();
        boolean found = false;

        for (Movie movie : movies) {
            if (movie.getTitle().toLowerCase().contains(keyword)
                    || movie.getDirector().toLowerCase().contains(keyword)
                    || movie.getGenre().toLowerCase().contains(keyword)) {
                System.out.println(movie);
                found = true;
            }
        }

        if (!found) {
            System.out.println("No matching movies found.");
        }
    }

    private static void sortMovies() {
        System.out.println("--- Sort Movies ---");

        if (movies.isEmpty()) {
            System.out.println("No movies available.");
            return;
        }

        System.out.println("1. Sort by title");
        System.out.println("2. Sort by year");
        System.out.println("3. Sort by rating");
        System.out.println("4. Sort by watched status");

        String option = readInput("Choose sorting option: ");

        switch (option) {
            case "1":
                sortByTitle();
                System.out.println("Sorted by title.");
                break;
            case "2":
                sortByYear();
                System.out.println("Sorted by year.");
                break;
            case "3":
                sortByRatingDescending();
                System.out.println("Sorted by rating.");
                break;
            case "4":
                sortByWatchedStatus();
                System.out.println("Sorted by watched status.");
                break;
            default:
                System.out.println("Invalid sorting option.");
                return;
        }

        viewMovies();
    }

    private static void sortByTitle() {
        for (int i = 0; i < movies.size() - 1; i++) {
            for (int j = 0; j < movies.size() - 1 - i; j++) {
                if (movies.get(j).getTitle().compareToIgnoreCase(movies.get(j + 1).getTitle()) > 0) {
                    Movie temp = movies.get(j);
                    movies.set(j, movies.get(j + 1));
                    movies.set(j + 1, temp);
                }
            }
        }
    }

    private static void sortByYear() {
        for (int i = 0; i < movies.size() - 1; i++) {
            int minIndex = i;

            for (int j = i + 1; j < movies.size(); j++) {
                if (movies.get(j).getYear() < movies.get(minIndex).getYear()) {
                    minIndex = j;
                }
            }

            if (minIndex != i) {
                Movie temp = movies.get(i);
                movies.set(i, movies.get(minIndex));
                movies.set(minIndex, temp);
            }
        }
    }

    private static void sortByRatingDescending() {
        for (int i = 1; i < movies.size(); i++) {
            Movie current = movies.get(i);
            int j = i - 1;

            while (j >= 0 && movies.get(j).getRating() < current.getRating()) {
                movies.set(j + 1, movies.get(j));
                j--;
            }

            movies.set(j + 1, current);
        }
    }

    private static void sortByWatchedStatus() {
        List<Movie> unwatched = new ArrayList<>();
        List<Movie> watched = new ArrayList<>();

        for (Movie movie : movies) {
            if (movie.isWatched()) {
                watched.add(movie);
            } else {
                unwatched.add(movie);
            }
        }

        movies.clear();
        movies.addAll(unwatched);
        movies.addAll(watched);
    }

    private static void showStatistics() {
        System.out.println("--- Statistics ---");

        int total = movies.size();
        int watchedCount = 0;
        int unwatchedCount = 0;
        int ratingSum = 0;
        int recentMovies = 0;

        for (Movie movie : movies) {
            ratingSum += movie.getRating();

            if (movie.isWatched()) {
                watchedCount++;
            } else {
                unwatchedCount++;
            }

            if (movie.getYear() >= 2020) {
                recentMovies++;
            }
        }

        double averageRating = total == 0 ? 0.0 : (double) ratingSum / total;

        System.out.println("Total movies: " + total);
        System.out.println("Watched movies: " + watchedCount);
        System.out.println("Unwatched movies: " + unwatchedCount);
        System.out.println("Movies released in 2020 or later: " + recentMovies);
        System.out.printf("Average rating: %.2f%n", averageRating);
    }

    private static void updateMovieRating() {
        System.out.println("--- Update Rating ---");

        if (movies.isEmpty()) {
            System.out.println("No movies available.");
            return;
        }

        int id = readInt("Enter movie ID: ");
        Movie movie = findMovieById(id);

        if (movie == null) {
            System.out.println("Movie not found.");
            return;
        }

        int newRating = readRating();
        movie.setRating(newRating);

        System.out.println("Rating updated:");
        System.out.println(movie);
    }

    private static void removeWatchedMovies() {
        System.out.println("--- Remove Watched Movies ---");

        if (movies.isEmpty()) {
            System.out.println("No movies available.");
            return;
        }

        List<Movie> remainingMovies = new ArrayList<>();
        int removed = 0;

        for (Movie movie : movies) {
            if (movie.isWatched()) {
                removed++;
            } else {
                remainingMovies.add(movie);
            }
        }

        movies.clear();
        movies.addAll(remainingMovies);

        System.out.println("Removed " + removed + " watched movie(s).");
    }

    private static Movie findMovieById(int id) {
        for (Movie movie : movies) {
            if (movie.getId() == id) {
                return movie;
            }
        }
        return null;
    }

    private static int readYear() {
        while (true) {
            int year = readInt("Year: ");
            if (year >= 1888 && year <= 2100) {
                return year;
            }
            System.out.println("Enter a valid year.");
        }
    }

    private static int readRating() {
        while (true) {
            int rating = readInt("Rating (1-5): ");
            if (rating >= 1 && rating <= 5) {
                return rating;
            }
            System.out.println("Rating must be between 1 and 5.");
        }
    }

    private static int readInt(String prompt) {
        while (true) {
            String value = readInput(prompt);
            try {
                return Integer.parseInt(value);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid integer.");
            }
        }
    }

    private static String readInput(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim();
    }

    private static String readRequired(String prompt) {
        while (true) {
            String value = readInput(prompt);
            if (!value.isEmpty()) {
                return value;
            }
            System.out.println("Input cannot be empty.");
        }
    }

    private static void pause() {
        System.out.println();
        System.out.print("Press Enter to continue...");
        scanner.nextLine();
    }

    private static void loadSampleMovies() {
        movies.add(new Movie(nextId++, "Inception", "Christopher Nolan", "Sci-Fi", 2010, 5, true));
        movies.add(new Movie(nextId++, "Interstellar", "Christopher Nolan", "Sci-Fi", 2014, 5, false));
        movies.add(new Movie(nextId++, "The Batman", "Matt Reeves", "Action", 2022, 4, false));
        movies.add(new Movie(nextId++, "Whiplash", "Damien Chazelle", "Drama", 2014, 5, true));
    }
}