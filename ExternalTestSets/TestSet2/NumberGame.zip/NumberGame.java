import java.util.Random;
import java.util.Scanner;

/**
 * Number Guessing Game
 * Try to guess the secret number between 1 and 100!
 */
public class NumberGame {

    static Scanner scanner = new Scanner(System.in);
    static Random  random  = new Random();

    public static void main(String[] args) {
        System.out.println("================================");
        System.out.println("   🎯 Number Guessing Game!    ");
        System.out.println("================================");

        int gamesPlayed = 0;
        int totalGuesses = 0;
        int bestGame = Integer.MAX_VALUE;

        while (true) {
            int guesses = playRound();
            gamesPlayed++;
            totalGuesses += guesses;
            if (guesses < bestGame) bestGame = guesses;

            System.out.printf("%nNice! You got it in %d guess%s.%n", guesses, guesses == 1 ? "" : "es");
            System.out.printf("Stats — Games: %d | Avg guesses: %.1f | Best: %d%n",
                gamesPlayed, (double) totalGuesses / gamesPlayed, bestGame);

            System.out.print("\nPlay again? (yes/no): ");
            String answer = scanner.nextLine().trim().toLowerCase();
            if (!answer.startsWith("y")) break;
        }

        System.out.println("\nThanks for playing! Goodbye 👋");
    }

    static int playRound() {
        int secret  = random.nextInt(100) + 1;
        int guesses = 0;

        System.out.println("\nI'm thinking of a number between 1 and 100...");

        while (true) {
            System.out.print("Your guess: ");
            String input = scanner.nextLine().trim();

            int guess;
            try {
                guess = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a valid number.");
                continue;
            }

            if (guess < 1 || guess > 100) {
                System.out.println("Out of range! Try between 1 and 100.");
                continue;
            }

            guesses++;

            if (guess < secret)       System.out.println("Too low!  ⬆");
            else if (guess > secret)  System.out.println("Too high! ⬇");
            else                      break;
        }

        return guesses;
    }
}
