import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class NumberGuessGame {

    private static final int MIN = 1;
    private static final int MAX = 200;

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        printWelcome();

        boolean playAgain = true;

        while (playAgain) {
            playSingleGame(scanner, random);
            playAgain = askToPlayAgain(scanner);
        }

        System.out.println("\nThanks for playing!");
        scanner.close();
    }

    private static void printWelcome() {
        System.out.println("========================================");
        System.out.println("      NUMBER GUESSING TERMINAL GAME     ");
        System.out.println("========================================");
        System.out.println("I am thinking of a number between " + MIN + " and " + MAX + ".");
        System.out.println("Try to guess it in as few attempts as possible.");
        System.out.println("You will get feedback after each guess.");
        System.out.println();
    }

    private static void playSingleGame(Scanner scanner, Random random) {
        int secretNumber = random.nextInt(MAX - MIN + 1) + MIN;

        List<Integer> guesses = new ArrayList<>();
        int attempts = 0;

        int bestDistance = Integer.MAX_VALUE;
        int worstDistance = Integer.MIN_VALUE;

        long startTime = System.currentTimeMillis();

        boolean guessedCorrectly = false;

        int previousDistance = -1;
        int highGuesses = 0;
        int lowGuesses = 0;

        int lowestGuess = Integer.MAX_VALUE;
        int highestGuess = Integer.MIN_VALUE;

        System.out.println("----------------------------------------");
        System.out.println("New game started!");
        System.out.println("Guess the number between " + MIN + " and " + MAX + ".");
        System.out.println("----------------------------------------");

        while (!guessedCorrectly) {
            int guess = readValidGuess(scanner);

            attempts++;
            guesses.add(guess);

            if (guess < lowestGuess) {
                lowestGuess = guess;
            }
            if (guess > highestGuess) {
                highestGuess = guess;
            }

            int distance = Math.abs(secretNumber - guess);

            if (distance < bestDistance) {
                bestDistance = distance;
            }
            if (distance > worstDistance) {
                worstDistance = distance;
            }

            if (guess < secretNumber) {
                lowGuesses++;
                System.out.println("Too low.");
            } else if (guess > secretNumber) {
                highGuesses++;
                System.out.println("Too high.");
            } else {
                guessedCorrectly = true;
                long endTime = System.currentTimeMillis();
                double secondsPlayed = (endTime - startTime) / 1000.0;

                System.out.println("\nCorrect! You guessed the number.");
                printGameStats(
                    secretNumber,
                    guesses,
                    attempts,
                    bestDistance,
                    worstDistance,
                    highGuesses,
                    lowGuesses,
                    lowestGuess,
                    highestGuess,
                    secondsPlayed
                );
                break;
            }

            printTemperatureHint(distance);
            printProgressHint(previousDistance, distance);

            previousDistance = distance;

            if (attempts % 5 == 0) {
                printRangeReminder(lowestGuess, highestGuess);
            }

            System.out.println();
        }
    }

    private static int readValidGuess(Scanner scanner) {
        while (true) {
            System.out.print("Enter your guess: ");

            if (!scanner.hasNextInt()) {
                String badInput = scanner.nextLine();
                System.out.println("'" + badInput + "' is not a valid whole number.");
                continue;
            }

            int guess = scanner.nextInt();
            scanner.nextLine(); // consume leftover newline

            if (guess < MIN || guess > MAX) {
                System.out.println("Please enter a number between " + MIN + " and " + MAX + ".");
                continue;
            }

            return guess;
        }
    }

    private static void printTemperatureHint(int distance) {
        if (distance == 0) {
            return;
        } else if (distance <= 3) {
            System.out.println("Hint: Boiling hot!");
        } else if (distance <= 8) {
            System.out.println("Hint: Very warm.");
        } else if (distance <= 15) {
            System.out.println("Hint: Warm.");
        } else if (distance <= 30) {
            System.out.println("Hint: Cool.");
        } else {
            System.out.println("Hint: Cold.");
        }
    }

    private static void printProgressHint(int previousDistance, int currentDistance) {
        if (previousDistance == -1) {
            return;
        }

        if (currentDistance < previousDistance) {
            System.out.println("You are getting closer.");
        } else if (currentDistance > previousDistance) {
            System.out.println("You are getting farther away.");
        } else {
            System.out.println("You are exactly as close as your last guess.");
        }
    }

    private static void printRangeReminder(int lowestGuess, int highestGuess) {
        System.out.println("----- Progress Update -----");
        System.out.println("Your lowest guess so far:  " + lowestGuess);
        System.out.println("Your highest guess so far: " + highestGuess);
        System.out.println("---------------------------");
    }

    private static void printGameStats(
        int secretNumber,
        List<Integer> guesses,
        int attempts,
        int bestDistance,
        int worstDistance,
        int highGuesses,
        int lowGuesses,
        int lowestGuess,
        int highestGuess,
        double secondsPlayed
    ) {
        int sum = 0;
        for (int guess : guesses) {
            sum += guess;
        }

        double averageGuess = (double) sum / guesses.size();

        System.out.println("========================================");
        System.out.println("               GAME STATS               ");
        System.out.println("========================================");
        System.out.println("Secret number:            " + secretNumber);
        System.out.println("Total attempts:           " + attempts);
        System.out.println("Too high guesses:         " + highGuesses);
        System.out.println("Too low guesses:          " + lowGuesses);
        System.out.println("Lowest guess made:        " + lowestGuess);
        System.out.println("Highest guess made:       " + highestGuess);
        System.out.printf ("Average guess value:      %.2f%n", averageGuess);
        System.out.println("Closest distance reached: " + bestDistance);
        System.out.println("Farthest distance reached:" + " " + worstDistance);
        System.out.printf ("Time played:              %.2f seconds%n", secondsPlayed);
        System.out.println("Guess history:            " + formatGuessHistory(guesses));
        System.out.println("Performance rank:         " + getPerformanceRank(attempts));
        System.out.println("========================================");
    }

    private static String formatGuessHistory(List<Integer> guesses) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < guesses.size(); i++) {
            sb.append(guesses.get(i));
            if (i != guesses.size() - 1) {
                sb.append(", ");
            }
        }

        return sb.toString();
    }

    private static String getPerformanceRank(int attempts) {
        if (attempts <= 4) {
            return "Legendary";
        } else if (attempts <= 7) {
            return "Excellent";
        } else if (attempts <= 10) {
            return "Great";
        } else if (attempts <= 14) {
            return "Solid";
        } else if (attempts <= 20) {
            return "Persistent";
        } else {
            return "You got there!";
        }
    }

    private static boolean askToPlayAgain(Scanner scanner) {
        while (true) {
            System.out.print("\nWould you like to play again? (y/n): ");
            String answer = scanner.nextLine().trim().toLowerCase();

            if (answer.equals("y") || answer.equals("yes")) {
                System.out.println();
                return true;
            } else if (answer.equals("n") || answer.equals("no")) {
                return false;
            } else {
                System.out.println("Please type 'y' or 'n'.");
            }
        }
    }
}