import java.util.*;

/**
 * Trivia Quiz Game
 * Answer multiple-choice questions and see how you score!
 */
public class QuizGame {

    static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        List<Question> questions = buildQuestions();
        Collections.shuffle(questions);

        System.out.println("==============================");
        System.out.println("      🧠 Trivia Quiz!         ");
        System.out.println("==============================");
        System.out.println("Answer each question (1-4).\n");

        int score = 0;

        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            System.out.printf("Q%d: %s%n", i + 1, q.getQuestion());

            List<String> options = q.getOptions();
            for (int j = 0; j < options.size(); j++) {
                System.out.printf("  %d) %s%n", j + 1, options.get(j));
            }

            int answer = getAnswer(options.size());

            if (answer == q.getCorrectIndex() + 1) {
                System.out.println("✅ Correct!\n");
                score++;
            } else {
                System.out.printf("❌ Wrong! The answer was: %s%n%n",
                    options.get(q.getCorrectIndex()));
            }
        }

        System.out.println("==============================");
        System.out.printf("  Final Score: %d / %d%n", score, questions.size());
        System.out.println("  " + getRating(score, questions.size()));
        System.out.println("==============================");
    }

    static int getAnswer(int max) {
        while (true) {
            System.out.print("Your answer: ");
            try {
                int input = Integer.parseInt(scanner.nextLine().trim());
                if (input >= 1 && input <= max) return input;
            } catch (NumberFormatException ignored) {}
            System.out.println("Please enter a number between 1 and " + max + ".");
        }
    }

    static String getRating(int score, int total) {
        double pct = (double) score / total;
        if (pct == 1.0)  return "🏆 Perfect score!";
        if (pct >= 0.75) return "🌟 Great job!";
        if (pct >= 0.5)  return "👍 Not bad!";
        if (pct >= 0.25) return "📚 Keep studying!";
        return "💪 Better luck next time!";
    }

    static List<Question> buildQuestions() {
        List<Question> list = new ArrayList<>();

        list.add(new Question("What is the capital of Japan?",
            List.of("Beijing", "Seoul", "Tokyo", "Bangkok"), 2));

        list.add(new Question("How many sides does a hexagon have?",
            List.of("5", "6", "7", "8"), 1));

        list.add(new Question("Which planet is closest to the Sun?",
            List.of("Venus", "Earth", "Mars", "Mercury"), 3));

        list.add(new Question("What gas do plants absorb from the air?",
            List.of("Oxygen", "Nitrogen", "Carbon Dioxide", "Hydrogen"), 2));

        list.add(new Question("Who painted the Mona Lisa?",
            List.of("Michelangelo", "Raphael", "Leonardo da Vinci", "Donatello"), 2));

        list.add(new Question("What is the largest ocean on Earth?",
            List.of("Atlantic", "Indian", "Arctic", "Pacific"), 3));

        list.add(new Question("How many bones are in the adult human body?",
            List.of("206", "189", "215", "230"), 0));

        list.add(new Question("What is the chemical symbol for gold?",
            List.of("Go", "Gd", "Au", "Ag"), 2));

        return list;
    }
}

class Question {
    private String question;
    private List<String> options;
    private int correctIndex;

    public Question(String question, List<String> options, int correctIndex) {
        this.question     = question;
        this.options      = options;
        this.correctIndex = correctIndex;
    }

    public String getQuestion()      { return question; }
    public List<String> getOptions() { return options; }
    public int getCorrectIndex()     { return correctIndex; }
}
