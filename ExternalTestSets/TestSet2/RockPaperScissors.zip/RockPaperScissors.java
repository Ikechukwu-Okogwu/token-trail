import java.util.*;

/**
 * Rock Paper Scissors
 * Play against the computer — best of however many rounds you want!
 */
public class RockPaperScissors {

    static Scanner scanner = new Scanner(System.in);
    static Random  random  = new Random();

    static final String[] MOVES = {"Rock", "Paper", "Scissors"};
    static final String[] EMOJI = {"🪨",   "📄",    "✂️"};

    public static void main(String[] args) {
        System.out.println("==============================");
        System.out.println("   🪨 Rock Paper Scissors! ✂️  ");
        System.out.println("==============================\n");

        int playerWins = 0;
        int cpuWins    = 0;
        int ties       = 0;

        while (true) {
            System.out.println("Pick your move:");
            System.out.println("  1) 🪨 Rock");
            System.out.println("  2) 📄 Paper");
            System.out.println("  3) ✂️  Scissors");
            System.out.println("  0) Quit");
            System.out.print("Your choice: ");

            String input = scanner.nextLine().trim();
            if (input.equals("0")) break;

            int playerMove;
            try {
                playerMove = Integer.parseInt(input) - 1;
                if (playerMove < 0 || playerMove > 2) throw new NumberFormatException();
            } catch (NumberFormatException e) {
                System.out.println("Invalid choice, try again.\n");
                continue;
            }

            int cpuMove = random.nextInt(3);

            System.out.printf("%nYou: %s %s   vs   CPU: %s %s%n",
                EMOJI[playerMove], MOVES[playerMove],
                EMOJI[cpuMove],    MOVES[cpuMove]);

            int result = getResult(playerMove, cpuMove);
            if (result == 1)       { System.out.println("🎉 You win this round!"); playerWins++; }
            else if (result == -1) { System.out.println("💻 CPU wins this round!"); cpuWins++; }
            else                   { System.out.println("🤝 It's a tie!");          ties++; }

            System.out.printf("Score — You: %d | CPU: %d | Ties: %d%n%n",
                playerWins, cpuWins, ties);
        }

        int total = playerWins + cpuWins + ties;
        System.out.println("\n==============================");
        System.out.printf("  Rounds played : %d%n", total);
        System.out.printf("  Your wins     : %d%n", playerWins);
        System.out.printf("  CPU wins      : %d%n", cpuWins);
        System.out.printf("  Ties          : %d%n", ties);
        if (total > 0) {
            if      (playerWins > cpuWins) System.out.println("\n  🏆 You won overall!");
            else if (cpuWins > playerWins) System.out.println("\n  💻 CPU won overall!");
            else                           System.out.println("\n  🤝 Overall tie!");
        }
        System.out.println("==============================");
        System.out.println("Thanks for playing! 👋");
    }

    // Returns 1 if player wins, -1 if CPU wins, 0 for tie
    static int getResult(int player, int cpu) {
        if (player == cpu) return 0;
        if ((player == 0 && cpu == 2) ||
            (player == 1 && cpu == 0) ||
            (player == 2 && cpu == 1)) return 1;
        return -1;
    }
}
