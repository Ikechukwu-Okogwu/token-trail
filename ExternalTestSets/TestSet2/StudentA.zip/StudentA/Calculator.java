import java.util.Scanner;
import java.util.ArrayList;

/**
 * Calculator application entry point.
 * Supports basic arithmetic and history tracking.
 */
public class Calculator {

    private MathEngine engine;
    private HistoryLog log;
    private Scanner inputReader;

    public Calculator() {
        engine = new MathEngine();
        log = new HistoryLog();
        inputReader = new Scanner(System.in);
    }

    public void start() {
        System.out.println("=== Simple Calculator ===");
        System.out.println("Operators: +  -  *  /  %  ^");
        System.out.println("Commands: history, clear, quit");
        System.out.println();

        boolean running = true;
        while (running) {
            System.out.print("> ");
            String userInput = inputReader.nextLine().trim();

            if (userInput.equalsIgnoreCase("quit")) {
                running = false;
                System.out.println("Goodbye.");
            } else if (userInput.equalsIgnoreCase("history")) {
                printHistory();
            } else if (userInput.equalsIgnoreCase("clear")) {
                log.clearAll();
                System.out.println("History cleared.");
            } else if (!userInput.isEmpty()) {
                processExpression(userInput);
            }
        }

        inputReader.close();
    }

    private void processExpression(String expr) {
        try {
            Tokenizer tokenizer = new Tokenizer(expr);
            double leftOperand = tokenizer.nextNumber();
            char operator = tokenizer.nextOperator();
            double rightOperand = tokenizer.nextNumber();

            double result = engine.calculate(leftOperand, operator, rightOperand);
            String entry = expr + " = " + formatResult(result);
            log.addEntry(entry);
            System.out.println("= " + formatResult(result));
        } catch (ArithmeticException ae) {
            System.out.println("Math error: " + ae.getMessage());
        } catch (Exception ex) {
            System.out.println("Invalid input. Example: 5 + 3");
        }
    }

    private void printHistory() {
        ArrayList<String> entries = log.getEntries();
        if (entries.isEmpty()) {
            System.out.println("No history yet.");
        } else {
            System.out.println("--- History ---");
            for (int i = 0; i < entries.size(); i++) {
                System.out.println((i + 1) + ". " + entries.get(i));
            }
            System.out.println("---------------");
        }
    }

    private String formatResult(double result) {
        if (result == (long) result) {
            return String.valueOf((long) result);
        }
        return String.format("%.4f", result);
    }

    public static void main(String[] args) {
        Calculator calc = new Calculator();
        calc.start();
    }
}
