import java.util.ArrayList;

/**
 * HistoryLog stores and manages past calculation entries.
 * Entries are stored in the order they were added.
 */
public class HistoryLog {

    private ArrayList<String> entries;
    private int maxEntries;

    public HistoryLog() {
        entries = new ArrayList<>();
        maxEntries = 50;
    }

    public HistoryLog(int maxEntries) {
        if (maxEntries <= 0) {
            throw new IllegalArgumentException("Max entries must be positive.");
        }
        entries = new ArrayList<>();
        this.maxEntries = maxEntries;
    }

    /**
     * Adds a new entry to the history.
     * If at capacity, the oldest entry is removed.
     */
    public void addEntry(String entry) {
        if (entry == null || entry.isEmpty()) {
            return;
        }
        if (entries.size() >= maxEntries) {
            entries.remove(0);
        }
        entries.add(entry);
    }

    /**
     * Returns a copy of all stored entries.
     */
    public ArrayList<String> getEntries() {
        return new ArrayList<>(entries);
    }

    /**
     * Returns the most recent entry, or null if empty.
     */
    public String getLastEntry() {
        if (entries.isEmpty()) {
            return null;
        }
        return entries.get(entries.size() - 1);
    }

    /**
     * Returns the number of entries currently stored.
     */
    public int getCount() {
        return entries.size();
    }

    /**
     * Removes all stored entries.
     */
    public void clearAll() {
        entries.clear();
    }

    /**
     * Returns whether there are any stored entries.
     */
    public boolean isEmpty() {
        return entries.isEmpty();
    }

    /**
     * Returns the entry at the specified index (0-based).
     */
    public String getEntryAt(int index) {
        if (index < 0 || index >= entries.size()) {
            throw new IndexOutOfBoundsException("No entry at index: " + index);
        }
        return entries.get(index);
    }

    /**
     * Searches history for entries containing the given keyword.
     */
    public ArrayList<String> search(String keyword) {
        ArrayList<String> matches = new ArrayList<>();
        for (String entry : entries) {
            if (entry.contains(keyword)) {
                matches.add(entry);
            }
        }
        return matches;
    }

    /**
     * Returns a formatted string of all entries for display.
     */
    public String getSummary() {
        if (entries.isEmpty()) {
            return "No history available.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < entries.size(); i++) {
            sb.append((i + 1)).append(". ").append(entries.get(i)).append("\n");
        }
        return sb.toString().trim();
    }
}
