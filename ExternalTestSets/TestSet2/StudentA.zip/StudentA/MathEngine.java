/**
 * MathEngine handles all arithmetic operations.
 * Supports: addition, subtraction, multiplication,
 * division, modulo, and exponentiation.
 */
public class MathEngine {

    public MathEngine() {
        // Default constructor
    }

    /**
     * Performs a calculation given two operands and an operator.
     * @param leftOperand  the left-hand value
     * @param operator     the arithmetic operator character
     * @param rightOperand the right-hand value
     * @return the computed result
     */
    public double calculate(double leftOperand, char operator, double rightOperand) {
        switch (operator) {
            case '+':
                return add(leftOperand, rightOperand);
            case '-':
                return subtract(leftOperand, rightOperand);
            case '*':
                return multiply(leftOperand, rightOperand);
            case '/':
                return divide(leftOperand, rightOperand);
            case '%':
                return modulo(leftOperand, rightOperand);
            case '^':
                return power(leftOperand, rightOperand);
            default:
                throw new IllegalArgumentException("Unknown operator: " + operator);
        }
    }

    private double add(double a, double b) {
        return a + b;
    }

    private double subtract(double a, double b) {
        return a - b;
    }

    private double multiply(double a, double b) {
        return a * b;
    }

    private double divide(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Division by zero is undefined.");
        }
        return a / b;
    }

    private double modulo(double a, double b) {
        if (b == 0) {
            throw new ArithmeticException("Modulo by zero is undefined.");
        }
        return a % b;
    }

    private double power(double base, double exponent) {
        return Math.pow(base, exponent);
    }

    /**
     * Returns true if the result is a whole number.
     */
    public boolean isWholeNumber(double value) {
        return value == Math.floor(value) && !Double.isInfinite(value);
    }

    /**
     * Rounds a result to a given number of decimal places.
     */
    public double roundTo(double value, int decimalPlaces) {
        if (decimalPlaces < 0) {
            throw new IllegalArgumentException("Decimal places must be non-negative.");
        }
        double scale = Math.pow(10, decimalPlaces);
        return Math.round(value * scale) / scale;
    }

    /**
     * Returns the absolute value of a number.
     */
    public double absolute(double value) {
        return Math.abs(value);
    }

    /**
     * Returns the square root of a non-negative number.
     */
    public double squareRoot(double value) {
        if (value < 0) {
            throw new ArithmeticException("Cannot take square root of a negative number.");
        }
        return Math.sqrt(value);
    }
}
