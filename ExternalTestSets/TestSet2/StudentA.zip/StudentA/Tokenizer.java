/**
 * Tokenizer parses a raw expression string into numeric
 * and operator tokens for the calculator to process.
 */
public class Tokenizer {

    private String expression;
    private int position;

    public Tokenizer(String expression) {
        if (expression == null) {
            throw new IllegalArgumentException("Expression cannot be null.");
        }
        this.expression = expression.trim();
        this.position = 0;
    }

    /**
     * Reads and returns the next number token from the expression.
     * Skips any leading whitespace.
     */
    public double nextNumber() {
        skipWhitespace();

        if (position >= expression.length()) {
            throw new IllegalStateException("Expected a number but reached end of expression.");
        }

        int startPos = position;

        // Handle optional leading negative sign
        if (expression.charAt(position) == '-') {
            position++;
        }

        boolean hasDot = false;
        while (position < expression.length()) {
            char ch = expression.charAt(position);
            if (Character.isDigit(ch)) {
                position++;
            } else if (ch == '.' && !hasDot) {
                hasDot = true;
                position++;
            } else {
                break;
            }
        }

        String numberToken = expression.substring(startPos, position);

        if (numberToken.isEmpty() || numberToken.equals("-")) {
            throw new NumberFormatException("Invalid number near position " + startPos);
        }

        return Double.parseDouble(numberToken);
    }

    /**
     * Reads and returns the next operator character from the expression.
     * Skips any leading whitespace.
     */
    public char nextOperator() {
        skipWhitespace();

        if (position >= expression.length()) {
            throw new IllegalStateException("Expected an operator but reached end of expression.");
        }

        char operatorChar = expression.charAt(position);
        String validOperators = "+-*/%^";

        if (validOperators.indexOf(operatorChar) == -1) {
            throw new IllegalArgumentException("Unrecognized operator: '" + operatorChar + "'");
        }

        position++;
        return operatorChar;
    }

    /**
     * Returns true if there are more characters to read.
     */
    public boolean hasMore() {
        skipWhitespace();
        return position < expression.length();
    }

    /**
     * Resets the tokenizer back to the start of the expression.
     */
    public void reset() {
        position = 0;
    }

    /**
     * Returns the remaining unparsed portion of the expression.
     */
    public String getRemainder() {
        if (position >= expression.length()) {
            return "";
        }
        return expression.substring(position).trim();
    }

    private void skipWhitespace() {
        while (position < expression.length() && Character.isWhitespace(expression.charAt(position))) {
            position++;
        }
    }

    /**
     * Returns the full original expression string.
     */
    public String getExpression() {
        return expression;
    }
}
