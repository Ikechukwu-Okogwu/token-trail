/**
 * ArithmeticProcessor executes arithmetic operations.
 * Supports: addition, subtraction, multiplication,
 * division, modulo, and exponentiation.
 */
public class ArithmeticProcessor {

    public ArithmeticProcessor() {
        // Default constructor
    }

    /**
     * Computes a result given two values and an operator symbol.
     * @param firstVal   the left-hand value
     * @param opSymbol   the arithmetic operator character
     * @param secondVal  the right-hand value
     * @return the computed outcome
     */
    public double compute(double firstVal, char opSymbol, double secondVal) {
        switch (opSymbol) {
            case '+':
                return addValues(firstVal, secondVal);
            case '-':
                return subtractValues(firstVal, secondVal);
            case '*':
                return multiplyValues(firstVal, secondVal);
            case '/':
                return divideValues(firstVal, secondVal);
            case '%':
                return moduloValues(firstVal, secondVal);
            case '^':
                return raisepower(firstVal, secondVal);
            default:
                throw new IllegalArgumentException("Unknown operator: " + opSymbol);
        }
    }

    private double addValues(double x, double y) {
        return x + y;
    }

    private double subtractValues(double x, double y) {
        return x - y;
    }

    private double multiplyValues(double x, double y) {
        return x * y;
    }

    private double divideValues(double x, double y) {
        if (y == 0) {
            throw new ArithmeticException("Division by zero is undefined.");
        }
        return x / y;
    }

    private double moduloValues(double x, double y) {
        if (y == 0) {
            throw new ArithmeticException("Modulo by zero is undefined.");
        }
        return x % y;
    }

    private double raisepower(double baseNum, double expNum) {
        return Math.pow(baseNum, expNum);
    }

    /**
     * Returns true if the result is a whole number.
     */
    public boolean isInteger(double val) {
        return val == Math.floor(val) && !Double.isInfinite(val);
    }

    /**
     * Rounds a result to a given number of decimal places.
     */
    public double roundResult(double val, int places) {
        if (places < 0) {
            throw new IllegalArgumentException("Decimal places must be non-negative.");
        }
        double factor = Math.pow(10, places);
        return Math.round(val * factor) / factor;
    }

    /**
     * Returns the absolute value of a number.
     */
    public double absValue(double val) {
        return Math.abs(val);
    }

    /**
     * Returns the square root of a non-negative number.
     */
    public double sqrt(double val) {
        if (val < 0) {
            throw new ArithmeticException("Cannot take square root of a negative number.");
        }
        return Math.sqrt(val);
    }
}
