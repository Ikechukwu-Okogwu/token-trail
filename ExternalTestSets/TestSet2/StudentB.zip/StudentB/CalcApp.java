import java.util.Scanner;
import java.util.ArrayList;

/**
 * CalcApp is the main entry point for the arithmetic tool.
 * Handles user interaction, computation dispatch, and record keeping.
 */
public class CalcApp {

    private ArithmeticProcessor processor;
    private RecordKeeper records;
    private Scanner consoleReader;

    public CalcApp() {
        processor = new ArithmeticProcessor();
        records = new RecordKeeper();
        consoleReader = new Scanner(System.in);
    }

    public void run() {
        System.out.println("=== Simple Calculator ===");
        System.out.println("Operators: +  -  *  /  %  ^");
        System.out.println("Commands: history, clear, quit");
        System.out.println();

        boolean active = true;
        while (active) {
            System.out.print("> ");
            String rawInput = consoleReader.nextLine().trim();

            if (rawInput.equalsIgnoreCase("quit")) {
                active = false;
                System.out.println("Goodbye.");
            } else if (rawInput.equalsIgnoreCase("history")) {
                displayHistory();
            } else if (rawInput.equalsIgnoreCase("clear")) {
                records.wipeAll();
                System.out.println("History cleared.");
            } else if (!rawInput.isEmpty()) {
                evaluateInput(rawInput);
            }
        }

        consoleReader.close();
    }

    private void evaluateInput(String inputLine) {
        try {
            ExpressionParser parser = new ExpressionParser(inputLine);
            double firstVal = parser.nextNumber();
            char opSymbol = parser.nextOperator();
            double secondVal = parser.nextNumber();

            double outcome = processor.compute(firstVal, opSymbol, secondVal);
            String record = inputLine + " = " + displayValue(outcome);
            records.saveRecord(record);
            System.out.println("= " + displayValue(outcome));
        } catch (ArithmeticException ae) {
            System.out.println("Math error: " + ae.getMessage());
        } catch (Exception ex) {
            System.out.println("Invalid input. Example: 5 + 3");
        }
    }

    private void displayHistory() {
        ArrayList<String> allRecords = records.fetchRecords();
        if (allRecords.isEmpty()) {
            System.out.println("No history yet.");
        } else {
            System.out.println("--- History ---");
            for (int idx = 0; idx < allRecords.size(); idx++) {
                System.out.println((idx + 1) + ". " + allRecords.get(idx));
            }
            System.out.println("---------------");
        }
    }

    private String displayValue(double val) {
        if (val == (long) val) {
            return String.valueOf((long) val);
        }
        return String.format("%.4f", val);
    }

    public static void main(String[] args) {
        CalcApp app = new CalcApp();
        app.run();
    }
}
