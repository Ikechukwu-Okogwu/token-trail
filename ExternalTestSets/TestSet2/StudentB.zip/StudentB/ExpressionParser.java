/**
 * ExpressionParser breaks a raw input string into
 * numeric and operator tokens for computation.
 */
public class ExpressionParser {

    private String inputExpr;
    private int curPos;

    public ExpressionParser(String inputExpr) {
        if (inputExpr == null) {
            throw new IllegalArgumentException("Expression cannot be null.");
        }
        this.inputExpr = inputExpr.trim();
        this.curPos = 0;
    }

    /**
     * Reads and returns the next numeric token.
     * Skips any leading whitespace.
     */
    public double nextNumber() {
        advancePastSpaces();

        if (curPos >= inputExpr.length()) {
            throw new IllegalStateException("Expected a number but reached end of expression.");
        }

        int startIdx = curPos;

        // Handle optional leading negative sign
        if (inputExpr.charAt(curPos) == '-') {
            curPos++;
        }

        boolean dotSeen = false;
        while (curPos < inputExpr.length()) {
            char ch = inputExpr.charAt(curPos);
            if (Character.isDigit(ch)) {
                curPos++;
            } else if (ch == '.' && !dotSeen) {
                dotSeen = true;
                curPos++;
            } else {
                break;
            }
        }

        String numStr = inputExpr.substring(startIdx, curPos);

        if (numStr.isEmpty() || numStr.equals("-")) {
            throw new NumberFormatException("Invalid number near position " + startIdx);
        }

        return Double.parseDouble(numStr);
    }

    /**
     * Reads and returns the next operator character.
     * Skips any leading whitespace.
     */
    public char nextOperator() {
        advancePastSpaces();

        if (curPos >= inputExpr.length()) {
            throw new IllegalStateException("Expected an operator but reached end of expression.");
        }

        char opChar = inputExpr.charAt(curPos);
        String allowedOps = "+-*/%^";

        if (allowedOps.indexOf(opChar) == -1) {
            throw new IllegalArgumentException("Unrecognized operator: '" + opChar + "'");
        }

        curPos++;
        return opChar;
    }

    /**
     * Returns true if there are more characters to read.
     */
    public boolean moreTokens() {
        advancePastSpaces();
        return curPos < inputExpr.length();
    }

    /**
     * Resets the parser back to the beginning of the expression.
     */
    public void rewind() {
        curPos = 0;
    }

    /**
     * Returns the unparsed remainder of the expression.
     */
    public String remainder() {
        if (curPos >= inputExpr.length()) {
            return "";
        }
        return inputExpr.substring(curPos).trim();
    }

    private void advancePastSpaces() {
        while (curPos < inputExpr.length() && Character.isWhitespace(inputExpr.charAt(curPos))) {
            curPos++;
        }
    }

    /**
     * Returns the original input expression.
     */
    public String getInputExpr() {
        return inputExpr;
    }
}
