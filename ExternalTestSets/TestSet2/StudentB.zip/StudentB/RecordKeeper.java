import java.util.ArrayList;

/**
 * RecordKeeper stores and manages past computation records.
 * Records are stored in insertion order.
 */
public class RecordKeeper {

    private ArrayList<String> savedRecords;
    private int recordLimit;

    public RecordKeeper() {
        savedRecords = new ArrayList<>();
        recordLimit = 50;
    }

    public RecordKeeper(int recordLimit) {
        if (recordLimit <= 0) {
            throw new IllegalArgumentException("Max entries must be positive.");
        }
        savedRecords = new ArrayList<>();
        this.recordLimit = recordLimit;
    }

    /**
     * Saves a new record.
     * If at capacity, the oldest record is dropped.
     */
    public void saveRecord(String record) {
        if (record == null || record.isEmpty()) {
            return;
        }
        if (savedRecords.size() >= recordLimit) {
            savedRecords.remove(0);
        }
        savedRecords.add(record);
    }

    /**
     * Returns a copy of all stored records.
     */
    public ArrayList<String> fetchRecords() {
        return new ArrayList<>(savedRecords);
    }

    /**
     * Returns the most recently saved record, or null if empty.
     */
    public String fetchLatest() {
        if (savedRecords.isEmpty()) {
            return null;
        }
        return savedRecords.get(savedRecords.size() - 1);
    }

    /**
     * Returns the number of records currently stored.
     */
    public int totalRecords() {
        return savedRecords.size();
    }

    /**
     * Removes all stored records.
     */
    public void wipeAll() {
        savedRecords.clear();
    }

    /**
     * Returns whether there are any stored records.
     */
    public boolean hasNoRecords() {
        return savedRecords.isEmpty();
    }

    /**
     * Returns the record at the specified index (0-based).
     */
    public String fetchAt(int idx) {
        if (idx < 0 || idx >= savedRecords.size()) {
            throw new IndexOutOfBoundsException("No record at index: " + idx);
        }
        return savedRecords.get(idx);
    }

    /**
     * Searches records for entries containing the given keyword.
     */
    public ArrayList<String> findMatches(String keyword) {
        ArrayList<String> matches = new ArrayList<>();
        for (String rec : savedRecords) {
            if (rec.contains(keyword)) {
                matches.add(rec);
            }
        }
        return matches;
    }

    /**
     * Returns a formatted string of all records for display.
     */
    public String buildSummary() {
        if (savedRecords.isEmpty()) {
            return "No history available.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < savedRecords.size(); i++) {
            sb.append((i + 1)).append(". ").append(savedRecords.get(i)).append("\n");
        }
        return sb.toString().trim();
    }
}
