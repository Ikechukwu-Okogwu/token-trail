/**
 * InputSplitter parses a user-supplied expression string
 * into number and operator tokens for evaluation.
 */
public class InputSplitter {

    private String rawInput;
    private int scanPos;

    public InputSplitter(String rawInput) {
        if (rawInput == null) {
            throw new IllegalArgumentException("Expression cannot be null.");
        }
        this.rawInput = rawInput.trim();
        this.scanPos = 0;
    }

    /**
     * Extracts and returns the next number from the input.
     * Advances past any leading whitespace first.
     */
    public double nextNumber() {
        skipBlanks();

        if (scanPos >= rawInput.length()) {
            throw new IllegalStateException("Expected a number but reached end of expression.");
        }

        int markPos = scanPos;

        // Handle optional leading negative sign
        if (rawInput.charAt(scanPos) == '-') {
            scanPos++;
        }

        boolean foundDot = false;
        while (scanPos < rawInput.length()) {
            char c = rawInput.charAt(scanPos);
            if (Character.isDigit(c)) {
                scanPos++;
            } else if (c == '.' && !foundDot) {
                foundDot = true;
                scanPos++;
            } else {
                break;
            }
        }

        String chunk = rawInput.substring(markPos, scanPos);

        if (chunk.isEmpty() || chunk.equals("-")) {
            throw new NumberFormatException("Invalid number near position " + markPos);
        }

        return Double.parseDouble(chunk);
    }

    /**
     * Extracts and returns the next operator from the input.
     * Advances past any leading whitespace first.
     */
    public char nextOperator() {
        skipBlanks();

        if (scanPos >= rawInput.length()) {
            throw new IllegalStateException("Expected an operator but reached end of expression.");
        }

        char sym = rawInput.charAt(scanPos);
        String legalOps = "+-*/%^";

        if (legalOps.indexOf(sym) == -1) {
            throw new IllegalArgumentException("Unrecognized operator: '" + sym + "'");
        }

        scanPos++;
        return sym;
    }

    /**
     * Returns true if there are remaining characters to parse.
     */
    public boolean canContinue() {
        skipBlanks();
        return scanPos < rawInput.length();
    }

    /**
     * Resets the scan position to the beginning.
     */
    public void restart() {
        scanPos = 0;
    }

    /**
     * Returns the portion of input not yet parsed.
     */
    public String leftover() {
        if (scanPos >= rawInput.length()) {
            return "";
        }
        return rawInput.substring(scanPos).trim();
    }

    private void skipBlanks() {
        while (scanPos < rawInput.length() && Character.isWhitespace(rawInput.charAt(scanPos))) {
            scanPos++;
        }
    }

    /**
     * Returns the original raw input string.
     */
    public String getRawInput() {
        return rawInput;
    }
}
