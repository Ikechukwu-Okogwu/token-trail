import java.util.Scanner;
import java.util.ArrayList;

/**
 * MathTool is the main driver for the arithmetic utility.
 * Manages the user session, delegates computation, and tracks operations.
 */
public class MathTool {

    private OperationHandler handler;
    private SessionLog sessionLog;
    private Scanner keyboardInput;

    public MathTool() {
        handler = new OperationHandler();
        sessionLog = new SessionLog();
        keyboardInput = new Scanner(System.in);
    }

    public void launch() {
        System.out.println("=== Simple Calculator ===");
        System.out.println("Operators: +  -  *  /  %  ^");
        System.out.println("Commands: history, clear, quit");
        System.out.println();

        boolean keepGoing = true;
        while (keepGoing) {
            System.out.print("> ");
            String line = keyboardInput.nextLine().trim();

            if (line.equalsIgnoreCase("quit")) {
                keepGoing = false;
                System.out.println("Goodbye.");
            } else if (line.equalsIgnoreCase("history")) {
                showLog();
            } else if (line.equalsIgnoreCase("clear")) {
                sessionLog.purge();
                System.out.println("History cleared.");
            } else if (!line.isEmpty()) {
                handleLine(line);
            }
        }

        keyboardInput.close();
    }

    private void handleLine(String line) {
        try {
            InputSplitter splitter = new InputSplitter(line);
            double numA = splitter.nextNumber();
            char opToken = splitter.nextOperator();
            double numB = splitter.nextNumber();

            double answer = handler.execute(numA, opToken, numB);
            String logEntry = line + " = " + renderValue(answer);
            sessionLog.append(logEntry);
            System.out.println("= " + renderValue(answer));
        } catch (ArithmeticException ae) {
            System.out.println("Math error: " + ae.getMessage());
        } catch (Exception ex) {
            System.out.println("Invalid input. Example: 5 + 3");
        }
    }

    private void showLog() {
        ArrayList<String> logEntries = sessionLog.retrieve();
        if (logEntries.isEmpty()) {
            System.out.println("No history yet.");
        } else {
            System.out.println("--- History ---");
            for (int n = 0; n < logEntries.size(); n++) {
                System.out.println((n + 1) + ". " + logEntries.get(n));
            }
            System.out.println("---------------");
        }
    }

    private String renderValue(double num) {
        if (num == (long) num) {
            return String.valueOf((long) num);
        }
        return String.format("%.4f", num);
    }

    public static void main(String[] args) {
        MathTool tool = new MathTool();
        tool.launch();
    }
}
