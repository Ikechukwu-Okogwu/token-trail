/**
 * OperationHandler carries out arithmetic operations.
 * Supports: addition, subtraction, multiplication,
 * division, modulo, and exponentiation.
 */
public class OperationHandler {

    public OperationHandler() {
        // Default constructor
    }

    /**
     * Executes the appropriate operation on two numbers.
     * @param numA     the left-hand operand
     * @param opToken  the operator character
     * @param numB     the right-hand operand
     * @return the resulting answer
     */
    public double execute(double numA, char opToken, double numB) {
        switch (opToken) {
            case '+':
                return doAdd(numA, numB);
            case '-':
                return doSubtract(numA, numB);
            case '*':
                return doMultiply(numA, numB);
            case '/':
                return doDivide(numA, numB);
            case '%':
                return doModulo(numA, numB);
            case '^':
                return doPower(numA, numB);
            default:
                throw new IllegalArgumentException("Unknown operator: " + opToken);
        }
    }

    private double doAdd(double p, double q) {
        return p + q;
    }

    private double doSubtract(double p, double q) {
        return p - q;
    }

    private double doMultiply(double p, double q) {
        return p * q;
    }

    private double doDivide(double p, double q) {
        if (q == 0) {
            throw new ArithmeticException("Division by zero is undefined.");
        }
        return p / q;
    }

    private double doModulo(double p, double q) {
        if (q == 0) {
            throw new ArithmeticException("Modulo by zero is undefined.");
        }
        return p % q;
    }

    private double doPower(double baseVal, double expVal) {
        return Math.pow(baseVal, expVal);
    }

    /**
     * Returns true if the value has no fractional part.
     */
    public boolean isWhole(double num) {
        return num == Math.floor(num) && !Double.isInfinite(num);
    }

    /**
     * Rounds a value to the given number of decimal places.
     */
    public double roundValue(double num, int decimals) {
        if (decimals < 0) {
            throw new IllegalArgumentException("Decimal places must be non-negative.");
        }
        double multiplier = Math.pow(10, decimals);
        return Math.round(num * multiplier) / multiplier;
    }

    /**
     * Returns the absolute value of a number.
     */
    public double getAbsolute(double num) {
        return Math.abs(num);
    }

    /**
     * Returns the square root of a non-negative number.
     */
    public double getSqrt(double num) {
        if (num < 0) {
            throw new ArithmeticException("Cannot take square root of a negative number.");
        }
        return Math.sqrt(num);
    }
}
