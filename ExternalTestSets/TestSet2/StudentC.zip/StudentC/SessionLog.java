import java.util.ArrayList;

/**
 * SessionLog records and manages arithmetic operations performed
 * during a user session. Entries are stored in order of occurrence.
 */
public class SessionLog {

    private ArrayList<String> logEntries;
    private int entryLimit;

    public SessionLog() {
        logEntries = new ArrayList<>();
        entryLimit = 50;
    }

    public SessionLog(int entryLimit) {
        if (entryLimit <= 0) {
            throw new IllegalArgumentException("Max entries must be positive.");
        }
        logEntries = new ArrayList<>();
        this.entryLimit = entryLimit;
    }

    /**
     * Appends a new log entry.
     * Oldest entry is dropped when capacity is reached.
     */
    public void append(String logEntry) {
        if (logEntry == null || logEntry.isEmpty()) {
            return;
        }
        if (logEntries.size() >= entryLimit) {
            logEntries.remove(0);
        }
        logEntries.add(logEntry);
    }

    /**
     * Returns a copy of all stored log entries.
     */
    public ArrayList<String> retrieve() {
        return new ArrayList<>(logEntries);
    }

    /**
     * Returns the most recent log entry, or null if none exist.
     */
    public String latestEntry() {
        if (logEntries.isEmpty()) {
            return null;
        }
        return logEntries.get(logEntries.size() - 1);
    }

    /**
     * Returns the total number of stored entries.
     */
    public int entryCount() {
        return logEntries.size();
    }

    /**
     * Clears all stored log entries.
     */
    public void purge() {
        logEntries.clear();
    }

    /**
     * Returns whether the log currently has no entries.
     */
    public boolean isBlank() {
        return logEntries.isEmpty();
    }

    /**
     * Returns the log entry at the given index (0-based).
     */
    public String entryAt(int pos) {
        if (pos < 0 || pos >= logEntries.size()) {
            throw new IndexOutOfBoundsException("No entry at index: " + pos);
        }
        return logEntries.get(pos);
    }

    /**
     * Finds all entries containing the given search term.
     */
    public ArrayList<String> lookup(String term) {
        ArrayList<String> hits = new ArrayList<>();
        for (String entry : logEntries) {
            if (entry.contains(term)) {
                hits.add(entry);
            }
        }
        return hits;
    }

    /**
     * Returns a numbered summary of all log entries.
     */
    public String formatAll() {
        if (logEntries.isEmpty()) {
            return "No history available.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < logEntries.size(); i++) {
            sb.append((i + 1)).append(". ").append(logEntries.get(i)).append("\n");
        }
        return sb.toString().trim();
    }
}
