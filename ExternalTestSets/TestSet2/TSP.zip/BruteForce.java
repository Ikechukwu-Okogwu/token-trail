package tsp;

import java.util.ArrayList;
import java.util.List;

/**
 * Brute-force exact solver for the Traveling Salesman Problem.
 *
 * <p>Tries every permutation of cities (fixing the first city to avoid
 * counting rotations multiple times) to find the globally optimal tour.
 *
 * <p><strong>WARNING:</strong> Only feasible for small inputs.
 * Time complexity: O(n!) — impractical beyond ~11 cities.
 *
 * <p>The first city is always held fixed; all permutations of the
 * remaining (n-1) cities are evaluated, giving (n-1)! total tours checked.
 */
public class BruteForce {

    private final List<City> cities;
    private Tour bestTour;
    private long permutationsChecked;

    /**
     * Constructs a BruteForce solver for the given cities.
     *
     * @param cities the cities to visit (must be <= 11 for practical runtime)
     */
    public BruteForce(List<City> cities) {
        if (cities == null || cities.size() < 2) {
            throw new IllegalArgumentException("Need at least 2 cities.");
        }
        if (cities.size() > 11) {
            System.out.println("[WARNING] Brute force with " + cities.size()
                + " cities may be very slow. Consider using the heuristic solver.");
        }
        this.cities = new ArrayList<>(cities);
        this.bestTour = null;
        this.permutationsChecked = 0;
    }

    /**
     * Runs the brute-force search and returns the optimal tour.
     *
     * @return the globally optimal Tour
     */
    public Tour solve() {
        bestTour = null;
        permutationsChecked = 0;

        System.out.println("\n=== Brute-Force Exact Solver ===");
        System.out.println("Cities: " + cities.size());

        long factorial = factorial(cities.size() - 1);
        System.out.println("Permutations to check: " + factorial);
        System.out.println("--------------------------------");

        // Fix the first city; permute the rest
        List<City> fixed = new ArrayList<>(cities.subList(1, cities.size()));
        permute(fixed, 0);

        System.out.printf("Checked %,d permutations.%n", permutationsChecked);
        System.out.printf("Optimal distance: %.2f%n", bestTour.getTotalDistance());
        System.out.println("Optimal route: " + bestTour.getRouteString());
        System.out.println();

        return bestTour;
    }

    /**
     * Recursively generates all permutations of the list from index {@code start} onward,
     * evaluating each complete permutation as a tour.
     *
     * @param perm  the mutable city list being permuted
     * @param start the current position being fixed
     */
    private void permute(List<City> perm, int start) {
        if (start == perm.size()) {
            evaluateTour(perm);
            return;
        }

        for (int i = start; i < perm.size(); i++) {
            swap(perm, start, i);
            permute(perm, start + 1);
            swap(perm, start, i); // backtrack
        }
    }

    /**
     * Evaluates a candidate permutation as a full tour (with the fixed first city prepended).
     */
    private void evaluateTour(List<City> perm) {
        List<City> fullRoute = new ArrayList<>();
        fullRoute.add(cities.get(0)); // always start here
        fullRoute.addAll(perm);

        Tour candidate = new Tour(fullRoute);
        permutationsChecked++;

        if (bestTour == null || candidate.getTotalDistance() < bestTour.getTotalDistance()) {
            bestTour = new Tour(candidate);
        }
    }

    /**
     * Swaps elements at positions i and j in the list.
     */
    private static void swap(List<City> list, int i, int j) {
        City tmp = list.get(i);
        list.set(i, list.get(j));
        list.set(j, tmp);
    }

    /**
     * Computes n! iteratively.
     */
    private static long factorial(int n) {
        long result = 1;
        for (int i = 2; i <= n; i++) result *= i;
        return result;
    }

    /**
     * Returns how many permutations were evaluated.
     */
    public long getPermutationsChecked() {
        return permutationsChecked;
    }
}
