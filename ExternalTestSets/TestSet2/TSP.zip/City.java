package tsp;

/**
 * Represents a city (node) in the Traveling Salesman Problem.
 * Each city has a unique ID, a label, and (x, y) coordinates
 * used to compute Euclidean distances.
 */
public class City {

    private final int id;
    private final String name;
    private final double x;
    private final double y;

    /**
     * Constructs a city with the given ID, name, and coordinates.
     *
     * @param id   unique identifier
     * @param name human-readable city name
     * @param x    x-coordinate on the 2D plane
     * @param y    y-coordinate on the 2D plane
     */
    public City(int id, String name, double x, double y) {
        this.id = id;
        this.name = name;
        this.x = x;
        this.y = y;
    }

    /**
     * Computes the Euclidean distance from this city to another.
     *
     * @param other the target city
     * @return straight-line distance
     */
    public double distanceTo(City other) {
        double dx = this.x - other.x;
        double dy = this.y - other.y;
        return Math.sqrt(dx * dx + dy * dy);
    }

    // --- Getters ---

    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof City)) return false;
        return this.id == ((City) o).id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }

    @Override
    public String toString() {
        return String.format("%s(%.1f,%.1f)", name, x, y);
    }
}
