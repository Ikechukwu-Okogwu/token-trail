package tsp;

import java.util.Arrays;
import java.util.List;

/**
 * Entry point for the Traveling Salesman Problem demonstration.
 *
 * <p>Runs three scenarios:
 *   1. Small instance (6 cities) — brute force vs. nearest neighbor + 2-opt
 *   2. Medium instance (12 cities) — nearest neighbor + 2-opt only
 *   3. Named city road trip (10 cities in Ontario) — nearest neighbor + 2-opt
 */
public class Main {

    public static void main(String[] args) {
        printBanner();
        runScenario1_SmallBruteForce();
        runScenario2_MediumHeuristic();
        runScenario3_OntarioRoadTrip();
    }

    // -------------------------------------------------------------------
    // Banner
    // -------------------------------------------------------------------

    private static void printBanner() {
        System.out.println("╔══════════════════════════════════════════════╗");
        System.out.println("║   Traveling Salesman Problem — Demo Suite   ║");
        System.out.println("╚══════════════════════════════════════════════╝");
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Scenario 1: Small instance — compare brute force vs heuristic
    // -------------------------------------------------------------------

    /**
     * 6-city instance small enough for brute force (5! = 120 permutations).
     * Demonstrates that 2-opt can match or get very close to the exact optimum.
     */
    private static void runScenario1_SmallBruteForce() {
        printSectionHeader("SCENARIO 1", "Small Instance — Brute Force vs. Heuristic (6 cities)");

        List<City> cities = Arrays.asList(
            new City(0, "Alpha",   0.0,  0.0),
            new City(1, "Beta",    3.0,  4.0),
            new City(2, "Gamma",   6.0,  1.0),
            new City(3, "Delta",   7.0,  5.0),
            new City(4, "Epsilon", 4.0,  8.0),
            new City(5, "Zeta",    1.0,  6.0)
        );

        printCityList(cities);

        // --- Brute Force (exact) ---
        BruteForce bf = new BruteForce(cities);
        Tour optimal = bf.solve();

        // --- Nearest Neighbor + 2-opt (heuristic) ---
        NearestNeighborHeuristic nn = new NearestNeighborHeuristic(cities);
        Tour greedyTour = nn.buildTour(0);

        TwoOptImprover twoOpt = new TwoOptImprover(true);
        Tour improvedTour = twoOpt.improve(new Tour(greedyTour));

        // --- Comparison ---
        printComparison(optimal, greedyTour, improvedTour);
    }

    // -------------------------------------------------------------------
    // Scenario 2: Medium instance — heuristic only
    // -------------------------------------------------------------------

    /**
     * 12-city instance (11! ≈ 40 million permutations — brute force impractical).
     * Shows the heuristic pipeline at moderate scale.
     */
    private static void runScenario2_MediumHeuristic() {
        printSectionHeader("SCENARIO 2", "Medium Instance — Heuristic Only (12 cities)");

        List<City> cities = Arrays.asList(
            new City(0,  "A",  2.0,  3.0),
            new City(1,  "B",  5.0,  8.0),
            new City(2,  "C",  9.0,  2.0),
            new City(3,  "D",  1.0,  7.0),
            new City(4,  "E",  7.0,  6.0),
            new City(5,  "F",  3.0,  1.0),
            new City(6,  "G",  8.0,  9.0),
            new City(7,  "H",  4.0,  5.0),
            new City(8,  "I",  6.0,  3.0),
            new City(9,  "J",  0.0,  5.0),
            new City(10, "K", 10.0,  5.0),
            new City(11, "L",  5.0,  0.0)
        );

        printCityList(cities);

        // Try all starting cities, pick best greedy tour
        NearestNeighborHeuristic nn = new NearestNeighborHeuristic(cities);
        System.out.println("(Running nearest neighbor from all starting cities silently...)");
        Tour bestGreedy = nn.buildBestTour();
        System.out.printf("Best greedy tour (over all starts): %.2f%n", bestGreedy.getTotalDistance());
        System.out.println("Route: " + bestGreedy.getRouteString());
        System.out.println();

        TwoOptImprover twoOpt = new TwoOptImprover(false); // quiet mode
        Tour improved = twoOpt.improve(new Tour(bestGreedy));

        System.out.println("After 2-opt:");
        System.out.printf("  Distance  : %.2f%n", improved.getTotalDistance());
        System.out.printf("  Reduction : %.2f%%%n",
            100.0 * (bestGreedy.getTotalDistance() - improved.getTotalDistance())
                  / bestGreedy.getTotalDistance());
        System.out.println("  Route     : " + improved.getRouteString());
        System.out.println();
    }

    // -------------------------------------------------------------------
    // Scenario 3: Ontario road trip (named cities, realistic coordinates)
    // -------------------------------------------------------------------

    /**
     * A 10-city road trip through Southern Ontario.
     * Coordinates are approximate (scaled from real lat/lon).
     * Demonstrates the algorithm on a geographically meaningful problem.
     */
    private static void runScenario3_OntarioRoadTrip() {
        printSectionHeader("SCENARIO 3", "Ontario Road Trip (10 cities)");

        // Coordinates scaled from approximate lat/lon (x ≈ lon offset, y ≈ lat offset)
        List<City> cities = Arrays.asList(
            new City(0,  "Toronto",     100.0,  85.0),
            new City(1,  "Hamilton",     70.0,  75.0),
            new City(2,  "Kitchener",    48.0,  82.0),
            new City(3,  "London",       25.0,  72.0),
            new City(4,  "Windsor",       0.0,  55.0),
            new City(5,  "Sarnia",       10.0,  78.0),
            new City(6,  "Barrie",       88.0, 110.0),
            new City(7,  "Kingston",    155.0,  92.0),
            new City(8,  "Ottawa",      185.0, 118.0),
            new City(9,  "Sudbury",      85.0, 145.0)
        );

        printCityList(cities);

        // Nearest neighbor from Toronto (id=0)
        NearestNeighborHeuristic nn = new NearestNeighborHeuristic(cities);
        Tour greedyTour = nn.buildTour(0);

        // 2-opt improvement
        TwoOptImprover twoOpt = new TwoOptImprover(true);
        Tour finalTour = twoOpt.improve(new Tour(greedyTour));

        // Summary
        printFinalSummary(finalTour, greedyTour);
    }

    // -------------------------------------------------------------------
    // Utility printing methods
    // -------------------------------------------------------------------

    private static void printSectionHeader(String tag, String title) {
        System.out.println("══════════════════════════════════════════════════");
        System.out.println(" " + tag + ": " + title);
        System.out.println("══════════════════════════════════════════════════");
    }

    private static void printCityList(List<City> cities) {
        System.out.println("Cities:");
        for (City c : cities) {
            System.out.printf("  [%2d] %-12s  (%.1f, %.1f)%n",
                c.getId(), c.getName(), c.getX(), c.getY());
        }
        System.out.println();
    }

    private static void printComparison(Tour optimal, Tour greedy, Tour improved) {
        System.out.println("┌─────────────────────────────────────────────────┐");
        System.out.println("│                   COMPARISON                   │");
        System.out.println("├─────────────────────────────────────────────────┤");
        System.out.printf("│ %-20s  dist = %8.2f              │%n",
            "Brute force (optimal):", optimal.getTotalDistance());
        System.out.printf("│ %-20s  dist = %8.2f              │%n",
            "Nearest neighbor:", greedy.getTotalDistance());
        System.out.printf("│ %-20s  dist = %8.2f              │%n",
            "After 2-opt:", improved.getTotalDistance());

        double gapGreedy = 100.0 * (greedy.getTotalDistance() - optimal.getTotalDistance())
                                  / optimal.getTotalDistance();
        double gapImproved = 100.0 * (improved.getTotalDistance() - optimal.getTotalDistance())
                                    / optimal.getTotalDistance();

        System.out.println("├─────────────────────────────────────────────────┤");
        System.out.printf("│ Greedy gap from optimal:   %6.2f%%%n", gapGreedy);
        System.out.printf("│ 2-opt gap from optimal:    %6.2f%%%n", gapImproved);
        System.out.println("└─────────────────────────────────────────────────┘");

        System.out.println("\nOptimal route : " + optimal.getRouteString());
        System.out.println("2-opt route   : " + improved.getRouteString());
        System.out.println();
    }

    private static void printFinalSummary(Tour finalTour, Tour greedyTour) {
        double improvement = greedyTour.getTotalDistance() - finalTour.getTotalDistance();
        double pct = 100.0 * improvement / greedyTour.getTotalDistance();

        System.out.println("┌─────────────────────────────────────────────────┐");
        System.out.println("│               FINAL TOUR SUMMARY               │");
        System.out.println("├─────────────────────────────────────────────────┤");
        System.out.printf("│ Greedy distance : %8.2f                       │%n",
            greedyTour.getTotalDistance());
        System.out.printf("│ 2-opt distance  : %8.2f                       │%n",
            finalTour.getTotalDistance());
        System.out.printf("│ Saved           : %8.2f  (%.2f%% shorter)%n",
            improvement, pct);
        System.out.println("├─────────────────────────────────────────────────┤");
        System.out.println("│ Final route:                                    │");
        System.out.printf("│   %s%n", finalTour.getRouteString());
        System.out.println("└─────────────────────────────────────────────────┘");
        System.out.println();
    }
}
