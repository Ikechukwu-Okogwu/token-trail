package tsp;

import java.util.ArrayList;
import java.util.List;

/**
 * Nearest Neighbor heuristic for the Traveling Salesman Problem.
 *
 * <p>This greedy algorithm builds an initial tour by repeatedly visiting
 * the closest unvisited city from the current position.
 *
 * <p>It does not guarantee an optimal solution, but typically produces a
 * reasonable starting point (often within 20-25% of optimal) very quickly.
 *
 * <p>Time complexity: O(n²)
 */
public class NearestNeighborHeuristic {

    private final List<City> cities;

    /**
     * Constructs the heuristic with the given list of cities.
     *
     * @param cities list of all cities to visit
     */
    public NearestNeighborHeuristic(List<City> cities) {
        if (cities == null || cities.isEmpty()) {
            throw new IllegalArgumentException("City list must not be null or empty.");
        }
        this.cities = new ArrayList<>(cities);
    }

    /**
     * Runs the nearest neighbor heuristic starting from the city at the given index.
     *
     * @param startIndex index of the starting city in the city list
     * @return a Tour representing the greedy solution
     */
    public Tour buildTour(int startIndex) {
        int n = cities.size();
        boolean[] visited = new boolean[n];
        Tour tour = new Tour();

        int currentIndex = startIndex;
        visited[currentIndex] = true;
        tour.addCity(cities.get(currentIndex));

        System.out.println("\n=== Nearest Neighbor Heuristic ===");
        System.out.printf("Start: %s%n", cities.get(startIndex).getName());
        System.out.println("-----------------------------------");

        for (int step = 1; step < n; step++) {
            int nearestIndex = findNearestUnvisited(currentIndex, visited);
            visited[nearestIndex] = true;
            tour.addCity(cities.get(nearestIndex));

            double dist = cities.get(currentIndex).distanceTo(cities.get(nearestIndex));
            System.out.printf("Step %2d | %-12s -> %-12s  (leg: %6.2f)%n",
                step,
                cities.get(currentIndex).getName(),
                cities.get(nearestIndex).getName(),
                dist
            );

            currentIndex = nearestIndex;
        }

        // Close the tour
        double returnDist = cities.get(currentIndex).distanceTo(cities.get(startIndex));
        System.out.printf("Return  | %-12s -> %-12s  (leg: %6.2f)%n",
            cities.get(currentIndex).getName(),
            cities.get(startIndex).getName(),
            returnDist
        );
        System.out.println("-----------------------------------");
        System.out.printf("Greedy tour distance: %.2f%n%n", tour.getTotalDistance());

        return tour;
    }

    /**
     * Tries all possible starting cities and returns the best greedy tour found.
     *
     * @return the best tour among all starting cities
     */
    public Tour buildBestTour() {
        Tour best = null;

        for (int i = 0; i < cities.size(); i++) {
            Tour candidate = buildTourSilent(i);
            if (best == null || candidate.getTotalDistance() < best.getTotalDistance()) {
                best = candidate;
            }
        }
        return best;
    }

    /**
     * Runs the heuristic silently (no console output) from the given start index.
     */
    private Tour buildTourSilent(int startIndex) {
        int n = cities.size();
        boolean[] visited = new boolean[n];
        Tour tour = new Tour();

        int currentIndex = startIndex;
        visited[currentIndex] = true;
        tour.addCity(cities.get(currentIndex));

        for (int step = 1; step < n; step++) {
            int nearestIndex = findNearestUnvisited(currentIndex, visited);
            visited[nearestIndex] = true;
            tour.addCity(cities.get(nearestIndex));
            currentIndex = nearestIndex;
        }

        return tour;
    }

    /**
     * Finds the index of the nearest unvisited city from the given city.
     *
     * @param currentIndex index of the current city
     * @param visited      array tracking which cities have been visited
     * @return index of the nearest unvisited city
     */
    private int findNearestUnvisited(int currentIndex, boolean[] visited) {
        City current = cities.get(currentIndex);
        int bestIndex = -1;
        double bestDist = Double.MAX_VALUE;

        for (int i = 0; i < cities.size(); i++) {
            if (!visited[i]) {
                double dist = current.distanceTo(cities.get(i));
                if (dist < bestDist) {
                    bestDist = dist;
                    bestIndex = i;
                }
            }
        }

        return bestIndex;
    }
}
