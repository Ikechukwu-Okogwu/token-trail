package tsp;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Represents a candidate solution (tour) for the TSP.
 *
 * <p>A tour is an ordered list of cities that forms a cycle:
 * the salesman visits each city exactly once and returns to the start.
 * The total tour distance is the sum of all consecutive edge distances,
 * including the return leg from the last city back to the first.
 */
public class Tour {

    private final List<City> cities;
    private double cachedDistance = -1.0; // lazy-computed, invalidated on mutation

    /**
     * Constructs an empty tour.
     */
    public Tour() {
        this.cities = new ArrayList<>();
    }

    /**
     * Constructs a tour from an existing ordered list of cities.
     *
     * @param cities ordered city sequence (does not need to include return leg)
     */
    public Tour(List<City> cities) {
        this.cities = new ArrayList<>(cities);
    }

    /**
     * Copy constructor — creates a deep copy of another tour.
     *
     * @param other the tour to copy
     */
    public Tour(Tour other) {
        this.cities = new ArrayList<>(other.cities);
        this.cachedDistance = other.cachedDistance;
    }

    /**
     * Appends a city to the end of the tour.
     *
     * @param city city to add
     */
    public void addCity(City city) {
        cities.add(city);
        cachedDistance = -1; // invalidate cache
    }

    /**
     * Returns the total tour distance, including the return to the start.
     * Result is cached after the first computation.
     *
     * @return total Euclidean tour length
     */
    public double getTotalDistance() {
        if (cachedDistance >= 0) return cachedDistance;

        double total = 0.0;
        int n = cities.size();
        for (int i = 0; i < n; i++) {
            City from = cities.get(i);
            City to = cities.get((i + 1) % n); // wraps around
            total += from.distanceTo(to);
        }
        cachedDistance = total;
        return total;
    }

    /**
     * Swaps the cities at positions i and j (in-place 2-opt move).
     * Invalidates the distance cache.
     */
    public void swap(int i, int j) {
        Collections.swap(cities, i, j);
        cachedDistance = -1;
    }

    /**
     * Reverses the segment of the tour between indices i and j (inclusive).
     * This is the core operation of the 2-opt improvement heuristic.
     *
     * @param i start index of the segment
     * @param j end index of the segment (i <= j)
     */
    public void reverseSegment(int i, int j) {
        while (i < j) {
            Collections.swap(cities, i, j);
            i++;
            j--;
        }
        cachedDistance = -1;
    }

    /**
     * Returns the city at the given position in the tour.
     *
     * @param index position index (0-based)
     * @return the city at that position
     */
    public City getCity(int index) {
        return cities.get(index);
    }

    /**
     * Returns the number of cities in the tour.
     */
    public int size() {
        return cities.size();
    }

    /**
     * Returns an unmodifiable view of the city sequence.
     */
    public List<City> getCities() {
        return Collections.unmodifiableList(cities);
    }

    /**
     * Returns a formatted string describing the tour route.
     * Example: "A -> B -> C -> D -> (A)"
     */
    public String getRouteString() {
        if (cities.isEmpty()) return "(empty tour)";

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cities.size(); i++) {
            sb.append(cities.get(i).getName());
            if (i < cities.size() - 1) sb.append(" -> ");
        }
        sb.append(" -> (").append(cities.get(0).getName()).append(")");
        return sb.toString();
    }

    @Override
    public String toString() {
        return String.format("Tour[%d cities, dist=%.2f]", cities.size(), getTotalDistance());
    }
}
