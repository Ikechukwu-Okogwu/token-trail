package tsp;

/**
 * 2-opt local search improvement algorithm for the TSP.
 *
 * <p>Starting from an initial tour, 2-opt iteratively checks every pair of
 * non-adjacent edges (i, i+1) and (j, j+1). If reversing the segment between
 * i+1 and j produces a shorter tour, the reversal is applied. This continues
 * until no improving swap can be found (local optimum).
 *
 * <p>The name "2-opt" refers to removing 2 edges and reconnecting the tour
 * in a different way.
 *
 * <p>Time complexity per iteration: O(n²). Convergence typically takes
 * O(n) iterations, giving O(n³) overall in the worst case.
 */
public class TwoOptImprover {

    private final boolean verbose;
    private int totalImprovements;
    private int totalIterations;

    /**
     * Constructs a TwoOptImprover.
     *
     * @param verbose if true, prints each improving swap to the console
     */
    public TwoOptImprover(boolean verbose) {
        this.verbose = verbose;
        this.totalImprovements = 0;
        this.totalIterations = 0;
    }

    /**
     * Improves the given tour in-place using 2-opt until no further
     * improvement is possible.
     *
     * @param tour the initial tour to improve (modified in-place)
     * @return the same tour object, now locally optimal under 2-opt
     */
    public Tour improve(Tour tour) {
        totalImprovements = 0;
        totalIterations = 0;

        int n = tour.size();
        boolean improved = true;

        System.out.println("=== 2-opt Local Search ===");
        System.out.println("--------------------------");

        while (improved) {
            improved = false;
            totalIterations++;

            for (int i = 0; i < n - 1; i++) {
                for (int j = i + 2; j < n; j++) {
                    // Skip the wrap-around edge (n-1 -> 0) when i=0
                    if (i == 0 && j == n - 1) continue;

                    double gain = computeGain(tour, i, j);

                    if (gain > 1e-10) { // Improvement found
                        tour.reverseSegment(i + 1, j);
                        improved = true;
                        totalImprovements++;

                        if (verbose) {
                            System.out.printf(
                                "Iter %3d | Swap edges (%s-%s) & (%s-%s)  gain=%.4f  dist=%.2f%n",
                                totalIterations,
                                tour.getCity(i).getName(),
                                tour.getCity(i + 1).getName(),
                                tour.getCity(j).getName(),
                                tour.getCity((j + 1) % n).getName(),
                                gain,
                                tour.getTotalDistance()
                            );
                        }

                        break; // Restart scan after each improvement (first-improvement strategy)
                    }
                }
                if (improved) break;
            }
        }

        System.out.printf("Completed: %d iterations, %d improvements%n",
            totalIterations, totalImprovements);
        System.out.printf("Improved tour distance: %.2f%n%n", tour.getTotalDistance());

        return tour;
    }

    /**
     * Computes the distance gain (reduction) from performing a 2-opt swap
     * between edge (i, i+1) and edge (j, j+1).
     *
     * <p>If the returned value is positive, reversing the segment [i+1..j]
     * will shorten the tour.
     *
     * @param tour the current tour
     * @param i    index of the first edge start
     * @param j    index of the second edge start
     * @return distance reduction (positive = improvement)
     */
    private double computeGain(Tour tour, int i, int j) {
        int n = tour.size();
        City a = tour.getCity(i);
        City b = tour.getCity(i + 1);
        City c = tour.getCity(j);
        City d = tour.getCity((j + 1) % n);

        // Current cost: d(a,b) + d(c,d)
        // After swap:  d(a,c) + d(b,d)
        double currentCost = a.distanceTo(b) + c.distanceTo(d);
        double newCost = a.distanceTo(c) + b.distanceTo(d);

        return currentCost - newCost;
    }

    /**
     * Returns how many improving swaps were applied in the last run.
     */
    public int getTotalImprovements() {
        return totalImprovements;
    }

    /**
     * Returns how many outer iterations the last run required.
     */
    public int getTotalIterations() {
        return totalIterations;
    }
}
