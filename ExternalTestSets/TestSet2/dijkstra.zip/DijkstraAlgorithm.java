package dijkstra;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;

/**
 * Implements Dijkstra's shortest path algorithm on a weighted graph.
 *
 * <p>The algorithm finds the shortest path from a single source vertex
 * to all other reachable vertices in a graph with non-negative edge weights.
 *
 * <p>Time complexity:  O((V + E) log V) using a binary min-heap priority queue.
 * Space complexity: O(V + E)
 */
public class DijkstraAlgorithm {

    private final Graph graph;
    private boolean hasRun;
    private Vertex lastSource;

    // Tracks the order in which vertices were finalized
    private final List<Vertex> visitOrder;

    /**
     * Constructs a DijkstraAlgorithm instance for the given graph.
     *
     * @param graph the graph to operate on
     */
    public DijkstraAlgorithm(Graph graph) {
        this.graph = graph;
        this.hasRun = false;
        this.visitOrder = new ArrayList<>();
    }

    /**
     * Runs Dijkstra's algorithm from the specified source vertex.
     *
     * <p>After calling this, you can retrieve shortest distances and paths
     * via {@link #getShortestPath(int)} and querying vertex distances directly.
     *
     * @param sourceId the ID of the source vertex
     */
    public void run(int sourceId) {
        graph.resetVertices();
        visitOrder.clear();

        Vertex source = graph.getVertex(sourceId);
        source.setDistance(0);
        lastSource = source;
        hasRun = true;

        System.out.println("\n=== Dijkstra's Algorithm ===");
        System.out.println("Source: " + source.getLabel());
        System.out.println("----------------------------");

        // Min-heap priority queue ordered by tentative distance
        PriorityQueue<Vertex> pq = new PriorityQueue<>();
        pq.offer(source);

        int step = 0;

        while (!pq.isEmpty()) {
            // Extract vertex with smallest tentative distance
            Vertex current = pq.poll();

            // Skip if already finalized (stale entry in PQ)
            if (current.isVisited()) continue;

            current.setVisited(true);
            visitOrder.add(current);
            step++;

            System.out.printf("Step %2d | Finalize %-10s | dist = %s%n",
                step,
                current.getLabel(),
                current.getDistanceString()
            );

            // Relax all outgoing edges from current
            for (Edge edge : graph.getEdgesFrom(current.getId())) {
                Vertex neighbor = edge.getDestination();

                if (neighbor.isVisited()) continue;

                // Candidate distance through current
                int newDist = current.getDistance() + edge.getWeight();

                if (newDist < neighbor.getDistance()) {
                    neighbor.setDistance(newDist);
                    neighbor.setPredecessor(current);
                    pq.offer(neighbor); // Re-insert with updated priority

                    System.out.printf("         | Relax edge %s -> %s  (new dist: %d)%n",
                        current.getLabel(),
                        neighbor.getLabel(),
                        newDist
                    );
                }
            }
        }

        System.out.println("----------------------------");
        System.out.println("Algorithm complete.\n");
    }

    /**
     * Reconstructs the shortest path from the source to the target vertex.
     *
     * @param targetId the ID of the destination vertex
     * @return a {@link ShortestPathResult} containing the path and total distance
     * @throws IllegalStateException if {@link #run(int)} has not been called first
     */
    public ShortestPathResult getShortestPath(int targetId) {
        ensureHasRun();

        Vertex target = graph.getVertex(targetId);

        if (target.getDistance() == Integer.MAX_VALUE) {
            return ShortestPathResult.unreachable(lastSource, target);
        }

        // Walk backwards via predecessor chain
        List<Vertex> path = new ArrayList<>();
        Vertex current = target;

        while (current != null) {
            path.add(current);
            current = current.getPredecessor();
        }

        Collections.reverse(path);
        return new ShortestPathResult(lastSource, target, path, target.getDistance());
    }

    /**
     * Prints the shortest path to every vertex in the graph.
     */
    public void printAllShortestPaths() {
        ensureHasRun();

        System.out.println("=== Shortest Paths from " + lastSource.getLabel() + " ===");

        List<Vertex> sorted = new ArrayList<>(graph.getVertices());
        sorted.sort((a, b) -> Integer.compare(a.getId(), b.getId()));

        for (Vertex v : sorted) {
            ShortestPathResult result = getShortestPath(v.getId());
            System.out.println(result);
        }

        System.out.println();
    }

    /**
     * Returns the list of vertices in the order they were finalized.
     *
     * @return visit order list
     */
    public List<Vertex> getVisitOrder() {
        ensureHasRun();
        return Collections.unmodifiableList(visitOrder);
    }

    /**
     * Returns the graph this algorithm operates on.
     */
    public Graph getGraph() {
        return graph;
    }

    private void ensureHasRun() {
        if (!hasRun) {
            throw new IllegalStateException(
                "run() must be called before retrieving results."
            );
        }
    }
}
