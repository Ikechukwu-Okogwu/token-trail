package dijkstra;

/**
 * Entry point for the Dijkstra's Shortest Path demonstration.
 *
 * <p>Runs three different graph scenarios to showcase the algorithm:
 *   1. A small textbook-style graph
 *   2. A city road network
 *   3. A graph with an unreachable vertex
 */
public class Main {

    public static void main(String[] args) {
        System.out.println("╔══════════════════════════════════════╗");
        System.out.println("║   Dijkstra's Shortest Path — Demo   ║");
        System.out.println("╚══════════════════════════════════════╝\n");

        runScenario1();
        runScenario2();
        runScenario3();
    }

    // ---------------------------------------------------------------
    // Scenario 1: Classic textbook graph
    // ---------------------------------------------------------------

    /**
     * A simple 6-node undirected graph, often seen in textbooks.
     *
     * Edges:
     *   A-B:4, A-C:2
     *   B-C:5, B-D:10
     *   C-E:3
     *   D-F:11
     *   E-D:4, E-F:6
     *
     * Expected shortest paths from A:
     *   A->A: 0
     *   A->B: 4
     *   A->C: 2
     *   A->D: 9   (A->C->E->D)
     *   A->E: 5   (A->C->E)
     *   A->F: 11  (A->C->E->F)
     */
    private static void runScenario1() {
        System.out.println("══════════════════════════════════════");
        System.out.println(" SCENARIO 1: Classic Textbook Graph  ");
        System.out.println("══════════════════════════════════════");

        Graph g = new Graph(false); // undirected

        Vertex a = g.addVertex(0, "A");
        Vertex b = g.addVertex(1, "B");
        Vertex c = g.addVertex(2, "C");
        Vertex d = g.addVertex(3, "D");
        Vertex e = g.addVertex(4, "E");
        Vertex f = g.addVertex(5, "F");

        g.addEdge(0, 1, 4);  // A-B
        g.addEdge(0, 2, 2);  // A-C
        g.addEdge(1, 2, 5);  // B-C
        g.addEdge(1, 3, 10); // B-D
        g.addEdge(2, 4, 3);  // C-E
        g.addEdge(3, 5, 11); // D-F
        g.addEdge(4, 3, 4);  // E-D
        g.addEdge(4, 5, 6);  // E-F

        g.printGraph();

        DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(g);
        dijkstra.run(0); // Source: A
        dijkstra.printAllShortestPaths();

        // Highlight one specific path
        ShortestPathResult result = dijkstra.getShortestPath(5); // A -> F
        System.out.println("Highlighted: " + result.getPathString());
        System.out.println();
    }

    // ---------------------------------------------------------------
    // Scenario 2: City road network
    // ---------------------------------------------------------------

    /**
     * A directed graph representing a simplified city map.
     * Weights represent travel times in minutes.
     *
     *   Hamilton -> Ancaster: 12
     *   Hamilton -> Dundas:   18
     *   Ancaster -> Burlington: 20
     *   Ancaster -> Dundas:    7
     *   Dundas -> Waterdown:  15
     *   Burlington -> Oakville: 10
     *   Waterdown -> Burlington: 8
     *   Oakville -> Toronto:   35
     *   Burlington -> Toronto: 45
     */
    private static void runScenario2() {
        System.out.println("══════════════════════════════════════");
        System.out.println(" SCENARIO 2: City Road Network       ");
        System.out.println("══════════════════════════════════════");

        Graph g = new Graph(true); // directed

        g.addVertex(0, "Hamilton");
        g.addVertex(1, "Ancaster");
        g.addVertex(2, "Dundas");
        g.addVertex(3, "Burlington");
        g.addVertex(4, "Waterdown");
        g.addVertex(5, "Oakville");
        g.addVertex(6, "Toronto");

        g.addEdge(0, 1, 12); // Hamilton -> Ancaster
        g.addEdge(0, 2, 18); // Hamilton -> Dundas
        g.addEdge(1, 3, 20); // Ancaster -> Burlington
        g.addEdge(1, 2, 7);  // Ancaster -> Dundas
        g.addEdge(2, 4, 15); // Dundas -> Waterdown
        g.addEdge(3, 5, 10); // Burlington -> Oakville
        g.addEdge(4, 3, 8);  // Waterdown -> Burlington
        g.addEdge(5, 6, 35); // Oakville -> Toronto
        g.addEdge(3, 6, 45); // Burlington -> Toronto

        g.printGraph();

        DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(g);
        dijkstra.run(0); // Source: Hamilton
        dijkstra.printAllShortestPaths();

        ShortestPathResult toToronto = dijkstra.getShortestPath(6);
        System.out.println("Fastest route to Toronto:");
        System.out.println("  " + toToronto.getPathString());
        System.out.printf("  Total time: %d minutes, %d hops%n%n",
            toToronto.getTotalDistance(), toToronto.getHopCount());
    }

    // ---------------------------------------------------------------
    // Scenario 3: Disconnected graph — unreachable vertex
    // ---------------------------------------------------------------

    /**
     * A directed graph where one vertex is unreachable from the source.
     *
     *   0 -> 1: 5
     *   0 -> 2: 9
     *   1 -> 3: 3
     *   2 -> 3: 1
     *   4 -> 3: 2   <-- vertex 4 is isolated from source 0
     */
    private static void runScenario3() {
        System.out.println("══════════════════════════════════════");
        System.out.println(" SCENARIO 3: Disconnected Graph      ");
        System.out.println("══════════════════════════════════════");

        Graph g = new Graph(true); // directed

        g.addVertex(0, "S");
        g.addVertex(1, "X");
        g.addVertex(2, "Y");
        g.addVertex(3, "T");
        g.addVertex(4, "Z"); // isolated — no edge from S-side to Z

        g.addEdge(0, 1, 5); // S -> X
        g.addEdge(0, 2, 9); // S -> Y
        g.addEdge(1, 3, 3); // X -> T
        g.addEdge(2, 3, 1); // Y -> T
        g.addEdge(4, 3, 2); // Z -> T  (Z not reachable from S)

        g.printGraph();

        DijkstraAlgorithm dijkstra = new DijkstraAlgorithm(g);
        dijkstra.run(0); // Source: S
        dijkstra.printAllShortestPaths();

        ShortestPathResult unreachable = dijkstra.getShortestPath(4); // S -> Z
        System.out.println("Attempting path to isolated vertex Z:");
        System.out.println("  Reachable: " + unreachable.isReachable());
        System.out.println("  " + unreachable.getPathString());
        System.out.println();

        // Visit order summary
        System.out.println("Vertices finalized in order:");
        int i = 1;
        for (Vertex v : dijkstra.getVisitOrder()) {
            System.out.printf("  %d. %s (distance %s)%n",
                i++, v.getLabel(), v.getDistanceString());
        }
        System.out.println();
    }
}
