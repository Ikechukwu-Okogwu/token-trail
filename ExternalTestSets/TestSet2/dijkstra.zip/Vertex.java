package dijkstra;

/**
 * Represents a vertex (node) in a weighted graph.
 * Each vertex has a unique integer ID and an optional label.
 */
public class Vertex implements Comparable<Vertex> {

    private final int id;
    private final String label;

    // Tentative distance from the source vertex (used during Dijkstra's)
    private int distance;

    // Previous vertex on the shortest path (used for path reconstruction)
    private Vertex predecessor;

    // Whether this vertex has been finalized (visited) by Dijkstra's
    private boolean visited;

    /**
     * Constructs a vertex with the given ID and label.
     *
     * @param id    unique identifier for this vertex
     * @param label human-readable name/label
     */
    public Vertex(int id, String label) {
        this.id = id;
        this.label = label;
        this.distance = Integer.MAX_VALUE; // Infinity by default
        this.predecessor = null;
        this.visited = false;
    }

    /**
     * Constructs a vertex with only an ID (label defaults to "V{id}").
     *
     * @param id unique identifier for this vertex
     */
    public Vertex(int id) {
        this(id, "V" + id);
    }

    // --- Getters ---

    public int getId() {
        return id;
    }

    public String getLabel() {
        return label;
    }

    public int getDistance() {
        return distance;
    }

    public Vertex getPredecessor() {
        return predecessor;
    }

    public boolean isVisited() {
        return visited;
    }

    // --- Setters ---

    public void setDistance(int distance) {
        this.distance = distance;
    }

    public void setPredecessor(Vertex predecessor) {
        this.predecessor = predecessor;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }

    /**
     * Resets this vertex to its initial state.
     * Called before running a new Dijkstra search.
     */
    public void reset() {
        this.distance = Integer.MAX_VALUE;
        this.predecessor = null;
        this.visited = false;
    }

    /**
     * Returns a formatted distance string — "∞" if unreachable,
     * otherwise the numeric distance.
     */
    public String getDistanceString() {
        return (distance == Integer.MAX_VALUE) ? "∞" : String.valueOf(distance);
    }

    /**
     * Vertices are compared by their tentative distance,
     * enabling use in a priority queue.
     */
    @Override
    public int compareTo(Vertex other) {
        return Integer.compare(this.distance, other.distance);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Vertex)) return false;
        Vertex other = (Vertex) o;
        return this.id == other.id;
    }

    @Override
    public int hashCode() {
        return Integer.hashCode(id);
    }

    @Override
    public String toString() {
        return label + "(d=" + getDistanceString() + ")";
    }
}
