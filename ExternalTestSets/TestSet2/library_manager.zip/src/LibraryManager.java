import java.util.*;
import java.util.stream.*;

/**
 * LibraryManager - A simple library book management system.
 */
public class LibraryManager {

    // ── Inner model ──────────────────────────────────────────────────────────

    static class Book {
        private final String isbn;
        private final String title;
        private final String author;
        private final int year;
        private boolean checkedOut;
        private String borrower;

        Book(String isbn, String title, String author, int year) {
            this.isbn       = isbn;
            this.title      = title;
            this.author     = author;
            this.year       = year;
            this.checkedOut = false;
            this.borrower   = null;
        }

        String getIsbn()    { return isbn; }
        String getTitle()   { return title; }
        String getAuthor()  { return author; }
        int    getYear()    { return year; }
        boolean isCheckedOut() { return checkedOut; }
        String getBorrower()   { return borrower; }

        void checkOut(String borrowerName) {
            this.checkedOut = true;
            this.borrower   = borrowerName;
        }

        void returnBook() {
            this.checkedOut = false;
            this.borrower   = null;
        }

        @Override
        public String toString() {
            String status = checkedOut ? "[OUT → " + borrower + "]" : "[IN]";
            return String.format("%-14s | %-30s | %-20s | %d | %s",
                    isbn, title, author, year, status);
        }
    }

    // ── State ────────────────────────────────────────────────────────────────

    private final Map<String, Book> catalog = new LinkedHashMap<>();
    private final List<String>      auditLog = new ArrayList<>();

    // ── Core operations ──────────────────────────────────────────────────────

    public boolean addBook(String isbn, String title, String author, int year) {
        if (catalog.containsKey(isbn)) {
            log("ADD FAILED – duplicate ISBN: " + isbn);
            return false;
        }
        catalog.put(isbn, new Book(isbn, title, author, year));
        log("ADDED: " + title + " (" + isbn + ")");
        return true;
    }

    public boolean removeBook(String isbn) {
        Book book = catalog.get(isbn);
        if (book == null) {
            log("REMOVE FAILED – not found: " + isbn);
            return false;
        }
        if (book.isCheckedOut()) {
            log("REMOVE FAILED – currently checked out: " + isbn);
            return false;
        }
        catalog.remove(isbn);
        log("REMOVED: " + book.getTitle());
        return true;
    }

    public boolean checkOut(String isbn, String borrowerName) {
        Book book = catalog.get(isbn);
        if (book == null) {
            log("CHECKOUT FAILED – not found: " + isbn);
            return false;
        }
        if (book.isCheckedOut()) {
            log("CHECKOUT FAILED – already out: " + isbn);
            return false;
        }
        book.checkOut(borrowerName);
        log("CHECKOUT: \"" + book.getTitle() + "\" → " + borrowerName);
        return true;
    }

    public boolean returnBook(String isbn) {
        Book book = catalog.get(isbn);
        if (book == null) {
            log("RETURN FAILED – not found: " + isbn);
            return false;
        }
        if (!book.isCheckedOut()) {
            log("RETURN FAILED – not checked out: " + isbn);
            return false;
        }
        String borrower = book.getBorrower();
        book.returnBook();
        log("RETURNED: \"" + book.getTitle() + "\" by " + borrower);
        return true;
    }

    // ── Queries ──────────────────────────────────────────────────────────────

    public Optional<Book> findByIsbn(String isbn) {
        return Optional.ofNullable(catalog.get(isbn));
    }

    public List<Book> searchByTitle(String keyword) {
        String kw = keyword.toLowerCase();
        return catalog.values().stream()
                .filter(b -> b.getTitle().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }

    public List<Book> searchByAuthor(String author) {
        String kw = author.toLowerCase();
        return catalog.values().stream()
                .filter(b -> b.getAuthor().toLowerCase().contains(kw))
                .collect(Collectors.toList());
    }

    public List<Book> getAvailableBooks() {
        return catalog.values().stream()
                .filter(b -> !b.isCheckedOut())
                .collect(Collectors.toList());
    }

    public List<Book> getCheckedOutBooks() {
        return catalog.values().stream()
                .filter(Book::isCheckedOut)
                .collect(Collectors.toList());
    }

    public Map<String, Long> booksByDecade() {
        return catalog.values().stream()
                .collect(Collectors.groupingBy(
                        b -> (b.getYear() / 10 * 10) + "s",
                        Collectors.counting()));
    }

    // ── Reporting ────────────────────────────────────────────────────────────

    public void printCatalog() {
        System.out.println("\n=== LIBRARY CATALOG (" + catalog.size() + " books) ===");
        String header = String.format("%-14s | %-30s | %-20s | %s | %s",
                "ISBN", "Title", "Author", "Year", "Status");
        System.out.println(header);
        System.out.println("-".repeat(header.length()));
        catalog.values().forEach(System.out::println);
    }

    public void printAuditLog() {
        System.out.println("\n=== AUDIT LOG ===");
        auditLog.forEach(e -> System.out.println("  " + e));
    }

    public void printStats() {
        long total     = catalog.size();
        long available = getAvailableBooks().size();
        long out       = getCheckedOutBooks().size();
        System.out.println("\n=== STATS ===");
        System.out.println("  Total books  : " + total);
        System.out.println("  Available    : " + available);
        System.out.println("  Checked out  : " + out);
        System.out.println("  By decade    : " + booksByDecade());
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private void log(String message) {
        String entry = "[" + new Date() + "] " + message;
        auditLog.add(entry);
    }

    // ── Demo main ────────────────────────────────────────────────────────────

    public static void main(String[] args) {
        LibraryManager lib = new LibraryManager();

        // Seed catalog
        lib.addBook("978-0-06-112008-4", "To Kill a Mockingbird",       "Harper Lee",        1960);
        lib.addBook("978-0-7432-7356-5", "1984",                         "George Orwell",     1949);
        lib.addBook("978-0-14-028329-7", "Of Mice and Men",              "John Steinbeck",    1937);
        lib.addBook("978-0-06-093546-9", "The Great Gatsby",             "F. Scott Fitzgerald",1925);
        lib.addBook("978-0-316-76948-0", "The Catcher in the Rye",       "J.D. Salinger",     1951);
        lib.addBook("978-0-06-093545-2", "Brave New World",              "Aldous Huxley",     1932);
        lib.addBook("978-0-525-55360-5", "The Midnight Library",         "Matt Haig",         2020);
        lib.addBook("978-1-250-30185-4", "Project Hail Mary",            "Andy Weir",         2021);

        // Operations
        lib.checkOut("978-0-06-112008-4", "Alice");
        lib.checkOut("978-0-7432-7356-5", "Bob");
        lib.checkOut("978-0-7432-7356-5", "Carol");   // should fail – already out
        lib.returnBook("978-0-06-112008-4");
        lib.removeBook("978-0-7432-7356-5");           // should fail – checked out
        lib.removeBook("978-0-14-028329-7");

        // Reports
        lib.printCatalog();
        lib.printStats();

        System.out.println("\n=== SEARCH: 'the' in title ===");
        lib.searchByTitle("the").forEach(System.out::println);

        System.out.println("\n=== AVAILABLE BOOKS ===");
        lib.getAvailableBooks().forEach(System.out::println);

        lib.printAuditLog();
    }
}
