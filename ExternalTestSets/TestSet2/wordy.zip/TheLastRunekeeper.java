public class TheLastRunekeeper {

    public static void main(String[] args) {

        // ----------------------------------------------------------------
        // THE LAST RUNEKEEPER
        // A tale of Edrin Ashvale, apprentice to the dying order of Runekeepers
        // ----------------------------------------------------------------

        System.out.println("==========================================================");
        System.out.println("              T H E   L A S T   R U N E K E E P E R      ");
        System.out.println("==========================================================");
        System.out.println();

        // --- CHAPTER I: THE DYING FLAME ---
        System.out.println("  ~ Chapter I: The Dying Flame ~");
        System.out.println();
        System.out.println("The fire in the tower had not gone out in four hundred years.");
        System.out.println("Tonight, it flickered.");
        System.out.println();
        System.out.println("Edrin Ashvale noticed it first — he always noticed things others missed.");
        System.out.println("At seventeen, he was the youngest apprentice the Runekeeper order");
        System.out.println("had accepted in living memory, and also, as Master Caldwin liked to");
        System.out.println("remind him, the clumsiest.");
        System.out.println();
        System.out.println("\"Master,\" he said, ink still dripping from his fingers onto the");
        System.out.println("stone floor. \"The Hearthstone. Look.\"");
        System.out.println();
        System.out.println("Caldwin looked up from his desk, where a dozen unfinished runes lay");
        System.out.println("spread like fallen leaves. His eyes, pale as winter moons, found the");
        System.out.println("stone in the centre of the room. It was a dull, pulsing amber now.");
        System.out.println("It should have been blazing gold.");
        System.out.println();
        System.out.println("\"So it begins,\" the old man said quietly. Not with fear. With");
        System.out.println("the calm exhaustion of someone who had been expecting bad news");
        System.out.println("for a very long time.");
        System.out.println();

        // --- CHAPTER II: THE MISSION ---
        System.out.println("----------------------------------------------------------");
        System.out.println("  ~ Chapter II: The Weight of a Name ~");
        System.out.println();
        System.out.println("Caldwin told him everything that night.");
        System.out.println();
        System.out.println("The Hearthstone was the anchor of the world's rune-web — an invisible");
        System.out.println("lattice of carved language that held back the Unmade, creatures of");
        System.out.println("pure entropy that had nearly swallowed the world an age ago.");
        System.out.println("Every Runekeeper alive contributed a thread to that web simply by");
        System.out.println("existing, by knowing the old words.");
        System.out.println();
        System.out.println("There were three Runekeepers left.");
        System.out.println("Old Maret in the eastern fens had died last winter.");
        System.out.println("That left two: Caldwin, and Edrin.");
        System.out.println();
        System.out.println("\"The stone needs to be relit at the Source,\" Caldwin said,");
        System.out.println("pressing a small leather satchel into Edrin's hands.");
        System.out.println("\"The Ashwell, in the roots of the Greymere Mountains.\"");
        System.out.println();
        System.out.println("\"That's three weeks of travel,\" Edrin said.");
        System.out.println();
        System.out.println("\"Twelve days if you run.\"");
        System.out.println();
        System.out.println("\"And you can't come because—\"");
        System.out.println();
        System.out.println("\"Because someone must stay and hold the remaining runes stable.");
        System.out.println("If the web collapses while you travel, none of it will matter.\"");
        System.out.println("Caldwin met his eyes. \"You are the last runekeeper who can move.\"");
        System.out.println("A pause. \"You always were better at the field-scripts anyway.\"");
        System.out.println();
        System.out.println("Edrin stared at the satchel. Inside it, wrapped in oilcloth,");
        System.out.println("was a fragment of the original Hearthstone — cold and dark as coal.");
        System.out.println("He had to bring it to the Ashwell and speak the Rekindling.");
        System.out.println("A ceremony he had only ever read about. That no living person");
        System.out.println("had performed in two centuries.");
        System.out.println();
        System.out.println("\"No pressure,\" Caldwin added, which was the closest he ever came");
        System.out.println("to a joke.");
        System.out.println();

        // --- CHAPTER III: THE ROAD ---
        System.out.println("----------------------------------------------------------");
        System.out.println("  ~ Chapter III: The Road Through Ashenmoor ~");
        System.out.println();
        System.out.println("He left before dawn, with a pack on his back and ink-stained hands.");
        System.out.println();
        System.out.println("The road south was easy for the first two days — farmland, merchant");
        System.out.println("tracks, the smell of woodsmoke from warm houses. Edrin kept his");
        System.out.println("hood up and his mouth shut. Runekeepers weren't feared, exactly,");
        System.out.println("but they made people uneasy. All those symbols. All that silence.");
        System.out.println();
        System.out.println("On the third day, the road dissolved into the Ashenmoor.");
        System.out.println();
        System.out.println("The moor was a wide flat bruise of a landscape — grey-green heath,");
        System.out.println("bone-white standing stones, and a wind that never seemed to come");
        System.out.println("from any one direction. Edrin navigated by rune-marks carved into");
        System.out.println("the stones centuries ago by his predecessors. He found himself");
        System.out.println("grateful for them in a way he had never been grateful for a textbook.");
        System.out.println();
        System.out.println("On the fourth night, something followed him.");
        System.out.println();
        System.out.println("He heard it first — a low, resonant hum, like a voice trying to");
        System.out.println("form words in a language made of static. Then he saw it: a shape");
        System.out.println("at the edge of his firelight, tall and thin and wrong, like a shadow");
        System.out.println("with no object to cast it.");
        System.out.println();
        System.out.println("An Unmade scout. The web was already fraying.");
        System.out.println();
        System.out.println("Edrin's hands moved before his mind caught up. He drew a Ward-rune");
        System.out.println("in the air with two fingers, tracing the symbol from memory, feeling");
        System.out.println("the familiar warmth as the script took hold. A ring of pale light");
        System.out.println("bloomed around his camp. The shadow-thing recoiled, then drifted");
        System.out.println("back into the dark, humming its terrible formless hum.");
        System.out.println();
        System.out.println("He did not sleep the rest of that night.");
        System.out.println();
        System.out.println("He ran faster in the morning.");
        System.out.println();

        // --- CHAPTER IV: THE ASHWELL ---
        System.out.println("----------------------------------------------------------");
        System.out.println("  ~ Chapter IV: The Ashwell ~");
        System.out.println();
        System.out.println("He reached the Greymere Mountains on the ninth day.");
        System.out.println("The Ashwell was in a cavern beneath the roots of the range —");
        System.out.println("a pool of water so still it looked like a mirror, fed by an");
        System.out.println("underground spring that had run since before the first rune was");
        System.out.println("ever carved.");
        System.out.println();
        System.out.println("The air inside the cavern hummed with latent script. Edrin could");
        System.out.println("feel the old words pressing against the inside of his skull,");
        System.out.println("recognising him, waiting.");
        System.out.println();
        System.out.println("He knelt at the edge of the pool and unwrapped the stone fragment.");
        System.out.println("It was even colder here. Even darker. A small, dead thing.");
        System.out.println();
        System.out.println("He opened the Rekindling text from memory — Caldwin had made him");
        System.out.println("recite it every evening for six years, and suddenly Edrin understood");
        System.out.println("why. He had thought it was punishment for spilling the ink.");
        System.out.println("It was not punishment. It was preparation.");
        System.out.println();
        System.out.println("He spoke the first word.");
        System.out.println();
        System.out.println("The pool shivered.");
        System.out.println();
        System.out.println("He spoke the second. Then the third. The words were heavy and old");
        System.out.println("and cost something — not pain, exactly, but effort drawn from a");
        System.out.println("place deeper than muscle. The cavern filled with light, soft and");
        System.out.println("gold, as the rune-script in the walls began to wake.");
        System.out.println();
        System.out.println("At the final word, he pressed the stone fragment to the surface");
        System.out.println("of the pool.");
        System.out.println();
        System.out.println("The water rose up around his hand — warm, alive, luminous —");
        System.out.println("and the stone fragment blazed.");
        System.out.println();
        System.out.println("Gold. Brilliant, burning, ancient gold.");
        System.out.println();

        // --- EPILOGUE ---
        System.out.println("----------------------------------------------------------");
        System.out.println("  ~ Epilogue ~");
        System.out.println();
        System.out.println("He carried the relit stone back across the moor in seven days.");
        System.out.println("The Unmade did not follow him this time.");
        System.out.println();
        System.out.println("Caldwin was asleep in his chair when Edrin returned, surrounded");
        System.out.println("by a lattice of rune-script so dense and intricate it had filled");
        System.out.println("every inch of the tower walls. He had spent twelve days holding");
        System.out.println("the world together with nothing but an old man's memory and will.");
        System.out.println();
        System.out.println("Edrin placed the glowing stone back in its housing.");
        System.out.println("The tower filled with gold light. The fire blazed high.");
        System.out.println();
        System.out.println("Caldwin opened one eye.");
        System.out.println();
        System.out.println("\"You're late,\" he said.");
        System.out.println();
        System.out.println("\"I ran into something on the moor.\"");
        System.out.println();
        System.out.println("\"Unmade?\"");
        System.out.println();
        System.out.println("\"Just one. I warded it off.\"");
        System.out.println();
        System.out.println("The old man closed his eye again. A long silence.");
        System.out.println("Then, very quietly:");
        System.out.println();
        System.out.println("\"Good. You've earned the ink off your hands, I think.\"");
        System.out.println();
        System.out.println("Edrin looked down. His hands were clean.");
        System.out.println("They had been, since the Ashwell.");
        System.out.println("He hadn't noticed until now.");
        System.out.println();
        System.out.println("He sat down at his desk, picked up his quill, and began to write.");
        System.out.println();
        System.out.println("==========================================================");
        System.out.println("                       ~ fin ~                            ");
        System.out.println("==========================================================");
    }
}
