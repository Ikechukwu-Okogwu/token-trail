/**
 * LinkedList.java
 * Author: Aisha Kowalski
 * Student ID: 6534990
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 18, 2025
 *
 * Design notes:
 * - Maintaining a tail pointer allows O(1) insertions at the end.
 * - Reverse is implemented using a Java Stack to store node data,
 *   then refill values back in forward order.
 */
import java.util.Stack;

public class LinkedList {

    private Node head;
    private Node tail;  // tail pointer for O(1) append
    private int count;

    public LinkedList() {
        head = null;
        tail = null;
        count = 0;
    }

    /**
     * Appends value to tail — O(1) with tail pointer.
     * @param value integer to insert
     */
    public void insert(int value) {
        Node newNode = new Node(value);
        if (head == null) {
            head = newNode;
            tail = newNode;
        } else {
            tail.next = newNode;
            tail = newNode;
        }
        count++;
    }

    /**
     * Removes the first node matching value.
     * Updates tail if tail is deleted.
     * @param value integer to delete
     */
    public void delete(int value) {
        if (head == null) return;
        if (head.data == value) {
            if (head == tail) tail = null; // list becomes empty
            head = head.next;
            count--;
            return;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.data == value) {
                if (current.next == tail) tail = current; // update tail
                current.next = current.next.next;
                count--;
                return;
            }
            current = current.next;
        }
    }

    /**
     * Returns whether the list contains value.
     * @param value integer to search
     */
    public boolean contains(int value) {
        Node current = head;
        while (current != null) {
            if (current.data == value) return true;
            current = current.next;
        }
        return false;
    }

    /**
     * Returns the number of elements.
     */
    public int size() {
        return count;
    }

    /**
     * Reverses the list by pushing all values onto a Stack,
     * then popping them back into the nodes.
     */
    public void reverse() {
        Stack<Integer> stack = new Stack<>();
        Node current = head;
        while (current != null) {
            stack.push(current.data);
            current = current.next;
        }
        current = head;
        while (current != null) {
            current.data = stack.pop();
            current = current.next;
        }
        // Swap head and tail references
        Node temp = head;
        head = tail;
        tail = temp;
    }

    /**
     * Prints all list values on a single line.
     */
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
