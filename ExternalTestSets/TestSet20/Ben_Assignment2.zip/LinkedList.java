/**
 * LinkedList.java
 * Author: Benjamin Okafor
 * Student ID: 6499003
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 11, 2025
 *
 * I overrode toString() for display and used a two-pass
 * method to reverse (collect into array, then refill).
 */
public class LinkedList {

    private Node head;

    public LinkedList() {
        head = null;
    }

    /**
     * Appends a new node at the end.
     * @param value value to insert
     */
    public void insert(int value) {
        Node node = new Node(value);
        if (head == null) {
            head = node;
            return;
        }
        Node t = head;
        while (t.next != null) t = t.next;
        t.next = node;
    }

    /**
     * Finds and removes first occurrence of value.
     * @param value value to delete
     */
    public void delete(int value) {
        if (head == null) return;
        if (head.data == value) { head = head.next; return; }
        Node t = head;
        while (t.next != null) {
            if (t.next.data == value) { t.next = t.next.next; return; }
            t = t.next;
        }
    }

    /**
     * Linear search for value.
     * @return true if present
     */
    public boolean contains(int value) {
        for (Node t = head; t != null; t = t.next)
            if (t.data == value) return true;
        return false;
    }

    /**
     * Counts nodes with a loop.
     */
    public int size() {
        int s = 0;
        for (Node t = head; t != null; t = t.next) s++;
        return s;
    }

    /**
     * Reverses by collecting data, then re-writing in reverse.
     */
    public void reverse() {
        int sz = size();
        if (sz < 2) return;
        int[] buf = new int[sz];
        Node t = head;
        for (int i = 0; i < sz; i++, t = t.next) buf[i] = t.data;
        t = head;
        for (int i = sz - 1; i >= 0; i--, t = t.next) t.data = buf[i];
    }

    /**
     * Uses display() via toString delegation.
     */
    public void display() {
        System.out.println(this.toString());
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        for (Node t = head; t != null; t = t.next) {
            sb.append(t.data);
            if (t.next != null) sb.append(" ");
        }
        return sb.toString();
    }
}
