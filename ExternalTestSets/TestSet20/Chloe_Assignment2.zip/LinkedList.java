/**
 * LinkedList.java
 * Author: Chloe Osei
 * Student ID: 6509341
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 19, 2025
 *
 * My approach: I use a sentinel (dummy) head node so that I never
 * have to special-case an empty list in insert/delete.
 */
public class LinkedList {

    // Sentinel node — its data is ignored, simplifies edge cases
    private final Node sentinel;

    public LinkedList() {
        sentinel = new Node(-1); // dummy head
    }

    /**
     * Traverses from sentinel to the last node and appends.
     * @param value integer to insert
     */
    public void insert(int value) {
        Node cur = sentinel;
        while (cur.next != null) {
            cur = cur.next;
        }
        cur.next = new Node(value);
    }

    /**
     * Removes the first real node whose data matches value.
     * @param value integer to delete
     */
    public void delete(int value) {
        Node cur = sentinel;
        while (cur.next != null) {
            if (cur.next.data == value) {
                cur.next = cur.next.next;
                return;
            }
            cur = cur.next;
        }
    }

    /**
     * Returns true if value is found after sentinel.
     * @param value integer to find
     */
    public boolean contains(int value) {
        Node cur = sentinel.next;
        while (cur != null) {
            if (cur.data == value) return true;
            cur = cur.next;
        }
        return false;
    }

    /**
     * Counts all nodes after sentinel.
     */
    public int size() {
        int cnt = 0;
        Node cur = sentinel.next;
        while (cur != null) {
            cnt++;
            cur = cur.next;
        }
        return cnt;
    }

    /**
     * Reverses the list (nodes after sentinel).
     */
    public void reverse() {
        Node prev = null;
        Node cur = sentinel.next;
        while (cur != null) {
            Node nxt = cur.next;
            cur.next = prev;
            prev = cur;
            cur = nxt;
        }
        sentinel.next = prev;
    }

    /**
     * Prints all values after the sentinel node.
     */
    public void display() {
        Node cur = sentinel.next;
        while (cur != null) {
            System.out.print(cur.data + " ");
            cur = cur.next;
        }
        System.out.println();
    }
}
