/**
 * LinkedList.java
 * Author: Devon Park
 * Student ID: 6461772
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 12, 2025
 *
 * Notes:
 * - I used a do-while loop in size() to handle traversal.
 * - Reverse works by collecting all values and re-assigning in reverse.
 */
public class LinkedList {

    private Node head;

    public LinkedList() {
        head = null;
    }

    /**
     * Inserts at the end of the list.
     */
    public void insert(int value) {
        Node n = new Node(value);
        if (head == null) {
            head = n;
            return;
        }
        Node cur = head;
        while (cur.next != null) {
            cur = cur.next;
        }
        cur.next = n;
    }

    /**
     * Deletes the first occurrence of value.
     */
    public void delete(int value) {
        if (head == null) return;
        if (head.data == value) {
            head = head.next;
            return;
        }
        Node cur = head;
        while (cur.next != null) {
            if (cur.next.data == value) {
                cur.next = cur.next.next;
                return;
            }
            cur = cur.next;
        }
    }

    /**
     * Checks if value is in the list.
     */
    public boolean contains(int value) {
        Node cur = head;
        while (cur != null) {
            if (cur.data == value) return true;
            cur = cur.next;
        }
        return false;
    }

    /**
     * Counts nodes using a do-while loop.
     * Handles empty list with an upfront null check.
     */
    public int size() {
        if (head == null) return 0;
        int n = 0;
        Node cur = head;
        do {
            n++;
            cur = cur.next;
        } while (cur != null);
        return n;
    }

    /**
     * Reverses by collecting values into an array, then re-assigning.
     */
    public void reverse() {
        int len = size();
        if (len <= 1) return;

        int[] vals = new int[len];
        Node cur = head;
        for (int i = 0; i < len; i++) {
            vals[i] = cur.data;
            cur = cur.next;
        }

        cur = head;
        for (int i = len - 1; i >= 0; i--) {
            cur.data = vals[i];
            cur = cur.next;
        }
    }

    /**
     * Displays list values.
     */
    public void display() {
        Node cur = head;
        while (cur != null) {
            System.out.print(cur.data + " ");
            cur = cur.next;
        }
        System.out.println();
    }
}
