/**
 * LinkedList.java
 * Author: Grace Obi
 * Student ID: 6530044
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 22, 2025
 *
 * I structured this class to closely mimic what a
 * standard library implementation might look like — with
 * a `getHead()` accessor and more descriptive prints.
 */
public class LinkedList {

    private Node head;
    private int nodeCount;

    /** Constructs a new empty linked list. */
    public LinkedList() {
        head      = null;
        nodeCount = 0;
    }

    /**
     * Inserts a new integer at the end of the list.
     * @param value the integer to insert
     */
    public void insert(int value) {
        Node newNode = new Node(value);
        if (isEmpty()) {
            head = newNode;
        } else {
            getLastNode().next = newNode;
        }
        nodeCount++;
    }

    /**
     * Deletes the first node with the given value, if present.
     * @param value the integer to remove
     */
    public void delete(int value) {
        if (isEmpty()) return;

        if (head.data == value) {
            head = head.next;
            nodeCount--;
            return;
        }

        Node current = head;
        while (current.next != null) {
            if (current.next.data == value) {
                current.next = current.next.next;
                nodeCount--;
                return;
            }
            current = current.next;
        }
    }

    /**
     * Returns true if value is stored in the list.
     * @param value integer to search for
     */
    public boolean contains(int value) {
        Node current = head;
        while (current != null) {
            if (current.data == value) return true;
            current = current.next;
        }
        return false;
    }

    /**
     * Returns the number of nodes in the list.
     */
    public int size() {
        return nodeCount;
    }

    /**
     * Reverses the list using the standard in-place pointer-swap algorithm.
     */
    public void reverse() {
        Node prev    = null;
        Node current = head;
        while (current != null) {
            Node nextTemp = current.next;
            current.next  = prev;
            prev          = current;
            current       = nextTemp;
        }
        head = prev;
    }

    /**
     * Displays each value in the list.
     */
    public void display() {
        if (isEmpty()) {
            System.out.println("[empty]");
            return;
        }
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // --- Private helpers ---

    /** Returns true if the list has no elements. */
    private boolean isEmpty() {
        return head == null;
    }

    /** Returns the last node in the list. Assumes list is non-empty. */
    private Node getLastNode() {
        Node current = head;
        while (current.next != null) current = current.next;
        return current;
    }

    /** Returns the head node (for potential subclass use). */
    protected Node getHead() {
        return head;
    }
}
