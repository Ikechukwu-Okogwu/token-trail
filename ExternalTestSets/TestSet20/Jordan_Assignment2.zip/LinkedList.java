/**
 * LinkedList.java
 * Author: Jordan Blake
 * Student ID: 6488234
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 13, 2025
 *
 * Note: I chose to insert at the head for O(1) insert time.
 * I also used for-loop style traversal where applicable.
 */
public class LinkedList {

    private Node head;
    // Track size as a field to avoid re-counting each time
    private int listSize;

    public LinkedList() {
        head = null;
        listSize = 0;
    }

    /**
     * Inserts at the HEAD of the list (O(1) insertion).
     * NOTE: Order of elements will differ from tail-insertion approach.
     * @param value the value to insert
     */
    public void insert(int value) {
        Node newNode = new Node(value);
        newNode.next = head;
        head = newNode;
        listSize++;
    }

    /**
     * Deletes the first node with the matching value.
     */
    public void delete(int value) {
        if (head == null) return;
        if (head.data == value) {
            head = head.next;
            listSize--;
            return;
        }
        // Use a for-loop style traversal
        for (Node current = head; current.next != null; current = current.next) {
            if (current.next.data == value) {
                current.next = current.next.next;
                listSize--;
                return;
            }
        }
    }

    /**
     * Returns true if value exists in the list.
     */
    public boolean contains(int value) {
        for (Node current = head; current != null; current = current.next) {
            if (current.data == value) return true;
        }
        return false;
    }

    /**
     * Returns the pre-tracked size (O(1) due to listSize field).
     */
    public int size() {
        return listSize;
    }

    /**
     * Reverses the list using a recursive helper.
     */
    public void reverse() {
        head = reverseHelper(head);
    }

    // Recursive reversal helper
    private Node reverseHelper(Node node) {
        if (node == null || node.next == null) return node;
        Node reversed = reverseHelper(node.next);
        node.next.next = node;
        node.next = null;
        return reversed;
    }

    /**
     * Displays all elements in the list.
     */
    public void display() {
        for (Node current = head; current != null; current = current.next) {
            System.out.print(current.data + " ");
        }
        System.out.println();
    }
}
