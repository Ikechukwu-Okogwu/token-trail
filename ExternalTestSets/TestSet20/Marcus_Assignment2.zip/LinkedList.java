/**
 * LinkedList.java
 * Author: Marcus Reid
 * Student ID: 6477901
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 14, 2025
 */
public class LinkedList {

    // Pointer to the first element
    private Node first;

    // Initialize the list with no elements
    public LinkedList() {
        first = null;
    }

    /**
     * Adds a new value to the tail of the list.
     * @param val the integer to add
     */
    public void insert(int val) {
        Node newElement = new Node(val);
        if (first == null) {
            first = newElement;
            return;
        }
        Node temp = first;
        while (temp.next != null) {
            temp = temp.next;
        }
        temp.next = newElement;
    }

    /**
     * Removes the first node matching the given value.
     * @param val the integer to remove
     */
    public void delete(int val) {
        if (first == null) return;
        if (first.data == val) {
            first = first.next;
            return;
        }
        Node temp = first;
        while (temp.next != null) {
            if (temp.next.data == val) {
                temp.next = temp.next.next;
                return;
            }
            temp = temp.next;
        }
    }

    /**
     * Checks whether the list holds the given value.
     * @param val the integer to look for
     */
    public boolean contains(int val) {
        Node temp = first;
        while (temp != null) {
            if (temp.data == val) return true;
            temp = temp.next;
        }
        return false;
    }

    /**
     * Counts and returns total number of nodes.
     */
    public int size() {
        int total = 0;
        Node temp = first;
        while (temp != null) {
            total++;
            temp = temp.next;
        }
        return total;
    }

    /**
     * Reverses the order of nodes in-place.
     */
    public void reverse() {
        Node previous = null;
        Node temp = first;
        while (temp != null) {
            Node following = temp.next;
            temp.next = previous;
            previous = temp;
            temp = following;
        }
        first = previous;
    }

    /**
     * Outputs all list values to the console.
     */
    public void display() {
        Node temp = first;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}
