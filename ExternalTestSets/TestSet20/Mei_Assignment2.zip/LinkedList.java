/**
 * LinkedList.java
 * Author: Mei Lin
 * Student ID: 6512897
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 21, 2025
 *
 * I tried to be very explicit in my naming and comments.
 * I also added a private helper method to find the node
 * before a given value, which I reuse in delete().
 */
public class LinkedList {

    /** The first node of the list, or null if list is empty. */
    private Node headNode;

    /**
     * Initializes an empty linked list.
     */
    public LinkedList() {
        this.headNode = null;
    }

    /**
     * Appends the specified integer value to the end of this list.
     *
     * @param value the integer value to add
     */
    public void insert(int value) {
        Node nodeToInsert = new Node(value);

        // If the list is currently empty, the new node becomes the head
        if (this.headNode == null) {
            this.headNode = nodeToInsert;
            return;
        }

        // Otherwise walk to the very last node
        Node lastNode = this.headNode;
        while (lastNode.next != null) {
            lastNode = lastNode.next;
        }

        // Attach new node after the last node
        lastNode.next = nodeToInsert;
    }

    /**
     * Removes the first node in this list whose data matches the given value.
     *
     * @param value the integer value to remove
     */
    public void delete(int value) {
        if (this.headNode == null) {
            // Nothing to delete
            return;
        }

        if (this.headNode.data == value) {
            // Special case: deleting the head node
            this.headNode = this.headNode.next;
            return;
        }

        // Use helper to find the node just before the target
        Node nodeBefore = findNodeBefore(value);
        if (nodeBefore != null) {
            nodeBefore.next = nodeBefore.next.next;
        }
    }

    /**
     * Returns whether the list contains the specified value.
     *
     * @param value the integer to look for
     * @return true if found, false if not
     */
    public boolean contains(int value) {
        Node current = this.headNode;
        while (current != null) {
            if (current.data == value) {
                return true;
            }
            current = current.next;
        }
        return false;
    }

    /**
     * Returns the number of elements currently stored in this list.
     *
     * @return integer count of nodes
     */
    public int size() {
        int nodeCount = 0;
        Node current = this.headNode;
        while (current != null) {
            nodeCount++;
            current = current.next;
        }
        return nodeCount;
    }

    /**
     * Reverses this list in-place using the standard three-pointer technique.
     */
    public void reverse() {
        Node previousNode = null;
        Node currentNode  = this.headNode;
        Node nextNode;

        while (currentNode != null) {
            nextNode          = currentNode.next; // save next
            currentNode.next  = previousNode;     // flip pointer
            previousNode      = currentNode;      // advance prev
            currentNode       = nextNode;         // advance cur
        }

        this.headNode = previousNode;
    }

    /**
     * Prints all values in this list, separated by spaces.
     */
    public void display() {
        Node current = this.headNode;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    // -------------------------------------------------------
    // Private helper methods
    // -------------------------------------------------------

    /**
     * Finds and returns the node that comes immediately before
     * the first node whose data equals the given value.
     *
     * @param value the data value to search for
     * @return the predecessor node, or null if not found
     */
    private Node findNodeBefore(int value) {
        Node current = this.headNode;
        while (current.next != null) {
            if (current.next.data == value) {
                return current;
            }
            current = current.next;
        }
        return null;
    }
}
