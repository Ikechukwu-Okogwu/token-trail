/**
 * LinkedList.java
 * Author: Natalie Cruz
 * Student ID: 6543201
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 20, 2025
 *
 * I store a separate `length` field and used StringBuilder
 * for display to practice string building in Java.
 */
public class LinkedList {

    private Node head;
    private int length;

    public LinkedList() {
        head   = null;
        length = 0;
    }

    /**
     * Inserts value at the back of the list and increments length.
     */
    public void insert(int value) {
        if (head == null) {
            head = new Node(value);
            length++;
            return;
        }
        Node walker = head;
        while (walker.next != null) walker = walker.next;
        walker.next = new Node(value);
        length++;
    }

    /**
     * Deletes first matching node, decrements length.
     */
    public void delete(int value) {
        if (head == null) return;
        if (head.data == value) {
            head = head.next;
            length--;
            return;
        }
        Node walker = head;
        while (walker.next != null) {
            if (walker.next.data == value) {
                walker.next = walker.next.next;
                length--;
                return;
            }
            walker = walker.next;
        }
    }

    /**
     * Returns true if value is in the list.
     */
    public boolean contains(int value) {
        Node walker = head;
        while (walker != null) {
            if (walker.data == value) return true;
            walker = walker.next;
        }
        return false;
    }

    /**
     * Returns the length field directly.
     */
    public int size() {
        return length;
    }

    /**
     * Reverses the list by swapping node pointers.
     */
    public void reverse() {
        Node p = null;
        Node c = head;
        Node n;
        while (c != null) {
            n = c.next;
            c.next = p;
            p = c;
            c = n;
        }
        head = p;
    }

    /**
     * Displays the list using a StringBuilder.
     */
    public void display() {
        StringBuilder sb = new StringBuilder();
        Node walker = head;
        while (walker != null) {
            sb.append(walker.data).append(" ");
            walker = walker.next;
        }
        System.out.println(sb.toString().trim());
    }
}
