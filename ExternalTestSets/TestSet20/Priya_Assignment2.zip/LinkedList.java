/**
 * LinkedList.java
 * Author: Priya Sharma
 * Student ID: 6521088
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 17, 2025
 */
public class LinkedList {

    // The starting node of this linked structure
    private Node startNode;

    /**
     * Creates a new empty LinkedList.
     */
    public LinkedList() {
        startNode = null;
    }

    /**
     * Appends an element to the back of the list.
     * @param num value to append
     */
    public void insert(int num) {
        Node freshNode = new Node(num);
        if (startNode == null) {
            startNode = freshNode;
            return;
        }
        Node ptr = startNode;
        while (ptr.next != null) {
            ptr = ptr.next;
        }
        ptr.next = freshNode;
    }

    /**
     * Removes the first matching node from the list.
     * @param num value to delete
     */
    public void delete(int num) {
        if (startNode == null) return;
        if (startNode.data == num) {
            startNode = startNode.next;
            return;
        }
        Node ptr = startNode;
        while (ptr.next != null) {
            if (ptr.next.data == num) {
                ptr.next = ptr.next.next;
                return;
            }
            ptr = ptr.next;
        }
    }

    /**
     * Searches the list for a given value.
     * @param num value to find
     * @return true if found, false otherwise
     */
    public boolean contains(int num) {
        Node ptr = startNode;
        while (ptr != null) {
            if (ptr.data == num) return true;
            ptr = ptr.next;
        }
        return false;
    }

    /**
     * Returns the total count of nodes.
     */
    public int size() {
        int counter = 0;
        Node ptr = startNode;
        while (ptr != null) {
            counter++;
            ptr = ptr.next;
        }
        return counter;
    }

    /**
     * Reverses all nodes in-place using three pointers.
     */
    public void reverse() {
        Node behind = null;
        Node ptr = startNode;
        while (ptr != null) {
            Node ahead = ptr.next;
            ptr.next = behind;
            behind = ptr;
            ptr = ahead;
        }
        startNode = behind;
    }

    /**
     * Prints every value in the list on one line.
     */
    public void display() {
        Node ptr = startNode;
        while (ptr != null) {
            System.out.print(ptr.data + " ");
            ptr = ptr.next;
        }
        System.out.println();
    }
}
