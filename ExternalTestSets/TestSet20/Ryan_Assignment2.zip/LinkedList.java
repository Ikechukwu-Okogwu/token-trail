/**
 * LinkedList.java
 * Author: Ryan Fernandez
 * Student ID: 6477120
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 10, 2025
 *
 * I went with full recursion for insert and contains.
 * This felt cleaner to me than manual traversal with a while loop.
 */
public class LinkedList {

    private Node head;

    public LinkedList() {
        this.head = null;
    }

    // --- Public interface ---

    public void insert(int value) {
        head = insertRec(head, value);
    }

    public void delete(int value) {
        head = deleteRec(head, value);
    }

    public boolean contains(int value) {
        return containsRec(head, value);
    }

    public int size() {
        return sizeRec(head);
    }

    public void reverse() {
        head = reverseRec(head);
    }

    public void display() {
        displayRec(head);
        System.out.println();
    }

    // --- Recursive helpers ---

    /**
     * Recursively walks to end and inserts there.
     */
    private Node insertRec(Node node, int value) {
        if (node == null) return new Node(value);
        node.next = insertRec(node.next, value);
        return node;
    }

    /**
     * Recursively removes first match.
     */
    private Node deleteRec(Node node, int value) {
        if (node == null) return null;
        if (node.data == value) return node.next;
        node.next = deleteRec(node.next, value);
        return node;
    }

    /**
     * Recursively searches for value.
     */
    private boolean containsRec(Node node, int value) {
        if (node == null) return false;
        if (node.data == value) return true;
        return containsRec(node.next, value);
    }

    /**
     * Recursively counts nodes.
     */
    private int sizeRec(Node node) {
        if (node == null) return 0;
        return 1 + sizeRec(node.next);
    }

    /**
     * Classic recursive list reversal.
     */
    private Node reverseRec(Node node) {
        if (node == null || node.next == null) return node;
        Node rest = reverseRec(node.next);
        node.next.next = node;
        node.next = null;
        return rest;
    }

    /**
     * Recursively prints each node.
     */
    private void displayRec(Node node) {
        if (node == null) return;
        System.out.print(node.data + " ");
        displayRec(node.next);
    }
}
