/**
 * LinkedList.java
 * Author: Sofia Nguyen
 * Student ID: 6503415
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 16, 2025
 */
public class LinkedList {

    // Head node of the list
    private Node head;

    // Constructor initializes empty list
    public LinkedList() {
        head = null;
    }

    /**
     * Inserts a new value at the end of the list.
     * @param value the integer to insert
     */
    public void insert(int value) {
        Node newNode = new Node(value);
        if (head == null) {
            head = newNode;
            return;
        }
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        current.next = newNode;
    }

    /**
     * Deletes the first occurrence of the given value.
     * @param value the integer to remove
     */
    public void delete(int value) {
        if (head == null) return;
        if (head.data == value) {
            head = head.next;
            return;
        }
        Node current = head;
        while (current.next != null) {
            if (current.next.data == value) {
                current.next = current.next.next;
                return;
            }
            current = current.next;
        }
    }

    /**
     * Returns true if the list contains the given value.
     * @param value the integer to search for
     */
    public boolean contains(int value) {
        Node current = head;
        while (current != null) {
            if (current.data == value) return true;
            current = current.next;
        }
        return false;
    }

    /**
     * Returns the number of elements in the list.
     */
    public int size() {
        int count = 0;
        Node current = head;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }

    /**
     * Reverses the linked list in-place.
     */
    public void reverse() {
        Node prev = null;
        Node current = head;
        while (current != null) {
            Node nextNode = current.next;
            current.next = prev;
            prev = current;
            current = nextNode;
        }
        head = prev;
    }

    /**
     * Prints all elements of the list.
     */
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }
}
