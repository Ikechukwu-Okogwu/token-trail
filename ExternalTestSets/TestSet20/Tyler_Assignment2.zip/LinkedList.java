/**
 * LinkedList.java
 * Author: Tyler Novak
 * Student ID: 6488561
 * Course: COSC 2P03 - Data Structures
 * Assignment 2
 * Date: March 9, 2025
 *
 * I prefer concise code. Used ternary operators
 * and collapsed some loops to single-expression forms.
 */
public class LinkedList {

    private Node h; // head

    public LinkedList() { h = null; }

    /** Inserts value at end of list */
    public void insert(int v) {
        Node n = new Node(v);
        if (h == null) { h = n; return; }
        Node t = h;
        while (t.next != null) t = t.next;
        t.next = n;
    }

    /** Deletes first occurrence of value */
    public void delete(int v) {
        if (h == null) return;
        if (h.data == v) { h = h.next; return; }
        Node t = h;
        while (t.next != null && t.next.data != v) t = t.next;
        if (t.next != null) t.next = t.next.next;
    }

    /** Returns true if value is in list */
    public boolean contains(int v) {
        Node t = h;
        while (t != null) {
            if (t.data == v) return true;
            t = t.next;
        }
        return false;
    }

    /** Returns list size */
    public int size() {
        int s = 0;
        for (Node t = h; t != null; t = t.next) s++;
        return s;
    }

    /** Reverses list in-place */
    public void reverse() {
        Node p = null, c = h, nx;
        while (c != null) { nx = c.next; c.next = p; p = c; c = nx; }
        h = p;
    }

    /** Displays list values */
    public void display() {
        for (Node t = h; t != null; t = t.next) System.out.print(t.data + " ");
        System.out.println();
    }
}
