import java.util.*;

public class BankAccountSystem {
    static class Account {
        String accountNumber;
        String ownerName;
        double balance;

        Account(String accNum, String name, double initial) {
            this.accountNumber = accNum;
            this.ownerName = name;
            this.balance = initial;
        }

        void deposit(double amount) {
            if (amount > 0) {
                balance += amount;
                System.out.println("Deposited: $" + amount);
            }
        }

        boolean withdraw(double amount) {
            if (amount > 0 && amount <= balance) {
                balance -= amount;
                System.out.println("Withdrawn: $" + amount);
                return true;
            }
            System.out.println("Insufficient funds or invalid amount!");
            return false;
        }

        void display() {
            System.out.printf("Bank Account: %s | Owner: %s | Balance: $%.2f%n", 
                            accountNumber, ownerName, balance);
        }
    }

    private static final Map<String, Account> accounts = new HashMap<>();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Simple Bank Account System ===");

        while (true) {
            System.out.println("\n1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Check Balance");
            System.out.println("5. List All Accounts");
            System.out.println("6. Exit");
            System.out.print("Choose option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1 -> createAccount();
                case 2 -> deposit();
                case 3 -> withdraw();
                case 4 -> checkBalance();
                case 5 -> listAccounts();
                case 6 -> {
                    System.out.println("Thank you for using the Bank System!");
                    return;
                }
                default -> System.out.println("Invalid option!");
            }
        }
    }

    private static int getIntInput() {
        while (!scanner.hasNextInt()) {
            scanner.next();
            System.out.print("Please enter a valid number: ");
        }
        int input = scanner.nextInt();
        scanner.nextLine();
        return input;
    }

    private static void createAccount() {
        System.out.print("Enter owner name: ");
        String name = scanner.nextLine();
        System.out.print("Enter initial deposit: ");
        double initial = scanner.nextDouble();
        scanner.nextLine();

        String accNum = "BANK" + (1000 + accounts.size());
        Account acc = new Account(accNum, name, initial);
        accounts.put(accNum, acc);
        System.out.println("Account created! Number: " + accNum);
    }

    private static void deposit() {
        System.out.print("Enter account number: ");
        String accNum = scanner.nextLine();
        Account acc = accounts.get(accNum);
        if (acc != null) {
            System.out.print("Enter deposit amount: ");
            double amt = scanner.nextDouble();
            scanner.nextLine();
            acc.deposit(amt);
        } else {
            System.out.println("Account not found!");
        }
    }

    private static void withdraw() {
        System.out.print("Enter account number: ");
        String accNum = scanner.nextLine();
        Account acc = accounts.get(accNum);
        if (acc != null) {
            System.out.print("Enter withdrawal amount: ");
            double amt = scanner.nextDouble();
            scanner.nextLine();
            acc.withdraw(amt);
        } else {
            System.out.println("Account not found!");
        }
    }

    private static void checkBalance() {
        System.out.print("Enter account number: ");
        String accNum = scanner.nextLine();
        Account acc = accounts.get(accNum);
        if (acc != null) acc.display();
        else System.out.println("Account not found!");
    }

    private static void listAccounts() {
        if (accounts.isEmpty()) {
            System.out.println("No accounts yet.");
            return;
        }
        for (Account acc : accounts.values()) {
            acc.display();
        }
    }
}