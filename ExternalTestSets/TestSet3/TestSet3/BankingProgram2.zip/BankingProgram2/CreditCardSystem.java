import java.util.*;

public class CreditCardSystem {
    static class CreditCard {
        String cardNumber;
        String ownerName;
        double balance;        // Current balance (debt)
        double creditLimit;

        CreditCard(String cardNum, String name, double limit) {
            this.cardNumber = cardNum;
            this.ownerName = name;
            this.balance = 0.0;
            this.creditLimit = limit;
        }

        void makePurchase(double amount) {
            if (amount > 0 && (balance + amount) <= creditLimit) {
                balance += amount;
                System.out.println("Purchase of $" + amount + " approved.");
            } else {
                System.out.println("Purchase declined! Exceeds credit limit.");
            }
        }

        boolean makePayment(double amount) {
            if (amount > 0 && amount <= balance) {
                balance -= amount;
                System.out.println("Payment of $" + amount + " received.");
                return true;
            }
            System.out.println("Invalid payment amount!");
            return false;
        }

        void display() {
            System.out.printf("Credit Card: %s | Owner: %s | Balance: $%.2f | Limit: $%.2f%n", 
                            cardNumber, ownerName, balance, creditLimit);
        }
    }

    private static final Map<String, CreditCard> cards = new HashMap<>();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Simple Credit Card System ===");

        while (true) {
            System.out.println("\n1. Create Credit Card");
            System.out.println("2. Make Purchase");
            System.out.println("3. Make Payment");
            System.out.println("4. Check Balance");
            System.out.println("5. List All Cards");
            System.out.println("6. Exit");
            System.out.print("Choose option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1 -> createCard();
                case 2 -> makePurchase();
                case 3 -> makePayment();
                case 4 -> checkBalance();
                case 5 -> listCards();
                case 6 -> {
                    System.out.println("Thank you for using the Credit Card System!");
                    return;
                }
                default -> System.out.println("Invalid option!");
            }
        }
    }

    private static int getIntInput() {
        while (!scanner.hasNextInt()) {
            scanner.next();
            System.out.print("Please enter a valid number: ");
        }
        int input = scanner.nextInt();
        scanner.nextLine();
        return input;
    }

    private static void createCard() {
        System.out.print("Enter owner name: ");
        String name = scanner.nextLine();
        System.out.print("Enter credit limit: ");
        double limit = scanner.nextDouble();
        scanner.nextLine();

        String cardNum = "CARD" + (1000 + cards.size());
        CreditCard card = new CreditCard(cardNum, name, limit);
        cards.put(cardNum, card);
        System.out.println("Credit Card created! Number: " + cardNum);
    }

    private static void makePurchase() {
        System.out.print("Enter card number: ");
        String cardNum = scanner.nextLine();
        CreditCard card = cards.get(cardNum);
        if (card != null) {
            System.out.print("Enter purchase amount: ");
            double amt = scanner.nextDouble();
            scanner.nextLine();
            card.makePurchase(amt);
        } else {
            System.out.println("Card not found!");
        }
    }

    private static void makePayment() {
        System.out.print("Enter card number: ");
        String cardNum = scanner.nextLine();
        CreditCard card = cards.get(cardNum);
        if (card != null) {
            System.out.print("Enter payment amount: ");
            double amt = scanner.nextDouble();
            scanner.nextLine();
            card.makePayment(amt);
        } else {
            System.out.println("Card not found!");
        }
    }

    private static void checkBalance() {
        System.out.print("Enter card number: ");
        String cardNum = scanner.nextLine();
        CreditCard card = cards.get(cardNum);
        if (card != null) card.display();
        else System.out.println("Card not found!");
    }

    private static void listCards() {
        if (cards.isEmpty()) {
            System.out.println("No credit cards yet.");
            return;
        }
        for (CreditCard card : cards.values()) {
            card.display();
        }
    }
}