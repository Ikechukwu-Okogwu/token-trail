import java.util.Scanner;

public class BasicCalculator {
    private static double memory = 0.0;
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Basic Calculator with Memory ===");

        while (true) {
            showMenu();
            int choice = getIntInput();

            switch (choice) {
                case 1 -> performOperation("+");
                case 2 -> performOperation("-");
                case 3 -> performOperation("*");
                case 4 -> performOperation("/");
                case 5 -> calculateSquareRoot();
                case 6 -> calculatePower();
                case 7 -> storeInMemory();
                case 8 -> recallMemory();
                case 9 -> clearMemory();
                case 10 -> {
                    System.out.println("Thank you for using the calculator!");
                    return;
                }
                default -> System.out.println("Invalid option!");
            }
        }
    }

    private static void showMenu() {
        System.out.println("\n1. Add          2. Subtract");
        System.out.println("3. Multiply     4. Divide");
        System.out.println("5. Square Root  6. Power");
        System.out.println("7. Memory Store (M+)");
        System.out.println("8. Memory Recall (MR)");
        System.out.println("9. Clear Memory");
        System.out.println("10. Exit");
        System.out.print("Choose operation: ");
    }

    private static int getIntInput() {
        while (!sc.hasNextInt()) {
            sc.next();
            System.out.print("Please enter a valid number: ");
        }
        int val = sc.nextInt();
        sc.nextLine();
        return val;
    }

    private static void performOperation(String operator) {
        System.out.print("Enter first number: ");
        double a = sc.nextDouble();
        System.out.print("Enter second number: ");
        double b = sc.nextDouble();
        sc.nextLine();

        double result = switch (operator) {
            case "+" -> a + b;
            case "-" -> a - b;
            case "*" -> a * b;
            case "/" -> (b != 0) ? a / b : Double.NaN;
            default -> 0;
        };

        if (operator.equals("/") && b == 0) {
            System.out.println("Error: Cannot divide by zero!");
        } else {
            System.out.println("Result: " + result);
        }
    }

    private static void calculateSquareRoot() {
        System.out.print("Enter number: ");
        double num = sc.nextDouble();
        sc.nextLine();
        if (num >= 0) {
            System.out.println("√" + num + " = " + Math.sqrt(num));
        } else {
            System.out.println("Cannot calculate square root of negative number!");
        }
    }

    private static void calculatePower() {
        System.out.print("Enter base: ");
        double base = sc.nextDouble();
        System.out.print("Enter exponent: ");
        double exp = sc.nextDouble();
        sc.nextLine();
        System.out.println(base + "^" + exp + " = " + Math.pow(base, exp));
    }

    private static void storeInMemory() {
        System.out.print("Enter number to store in memory: ");
        memory = sc.nextDouble();
        sc.nextLine();
        System.out.println("Stored in memory: " + memory);
    }

    private static void recallMemory() {
        System.out.println("Memory value: " + memory);
    }

    private static void clearMemory() {
        memory = 0.0;
        System.out.println("Memory cleared.");
    }
}