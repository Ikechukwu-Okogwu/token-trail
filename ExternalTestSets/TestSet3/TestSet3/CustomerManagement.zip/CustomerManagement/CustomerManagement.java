import java.util.*;

public class CustomerManagement {
    static class Person {
        String id;
        String name;
        String email;

        Person(String id, String name, String email) {
            this.id = id;
            this.name = name;
            this.email = email;
        }

        void display() {
            System.out.printf("ID: %s | Name: %s | Email: %s%n", id, name, email);
        }
    }

    static class Customer extends Person {
        double totalSpent;

        Customer(String id, String name, String email, double totalSpent) {
            super(id, name, email);
            this.totalSpent = totalSpent;
        }

        @Override
        void display() {
            System.out.printf("Customer ID: %s | Name: %s | Email: %s | Total Spent: $%.2f%n", 
                            id, name, email, totalSpent);
        }
    }

    private static final Map<String, Customer> customers = new HashMap<>();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Customer Management System ===");

        while (true) {
            System.out.println("\n1. Add Customer");
            System.out.println("2. View Customer");
            System.out.println("3. List All Customers");
            System.out.println("4. Exit");
            System.out.print("Choice: ");

            int choice = getIntInput();

            switch (choice) {
                case 1 -> addCustomer();
                case 2 -> viewPerson();
                case 3 -> listAll();
                case 4 -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice");
            }
        }
    }

    private static int getIntInput() {
        while (!sc.hasNextInt()) {
            sc.next();
            System.out.print("Enter a valid number: ");
        }
        int val = sc.nextInt();
        sc.nextLine();
        return val;
    }

    private static void addCustomer() {
        System.out.print("ID: ");
        String id = sc.nextLine();
        System.out.print("Name: ");
        String name = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Total Spent: ");
        double spent = sc.nextDouble();
        sc.nextLine();

        customers.put(id, new Customer(id, name, email, spent));
        System.out.println("Customer added successfully!");
    }

    private static void viewPerson() {
        System.out.print("Enter ID: ");
        String id = sc.nextLine();
        Customer c = customers.get(id);
        if (c != null) c.display();
        else System.out.println("Not found");
    }

    private static void listAll() {
        if (customers.isEmpty()) {
            System.out.println("No customers yet.");
            return;
        }
        for (Customer c : customers.values()) c.display();
    }
}