import java.util.*;

public class EmployeeManagement {
    static class Person {
        String id;
        String name;
        String email;

        Person(String id, String name, String email) {
            this.id = id;
            this.name = name;
            this.email = email;
        }

        void display() {
            System.out.printf("ID: %s | Name: %s | Email: %s%n", id, name, email);
        }
    }

    static class Employee extends Person {
        double salary;

        Employee(String id, String name, String email, double salary) {
            super(id, name, email);
            this.salary = salary;
        }

        @Override
        void display() {
            System.out.printf("Employee ID: %s | Name: %s | Email: %s | Salary: $%.2f%n", 
                            id, name, email, salary);
        }
    }

    private static final Map<String, Employee> employees = new HashMap<>();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Employee Management System ===");

        while (true) {
            System.out.println("\n1. Add Employee");
            System.out.println("2. View Employee");
            System.out.println("3. List All Employees");
            System.out.println("4. Exit");
            System.out.print("Choice: ");

            int choice = getIntInput();

            switch (choice) {
                case 1 -> addEmployee();
                case 2 -> viewPerson();
                case 3 -> listAll();
                case 4 -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice");
            }
        }
    }

    private static int getIntInput() {
        while (!sc.hasNextInt()) {
            sc.next();
            System.out.print("Enter a valid number: ");
        }
        int val = sc.nextInt();
        sc.nextLine();
        return val;
    }

    private static void addEmployee() {
        System.out.print("ID: ");
        String id = sc.nextLine();
        System.out.print("Name: ");
        String name = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("Salary: ");
        double salary = sc.nextDouble();
        sc.nextLine();

        employees.put(id, new Employee(id, name, email, salary));
        System.out.println("Employee added successfully!");
    }

    private static void viewPerson() {
        System.out.print("Enter ID: ");
        String id = sc.nextLine();
        Employee e = employees.get(id);
        if (e != null) e.display();
        else System.out.println("Not found");
    }

    private static void listAll() {
        if (employees.isEmpty()) {
            System.out.println("No employees yet.");
            return;
        }
        for (Employee e : employees.values()) e.display();
    }
}