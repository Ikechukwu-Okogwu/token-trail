/**
 * Christian Cortina
 * 7444011
 * Feb 24 2025
 * COSC 2P13 A1
 */

import java.util.Scanner;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

public class Main {
    public static void main(String[] args) {
        // Create Scanner object for user input
        Scanner scanner = new Scanner(System.in);

        // Display welcome message and menu options
        System.out.println("Welcome to the Makerspace Simulator!");
        System.out.println("Choose which knickknacks to make:");
        System.out.println("1. Figurines");
        System.out.println("2. Motor Controllers");
        System.out.println("3. Chess Set");
        System.out.println("4. Toaster Pastry");
        System.out.println("5. Cup Holder");
        System.out.println("6. SAK Scales");
        System.out.println("7. Flashlight");

        // Get user's item choices as comma-separated input
        System.out.print("Enter comma-separated choices (e.g., 1,3,5): ");
        String[] choices = scanner.nextLine().split(",");

        // Array to store quantities for each chosen item
        int[] quantities = new int[choices.length];
        for (int i = 0; i < choices.length; i++) {
            // Prompt for and store quantity for each item
            System.out.print("Enter quantity for " + choices[i] + ": ");
            quantities[i] = scanner.nextInt();
        }

        // Get reporting interval from user
        System.out.print("Enter progress reporting interval: ");
        int reportInterval = scanner.nextInt();

        // Close scanner to prevent resource leak
        scanner.close();

        // Create locks for each piece of equipment to prevent concurrent access
        Lock resinPrinter = new ReentrantLock();
        Lock fdmPrinter = new ReentrantLock();
        Lock solderingIron = new ReentrantLock();
        Lock toasterOven = new ReentrantLock();
        Lock lathe = new ReentrantLock();
        Lock mill = new ReentrantLock();
        Lock airbrush = new ReentrantLock();

        // Process each user choice and start corresponding threads
        for (int i = 0; i < choices.length; i++) {
            int choice = Integer.parseInt(choices[i].trim());  // Convert choice to integer
            int quantity = quantities[i];  // Get corresponding quantity

            // Match choice to item and start appropriate thread
            switch (choice) {
                case 1:
                    new Thread(new Figurines(resinPrinter, airbrush, quantity, reportInterval)).start();
                    break;
                case 2:
                    new Thread(new MotorControllers(solderingIron, mill, toasterOven, quantity, reportInterval)).start();
                    break;
                case 3:
                    new Thread(new ChessSet(resinPrinter, lathe, fdmPrinter, quantity, reportInterval)).start();
                    break;
                case 4:
                    new Thread(new ToasterPastry(toasterOven, quantity, reportInterval)).start();
                    break;
                case 5:
                    new Thread(new CupHolder(toasterOven, fdmPrinter, airbrush, quantity, reportInterval)).start();
                    break;
                case 6:
                    new Thread(new SAKScales(mill, toasterOven, quantity, reportInterval)).start();
                    break;
                case 7:
                    new Thread(new Flashlight(lathe, solderingIron, quantity, reportInterval)).start();
                    break;
                default:
                    System.out.println("Invalid choice: " + choice);  // Handle invalid selections
            }
        }
    }
}

// Class to handle figurine production
class Figurines implements Runnable {
    private Lock resinPrinter, airbrush;  // Required equipment
    private int quantity, reportInterval;  // Production parameters

    // Constructor to initialize equipment and parameters
    public Figurines(Lock resinPrinter, Lock airbrush, int quantity, int reportInterval) {
        this.resinPrinter = resinPrinter;
        this.airbrush = airbrush;
        this.quantity = quantity;
        this.reportInterval = reportInterval;
    }

    @Override
    public void run() {
        // Produce specified quantity of figurines
        for (int i = 1; i <= quantity; i++) {
            resinPrinter.lock();  // Acquire resin printer
            try {
                System.out.println("Printing figurine " + i);
            } finally {
                resinPrinter.unlock();  // Release printer
            }

            airbrush.lock();  // Acquire airbrush
            try {
                System.out.println("Painting figurine " + i);
            } finally {
                airbrush.unlock();  // Release airbrush
            }

            // Report progress at specified intervals
            if (i % reportInterval == 0) {
                System.out.println("Progress: " + i + " figurines completed");
            }
        }
    }
}

// Class to handle motor controller production
class MotorControllers implements Runnable {
    private Lock solderingIron, mill, toasterOven;  // Required equipment
    private int quantity, reportInterval;  // Production parameters

    // Constructor to initialize equipment and parameters
    public MotorControllers(Lock solderingIron, Lock mill, Lock toasterOven, int quantity, int reportInterval) {
        this.solderingIron = solderingIron;
        this.mill = mill;
        this.toasterOven = toasterOven;
        this.quantity = quantity;
        this.reportInterval = reportInterval;
    }

    @Override
    public void run() {
        // Produce specified quantity of motor controllers
        for (int i = 1; i <= quantity; i++) {
            solderingIron.lock();  // Acquire soldering iron
            try {
                System.out.println("Tinning components for motor controller " + i);
            } finally {
                solderingIron.unlock();  // Release soldering iron
            }

            mill.lock();  // Acquire mill
            try {
                System.out.println("Cutting traces for motor controller " + i);
            } finally {
                mill.unlock();  // Release mill
            }

            toasterOven.lock();  // Acquire toaster oven
            try {
                System.out.println("Reflowing solder for motor controller " + i);
            } finally {
                toasterOven.unlock();  // Release toaster oven
            }

            // Report progress at specified intervals
            if (i % reportInterval == 0) {
                System.out.println("Progress: " + i + " motor controllers completed");
            }
        }
    }
}

// Class to handle chess set production
class ChessSet implements Runnable {
    private Lock resinPrinter, lathe, fdmPrinter;  // Required equipment
    private int quantity, reportInterval;  // Production parameters

    // Constructor to initialize equipment and parameters
    public ChessSet(Lock resinPrinter, Lock lathe, Lock fdmPrinter, int quantity, int reportInterval) {
        this.resinPrinter = resinPrinter;
        this.lathe = lathe;
        this.fdmPrinter = fdmPrinter;
        this.quantity = quantity;
        this.reportInterval = reportInterval;
    }

    @Override
    public void run() {
        // Produce specified quantity of chess sets
        for (int i = 1; i <= quantity; i++) {
            resinPrinter.lock();  // Acquire resin printer
            try {
                System.out.println("Printing chess pieces " + i);
            } finally {
                resinPrinter.unlock();  // Release printer
            }

            lathe.lock();  // Acquire lathe
            try {
                System.out.println("Turning rooks on lathe " + i);
            } finally {
                lathe.unlock();  // Release lathe
            }

            fdmPrinter.lock();  // Acquire FDM printer
            try {
                System.out.println("Printing chess board " + i);
            } finally {
                fdmPrinter.unlock();  // Release printer
            }

            // Report progress at specified intervals
            if (i % reportInterval == 0) {
                System.out.println("Progress: " + i + " chess sets completed");
            }
        }
    }
}

// Class to handle toaster pastry production
class ToasterPastry implements Runnable {
    private Lock toasterOven;  // Required equipment
    private int quantity, reportInterval;  // Production parameters

    // Constructor to initialize equipment and parameters
    public ToasterPastry(Lock toasterOven, int quantity, int reportInterval) {
        this.toasterOven = toasterOven;
        this.quantity = quantity;
        this.reportInterval = reportInterval;
    }

    @Override
    public void run() {
        // Produce specified quantity of toaster pastries
        for (int i = 1; i <= quantity; i++) {
            toasterOven.lock();  // Acquire toaster oven
            try {
                System.out.println("Baking toaster pastry " + i);
            } finally {
                toasterOven.unlock();  // Release toaster oven
            }

            // Report progress at specified intervals
            if (i % reportInterval == 0) {
                System.out.println("Progress: " + i + " toaster pastries completed");
            }
        }
    }
}

// Class to handle cup holder production
class CupHolder implements Runnable {
    private Lock toasterOven, fdmPrinter, airbrush;  // Required equipment
    private int quantity, reportInterval;  // Production parameters

    // Constructor to initialize equipment and parameters
    public CupHolder(Lock toasterOven, Lock fdmPrinter, Lock airbrush, int quantity, int reportInterval) {
        this.toasterOven = toasterOven;
        this.fdmPrinter = fdmPrinter;
        this.airbrush = airbrush;
        this.quantity = quantity;
        this.reportInterval = reportInterval;
    }

    @Override
    public void run() {
        // Produce specified quantity of cupholders
        for (int i = 1; i <= quantity; i++) {
            toasterOven.lock();  // Acquire toaster oven
            try {
                System.out.println("Drying filament for cup holder " + i);
            } finally {
                toasterOven.unlock();  // Release toaster oven
            }

            fdmPrinter.lock();  // Acquire FDM printer
            try {
                System.out.println("Printing cup holder " + i);
            } finally {
                fdmPrinter.unlock();  // Release printer
            }

            airbrush.lock();  // Acquire airbrush
            try {
                System.out.println("Smoothing cup holder " + i);
            } finally {
                airbrush.unlock();  // Release airbrush
            }

            // Report progress at specified intervals
            if (i % reportInterval == 0) {
                System.out.println("Progress: " + i + " cup holders completed");
            }
        }
    }
}

// Class to handle SAK scales production
class SAKScales implements Runnable {
    private Lock mill, toasterOven;  // Required equipment
    private int quantity, reportInterval;  // Production parameters

    // Constructor to initialize equipment and parameters
    public SAKScales(Lock mill, Lock toasterOven, int quantity, int reportInterval) {
        this.mill = mill;
        this.toasterOven = toasterOven;
        this.quantity = quantity;
        this.reportInterval = reportInterval;
    }

    @Override
    public void run() {
        // Produce specified quantity of SAK scales
        for (int i = 1; i <= quantity; i++) {
            mill.lock();  // Acquire mill
            try {
                System.out.println("Milling SAK scales " + i);
            } finally {
                mill.unlock();  // Release mill
            }

            toasterOven.lock();  // Acquire toaster oven
            try {
                System.out.println("Drying SAK scales " + i);
            } finally {
                toasterOven.unlock();  // Release toaster oven
            }

            // Report progress at specified intervals
            if (i % reportInterval == 0) {
                System.out.println("Progress: " + i + " SAK scales completed");
            }
        }
    }
}

// Class to handle flashlight production
class Flashlight implements Runnable {
    private Lock lathe, solderingIron;  // Required equipment
    private int quantity, reportInterval;  // Production parameters

    // Constructor to initialize equipment and parameters
    public Flashlight(Lock lathe, Lock solderingIron, int quantity, int reportInterval) {
        this.lathe = lathe;
        this.solderingIron = solderingIron;
        this.quantity = quantity;
        this.reportInterval = reportInterval;
    }

    @Override
    public void run() {
        // Produce specified quantity of flashlights
        for (int i = 1; i <= quantity; i++) {
            lathe.lock();  // Acquire lathe
            try {
                System.out.println("Turning flashlight body on lathe " + i);
            } finally {
                lathe.unlock();  // Release lathe
            }

            solderingIron.lock();  // Acquire soldering iron
            try {
                System.out.println("Assembling flashlight " + i);
            } finally {
                solderingIron.unlock();  // Release soldering iron
            }

            // Report progress at specified intervals
            if (i % reportInterval == 0) {
                System.out.println("Progress: " + i + " flashlights completed");
            }
        }
    }
}