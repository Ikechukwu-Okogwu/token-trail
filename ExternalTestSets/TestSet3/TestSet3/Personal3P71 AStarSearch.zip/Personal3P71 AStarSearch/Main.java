/*
 * Christian Cortina
 * 7444011
 * COSC 3p71 Assigment 1
 * Oct 20 2024
 */

import java.io.*;
import java.util.*;

// Defines a class representing the state of the puzzle at any given time
class PuzzleState implements Comparable<PuzzleState> {
    int[][] board; // Stores the current puzzle board config
    int moves; // Number of moves taken to reach this state
    PuzzleState previous; // Reference to the previous state
    int size; // Size of the board
    int[][] goal; // Goal configuration of the board
    String heuristicType; // Type of heuristic

    // Constructor to initialize the puzzle state
    public PuzzleState(int[][] board, int[][] goal, int moves, PuzzleState previous, String heuristicType) {
        this.board = board; // Assigns the input board
        this.goal = goal; // Stores the goal configuration
        this.moves = moves; // Stores the current number of moves
        this.previous = previous; // Tracks the previous puzzle state
        this.size = board.length; // Determines the size of the board
        this.heuristicType = heuristicType; // Stores the selected heuristic
    }

    // Implements the compareTo method to compare two puzzle states based on their f() value
    @Override
    public int compareTo(PuzzleState other) {
        return Integer.compare(this.f(), other.f()); // Compares f(n) values of two states
    }

    // Calculates the f(n) value as g(n) + h(n)
    public int f() {
        return this.moves + heuristic(); // Sum of moves and heuristic
    }

    // Chooses  heuristic based on the user’s input
    public int heuristic() {
        switch (heuristicType.toLowerCase()) { // Converts heuristicType to lowercase for comparison
            case "manhattan": // If "manhattan", use Manhattan distance
                return manhattanDistance();
            case "misplaced": // If "misplaced", use misplaced tiles
                return misplacedTiles();
            case "reversal": // If "reversal", use adjacent tile reversals
                return adjacentTileReversals();
            default: // Throw an error for an invalid heuristic type
                throw new IllegalArgumentException("Invalid heuristic type: " + heuristicType);
        }
    }

    // Computes the Manhattan distance heuristic
    public int manhattanDistance() {
        int distance = 0; // Initialize the total distance
        for (int i = 0; i < size; i++) { // Iterate through rows
            for (int j = 0; j < size; j++) { // Iterate through columns
                int value = board[i][j]; // Get the tile value at (i, j)
                if (value != 0) { // Ignore the empty tile (0)
                    int targetX = (value - 1) / size; // Compute the target row in the goal
                    int targetY = (value - 1) % size; // Compute the target column in the goal
                    distance += Math.abs(i - targetX) + Math.abs(j - targetY); // Accumulate Manhattan distance
                }
            }
        }
        return distance; // Return the total distance
    }

    // Counts the number of misplaced tiles
    public int misplacedTiles() {
        int misplaced = 0; // Initialize the counter
        for (int i = 0; i < size; i++) { // Iterate through rows
            for (int j = 0; j < size; j++) { // Iterate through columns
                int value = board[i][j]; // Get the tile value at (i, j)
                if (value != 0 && value != goal[i][j]) { // Check if the tile is misplaced
                    misplaced++; // Increment the counter for each misplaced tile
                }
            }
        }
        return misplaced; // Return the total count of misplaced tiles
    }

    // Counts adjacent tile reversals
    public int adjacentTileReversals() {
        int reversals = 0; // Initialize the reversal counter

        // Check for horizontal reversals (left-to-right swaps)
        for (int i = 0; i < size; i++) { // Iterate through rows
            for (int j = 0; j < size - 1; j++) { // Iterate through columns, stopping one before the end
                int current = board[i][j]; // Current tile value
                int next = board[i][j + 1]; // Next tile value to the right
                if (current != 0 && next != 0) { // Ignore empty tiles
                    int currentGoalPos = getGoalPosition(current); // Goal position of the current tile
                    int nextGoalPos = getGoalPosition(next); // Goal position of the next tile
                    if (currentGoalPos > nextGoalPos) { // Check if they are reversed
                        reversals++; // Increment the reversal counter
                    }
                }
            }
        }

        // Check for vertical reversals (top-to-bottom swaps)
        for (int i = 0; i < size - 1; i++) { // Iterate through rows, stopping one before the end
            for (int j = 0; j < size; j++) { // Iterate through columns
                int current = board[i][j]; // Current tile value
                int next = board[i + 1][j]; // Tile value directly below
                if (current != 0 && next != 0) { // Ignore empty tiles
                    int currentGoalPos = getGoalPosition(current); // Goal position of the current tile
                    int nextGoalPos = getGoalPosition(next); // Goal position of the next tile
                    if (currentGoalPos > nextGoalPos) { // Check if they are reversed
                        reversals++; // Increment the reversal counter
                    }
                }
            }
        }
        return reversals; // Return the total number of reversals
    }

    // Helper method to get the goal position of a given tile value
    private int getGoalPosition(int value) {
        int x = (value - 1) / size; // Compute the row in the goal
        int y = (value - 1) % size; // Compute the column in the goal
        return x * size + y; // Return the position
    }

    // Checks if the current board matches the goal state
    public boolean isGoal() {
        return Arrays.deepEquals(board, goal); // Compare the current board with the goal
    }

    // Generates all neighboring states by sliding the empty tile
    public List<PuzzleState> getNeighbors() {
        List<PuzzleState> neighbors = new ArrayList<>(); // List to store neighboring states
        int[] zeroPos = findZero(); // Find the position of the empty tile
        int x = zeroPos[0], y = zeroPos[1]; // Store the row and column of the empty tile
        int[][] directions = { {1, 0}, {-1, 0}, {0, 1}, {0, -1} }; // Down, Up, Right, Left directions

        // Iterate over all possible directions
        for (int[] dir : directions) {
            int newX = x + dir[0]; // Compute the new row
            int newY = y + dir[1]; // Compute the new column
            if (newX >= 0 && newX < size && newY >= 0 && newY < size) { // Check if within bounds
                int[][] newBoard = copyBoard(board); // Create a copy of the current board
                newBoard[x][y] = newBoard[newX][newY]; // Swap the empty tile with the adjacent tile
                newBoard[newX][newY] = 0; // Set the new position of the empty tile
                neighbors.add(new PuzzleState(newBoard, goal, moves + 1, this, heuristicType)); // Add the new state to neighbors
            }
        }
        return neighbors; // Return the list of neighboring states
    }

    // Helper method to find the position of the empty tile
    private int[] findZero() {
        for (int i = 0; i < size; i++) { // Iterate through rows
            for (int j = 0; j < size; j++) { // Iterate through columns
                if (board[i][j] == 0) { // Check if the tile is empty
                    return new int[] { i, j }; // Return the position as an array
                }
            }
        }
        return null; // Return null if no empty tile is found
    }

    // Helper method to create a copy of the board
    private int[][] copyBoard(int[][] original) {
        int[][] copy = new int[size][size]; // Create a new board of the same size
        for (int i = 0; i < size; i++) { // Iterate through rows
            System.arraycopy(original[i], 0, copy[i], 0, size); // Copy each row
        }
        return copy; // Return the copied board
    }

    // Constructs the solution path from the initial state to the goal state
    public List<int[][]> getPath() {
        List<int[][]> path = new ArrayList<>(); // List to store the path
        PuzzleState state = this; // Start from the current state
        while (state != null) { // Traverse back to the initial state
            path.add(state.board); // Add each state to the path
            state = state.previous; // Move to the previous state
        }
        Collections.reverse(path); // Reverse the path to get the correct order
        return path; // Return the solution path
    }
}

// Main class that implements the A* algorithm
public class Main {

    // Performs A* search to find the solution path from the initial to the goal state
    public static List<int[][]> aStarSearch(int[][] initial, int[][] goal, String heuristicType) {
        PriorityQueue<PuzzleState> openList = new PriorityQueue<>(); // Open list to store states to explore
        Set<String> closedSet = new HashSet<>(); // Closed set to track visited states
        openList.add(new PuzzleState(initial, goal, 0, null, heuristicType)); // Add the initial state to the open list

        // Continue exploring while there are states in the open list
        while (!openList.isEmpty()) {
            PuzzleState currentState = openList.poll(); // Get the state with the lowest f(n) value

            if (currentState.isGoal()) { // Check if the current state is the goal state
                return currentState.getPath(); // Return the path from the initial state to the goal
            }

            String boardString = boardToString(currentState.board); // Convert the board to a string for hashing
            closedSet.add(boardString); // Add the current state to the closed set

            // Explore all valid neighboring states
            for (PuzzleState neighbor : currentState.getNeighbors()) {
                String neighborString = boardToString(neighbor.board); // Convert neighbor to a string
                if (!closedSet.contains(neighborString)) { // If the neighbor hasn't been visited
                    openList.add(neighbor); // Add it to the open list for exploration
                }
            }
        }

        return null; // Return null if no solution is found
    }

    // Converts a board configuration to a string for easy comparison and hashing
    private static String boardToString(int[][] board) {
        StringBuilder sb = new StringBuilder(); // Create a StringBuilder to build the string
        for (int[] row : board) { // Iterate over each row
            for (int value : row) { // Iterate over each value in the row
                sb.append(value).append(","); // Append the value followed by a comma
            }
        }
        return sb.toString(); // Return the string representation of the board
    }

    // Prints a board configuration to the console
    public static void printBoard(int[][] board) {
        for (int[] row : board) { // Iterate over each row
            System.out.println(Arrays.toString(row)); // Print the row as a string
        }
    }

    // Prints the solution path
    public static void printSolution(List<int[][]> solution) {
        if (solution == null) { // If no solution was found
            System.out.println("No solution found."); // Print a message
            return;
        }

        System.out.println("Initial Puzzle:");
        printBoard(solution.get(0)); // Print the initial board
        System.out.println();

        System.out.println("Total Moves: " + (solution.size() - 1)); // Print the total number of moves
        System.out.println("Steps from Initial to Goal:");

        System.out.println("Solved Puzzle:");
        printBoard(solution.get(solution.size() - 1)); // Print the solved board
        System.out.println();

        // Iterate through each step and print it
        for (int i = 0; i < solution.size(); i++) {
            System.out.println("Step " + i + ":");
            printBoard(solution.get(i)); // Print the board at each step
            System.out.println();
        }
    }

    // Reads a puzzle board configuration from a file
    public static int[][] readBoardFromFile(String filename) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) { // Open the file for reading
            int size = Integer.parseInt(br.readLine().trim()); // Read the size of the board
            int[][] board = new int[size][size]; // Create a new board of the specified size

            // Read the board configuration line by line
            for (int i = 0; i < size; i++) {
                String[] line = br.readLine().trim().split("\t"); // Split each line by tab
                for (int j = 0; j < size; j++) {
                    if (line[j].equalsIgnoreCase("X")) { // If the value is "X", it's an empty tile
                        board[i][j] = 0; // Set the value to 0
                    } else {
                        board[i][j] = Integer.parseInt(line[j]); //parse the integer value
                    }
                }
            }
            return board; // Return the board
        }
    }

    // Main method to run the A* search algorithm
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in); // Create a Scanner to read input

            String filename = "/C://Users//chris//OneDrive//Documents//puzzel2.txt/"; //needs to be changed for TA to run program

            System.out.print("Choose heuristic manhattan/misplaced/reversal (my heuristic): ");
            String heuristicType = scanner.nextLine(); // Read the heuristic type from the user

            int[][] initialBoard = readBoardFromFile(filename); // Read the initial board from the file

            int size = initialBoard.length; // Determine the size of the board
            int[][] goalBoard = new int[size][size]; // Create a new board for the goal configuration

            // Populate the goal board in the correct order
            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    goalBoard[i][j] = (i * size + j + 1) % (size * size); // Calculate goal value
                }
            }

            // Perform A* search to find the solution path
            long startTime = System.currentTimeMillis(); //start timer for testing
            List<int[][]> solution = aStarSearch(initialBoard, goalBoard, heuristicType);
            long endTime = System.currentTimeMillis(); //end timer

            long duration = endTime - startTime; //time difference
            System.out.println(duration + " ms"); //print time

            // Print the solution path
            printSolution(solution);
        } catch (IOException e) { // Handle file reading errors
            System.err.println("Error reading the file: " + e.getMessage()); // Print error message
        }
    }
}