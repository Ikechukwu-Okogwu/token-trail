/*
 * Christian Cortina
 * 7444011
 * COSC 3p71 Assignment 1
 * Oct 20 2024
 */
import java.io.*;
import java.util.*;

// PuzzleState class
class PuzzleState {
    int[][] board; // 2D array representing the current board configuration
    PuzzleState previous; // Reference to the previous state
    int size; // Size of the board
    int depth; // Depth of the state in the search tree

    // Constructor to initialize a PuzzleState
    public PuzzleState(int[][] board, PuzzleState previous, int depth) {
        this.board = board;
        this.previous = previous;
        this.size = board.length; // Assign the size based on board dimensions
        this.depth = depth;
    }

    // Checks if the current board matches the goal state
    public boolean isGoal(int[][] goal) {
        return Arrays.deepEquals(this.board, goal); // Compare
    }

    // Generates all possible next states from the current board configuration
    public List<PuzzleState> getNeighbors() {
        List<PuzzleState> neighbors = new ArrayList<>(); // Stores possible neighbors
        int[] zeroPos = findZero(); // Locate the empty tile
        int x = zeroPos[0], y = zeroPos[1]; // Extract coordinates of the empty tile
        int[][] directions = { {1, 0}, {-1, 0}, {0, 1}, {0, -1} }; // Down, Up, Right, Left

        // Loop through each possible move direction
        for (int[] dir : directions) {
            int newX = x + dir[0]; // Calculate new X position
            int newY = y + dir[1]; // Calculate new Y position

            // Check if the new position is within board boundaries
            if (newX >= 0 && newX < size && newY >= 0 && newY < size) {
                int[][] newBoard = copyBoard(this.board); // Create a copy of the board
                newBoard[x][y] = newBoard[newX][newY]; // Swap empty tile with the adjacent one
                newBoard[newX][newY] = 0; // Set the new position to 0
                neighbors.add(new PuzzleState(newBoard, this, depth + 1)); // Add new state
            }
        }
        return neighbors; // Return all neighbors
    }

    // Helper method to find the position of the empty tile
    private int[] findZero() {
        for (int i = 0; i < size; i++) { // Loop through rows
            for (int j = 0; j < size; j++) { // Loop through columns
                if (board[i][j] == 0) { // If empty tile found
                    return new int[] { i, j }; // Return its position
                }
            }
        }
        return null; // Return null if not found
    }

    // Creates a copy of the current board to avoid modifying the original
    private int[][] copyBoard(int[][] original) {
        int[][] copy = new int[size][size]; // Initialize new board with the same size
        for (int i = 0; i < size; i++) {
            System.arraycopy(original[i], 0, copy[i], 0, size); // Copy each row
        }
        return copy; // Return the new board copy
    }

    // Returns the path from the initial state to the current state
    public List<int[][]> getPath() {
        List<int[][]> path = new ArrayList<>(); // Store the path
        PuzzleState state = this; // Start from the current state
        while (state != null) { // Traverse back to the initial state
            path.add(state.board); // Add the current board to the path
            state = state.previous; // Move to the previous state
        }
        Collections.reverse(path); // Reverse to get the path in correct order
        return path; // Return the full path
    }
}

// Main class
public class Main {

    // IDDFS
    public static List<int[][]> iterativeDeepeningDFS(int[][] initial, int[][] goal) {
        int depth = 0; // Start with depth 0
        while (true) { // Loop until a solution is found
            System.out.println("Searching with depth limit: " + depth);
            // Perform depth-limited search with the current depth
            PuzzleState result = depthLimitedSearch(new PuzzleState(initial, null, 0), goal, depth);
            if (result != null) {
                return result.getPath(); // Return the solution path if found
            }
            depth++; // Increment the depth limit and search again
        }
    }

    // Depth-limited search to explore up to a specific depth
    public static PuzzleState depthLimitedSearch(PuzzleState currentState, int[][] goal, int limit) {
        if (currentState.isGoal(goal)) {
            return currentState; // Return the state if it's the goal
        }
        if (currentState.depth >= limit) {
            return null; // Stop if the depth limit is reached
        }

        // Explore all neighboring states
        for (PuzzleState neighbor : currentState.getNeighbors()) {
            PuzzleState result = depthLimitedSearch(neighbor, goal, limit); // Recursive call
            if (result != null) {
                return result; // Return the solution if found
            }
        }
        return null; // No solution found within this depth
    }

    // Prints the board
    public static void printBoard(int[][] board) {
        for (int[] row : board) {
            System.out.println(Arrays.toString(row)); // Print each row
        }
    }

    // Prints the entire solution path, including the initial and goal states
    public static void printSolution(List<int[][]> solution) {
        if (solution == null) {
            System.out.println("No solution found."); //  no solution
            return;
        }

        System.out.println("Initial Puzzle:");
        printBoard(solution.get(0)); // Print the initial board
        System.out.println();

        System.out.println("Solved Puzzle:");
        printBoard(solution.get(solution.size() - 1)); // Print the goal state
        System.out.println();

        System.out.println("Total Moves: " + (solution.size() - 1)); // Print total moves
        System.out.println("Steps from Initial to Goal:");

        // Print each step in the solution path
        for (int i = 0; i < solution.size(); i++) {
            System.out.println("Step " + i + ":");
            printBoard(solution.get(i));
            System.out.println();
        }
    }

    // Reads a puzzle board from a file
    public static int[][] readBoardFromFile(String filename) throws IOException {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            int size = Integer.parseInt(br.readLine().trim()); // Read board size
            int[][] board = new int[size][size]; // Initialize the board

            // Read each line and fill the board
            for (int i = 0; i < size; i++) {
                String[] line = br.readLine().trim().split("\t"); // Split by tabs
                for (int j = 0; j < size; j++) {
                    if (line[j].equalsIgnoreCase("X")) {
                        board[i][j] = 0; // Make empty tile 0
                    } else {
                        board[i][j] = Integer.parseInt(line[j]); // Parse numbers
                    }
                }
            }
            return board; // Return the board
        }
    }

    // Main method to execute the program
    public static void main(String[] args) {
        try {
            Scanner scanner = new Scanner(System.in); // Scanner for user input

            String filename = "/C://Users//chris//OneDrive//Documents//puzzel2.txt/"; // File path which needs to be changed for TA to run program
            int[][] initialBoard = readBoardFromFile(filename); // Load the initial board

            int size = initialBoard.length; // Get board size
            int[][] goalBoard = new int[size][size]; // Initialize goal board

            // Fill the goal board with the correct sequence
            for (int i = 0; i < size; i++) {
                for (int j = 0; j < size; j++) {
                    goalBoard[i][j] = (i * size + j + 1) % (size * size);
                }
            }

            long startTime = System.currentTimeMillis(); // Start timer for testing

            List<int[][]> solution = iterativeDeepeningDFS(initialBoard, goalBoard); // Solve the puzzle

            long endTime = System.currentTimeMillis(); // End timer

            long duration = endTime - startTime; // Time difference
            System.out.println(duration + " ms");

            printSolution(solution); // Print the solution
        } catch (IOException e) {
            System.err.println("Error reading the file: " + e.getMessage()); // Print error message
        }
    }
}
