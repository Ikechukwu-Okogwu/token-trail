import java.util.*;

public class QuizGame {
    static class Question {
        String questionText;
        String[] options;
        int correctIndex;

        Question(String q, String[] opts, int correct) {
            this.questionText = q;
            this.options = opts;
            this.correctIndex = correct;
        }
    }

    private static final List<Question> questions = new ArrayList<>();
    private static int score = 0;
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        loadQuestions();
        System.out.println("=== General Knowledge Quiz ===\n");

        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            System.out.println("Question " + (i + 1) + ": " + q.questionText);
            for (int j = 0; j < q.options.length; j++) {
                System.out.println((j + 1) + ". " + q.options[j]);
            }
            System.out.print("Your answer (1-" + q.options.length + "): ");
            int answer = sc.nextInt();
            sc.nextLine();

            if (answer == q.correctIndex) {
                System.out.println("Correct!\n");
                score++;
            } else {
                System.out.println("Wrong! The correct answer was " + q.correctIndex + "\n");
            }
        }

        System.out.println("=== Quiz Completed ===");
        System.out.println("Final Score: " + score + "/" + questions.size());
        double percent = (score * 100.0) / questions.size();
        System.out.printf("Percentage: %.1f%%\n", percent);

        if (percent >= 80) System.out.println("Excellent performance!");
        else if (percent >= 60) System.out.println("Good job!");
        else System.out.println("Keep practicing!");
    }

    private static void loadQuestions() {
        questions.add(new Question("Capital of Italy?", new String[]{"Paris", "Rome", "Madrid", "Berlin"}, 2));
        questions.add(new Question("Largest planet in our solar system?", new String[]{"Earth", "Mars", "Jupiter", "Saturn"}, 3));
        questions.add(new Question("What is 15 + 27?", new String[]{"40", "42", "45", "52"}, 2));
        questions.add(new Question("Chemical symbol for Gold?", new String[]{"Go", "Gd", "Au", "Ag"}, 3));
        questions.add(new Question("How many continents are there?", new String[]{"5", "6", "7", "8"}, 3));
        questions.add(new Question("Who painted the Mona Lisa?", new String[]{"Picasso", "Van Gogh", "Da Vinci", "Rembrandt"}, 3));
    }
}