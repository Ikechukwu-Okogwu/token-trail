import java.util.*;

public class StudentManagement {
    static class Person {
        String id;
        String name;
        String email;

        Person(String id, String name, String email) {
            this.id = id;
            this.name = name;
            this.email = email;
        }

        void display() {
            System.out.printf("ID: %s | Name: %s | Email: %s%n", id, name, email);
        }
    }

    static class Student extends Person {
        double gpa;

        Student(String id, String name, String email, double gpa) {
            super(id, name, email);
            this.gpa = gpa;
        }

        @Override
        void display() {
            System.out.printf("Student ID: %s | Name: %s | Email: %s | GPA: %.2f%n", 
                            id, name, email, gpa);
        }
    }

    private static final Map<String, Student> students = new HashMap<>();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Student Management System ===");

        while (true) {
            System.out.println("\n1. Add Student");
            System.out.println("2. View Student");
            System.out.println("3. List All Students");
            System.out.println("4. Exit");
            System.out.print("Choice: ");

            int choice = getIntInput();

            switch (choice) {
                case 1 -> addStudent();
                case 2 -> viewPerson();
                case 3 -> listAll();
                case 4 -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice");
            }
        }
    }

    private static int getIntInput() {
        while (!sc.hasNextInt()) {
            sc.next();
            System.out.print("Enter a valid number: ");
        }
        int val = sc.nextInt();
        sc.nextLine();
        return val;
    }

    private static void addStudent() {
        System.out.print("ID: ");
        String id = sc.nextLine();
        System.out.print("Name: ");
        String name = sc.nextLine();
        System.out.print("Email: ");
        String email = sc.nextLine();
        System.out.print("GPA: ");
        double gpa = sc.nextDouble();
        sc.nextLine();

        students.put(id, new Student(id, name, email, gpa));
        System.out.println("Student added successfully!");
    }

    private static void viewPerson() {
        System.out.print("Enter ID: ");
        String id = sc.nextLine();
        Student s = students.get(id);
        if (s != null) s.display();
        else System.out.println("Not found");
    }

    private static void listAll() {
        if (students.isEmpty()) {
            System.out.println("No students yet.");
            return;
        }
        for (Student s : students.values()) s.display();
    }
}