import java.util.*;

public class TodoList {
    static class Task {
        String description;
        boolean isCompleted;

        Task(String desc) {
            this.description = desc;
            this.isCompleted = false;
        }
    }

    private static final List<Task> tasks = new ArrayList<>();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Simple Todo List ===");

        while (true) {
            System.out.println("\n1. Add Task");
            System.out.println("2. List Tasks");
            System.out.println("3. Mark Task Complete");
            System.out.println("4. Delete Task");
            System.out.println("5. Exit");
            System.out.print("Choice: ");

            int choice = getIntInput();

            switch (choice) {
                case 1 -> addTask();
                case 2 -> listTasks();
                case 3 -> markComplete();
                case 4 -> deleteTask();
                case 5 -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice");
            }
        }
    }

    private static int getIntInput() {
        while (!sc.hasNextInt()) {
            sc.next();
            System.out.print("Enter a valid number: ");
        }
        int val = sc.nextInt();
        sc.nextLine();
        return val;
    }

    private static void addTask() {
        System.out.print("Enter task description: ");
        String desc = sc.nextLine();
        tasks.add(new Task(desc));
        System.out.println("Task added!");
    }

    private static void listTasks() {
        if (tasks.isEmpty()) {
            System.out.println("No tasks yet.");
            return;
        }
        System.out.println("\n=== Your Todo List ===");
        for (int i = 0; i < tasks.size(); i++) {
            Task t = tasks.get(i);
            System.out.printf("%d. [%s] %s%n", i + 1, t.isCompleted ? "✓" : " ", t.description);
        }
    }

    private static void markComplete() {
        listTasks();
        if (tasks.isEmpty()) return;
        System.out.print("Enter task number to complete: ");
        int index = getIntInput() - 1;
        if (index >= 0 && index < tasks.size()) {
            tasks.get(index).isCompleted = true;
            System.out.println("Task marked as complete!");
        } else {
            System.out.println("Invalid task number!");
        }
    }

    private static void deleteTask() {
        listTasks();
        if (tasks.isEmpty()) return;
        System.out.print("Enter task number to delete: ");
        int index = getIntInput() - 1;
        if (index >= 0 && index < tasks.size()) {
            tasks.remove(index);
            System.out.println("Task deleted!");
        } else {
            System.out.println("Invalid task number!");
        }
    }
}