import java.util.*;

public class TemperatureConverter {
    private static final List<String> history = new ArrayList<>();
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("=== Temperature Converter ===");

        while (true) {
            System.out.println("\n1. Celsius → Fahrenheit");
            System.out.println("2. Fahrenheit → Celsius");
            System.out.println("3. View History");
            System.out.println("4. Exit");
            System.out.print("Choose option: ");

            int choice = getIntInput();

            switch (choice) {
                case 1 -> celsiusToFahrenheit();
                case 2 -> fahrenheitToCelsius();
                case 3 -> showHistory();
                case 4 -> {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice!");
            }
        }
    }

    private static int getIntInput() {
        while (!sc.hasNextInt()) {
            sc.next();
            System.out.print("Enter a valid number: ");
        }
        int val = sc.nextInt();
        sc.nextLine();
        return val;
    }

    private static void celsiusToFahrenheit() {
        System.out.print("Enter temperature in Celsius: ");
        double c = sc.nextDouble();
        double f = (c * 9 / 5) + 32;
        String result = String.format("%.2f °C = %.2f °F", c, f);
        System.out.println(result);
        history.add(result);
    }

    private static void fahrenheitToCelsius() {
        System.out.print("Enter temperature in Fahrenheit: ");
        double f = sc.nextDouble();
        double c = (f - 32) * 5 / 9;
        String result = String.format("%.2f °F = %.2f °C", f, c);
        System.out.println(result);
        history.add(result);
    }

    private static void showHistory() {
        if (history.isEmpty()) {
            System.out.println("No conversions yet.");
            return;
        }
        System.out.println("\n=== Conversion History ===");
        for (String entry : history) {
            System.out.println(entry);
        }
    }
}