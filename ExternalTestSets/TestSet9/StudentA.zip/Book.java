import java.util.ArrayList;
import java.util.List;

/**
 * Book class representing a book in the library.
 */
public class Book {
    private String title;
    private String author;
    private String isbn;
    private boolean isCheckedOut;
    private int yearPublished;

    public Book(String title, String author, String isbn, int yearPublished) {
        this.title = title;
        this.author = author;
        this.isbn = isbn;
        this.yearPublished = yearPublished;
        this.isCheckedOut = false;
    }

    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public String getIsbn() { return isbn; }
    public int getYearPublished() { return yearPublished; }
    public boolean isCheckedOut() { return isCheckedOut; }

    public void checkOut() {
        if (isCheckedOut) {
            throw new IllegalStateException("Book is already checked out.");
        }
        isCheckedOut = true;
    }

    public void returnBook() {
        if (!isCheckedOut) {
            throw new IllegalStateException("Book is not checked out.");
        }
        isCheckedOut = false;
    }

    @Override
    public String toString() {
        return "Book{title='" + title + "', author='" + author +
               "', isbn='" + isbn + "', checkedOut=" + isCheckedOut + "}";
    }
}
