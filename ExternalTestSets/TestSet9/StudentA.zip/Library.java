import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Library management system.
 * Manages a collection of books with checkout and return functionality.
 */
public class Library {

    private String name;
    private List<Book> books;
    private int maxCapacity;

    public Library(String name, int maxCapacity) {
        this.name = name;
        this.maxCapacity = maxCapacity;
        this.books = new ArrayList<>();
    }

    /**
     * Add a book to the library collection.
     */
    public boolean addBook(Book book) {
        if (books.size() >= maxCapacity) {
            System.out.println("Library is at full capacity. Cannot add: " + book.getTitle());
            return false;
        }
        if (findByIsbn(book.getIsbn()) != null) {
            System.out.println("Book with ISBN " + book.getIsbn() + " already exists.");
            return false;
        }
        books.add(book);
        System.out.println("Added: " + book.getTitle());
        return true;
    }

    /**
     * Remove a book from the library by ISBN.
     */
    public boolean removeBook(String isbn) {
        Book book = findByIsbn(isbn);
        if (book == null) {
            System.out.println("Book not found: " + isbn);
            return false;
        }
        if (book.isCheckedOut()) {
            System.out.println("Cannot remove a checked out book.");
            return false;
        }
        books.remove(book);
        System.out.println("Removed: " + book.getTitle());
        return true;
    }

    /**
     * Check out a book by ISBN.
     */
    public boolean checkOutBook(String isbn) {
        Book book = findByIsbn(isbn);
        if (book == null) {
            System.out.println("Book not found: " + isbn);
            return false;
        }
        try {
            book.checkOut();
            System.out.println("Checked out: " + book.getTitle());
            return true;
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    /**
     * Return a checked out book by ISBN.
     */
    public boolean returnBook(String isbn) {
        Book book = findByIsbn(isbn);
        if (book == null) {
            System.out.println("Book not found: " + isbn);
            return false;
        }
        try {
            book.returnBook();
            System.out.println("Returned: " + book.getTitle());
            return true;
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    /**
     * Find a book by its ISBN.
     */
    public Book findByIsbn(String isbn) {
        for (Book book : books) {
            if (book.getIsbn().equals(isbn)) {
                return book;
            }
        }
        return null;
    }

    /**
     * Search books by author name.
     */
    public List<Book> findByAuthor(String author) {
        List<Book> result = new ArrayList<>();
        for (Book book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                result.add(book);
            }
        }
        return result;
    }

    /**
     * Get all currently available (not checked out) books.
     */
    public List<Book> getAvailableBooks() {
        List<Book> available = new ArrayList<>();
        for (Book book : books) {
            if (!book.isCheckedOut()) {
                available.add(book);
            }
        }
        return available;
    }

    /**
     * Get total number of books in the library.
     */
    public int getTotalBooks() {
        return books.size();
    }

    /**
     * Get number of checked out books.
     */
    public int getCheckedOutCount() {
        int count = 0;
        for (Book book : books) {
            if (book.isCheckedOut()) count++;
        }
        return count;
    }

    /**
     * Print a summary of the library status.
     */
    public void printStatus() {
        System.out.println("=== Library: " + name + " ===");
        System.out.println("Total books: " + getTotalBooks());
        System.out.println("Checked out: " + getCheckedOutCount());
        System.out.println("Available:   " + (getTotalBooks() - getCheckedOutCount()));
        System.out.println("Capacity:    " + maxCapacity);
    }

    public static void main(String[] args) {
        Library library = new Library("City Library", 100);

        Book b1 = new Book("Clean Code", "Robert Martin", "978-0132350884", 2008);
        Book b2 = new Book("The Pragmatic Programmer", "Andrew Hunt", "978-0201616224", 1999);
        Book b3 = new Book("Design Patterns", "Gang of Four", "978-0201633610", 1994);
        Book b4 = new Book("Refactoring", "Martin Fowler", "978-0201485677", 1999);
        Book b5 = new Book("Code Complete", "Steve McConnell", "978-0735619678", 2004);

        library.addBook(b1);
        library.addBook(b2);
        library.addBook(b3);
        library.addBook(b4);
        library.addBook(b5);

        library.printStatus();

        library.checkOutBook("978-0132350884");
        library.checkOutBook("978-0201616224");
        library.checkOutBook("978-0132350884"); // already checked out

        library.printStatus();

        library.returnBook("978-0132350884");
        library.removeBook("978-0201485677");

        List<Book> available = library.getAvailableBooks();
        System.out.println("\nAvailable books:");
        for (Book b : available) {
            System.out.println("  " + b);
        }

        library.printStatus();
    }
}
