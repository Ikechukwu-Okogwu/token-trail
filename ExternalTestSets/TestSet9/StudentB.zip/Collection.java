import java.util.ArrayList;
import java.util.List;

/**
 * Collection management system.
 * Manages a collection of items with borrow and return functionality.
 */
public class Collection {

    private String collectionName;
    private List<Item> itemList;
    private int totalCapacity;

    public Collection(String collectionName, int totalCapacity) {
        this.collectionName = collectionName;
        this.totalCapacity = totalCapacity;
        this.itemList = new ArrayList<>();
    }

    /**
     * Add an item to the collection.
     */
    public boolean addItem(Item item) {
        if (itemList.size() >= totalCapacity) {
            System.out.println("Collection is at full capacity. Cannot add: " + item.getItemName());
            return false;
        }
        if (findByCode(item.getItemCode()) != null) {
            System.out.println("Item with code " + item.getItemCode() + " already exists.");
            return false;
        }
        itemList.add(item);
        System.out.println("Added: " + item.getItemName());
        return true;
    }

    /**
     * Remove an item from the collection by code.
     */
    public boolean removeItem(String itemCode) {
        Item item = findByCode(itemCode);
        if (item == null) {
            System.out.println("Item not found: " + itemCode);
            return false;
        }
        if (item.isBorrowed()) {
            System.out.println("Cannot remove a borrowed item.");
            return false;
        }
        itemList.remove(item);
        System.out.println("Removed: " + item.getItemName());
        return true;
    }

    /**
     * Borrow an item by code.
     */
    public boolean borrowItem(String itemCode) {
        Item item = findByCode(itemCode);
        if (item == null) {
            System.out.println("Item not found: " + itemCode);
            return false;
        }
        try {
            item.borrow();
            System.out.println("Borrowed: " + item.getItemName());
            return true;
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    /**
     * Return a borrowed item by code.
     */
    public boolean returnItem(String itemCode) {
        Item item = findByCode(itemCode);
        if (item == null) {
            System.out.println("Item not found: " + itemCode);
            return false;
        }
        try {
            item.returnItem();
            System.out.println("Returned: " + item.getItemName());
            return true;
        } catch (IllegalStateException e) {
            System.out.println(e.getMessage());
            return false;
        }
    }

    /**
     * Find an item by its code.
     */
    public Item findByCode(String itemCode) {
        for (Item item : itemList) {
            if (item.getItemCode().equals(itemCode)) {
                return item;
            }
        }
        return null;
    }

    /**
     * Search items by creator name.
     */
    public List<Item> findByCreator(String creator) {
        List<Item> result = new ArrayList<>();
        for (Item item : itemList) {
            if (item.getItemCreator().equalsIgnoreCase(creator)) {
                result.add(item);
            }
        }
        return result;
    }

    /**
     * Get all currently available (not borrowed) items.
     */
    public List<Item> getAvailableItems() {
        List<Item> available = new ArrayList<>();
        for (Item item : itemList) {
            if (!item.isBorrowed()) {
                available.add(item);
            }
        }
        return available;
    }

    /**
     * Get total number of items in the collection.
     */
    public int getTotalItems() {
        return itemList.size();
    }

    /**
     * Get number of borrowed items.
     */
    public int getBorrowedCount() {
        int counter = 0;
        for (Item item : itemList) {
            if (item.isBorrowed()) counter++;
        }
        return counter;
    }

    /**
     * Print a summary of the collection status.
     */
    public void printStatus() {
        System.out.println("=== Collection: " + collectionName + " ===");
        System.out.println("Total items: " + getTotalItems());
        System.out.println("Borrowed:    " + getBorrowedCount());
        System.out.println("Available:   " + (getTotalItems() - getBorrowedCount()));
        System.out.println("Capacity:    " + totalCapacity);
    }

    public static void main(String[] args) {
        Collection collection = new Collection("City Collection", 100);

        Item i1 = new Item("Clean Code", "Robert Martin", "978-0132350884", 2008);
        Item i2 = new Item("The Pragmatic Programmer", "Andrew Hunt", "978-0201616224", 1999);
        Item i3 = new Item("Design Patterns", "Gang of Four", "978-0201633610", 1994);
        Item i4 = new Item("Refactoring", "Martin Fowler", "978-0201485677", 1999);
        Item i5 = new Item("Code Complete", "Steve McConnell", "978-0735619678", 2004);

        collection.addItem(i1);
        collection.addItem(i2);
        collection.addItem(i3);
        collection.addItem(i4);
        collection.addItem(i5);

        collection.printStatus();

        collection.borrowItem("978-0132350884");
        collection.borrowItem("978-0201616224");
        collection.borrowItem("978-0132350884"); // already borrowed

        collection.printStatus();

        collection.returnItem("978-0132350884");
        collection.removeItem("978-0201485677");

        List<Item> available = collection.getAvailableItems();
        System.out.println("\nAvailable items:");
        for (Item i : available) {
            System.out.println("  " + i);
        }

        collection.printStatus();
    }
}
