import java.util.ArrayList;
import java.util.List;

/**
 * Item class representing an item in the collection.
 */
public class Item {
    private String itemName;
    private String itemCreator;
    private String itemCode;
    private boolean isBorrowed;
    private int releaseYear;

    public Item(String itemName, String itemCreator, String itemCode, int releaseYear) {
        this.itemName = itemName;
        this.itemCreator = itemCreator;
        this.itemCode = itemCode;
        this.releaseYear = releaseYear;
        this.isBorrowed = false;
    }

    public String getItemName() { return itemName; }
    public String getItemCreator() { return itemCreator; }
    public String getItemCode() { return itemCode; }
    public int getReleaseYear() { return releaseYear; }
    public boolean isBorrowed() { return isBorrowed; }

    public void borrow() {
        if (isBorrowed) {
            throw new IllegalStateException("Item is already borrowed.");
        }
        isBorrowed = true;
    }

    public void returnItem() {
        if (!isBorrowed) {
            throw new IllegalStateException("Item is not borrowed.");
        }
        isBorrowed = false;
    }

    @Override
    public String toString() {
        return "Item{itemName='" + itemName + "', itemCreator='" + itemCreator +
               "', itemCode='" + itemCode + "', isBorrowed=" + isBorrowed + "}";
    }
}
