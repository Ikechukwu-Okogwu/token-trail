import java.util.ArrayList;
import java.util.List;

/**
 * Student grade management system.
 * Calculates final grades based on assignments, midterm, and final exam.
 */
public class GradeCalculator {

    private String studentName;
    private List<Double> assignmentScores;
    private double midtermScore;
    private double finalExamScore;

    private static final double ASSIGNMENT_WEIGHT = 0.40;
    private static final double MIDTERM_WEIGHT    = 0.30;
    private static final double FINAL_WEIGHT      = 0.30;

    public GradeCalculator(String studentName) {
        this.studentName = studentName;
        this.assignmentScores = new ArrayList<>();
        this.midtermScore = 0.0;
        this.finalExamScore = 0.0;
    }

    /**
     * Add an assignment score (0-100).
     */
    public void addAssignment(double score) {
        if (score < 0 || score > 100) {
            throw new IllegalArgumentException("Score must be between 0 and 100.");
        }
        assignmentScores.add(score);
    }

    /**
     * Set the midterm exam score.
     */
    public void setMidterm(double score) {
        if (score < 0 || score > 100) {
            throw new IllegalArgumentException("Score must be between 0 and 100.");
        }
        this.midtermScore = score;
    }

    /**
     * Set the final exam score.
     */
    public void setFinalExam(double score) {
        if (score < 0 || score > 100) {
            throw new IllegalArgumentException("Score must be between 0 and 100.");
        }
        this.finalExamScore = score;
    }

    /**
     * Calculate the average of all assignment scores.
     */
    public double getAssignmentAverage() {
        if (assignmentScores.isEmpty()) return 0.0;
        double total = 0.0;
        for (double score : assignmentScores) {
            total += score;
        }
        return total / assignmentScores.size();
    }

    /**
     * Calculate the final weighted grade.
     */
    public double getFinalGrade() {
        double assignmentAvg = getAssignmentAverage();
        return (assignmentAvg * ASSIGNMENT_WEIGHT)
             + (midtermScore  * MIDTERM_WEIGHT)
             + (finalExamScore * FINAL_WEIGHT);
    }

    /**
     * Convert numeric grade to letter grade.
     */
    public String getLetterGrade() {
        double grade = getFinalGrade();
        if (grade >= 90) return "A";
        if (grade >= 80) return "B";
        if (grade >= 70) return "C";
        if (grade >= 60) return "D";
        return "F";
    }

    /**
     * Check if the student passed the course.
     */
    public boolean isPassing() {
        return getFinalGrade() >= 50.0;
    }

    /**
     * Get the highest assignment score.
     */
    public double getHighestAssignment() {
        if (assignmentScores.isEmpty()) return 0.0;
        double highest = assignmentScores.get(0);
        for (double score : assignmentScores) {
            if (score > highest) highest = score;
        }
        return highest;
    }

    /**
     * Get the lowest assignment score.
     */
    public double getLowestAssignment() {
        if (assignmentScores.isEmpty()) return 0.0;
        double lowest = assignmentScores.get(0);
        for (double score : assignmentScores) {
            if (score < lowest) lowest = score;
        }
        return lowest;
    }

    /**
     * Print a full grade report.
     */
    public void printReport() {
        System.out.println("=== Grade Report: " + studentName + " ===");
        System.out.println("Assignments submitted: " + assignmentScores.size());
        System.out.printf("Assignment average:    %.2f%n", getAssignmentAverage());
        System.out.printf("Highest assignment:    %.2f%n", getHighestAssignment());
        System.out.printf("Lowest assignment:     %.2f%n", getLowestAssignment());
        System.out.printf("Midterm score:         %.2f%n", midtermScore);
        System.out.printf("Final exam score:      %.2f%n", finalExamScore);
        System.out.printf("Final grade:           %.2f%n", getFinalGrade());
        System.out.println("Letter grade:          " + getLetterGrade());
        System.out.println("Status:                " + (isPassing() ? "PASS" : "FAIL"));
    }

    public static void main(String[] args) {
        GradeCalculator student1 = new GradeCalculator("Alice");
        student1.addAssignment(85.0);
        student1.addAssignment(90.0);
        student1.addAssignment(78.0);
        student1.addAssignment(92.0);
        student1.addAssignment(88.0);
        student1.setMidterm(82.0);
        student1.setFinalExam(87.0);
        student1.printReport();

        System.out.println();

        GradeCalculator student2 = new GradeCalculator("Bob");
        student2.addAssignment(60.0);
        student2.addAssignment(55.0);
        student2.addAssignment(70.0);
        student2.addAssignment(45.0);
        student2.addAssignment(65.0);
        student2.setMidterm(58.0);
        student2.setFinalExam(62.0);
        student2.printReport();
    }
}
