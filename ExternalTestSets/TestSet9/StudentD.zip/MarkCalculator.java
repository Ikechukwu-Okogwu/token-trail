import java.util.ArrayList;
import java.util.List;

/**
 * Course mark management system.
 * Calculates final marks based on coursework, midterm, and final exam.
 */
public class MarkCalculator {

    private String learnerName;
    private List<Double> courseworkMarks;
    private double midtermMark;
    private double finalExamMark;

    private static final double COURSEWORK_WEIGHT = 0.40;
    private static final double MIDTERM_WEIGHT    = 0.30;
    private static final double FINAL_WEIGHT      = 0.30;

    public MarkCalculator(String learnerName) {
        this.learnerName = learnerName;
        this.courseworkMarks = new ArrayList<>();
        this.midtermMark = 0.0;
        this.finalExamMark = 0.0;
    }

    /**
     * Add a coursework mark (0-100).
     */
    public void addCoursework(double mark) {
        if (mark < 0 || mark > 100) {
            throw new IllegalArgumentException("Mark must be between 0 and 100.");
        }
        courseworkMarks.add(mark);
    }

    /**
     * Set the midterm exam mark.
     */
    public void setMidterm(double mark) {
        if (mark < 0 || mark > 100) {
            throw new IllegalArgumentException("Mark must be between 0 and 100.");
        }
        this.midtermMark = mark;
    }

    /**
     * Set the final exam mark.
     */
    public void setFinalExam(double mark) {
        if (mark < 0 || mark > 100) {
            throw new IllegalArgumentException("Mark must be between 0 and 100.");
        }
        this.finalExamMark = mark;
    }

    /**
     * Calculate the average of all coursework marks.
     */
    public double getCourseworkAverage() {
        if (courseworkMarks.isEmpty()) return 0.0;
        double total = 0.0;
        for (double mark : courseworkMarks) {
            total += mark;
        }
        return total / courseworkMarks.size();
    }

    /**
     * Calculate the final weighted mark.
     */
    public double getFinalMark() {
        double courseworkAvg = getCourseworkAverage();
        return (courseworkAvg  * COURSEWORK_WEIGHT)
             + (midtermMark    * MIDTERM_WEIGHT)
             + (finalExamMark  * FINAL_WEIGHT);
    }

    /**
     * Convert numeric mark to letter grade.
     */
    public String getLetterGrade() {
        double mark = getFinalMark();
        if (mark >= 90) return "A";
        if (mark >= 80) return "B";
        if (mark >= 70) return "C";
        if (mark >= 60) return "D";
        return "F";
    }

    /**
     * Check if the learner passed the course.
     */
    public boolean isPassing() {
        return getFinalMark() >= 50.0;
    }

    /**
     * Get the highest coursework mark.
     */
    public double getHighestCoursework() {
        if (courseworkMarks.isEmpty()) return 0.0;
        double highest = courseworkMarks.get(0);
        for (double mark : courseworkMarks) {
            if (mark > highest) highest = mark;
        }
        return highest;
    }

    /**
     * Get the lowest coursework mark.
     */
    public double getLowestCoursework() {
        if (courseworkMarks.isEmpty()) return 0.0;
        double lowest = courseworkMarks.get(0);
        for (double mark : courseworkMarks) {
            if (mark < lowest) lowest = mark;
        }
        return lowest;
    }

    /**
     * Print a full mark report.
     */
    public void printReport() {
        System.out.println("=== Mark Report: " + learnerName + " ===");
        System.out.println("Coursework submitted:  " + courseworkMarks.size());
        System.out.printf("Coursework average:    %.2f%n", getCourseworkAverage());
        System.out.printf("Highest coursework:    %.2f%n", getHighestCoursework());
        System.out.printf("Lowest coursework:     %.2f%n", getLowestCoursework());
        System.out.printf("Midterm mark:          %.2f%n", midtermMark);
        System.out.printf("Final exam mark:       %.2f%n", finalExamMark);
        System.out.printf("Final mark:            %.2f%n", getFinalMark());
        System.out.println("Letter grade:          " + getLetterGrade());
        System.out.println("Status:                " + (isPassing() ? "PASS" : "FAIL"));
    }

    public static void main(String[] args) {
        MarkCalculator learner1 = new MarkCalculator("Alice");
        learner1.addCoursework(85.0);
        learner1.addCoursework(90.0);
        learner1.addCoursework(78.0);
        learner1.addCoursework(92.0);
        learner1.addCoursework(88.0);
        learner1.setMidterm(82.0);
        learner1.setFinalExam(87.0);
        learner1.printReport();

        System.out.println();

        MarkCalculator learner2 = new MarkCalculator("Bob");
        learner2.addCoursework(60.0);
        learner2.addCoursework(55.0);
        learner2.addCoursework(70.0);
        learner2.addCoursework(45.0);
        learner2.addCoursework(65.0);
        learner2.setMidterm(58.0);
        learner2.setFinalExam(62.0);
        learner2.printReport();
    }
}
