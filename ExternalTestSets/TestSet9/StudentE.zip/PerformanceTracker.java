import java.util.ArrayList;
import java.util.List;

/**
 * Academic performance tracker.
 * Computes overall performance based on tasks, midterm, and final exam.
 */
public class PerformanceTracker {

    private String participantName;
    private List<Double> taskResults;
    private double midtermResult;
    private double finalResult;

    private static final double TASK_WEIGHT    = 0.40;
    private static final double MIDTERM_WEIGHT = 0.30;
    private static final double FINAL_WEIGHT   = 0.30;

    public PerformanceTracker(String participantName) {
        this.participantName = participantName;
        this.taskResults = new ArrayList<>();
        this.midtermResult = 0.0;
        this.finalResult = 0.0;
    }

    /**
     * Record a task result (0-100).
     */
    public void recordTask(double result) {
        if (result < 0 || result > 100) {
            throw new IllegalArgumentException("Result must be between 0 and 100.");
        }
        taskResults.add(result);
    }

    /**
     * Set the midterm result.
     */
    public void setMidterm(double result) {
        if (result < 0 || result > 100) {
            throw new IllegalArgumentException("Result must be between 0 and 100.");
        }
        this.midtermResult = result;
    }

    /**
     * Set the final exam result.
     */
    public void setFinalExam(double result) {
        if (result < 0 || result > 100) {
            throw new IllegalArgumentException("Result must be between 0 and 100.");
        }
        this.finalResult = result;
    }

    /**
     * Calculate the average of all task results.
     */
    public double getTaskAverage() {
        if (taskResults.isEmpty()) return 0.0;
        double sum = 0.0;
        for (double result : taskResults) {
            sum += result;
        }
        return sum / taskResults.size();
    }

    /**
     * Calculate the overall weighted performance score.
     */
    public double getOverallScore() {
        double taskAvg = getTaskAverage();
        return (taskAvg       * TASK_WEIGHT)
             + (midtermResult * MIDTERM_WEIGHT)
             + (finalResult   * FINAL_WEIGHT);
    }

    /**
     * Convert numeric score to letter grade.
     */
    public String getLetterGrade() {
        double score = getOverallScore();
        if (score >= 90) return "A";
        if (score >= 80) return "B";
        if (score >= 70) return "C";
        if (score >= 60) return "D";
        return "F";
    }

    /**
     * Check if the participant passed the course.
     */
    public boolean isPassing() {
        return getOverallScore() >= 50.0;
    }

    /**
     * Get the highest task result.
     */
    public double getHighestTask() {
        if (taskResults.isEmpty()) return 0.0;
        double highest = taskResults.get(0);
        for (double result : taskResults) {
            if (result > highest) highest = result;
        }
        return highest;
    }

    /**
     * Get the lowest task result.
     */
    public double getLowestTask() {
        if (taskResults.isEmpty()) return 0.0;
        double lowest = taskResults.get(0);
        for (double result : taskResults) {
            if (result < lowest) lowest = result;
        }
        return lowest;
    }

    /**
     * Print a full performance report.
     */
    public void printReport() {
        System.out.println("=== Performance Report: " + participantName + " ===");
        System.out.println("Tasks recorded:        " + taskResults.size());
        System.out.printf("Task average:          %.2f%n", getTaskAverage());
        System.out.printf("Highest task:          %.2f%n", getHighestTask());
        System.out.printf("Lowest task:           %.2f%n", getLowestTask());
        System.out.printf("Midterm result:        %.2f%n", midtermResult);
        System.out.printf("Final exam result:     %.2f%n", finalResult);
        System.out.printf("Overall score:         %.2f%n", getOverallScore());
        System.out.println("Letter grade:          " + getLetterGrade());
        System.out.println("Status:                " + (isPassing() ? "PASS" : "FAIL"));
    }

    public static void main(String[] args) {
        PerformanceTracker p1 = new PerformanceTracker("Alice");
        p1.recordTask(85.0);
        p1.recordTask(90.0);
        p1.recordTask(78.0);
        p1.recordTask(92.0);
        p1.recordTask(88.0);
        p1.setMidterm(82.0);
        p1.setFinalExam(87.0);
        p1.printReport();

        System.out.println();

        PerformanceTracker p2 = new PerformanceTracker("Bob");
        p2.recordTask(60.0);
        p2.recordTask(55.0);
        p2.recordTask(70.0);
        p2.recordTask(45.0);
        p2.recordTask(65.0);
        p2.setMidterm(58.0);
        p2.setFinalExam(62.0);
        p2.printReport();
    }
}
