import java.util.ArrayList;
import java.util.List;

/**
 * Sorting utility that implements bubble sort, selection sort,
 * and insertion sort on integer arrays.
 */
public class Sorter {

    private int[] data;
    private int size;

    public Sorter(int[] inputData) {
        this.size = inputData.length;
        this.data = new int[size];
        for (int i = 0; i < size; i++) {
            this.data[i] = inputData[i];
        }
    }

    /**
     * Reset data to a new array.
     */
    public void reset(int[] inputData) {
        this.size = inputData.length;
        this.data = new int[size];
        for (int i = 0; i < size; i++) {
            this.data[i] = inputData[i];
        }
    }

    /**
     * Bubble sort: repeatedly swap adjacent elements if out of order.
     */
    public void bubbleSort() {
        for (int pass = 0; pass < size - 1; pass++) {
            for (int j = 0; j < size - pass - 1; j++) {
                if (data[j] > data[j + 1]) {
                    int temp = data[j];
                    data[j] = data[j + 1];
                    data[j + 1] = temp;
                }
            }
        }
    }

    /**
     * Selection sort: find the minimum in unsorted part and place it at front.
     */
    public void selectionSort() {
        for (int i = 0; i < size - 1; i++) {
            int minIndex = i;
            for (int j = i + 1; j < size; j++) {
                if (data[j] < data[minIndex]) {
                    minIndex = j;
                }
            }
            int temp = data[minIndex];
            data[minIndex] = data[i];
            data[i] = temp;
        }
    }

    /**
     * Insertion sort: build sorted array one element at a time.
     */
    public void insertionSort() {
        for (int i = 1; i < size; i++) {
            int key = data[i];
            int j = i - 1;
            while (j >= 0 && data[j] > key) {
                data[j + 1] = data[j];
                j--;
            }
            data[j + 1] = key;
        }
    }

    /**
     * Check if the array is currently sorted in ascending order.
     */
    public boolean isSorted() {
        for (int i = 0; i < size - 1; i++) {
            if (data[i] > data[i + 1]) return false;
        }
        return true;
    }

    /**
     * Get the minimum value in the array.
     */
    public int getMin() {
        int min = data[0];
        for (int i = 1; i < size; i++) {
            if (data[i] < min) min = data[i];
        }
        return min;
    }

    /**
     * Get the maximum value in the array.
     */
    public int getMax() {
        int max = data[0];
        for (int i = 1; i < size; i++) {
            if (data[i] > max) max = data[i];
        }
        return max;
    }

    /**
     * Calculate the sum of all elements.
     */
    public long getSum() {
        long total = 0;
        for (int i = 0; i < size; i++) {
            total += data[i];
        }
        return total;
    }

    /**
     * Calculate the average of all elements.
     */
    public double getAverage() {
        return (double) getSum() / size;
    }

    /**
     * Count how many elements are greater than a given threshold.
     */
    public int countGreaterThan(int threshold) {
        int count = 0;
        for (int i = 0; i < size; i++) {
            if (data[i] > threshold) count++;
        }
        return count;
    }

    /**
     * Count how many elements are less than a given threshold.
     */
    public int countLessThan(int threshold) {
        int count = 0;
        for (int i = 0; i < size; i++) {
            if (data[i] < threshold) count++;
        }
        return count;
    }

    /**
     * Reverse the array in place.
     */
    public void reverse() {
        int left = 0;
        int right = size - 1;
        while (left < right) {
            int temp = data[left];
            data[left] = data[right];
            data[right] = temp;
            left++;
            right--;
        }
    }

    /**
     * Print the current state of the array.
     */
    public void print() {
        System.out.print("[");
        for (int i = 0; i < size; i++) {
            System.out.print(data[i]);
            if (i < size - 1) System.out.print(", ");
        }
        System.out.println("]");
    }

    /**
     * Print a summary report of the array.
     */
    public void printReport() {
        System.out.println("=== Array Report ===");
        System.out.print("Data:     ");
        print();
        System.out.println("Size:     " + size);
        System.out.println("Min:      " + getMin());
        System.out.println("Max:      " + getMax());
        System.out.println("Sum:      " + getSum());
        System.out.printf("Average:  %.2f%n", getAverage());
        System.out.println("Sorted:   " + isSorted());
    }

    public static void main(String[] args) {
        int[] original = {64, 34, 25, 12, 22, 11, 90, 45, 73, 8};

        Sorter s = new Sorter(original.clone());
        System.out.println("Original:");
        s.print();
        s.printReport();

        System.out.println("\nAfter bubble sort:");
        s.reset(original.clone());
        s.bubbleSort();
        s.print();
        System.out.println("Is sorted: " + s.isSorted());

        System.out.println("\nAfter selection sort:");
        s.reset(original.clone());
        s.selectionSort();
        s.print();
        System.out.println("Is sorted: " + s.isSorted());

        System.out.println("\nAfter insertion sort:");
        s.reset(original.clone());
        s.insertionSort();
        s.print();
        System.out.println("Is sorted: " + s.isSorted());

        System.out.println("\nReversed:");
        s.reverse();
        s.print();

        System.out.println("\nCount > 30: " + s.countGreaterThan(30));
        System.out.println("Count < 30: " + s.countLessThan(30));
    }
}
