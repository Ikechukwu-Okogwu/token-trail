import java.util.ArrayList;
import java.util.List;

/**
 * Array processing utility.
 */
public class ArrayProcessor {

    private int[] a;
    private int n;

    public ArrayProcessor(int[] v) {
        n = v.length;
        a = new int[n];
        int x = 0;
        while (x < n) { a[x] = v[x]; x++; }
    }

    public void load(int[] v) {
        n = v.length;
        a = new int[n];
        int x = 0;
        while (x < n) { a[x] = v[x]; x++; }
    }

    // sort method 1
    public void sortA() {
        int p = 0;
        while (p < n - 1) {
            int q = 0;
            while (q < n - p - 1) {
                if (a[q] > a[q+1]) {
                    a[q] ^= a[q+1];
                    a[q+1] ^= a[q];
                    a[q] ^= a[q+1];
                }
                q++;
            }
            p++;
        }
    }

    // sort method 2
    public void sortB() {
        int i = 0;
        while (i < n - 1) {
            int m = i, j = i + 1;
            while (j < n) {
                if (a[j] < a[m]) m = j;
                j++;
            }
            int t = a[m]; a[m] = a[i]; a[i] = t;
            i++;
        }
    }

    // sort method 3
    public void sortC() {
        int i = 1;
        while (i < n) {
            int k = a[i], j = i - 1;
            while (j >= 0 && a[j] > k) {
                a[j+1] = a[j];
                j--;
            }
            a[j+1] = k;
            i++;
        }
    }

    public boolean checkOrder() {
        int i = 0;
        while (i < n - 1) {
            if (a[i] > a[i+1]) return false;
            i++;
        }
        return true;
    }

    public int minVal() {
        int m = a[0], i = 1;
        while (i < n) { if (a[i] < m) m = a[i]; i++; }
        return m;
    }

    public int maxVal() {
        int m = a[0], i = 1;
        while (i < n) { if (a[i] > m) m = a[i]; i++; }
        return m;
    }

    public long sumAll() {
        long s = 0;
        int i = 0;
        while (i < n) { s += a[i]; i++; }
        return s;
    }

    public double meanVal() {
        return (double) sumAll() / n;
    }

    public int aboveThreshold(int t) {
        int c = 0, i = 0;
        while (i < n) { if (a[i] > t) c++; i++; }
        return c;
    }

    public int belowThreshold(int t) {
        int c = 0, i = 0;
        while (i < n) { if (a[i] < t) c++; i++; }
        return c;
    }

    public void flip() {
        int l = 0, r = n - 1;
        while (l < r) {
            int t = a[l]; a[l] = a[r]; a[r] = t;
            l++; r--;
        }
    }

    public void display() {
        System.out.print("[");
        int i = 0;
        while (i < n) {
            System.out.print(a[i]);
            if (i < n - 1) System.out.print(", ");
            i++;
        }
        System.out.println("]");
    }

    public void summary() {
        System.out.println("=== Array Report ===");
        System.out.print("Data:     "); display();
        System.out.println("Size:     " + n);
        System.out.println("Min:      " + minVal());
        System.out.println("Max:      " + maxVal());
        System.out.println("Sum:      " + sumAll());
        System.out.printf("Average:  %.2f%n", meanVal());
        System.out.println("Sorted:   " + checkOrder());
    }

    public static void main(String[] args) {
        int[] d = {64, 34, 25, 12, 22, 11, 90, 45, 73, 8};

        ArrayProcessor ap = new ArrayProcessor(d.clone());
        System.out.println("Original:");
        ap.display();
        ap.summary();

        System.out.println("\nAfter bubble sort:");
        ap.load(d.clone());
        ap.sortA();
        ap.display();
        System.out.println("Is sorted: " + ap.checkOrder());

        System.out.println("\nAfter selection sort:");
        ap.load(d.clone());
        ap.sortB();
        ap.display();
        System.out.println("Is sorted: " + ap.checkOrder());

        System.out.println("\nAfter insertion sort:");
        ap.load(d.clone());
        ap.sortC();
        ap.display();
        System.out.println("Is sorted: " + ap.checkOrder());

        System.out.println("\nReversed:");
        ap.flip();
        ap.display();

        System.out.println("\nCount > 30: " + ap.aboveThreshold(30));
        System.out.println("Count < 30: " + ap.belowThreshold(30));
    }
}
