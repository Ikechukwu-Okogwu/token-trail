import java.util.ArrayList;
import java.util.List;

/**
 * Bank account management system.
 * Handles deposits, withdrawals, and transaction history.
 */
public class BankAccount {

    private String accountHolder;
    private String accountNumber;
    private double balance;
    private List<String> transactionHistory;
    private static final double OVERDRAFT_LIMIT = 100.0;

    public BankAccount(String accountHolder, String accountNumber, double initialBalance) {
        this.accountHolder = accountHolder;
        this.accountNumber = accountNumber;
        this.balance = initialBalance;
        this.transactionHistory = new ArrayList<>();
        transactionHistory.add("Account opened with balance: $" + String.format("%.2f", initialBalance));
    }

    /**
     * Deposit money into the account.
     */
    public boolean deposit(double amount) {
        if (amount <= 0) {
            System.out.println("Deposit amount must be positive.");
            return false;
        }
        balance += amount;
        transactionHistory.add("Deposit: +$" + String.format("%.2f", amount) +
                               " | Balance: $" + String.format("%.2f", balance));
        System.out.println("Deposited $" + String.format("%.2f", amount));
        return true;
    }

    /**
     * Withdraw money from the account.
     */
    public boolean withdraw(double amount) {
        if (amount <= 0) {
            System.out.println("Withdrawal amount must be positive.");
            return false;
        }
        if (balance - amount < -OVERDRAFT_LIMIT) {
            System.out.println("Insufficient funds. Overdraft limit exceeded.");
            return false;
        }
        balance -= amount;
        transactionHistory.add("Withdrawal: -$" + String.format("%.2f", amount) +
                               " | Balance: $" + String.format("%.2f", balance));
        System.out.println("Withdrew $" + String.format("%.2f", amount));
        return true;
    }

    /**
     * Transfer money to another account.
     */
    public boolean transfer(BankAccount target, double amount) {
        if (target == null) {
            System.out.println("Target account not found.");
            return false;
        }
        if (withdraw(amount)) {
            target.deposit(amount);
            transactionHistory.add("Transfer to " + target.getAccountNumber() +
                                   ": -$" + String.format("%.2f", amount));
            return true;
        }
        return false;
    }

    /**
     * Get the current balance.
     */
    public double getBalance() {
        return balance;
    }

    /**
     * Get the account number.
     */
    public String getAccountNumber() {
        return accountNumber;
    }

    /**
     * Get the account holder name.
     */
    public String getAccountHolder() {
        return accountHolder;
    }

    /**
     * Check if account is overdrawn.
     */
    public boolean isOverdrawn() {
        return balance < 0;
    }

    /**
     * Get number of transactions.
     */
    public int getTransactionCount() {
        return transactionHistory.size();
    }

    /**
     * Get the most recent transaction.
     */
    public String getLastTransaction() {
        if (transactionHistory.isEmpty()) return "No transactions";
        return transactionHistory.get(transactionHistory.size() - 1);
    }

    /**
     * Calculate interest for a given rate.
     */
    public double calculateInterest(double annualRate) {
        if (annualRate < 0) return 0.0;
        return balance * (annualRate / 100.0);
    }

    /**
     * Apply interest to the account.
     */
    public void applyInterest(double annualRate) {
        double interest = calculateInterest(annualRate);
        if (interest > 0) {
            deposit(interest);
            System.out.println("Interest applied: $" + String.format("%.2f", interest));
        }
    }

    /**
     * Print full account statement.
     */
    public void printStatement() {
        System.out.println("=== Account Statement ===");
        System.out.println("Holder:  " + accountHolder);
        System.out.println("Account: " + accountNumber);
        System.out.printf("Balance: $%.2f%n", balance);
        System.out.println("Status:  " + (isOverdrawn() ? "OVERDRAWN" : "Good Standing"));
        System.out.println("--- Transaction History ---");
        for (String transaction : transactionHistory) {
            System.out.println("  " + transaction);
        }
    }

    public static void main(String[] args) {
        BankAccount alice = new BankAccount("Alice Smith", "ACC-001", 1000.00);
        BankAccount bob = new BankAccount("Bob Jones", "ACC-002", 500.00);

        alice.deposit(250.00);
        alice.withdraw(100.00);
        alice.transfer(bob, 200.00);
        alice.applyInterest(3.5);
        alice.withdraw(2000.00); // should fail

        System.out.println();
        alice.printStatement();

        System.out.println();
        bob.printStatement();

        System.out.println("\nAlice transactions: " + alice.getTransactionCount());
        System.out.println("Bob transactions:   " + bob.getTransactionCount());
        System.out.println("Alice overdrawn:    " + alice.isOverdrawn());
    }
}
