import java.util.ArrayList;
import java.util.List;

/**
 * Savings account management system.
 * Handles credits, debits, and operation history.
 */
public class SavingsAccount {

    private String ownerName;
    private String accountId;
    private double currentBalance;
    private List<String> operationHistory;
    private static final double MAX_OVERDRAFT = 100.0;

    public SavingsAccount(String ownerName, String accountId, double startingBalance) {
        this.ownerName = ownerName;
        this.accountId = accountId;
        this.currentBalance = startingBalance;
        this.operationHistory = new ArrayList<>();
        operationHistory.add("Account opened with balance: $" + String.format("%.2f", startingBalance));
    }

    /**
     * Credit money into the account.
     */
    public boolean credit(double amount) {
        if (amount <= 0) {
            System.out.println("Credit amount must be positive.");
            return false;
        }
        currentBalance += amount;
        operationHistory.add("Credit: +$" + String.format("%.2f", amount) +
                             " | Balance: $" + String.format("%.2f", currentBalance));
        System.out.println("Credited $" + String.format("%.2f", amount));
        return true;
    }

    /**
     * Debit money from the account.
     */
    public boolean debit(double amount) {
        if (amount <= 0) {
            System.out.println("Debit amount must be positive.");
            return false;
        }
        if (currentBalance - amount < -MAX_OVERDRAFT) {
            System.out.println("Insufficient funds. Overdraft limit exceeded.");
            return false;
        }
        currentBalance -= amount;
        operationHistory.add("Debit: -$" + String.format("%.2f", amount) +
                             " | Balance: $" + String.format("%.2f", currentBalance));
        System.out.println("Debited $" + String.format("%.2f", amount));
        return true;
    }

    /**
     * Send money to another account.
     */
    public boolean send(SavingsAccount recipient, double amount) {
        if (recipient == null) {
            System.out.println("Recipient account not found.");
            return false;
        }
        if (debit(amount)) {
            recipient.credit(amount);
            operationHistory.add("Sent to " + recipient.getAccountId() +
                                 ": -$" + String.format("%.2f", amount));
            return true;
        }
        return false;
    }

    /**
     * Get the current balance.
     */
    public double getCurrentBalance() {
        return currentBalance;
    }

    /**
     * Get the account id.
     */
    public String getAccountId() {
        return accountId;
    }

    /**
     * Get the owner name.
     */
    public String getOwnerName() {
        return ownerName;
    }

    /**
     * Check if account is overdrawn.
     */
    public boolean isOverdrawn() {
        return currentBalance < 0;
    }

    /**
     * Get number of operations.
     */
    public int getOperationCount() {
        return operationHistory.size();
    }

    /**
     * Get the most recent operation.
     */
    public String getLastOperation() {
        if (operationHistory.isEmpty()) return "No operations";
        return operationHistory.get(operationHistory.size() - 1);
    }

    /**
     * Calculate interest for a given rate.
     */
    public double calculateInterest(double annualRate) {
        if (annualRate < 0) return 0.0;
        return currentBalance * (annualRate / 100.0);
    }

    /**
     * Apply interest to the account.
     */
    public void applyInterest(double annualRate) {
        double interest = calculateInterest(annualRate);
        if (interest > 0) {
            credit(interest);
            System.out.println("Interest applied: $" + String.format("%.2f", interest));
        }
    }

    /**
     * Print full account statement.
     */
    public void printStatement() {
        System.out.println("=== Account Statement ===");
        System.out.println("Owner:   " + ownerName);
        System.out.println("Account: " + accountId);
        System.out.printf("Balance: $%.2f%n", currentBalance);
        System.out.println("Status:  " + (isOverdrawn() ? "OVERDRAWN" : "Good Standing"));
        System.out.println("--- Operation History ---");
        for (String operation : operationHistory) {
            System.out.println("  " + operation);
        }
    }

    public static void main(String[] args) {
        SavingsAccount alice = new SavingsAccount("Alice Smith", "ACC-001", 1000.00);
        SavingsAccount bob = new SavingsAccount("Bob Jones", "ACC-002", 500.00);

        alice.credit(250.00);
        alice.debit(100.00);
        alice.send(bob, 200.00);
        alice.applyInterest(3.5);
        alice.debit(2000.00); // should fail

        System.out.println();
        alice.printStatement();

        System.out.println();
        bob.printStatement();

        System.out.println("\nAlice operations: " + alice.getOperationCount());
        System.out.println("Bob operations:   " + bob.getOperationCount());
        System.out.println("Alice overdrawn:  " + alice.isOverdrawn());
    }
}
