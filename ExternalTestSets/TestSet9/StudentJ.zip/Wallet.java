import java.util.ArrayList;
import java.util.List;

/**
 * Wallet management system.
 * Handles additions, deductions, and activity log.
 */
public class Wallet {

    private String holderName;
    private String walletCode;
    private double funds;
    private List<String> activityLog;
    private static final double MINIMUM_ALLOWED = -100.0;

    public Wallet(String holderName, String walletCode, double openingFunds) {
        this.holderName = holderName;
        this.walletCode = walletCode;
        this.funds = openingFunds;
        this.activityLog = new ArrayList<>();
        activityLog.add("Wallet opened with funds: $" + String.format("%.2f", openingFunds));
    }

    /**
     * Add funds to the wallet.
     */
    public boolean addFunds(double amount) {
        if (amount <= 0) {
            System.out.println("Amount to add must be positive.");
            return false;
        }
        funds += amount;
        activityLog.add("Added: +$" + String.format("%.2f", amount) +
                        " | Funds: $" + String.format("%.2f", funds));
        System.out.println("Added $" + String.format("%.2f", amount));
        return true;
    }

    /**
     * Deduct funds from the wallet.
     */
    public boolean deductFunds(double amount) {
        if (amount <= 0) {
            System.out.println("Amount to deduct must be positive.");
            return false;
        }
        if (funds - amount < MINIMUM_ALLOWED) {
            System.out.println("Insufficient funds. Overdraft limit exceeded.");
            return false;
        }
        funds -= amount;
        activityLog.add("Deducted: -$" + String.format("%.2f", amount) +
                        " | Funds: $" + String.format("%.2f", funds));
        System.out.println("Deducted $" + String.format("%.2f", amount));
        return true;
    }

    /**
     * Move funds to another wallet.
     */
    public boolean moveFunds(Wallet destination, double amount) {
        if (destination == null) {
            System.out.println("Destination wallet not found.");
            return false;
        }
        if (deductFunds(amount)) {
            destination.addFunds(amount);
            activityLog.add("Moved to " + destination.getWalletCode() +
                            ": -$" + String.format("%.2f", amount));
            return true;
        }
        return false;
    }

    /**
     * Get the current funds.
     */
    public double getFunds() {
        return funds;
    }

    /**
     * Get the wallet code.
     */
    public String getWalletCode() {
        return walletCode;
    }

    /**
     * Get the holder name.
     */
    public String getHolderName() {
        return holderName;
    }

    /**
     * Check if wallet is overdrawn.
     */
    public boolean isOverdrawn() {
        return funds < 0;
    }

    /**
     * Get number of activities.
     */
    public int getActivityCount() {
        return activityLog.size();
    }

    /**
     * Get the most recent activity.
     */
    public String getLastActivity() {
        if (activityLog.isEmpty()) return "No activity";
        return activityLog.get(activityLog.size() - 1);
    }

    /**
     * Calculate interest for a given rate.
     */
    public double calculateInterest(double annualRate) {
        if (annualRate < 0) return 0.0;
        return funds * (annualRate / 100.0);
    }

    /**
     * Apply interest to the wallet.
     */
    public void applyInterest(double annualRate) {
        double interest = calculateInterest(annualRate);
        if (interest > 0) {
            addFunds(interest);
            System.out.println("Interest applied: $" + String.format("%.2f", interest));
        }
    }

    /**
     * Print full wallet statement.
     */
    public void printStatement() {
        System.out.println("=== Wallet Statement ===");
        System.out.println("Holder:  " + holderName);
        System.out.println("Wallet:  " + walletCode);
        System.out.printf("Funds:   $%.2f%n", funds);
        System.out.println("Status:  " + (isOverdrawn() ? "OVERDRAWN" : "Good Standing"));
        System.out.println("--- Activity Log ---");
        for (String activity : activityLog) {
            System.out.println("  " + activity);
        }
    }

    public static void main(String[] args) {
        Wallet alice = new Wallet("Alice Smith", "ACC-001", 1000.00);
        Wallet bob = new Wallet("Bob Jones", "ACC-002", 500.00);

        alice.addFunds(250.00);
        alice.deductFunds(100.00);
        alice.moveFunds(bob, 200.00);
        alice.applyInterest(3.5);
        alice.deductFunds(2000.00); // should fail

        System.out.println();
        alice.printStatement();

        System.out.println();
        bob.printStatement();

        System.out.println("\nAlice activities: " + alice.getActivityCount());
        System.out.println("Bob activities:   " + bob.getActivityCount());
        System.out.println("Alice overdrawn:  " + alice.isOverdrawn());
    }
}
