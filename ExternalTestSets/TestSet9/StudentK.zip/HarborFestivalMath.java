import java.util.ArrayList;
import java.util.List;

public class HarborFestivalMath {
    public int[] buildPressure(int[] crowdFlow, int[] staffPower) {
        int[] pressure = new int[crowdFlow.length];
        for (int i = 0; i < crowdFlow.length; i++) {
            pressure[i] = Math.max(1, crowdFlow[i] * 2 - staffPower[i] * 3 + (i % 3));
        }
        smooth(pressure);
        return pressure;
    }

    public int[] allocateLoads(int[] pressure, int zoneCount) {
        int[] load = new int[zoneCount];
        for (int i = 0; i < pressure.length; i++) {
            load[i % zoneCount] += pressure[i] / 2 + 1;
        }
        ensurePositive(load);
        return load;
    }

    public List<String> describeLoads(String[] zones, int[] load) {
        List<String> cards = new ArrayList<>();
        for (int i = 0; i < zones.length; i++) {
            cards.add(zones[i] + " receives " + load[i] + " volunteer slots");
        }
        return cards;
    }

    public int balanceGap(int[] load) {
        int min = load[0];
        int max = load[0];
        for (int value : load) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int findPeakSlot(int[] pressure) {
        int peak = 0;
        for (int i = 1; i < pressure.length; i++) {
            if (pressure[i] > pressure[peak]) peak = i;
        }
        return peak;
    }

    public int reserveCount(int[] pressure) {
        int reserve = 0;
        for (int value : pressure) {
            if (value > 25) reserve += 2;
            else if (value > 15) reserve += 1;
        }
        return reserve;
    }

    public int transitionScore(int[] load) {
        int motion = 0;
        for (int i = 1; i < load.length; i++) {
            motion += Math.abs(load[i] - load[i - 1]);
        }
        return Math.max(1, 32 - motion);
    }

    public String pressureLabel(int[] pressure) {
        int total = 0;
        for (int value : pressure) total += value;
        if (total > 170) return "dense";
        if (total > 130) return "steady";
        return "light";
    }

    private void smooth(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

    private void ensurePositive(int[] values) {
        int min = values[0];
        for (int value : values) {
            if (value < min) min = value;
        }
        if (min <= 0) {
            for (int i = 0; i < values.length; i++) {
                values[i] += Math.abs(min) + 1;
            }
        }
    }

public int edgeSum(int[] load) {
    return load[0] + load[load.length - 1];
}

public int midpointLoad(int[] load) {
    return load[load.length / 2];
}

public int descendingSteps(int[] pressure) {
    int count = 0;
    for (int i = 1; i < pressure.length; i++) {
        if (pressure[i] < pressure[i - 1]) count++;
    }
    return count;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) {
                return false;
            }
        }
        return true;
    }
        return even - odd;
    }

}
