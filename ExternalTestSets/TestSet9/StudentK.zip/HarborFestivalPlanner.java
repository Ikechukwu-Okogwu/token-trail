import java.util.Arrays;
import java.util.List;

public class HarborFestivalPlanner {
    public static void main(String[] args) {
        String[] zones = {"Tickets", "Crafts", "Soup", "Games", "Stage", "Info"};
        int[] crowdFlow = {14, 20, 23, 19, 24, 27, 32, 29, 25, 18};
        int[] staffPower = {4, 5, 6, 5, 7, 6, 8, 7, 6, 5};

        HarborFestivalMath math = new HarborFestivalMath();
        int[] pressure = math.buildPressure(crowdFlow, staffPower);
        int[] zoneLoad = math.allocateLoads(pressure, zones.length);
        List<String> cards = math.describeLoads(zones, zoneLoad);

        System.out.println("=== Harbor Festival Planner ===");
        System.out.println("Pressure: " + Arrays.toString(pressure));
        System.out.println("Zone Load: " + Arrays.toString(zoneLoad));
        for (String card : cards) {
            System.out.println(card);
        }

        System.out.println("Balance Gap: " + math.balanceGap(zoneLoad));
        System.out.println("Peak Slot: " + math.findPeakSlot(pressure));
        System.out.println("Reserve Count: " + math.reserveCount(pressure));
        System.out.println("Transition Score: " + math.transitionScore(zoneLoad));
        System.out.println("Pressure Label: " + math.pressureLabel(pressure));
        System.out.println("Total Score: " + math.sumValues(zoneLoad));
        System.out.println("Middle Average: " + math.middleAverage(zoneLoad));
        System.out.println("Stable Wave: " + math.isWaveStable(zoneLoad));

    }
}
