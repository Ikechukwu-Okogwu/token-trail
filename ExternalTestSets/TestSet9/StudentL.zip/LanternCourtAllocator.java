import java.util.Arrays;
import java.util.List;

public class LanternCourtAllocator {
    public static void main(String[] args) {
        String[] courts = {"Tickets", "Crafts", "Soup", "Games", "Stage", "Info"};
        int[] visitorWave = {14, 20, 23, 19, 24, 27, 32, 29, 25, 18};
        int[] helperForce = {4, 5, 6, 5, 7, 6, 8, 7, 6, 5};

        LanternCourtMath helper = new LanternCourtMath();
        int[] tension = helper.buildTension(visitorWave, helperForce);
        int[] courtLoad = helper.distributeLoad(tension, courts.length);
        List<String> rows = helper.renderPlan(courts, courtLoad);

        System.out.println("=== Lantern Court Allocator ===");
        System.out.println("Tension: " + Arrays.toString(tension));
        System.out.println("Court Load: " + Arrays.toString(courtLoad));
        for (String row : rows) {
            System.out.println(row);
        }

        System.out.println("Spread Gap: " + helper.spreadGap(courtLoad));
        System.out.println("Peak Slot: " + helper.peakIndex(tension));
        System.out.println("Reserve Count: " + helper.reserveUnits(tension));
        System.out.println("Transition Score: " + helper.flowScore(courtLoad));
        System.out.println("Pressure Label: " + helper.activityBand(tension));
        System.out.println("Total Score: " + helper.sumValues(courtLoad));
        System.out.println("Middle Average: " + helper.middleAverage(courtLoad));
        System.out.println("Stable Wave: " + helper.isWaveStable(courtLoad));

    }
}
