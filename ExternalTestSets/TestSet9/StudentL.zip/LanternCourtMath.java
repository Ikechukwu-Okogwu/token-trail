import java.util.ArrayList;
import java.util.List;

public class LanternCourtMath {
    public int[] buildTension(int[] visitorWave, int[] helperForce) {
        int[] tension = new int[visitorWave.length];
        for (int i = 0; i < visitorWave.length; i++) {
            tension[i] = Math.max(1, visitorWave[i] * 2 - helperForce[i] * 3 + (i % 3));
        }
        blur(tension);
        return tension;
    }

    public int[] distributeLoad(int[] tension, int courtCount) {
        int[] load = new int[courtCount];
        for (int i = 0; i < tension.length; i++) {
            load[i % courtCount] += tension[i] / 2 + 1;
        }
        keepPositive(load);
        return load;
    }

    public List<String> renderPlan(String[] courts, int[] load) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < courts.length; i++) {
            rows.add(courts[i] + " receives " + load[i] + " helper slots");
        }
        return rows;
    }

    public int spreadGap(int[] load) {
        int min = load[0];
        int max = load[0];
        for (int value : load) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int peakIndex(int[] tension) {
        int peak = 0;
        for (int i = 1; i < tension.length; i++) {
            if (tension[i] > tension[peak]) peak = i;
        }
        return peak;
    }

    public int reserveUnits(int[] tension) {
        int reserve = 0;
        for (int value : tension) {
            if (value > 25) reserve += 2;
            else if (value > 15) reserve += 1;
        }
        return reserve;
    }

    public int flowScore(int[] load) {
        int change = 0;
        for (int i = 1; i < load.length; i++) {
            change += Math.abs(load[i] - load[i - 1]);
        }
        return Math.max(1, 32 - change);
    }

    public String activityBand(int[] tension) {
        int total = 0;
        for (int value : tension) total += value;
        if (total > 170) return "dense";
        if (total > 130) return "steady";
        return "light";
    }

    private void blur(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

    private void keepPositive(int[] values) {
        int min = values[0];
        for (int value : values) {
            if (value < min) min = value;
        }
        if (min <= 0) {
            for (int i = 0; i < values.length; i++) {
                values[i] += Math.abs(min) + 1;
            }
        }
    }

public int edgeSum(int[] load) {
    return load[0] + load[load.length - 1];
}

public int midpointLoad(int[] load) {
    return load[load.length / 2];
}

public int descendingSteps(int[] tension) {
    int count = 0;
    for (int i = 1; i < tension.length; i++) {
        if (tension[i] < tension[i - 1]) count++;
    }
    return count;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) {
                return false;
            }
        }
        return true;
    }
        return even - odd;
    }

}
