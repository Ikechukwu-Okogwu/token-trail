import java.util.Arrays;
import java.util.List;

public class PierMarketBalancer {
    public static void main(String[] args) {
        String[] stalls = {"Tickets", "Crafts", "Soup", "Games", "Stage", "Info"};
        int[] footPulse = {14, 20, 23, 19, 24, 27, 32, 29, 25, 18};
        int[] crewLift = {4, 5, 6, 5, 7, 6, 8, 7, 6, 5};

        PierMarketMath math = new PierMarketMath();
        int[] intensity = math.computeIntensity(footPulse, crewLift);
        int[] stallLoad = math.spreadWork(intensity, stalls.length);
        List<String> notes = math.makeCards(stalls, stallLoad);

        System.out.println("=== Pier Market Balancer ===");
        System.out.println("Intensity: " + Arrays.toString(intensity));
        System.out.println("Stall Load: " + Arrays.toString(stallLoad));
        for (String note : notes) {
            System.out.println(note);
        }

        System.out.println("Spread Gap: " + math.rangeGap(stallLoad));
        System.out.println("Peak Slot: " + math.locatePeak(intensity));
        System.out.println("Reserve Count: " + math.extraCrew(intensity));
        System.out.println("Transition Score: " + math.stabilityScore(stallLoad));
        System.out.println("Pressure Label: " + math.crowdBand(intensity));
        System.out.println("Total Score: " + math.sumValues(stallLoad));
        System.out.println("Middle Average: " + math.middleAverage(stallLoad));
        System.out.println("Stable Wave: " + math.isWaveStable(stallLoad));

    }
}
