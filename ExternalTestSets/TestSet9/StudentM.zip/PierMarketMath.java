import java.util.ArrayList;
import java.util.List;

public class PierMarketMath {
    public int[] computeIntensity(int[] footPulse, int[] crewLift) {
        int[] intensity = new int[footPulse.length];
        for (int i = 0; i < footPulse.length; i++) {
            intensity[i] = Math.max(1, footPulse[i] * 2 - crewLift[i] * 3 + (i % 3));
        }
        smooth(intensity);
        return intensity;
    }

    public int[] spreadWork(int[] intensity, int stallCount) {
        int[] work = new int[stallCount];
        for (int i = 0; i < intensity.length; i++) {
            work[i % stallCount] += intensity[i] / 2 + 1;
        }
        lift(work);
        return work;
    }

    public List<String> makeCards(String[] stalls, int[] work) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < stalls.length; i++) {
            rows.add(stalls[i] + " receives " + work[i] + " crew slots");
        }
        return rows;
    }

    public int rangeGap(int[] work) {
        int min = work[0];
        int max = work[0];
        for (int value : work) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int locatePeak(int[] intensity) {
        int peak = 0;
        for (int i = 1; i < intensity.length; i++) {
            if (intensity[i] > intensity[peak]) peak = i;
        }
        return peak;
    }

    public int extraCrew(int[] intensity) {
        int reserve = 0;
        for (int value : intensity) {
            if (value > 25) reserve += 2;
            else if (value > 15) reserve += 1;
        }
        return reserve;
    }

    public int stabilityScore(int[] work) {
        int motion = 0;
        for (int i = 1; i < work.length; i++) {
            motion += Math.abs(work[i] - work[i - 1]);
        }
        return Math.max(1, 32 - motion);
    }

    public String crowdBand(int[] intensity) {
        int total = 0;
        for (int value : intensity) total += value;
        if (total > 170) return "dense";
        if (total > 130) return "steady";
        return "light";
    }

    private void smooth(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

    private void lift(int[] values) {
        int min = values[0];
        for (int value : values) {
            if (value < min) min = value;
        }
        if (min <= 0) {
            for (int i = 0; i < values.length; i++) {
                values[i] += Math.abs(min) + 1;
            }
        }
    }

public int edgeSum(int[] work) {
    return work[0] + work[work.length - 1];
}

public int midpointLoad(int[] work) {
    return work[work.length / 2];
}

public int descendingSteps(int[] intensity) {
    int count = 0;
    for (int i = 1; i < intensity.length; i++) {
        if (intensity[i] < intensity[i - 1]) count++;
    }
    return count;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) {
                return false;
            }
        }
        return true;
    }
        return even - odd;
    }

}
