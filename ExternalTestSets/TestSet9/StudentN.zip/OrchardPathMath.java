import java.util.ArrayList;
import java.util.List;

public class OrchardPathMath {
    public int[] mixYieldAndTravel(int[] yield, int[] travel) {
        int[] score = new int[yield.length];
        for (int i = 0; i < yield.length; i++) {
            score[i] = yield[i] * 3 - travel[i] * 2 + (i % 4);
        }
        soften(score);
        return score;
    }

    public int[] rankStops(int[] score) {
        int[] route = new int[score.length];
        boolean[] used = new boolean[score.length];
        for (int slot = 0; slot < route.length; slot++) {
            int best = -1;
            for (int i = 0; i < score.length; i++) {
                if (!used[i] && (best == -1 || score[i] > score[best])) best = i;
            }
            route[slot] = best;
            used[best] = true;
        }
        return route;
    }

    public List<String> describeRoute(int[] route, int[] score) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < route.length; i++) {
            rows.add("Inspect tree " + route[i] + " with score " + score[route[i]]);
        }
        return rows;
    }

    public int calmStretch(int[] score) {
        int longest = 1;
        int current = 1;
        for (int i = 1; i < score.length; i++) {
            if (score[i] <= score[i - 1] + 2) current++;
            else current = 1;
            if (current > longest) longest = current;
        }
        return longest;
    }

    public int routeChecksum(int[] route) {
        int sum = 0;
        for (int i = 0; i < route.length; i++) {
            sum += route[i] * (i + 3);
        }
        return sum;
    }

    public int bestIndex(int[] score) {
        int best = 0;
        for (int i = 1; i < score.length; i++) {
            if (score[i] > score[best]) best = i;
        }
        return best;
    }

    public String loadBand(int[] score) {
        int total = 0;
        for (int value : score) total += value;
        if (total > 250) return "heavy";
        if (total > 200) return "medium";
        return "light";
    }

    public int spreadScore(int[] score) {
        int min = score[0];
        int max = score[0];
        for (int value : score) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int edgeSum(int[] score) {
        return score[0] + score[score.length - 1];
    }

    public int medianLike(int[] route) {
        return route[route.length / 2];
    }

    public int downwardSteps(int[] score) {
        int count = 0;
        for (int i = 1; i < score.length; i++) {
            if (score[i] < score[i - 1]) count++;
        }
        return count;
    }

    private void soften(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

public int turningScore(int[] route) {
    int sum = 0;
    for (int i = 1; i < route.length; i++) {
        sum += Math.abs(route[i] - route[i - 1]);
    }
    return sum;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) return false;
        }
        return true;
    }
        return even - odd;
    }

}
