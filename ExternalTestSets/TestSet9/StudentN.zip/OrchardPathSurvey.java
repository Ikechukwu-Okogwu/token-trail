import java.util.Arrays;
import java.util.List;

public class OrchardPathSurvey {
    public static void main(String[] args) {
        int[] fruitYield = {12, 9, 16, 8, 11, 14, 10, 18, 7, 13};
        int[] walkingMinutes = {3, 4, 2, 5, 4, 3, 6, 2, 5, 4};

        OrchardPathMath math = new OrchardPathMath();
        int[] score = math.mixYieldAndTravel(fruitYield, walkingMinutes);
        int[] route = math.rankStops(score);
        List<String> notes = math.describeRoute(route, score);

        System.out.println("=== Orchard Path Survey ===");
        System.out.println("Score: " + Arrays.toString(score));
        System.out.println("Route: " + Arrays.toString(route));
        for (String note : notes) {
            System.out.println(note);
        }

        System.out.println("Calm Stretch: " + math.calmStretch(score));
        System.out.println("Checksum: " + math.routeChecksum(route));
        System.out.println("Peak Tree: " + math.bestIndex(score));
        System.out.println("Load Band: " + math.loadBand(score));
        System.out.println("Spread Score: " + math.spreadScore(score));
        System.out.println("Total Score: " + math.sumValues(route));
        System.out.println("Middle Average: " + math.middleAverage(route));
        System.out.println("Stable Wave: " + math.isWaveStable(route));

    }
}
