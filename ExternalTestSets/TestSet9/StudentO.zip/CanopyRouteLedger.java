import java.util.Arrays;
import java.util.List;

public class CanopyRouteLedger {
    public static void main(String[] args) {
        int[] harvestYield = {12, 9, 16, 8, 11, 14, 10, 18, 7, 13};
        int[] laneMinutes = {3, 4, 2, 5, 4, 3, 6, 2, 5, 4};

        CanopyRouteMath helper = new CanopyRouteMath();
        int[] ranking = helper.combineYieldAndWalk(harvestYield, laneMinutes);
        int[] order = helper.rankTrees(ranking);
        List<String> rows = helper.describe(order, ranking);

        System.out.println("=== Canopy Route Ledger ===");
        System.out.println("Ranking: " + Arrays.toString(ranking));
        System.out.println("Order: " + Arrays.toString(order));
        for (String row : rows) {
            System.out.println(row);
        }

        System.out.println("Quiet Stretch: " + helper.quietStretch(ranking));
        System.out.println("Checksum: " + helper.orderChecksum(order));
        System.out.println("Best Tree: " + helper.topIndex(ranking));
        System.out.println("Load Band: " + helper.band(ranking));
        System.out.println("Spread Score: " + helper.spreadGap(ranking));
        System.out.println("Total Score: " + helper.sumValues(order));
        System.out.println("Middle Average: " + helper.middleAverage(order));
        System.out.println("Stable Wave: " + helper.isWaveStable(order));

    }
}
