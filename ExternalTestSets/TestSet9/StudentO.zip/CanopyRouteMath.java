import java.util.ArrayList;
import java.util.List;

public class CanopyRouteMath {
    public int[] combineYieldAndWalk(int[] harvestYield, int[] laneMinutes) {
        int[] ranking = new int[harvestYield.length];
        for (int i = 0; i < harvestYield.length; i++) {
            ranking[i] = harvestYield[i] * 3 - laneMinutes[i] * 2 + (i % 4);
        }
        smooth(ranking);
        return ranking;
    }

    public int[] rankTrees(int[] ranking) {
        int[] order = new int[ranking.length];
        boolean[] used = new boolean[ranking.length];
        for (int slot = 0; slot < order.length; slot++) {
            int best = -1;
            for (int i = 0; i < ranking.length; i++) {
                if (!used[i] && (best == -1 || ranking[i] > ranking[best])) best = i;
            }
            order[slot] = best;
            used[best] = true;
        }
        return order;
    }

    public List<String> describe(int[] order, int[] ranking) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < order.length; i++) {
            rows.add("Inspect tree " + order[i] + " with score " + ranking[order[i]]);
        }
        return rows;
    }

    public int quietStretch(int[] ranking) {
        int longest = 1;
        int current = 1;
        for (int i = 1; i < ranking.length; i++) {
            if (ranking[i] <= ranking[i - 1] + 2) current++;
            else current = 1;
            if (current > longest) longest = current;
        }
        return longest;
    }

    public int orderChecksum(int[] order) {
        int sum = 0;
        for (int i = 0; i < order.length; i++) {
            sum += order[i] * (i + 3);
        }
        return sum;
    }

    public int topIndex(int[] ranking) {
        int best = 0;
        for (int i = 1; i < ranking.length; i++) {
            if (ranking[i] > ranking[best]) best = i;
        }
        return best;
    }

    public String band(int[] ranking) {
        int total = 0;
        for (int value : ranking) total += value;
        if (total > 250) return "heavy";
        if (total > 200) return "medium";
        return "light";
    }

    public int spreadGap(int[] ranking) {
        int min = ranking[0];
        int max = ranking[0];
        for (int value : ranking) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int edgeSum(int[] ranking) {
        return ranking[0] + ranking[ranking.length - 1];
    }

    public int midpointStop(int[] order) {
        return order[order.length / 2];
    }

    public int downwardSteps(int[] ranking) {
        int count = 0;
        for (int i = 1; i < ranking.length; i++) {
            if (ranking[i] < ranking[i - 1]) count++;
        }
        return count;
    }

    private void smooth(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

public int turningScore(int[] order) {
    int sum = 0;
    for (int i = 1; i < order.length; i++) {
        sum += Math.abs(order[i] - order[i - 1]);
    }
    return sum;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) return false;
        }
        return true;
    }
        return even - odd;
    }

}
