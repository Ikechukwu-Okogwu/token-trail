import java.util.ArrayList;
import java.util.List;

public class ArchiveShelfMath {
    public int[] buildRelevance(int[] requestCount, int[] ageDays) {
        int[] relevance = new int[requestCount.length];
        for (int i = 0; i < requestCount.length; i++) {
            relevance[i] = requestCount[i] * 3 - ageDays[i] * 2 + (i % 3);
        }
        merge(relevance);
        return relevance;
    }

    public int[] rankShelves(int[] relevance) {
        int[] order = new int[relevance.length];
        boolean[] used = new boolean[relevance.length];
        for (int slot = 0; slot < order.length; slot++) {
            int best = -1;
            for (int i = 0; i < relevance.length; i++) {
                if (!used[i] && (best == -1 || relevance[i] > relevance[best])) best = i;
            }
            order[slot] = best;
            used[best] = true;
        }
        return order;
    }

    public List<String> describe(int[] order, int[] relevance) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < order.length; i++) {
            rows.add("Place document " + order[i] + " near front with score " + relevance[order[i]]);
        }
        return rows;
    }

    public int freshness(int[] relevance) {
        int total = 0;
        for (int value : relevance) total += value;
        return total / relevance.length;
    }

    public String retentionBand(int[] relevance) {
        int min = relevance[0];
        int max = relevance[0];
        for (int value : relevance) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        if (max - min > 25) return "volatile";
        if (max - min > 15) return "mixed";
        return "stable";
    }

    public int checksum(int[] order) {
        int sum = 0;
        for (int i = 0; i < order.length; i++) {
            sum += order[i] * (i + 4);
        }
        return sum;
    }

    public int varianceGap(int[] relevance) {
        int min = relevance[0];
        int max = relevance[0];
        for (int value : relevance) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int peakIndex(int[] relevance) {
        int peak = 0;
        for (int i = 1; i < relevance.length; i++) {
            if (relevance[i] > relevance[peak]) peak = i;
        }
        return peak;
    }

    public int edgeSum(int[] relevance) {
        return relevance[0] + relevance[relevance.length - 1];
    }

    public int midShelf(int[] order) {
        return order[order.length / 2];
    }

    public int downwardSteps(int[] relevance) {
        int count = 0;
        for (int i = 1; i < relevance.length; i++) {
            if (relevance[i] < relevance[i - 1]) count++;
        }
        return count;
    }

    private void merge(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

public int turningScore(int[] order) {
    int sum = 0;
    for (int i = 1; i < order.length; i++) {
        sum += Math.abs(order[i] - order[i - 1]);
    }
    return sum;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) {
                return false;
            }
        }
        return true;
    }
        return even - odd;
    }

}
