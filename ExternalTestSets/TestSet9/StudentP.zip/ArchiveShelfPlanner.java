import java.util.Arrays;
import java.util.List;

public class ArchiveShelfPlanner {
    public static void main(String[] args) {
        int[] requestCount = {22, 17, 29, 11, 25, 21, 14, 27, 19, 23};
        int[] ageDays = {4, 9, 7, 13, 6, 8, 15, 10, 12, 5};

        ArchiveShelfMath math = new ArchiveShelfMath();
        int[] relevance = math.buildRelevance(requestCount, ageDays);
        int[] order = math.rankShelves(relevance);
        List<String> labels = math.describe(order, relevance);

        System.out.println("=== Archive Shelf Planner ===");
        System.out.println("Relevance: " + Arrays.toString(relevance));
        System.out.println("Order: " + Arrays.toString(order));
        for (String label : labels) {
            System.out.println(label);
        }

        System.out.println("Freshness Score: " + math.freshness(relevance));
        System.out.println("Retention Band: " + math.retentionBand(relevance));
        System.out.println("Checksum: " + math.checksum(order));
        System.out.println("Variance Gap: " + math.varianceGap(relevance));
        System.out.println("Peak Document: " + math.peakIndex(relevance));
        System.out.println("Total Score: " + math.sumValues(order));
        System.out.println("Middle Average: " + math.middleAverage(order));
        System.out.println("Stable Wave: " + math.isWaveStable(order));

    }
}
