import java.util.ArrayList;
import java.util.List;

public class RiverBeaconMath {
    public int[] buildAlerts(int[] depthReadings, int[] driftReadings) {
        int[] alert = new int[depthReadings.length];
        for (int i = 0; i < depthReadings.length; i++) {
            alert[i] = depthReadings[i] * 4 + driftReadings[i] * 3 - (i % 2);
        }
        smooth(alert);
        return alert;
    }

    public int[] rankMarkers(int[] alert) {
        int[] order = new int[alert.length];
        boolean[] used = new boolean[alert.length];
        for (int slot = 0; slot < order.length; slot++) {
            int best = -1;
            for (int i = 0; i < alert.length; i++) {
                if (!used[i] && (best == -1 || alert[i] > alert[best])) best = i;
            }
            order[slot] = best;
            used[best] = true;
        }
        return order;
    }

    public List<String> describe(int[] order, int[] alert) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < order.length; i++) {
            rows.add("Check marker " + order[i] + " with alert " + alert[order[i]]);
        }
        return rows;
    }

    public int trendScore(int[] alert) {
        int trend = 0;
        for (int i = 1; i < alert.length; i++) {
            trend += alert[i] - alert[i - 1];
        }
        return trend;
    }

    public String riskBand(int[] alert) {
        int peak = alert[0];
        for (int value : alert) {
            if (value > peak) peak = value;
        }
        if (peak > 70) return "critical";
        if (peak > 55) return "elevated";
        return "watch";
    }

    public int checksum(int[] order) {
        int sum = 0;
        for (int i = 0; i < order.length; i++) {
            sum += order[i] * (i + 5);
        }
        return sum;
    }

    public int spreadGap(int[] alert) {
        int min = alert[0];
        int max = alert[0];
        for (int value : alert) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int peakMarker(int[] alert) {
        int peak = 0;
        for (int i = 1; i < alert.length; i++) {
            if (alert[i] > alert[peak]) peak = i;
        }
        return peak;
    }

    public int edgeSum(int[] alert) {
        return alert[0] + alert[alert.length - 1];
    }

    public int midpointStop(int[] order) {
        return order[order.length / 2];
    }

    public int downwardSteps(int[] alert) {
        int count = 0;
        for (int i = 1; i < alert.length; i++) {
            if (alert[i] < alert[i - 1]) count++;
        }
        return count;
    }

    private void smooth(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

public int turningScore(int[] order) {
    int sum = 0;
    for (int i = 1; i < order.length; i++) {
        sum += Math.abs(order[i] - order[i - 1]);
    }
    return sum;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) {
                return false;
            }
        }
        return true;
    }
        return even - odd;
    }

}
