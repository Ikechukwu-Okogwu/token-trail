import java.util.Arrays;
import java.util.List;

public class RiverBeaconSurvey {
    public static void main(String[] args) {
        int[] depthReadings = {8, 9, 11, 10, 13, 12, 14, 15, 13, 12};
        int[] driftReadings = {2, 4, 3, 5, 4, 5, 6, 4, 3, 2};

        RiverBeaconMath math = new RiverBeaconMath();
        int[] alert = math.buildAlerts(depthReadings, driftReadings);
        int[] order = math.rankMarkers(alert);
        List<String> notes = math.describe(order, alert);

        System.out.println("=== River Beacon Survey ===");
        System.out.println("Alert: " + Arrays.toString(alert));
        System.out.println("Order: " + Arrays.toString(order));
        for (String note : notes) {
            System.out.println(note);
        }

        System.out.println("Trend Score: " + math.trendScore(alert));
        System.out.println("Risk Band: " + math.riskBand(alert));
        System.out.println("Checksum: " + math.checksum(order));
        System.out.println("Spread Gap: " + math.spreadGap(alert));
        System.out.println("Peak Marker: " + math.peakMarker(alert));
        System.out.println("Total Score: " + math.sumValues(order));
        System.out.println("Middle Average: " + math.middleAverage(order));
        System.out.println("Stable Wave: " + math.isWaveStable(order));

    }
}
