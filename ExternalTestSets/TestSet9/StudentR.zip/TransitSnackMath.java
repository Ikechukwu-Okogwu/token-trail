import java.util.ArrayList;
import java.util.List;

public class TransitSnackMath {
    public int[] buildHealth(int[] kioskSales, int[] restockDelay) {
        int[] health = new int[kioskSales.length];
        for (int i = 0; i < kioskSales.length; i++) {
            health[i] = kioskSales[i] * 2 - restockDelay[i] * 3 + (i % 4);
        }
        evenOut(health);
        return health;
    }

    public int[] rankDispatch(int[] health) {
        int[] order = new int[health.length];
        boolean[] used = new boolean[health.length];
        for (int slot = 0; slot < order.length; slot++) {
            int best = -1;
            for (int i = 0; i < health.length; i++) {
                if (!used[i] && (best == -1 || health[i] > health[best])) best = i;
            }
            order[slot] = best;
            used[best] = true;
        }
        return order;
    }

    public List<String> describe(int[] order, int[] health) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < order.length; i++) {
            rows.add("Restock kiosk " + order[i] + " with health " + health[order[i]]);
        }
        return rows;
    }

    public int rushScore(int[] health) {
        int total = 0;
        for (int value : health) total += value;
        return total;
    }

    public int coverageGap(int[] health) {
        int min = health[0];
        int max = health[0];
        for (int value : health) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int checksum(int[] order) {
        int sum = 0;
        for (int i = 0; i < order.length; i++) {
            sum += order[i] * (i + 7);
        }
        return sum;
    }

    public int peakKiosk(int[] health) {
        int peak = 0;
        for (int i = 1; i < health.length; i++) {
            if (health[i] > health[peak]) peak = i;
        }
        return peak;
    }

    public String signalBand(int[] health) {
        int average = rushScore(health) / health.length;
        if (average > 50) return "intense";
        if (average > 40) return "active";
        return "steady";
    }

    public int edgeSum(int[] health) {
        return health[0] + health[health.length - 1];
    }

    public int midpointStop(int[] order) {
        return order[order.length / 2];
    }

    public int downwardSteps(int[] health) {
        int count = 0;
        for (int i = 1; i < health.length; i++) {
            if (health[i] < health[i - 1]) count++;
        }
        return count;
    }

    private void evenOut(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

public int turningScore(int[] order) {
    int sum = 0;
    for (int i = 1; i < order.length; i++) {
        sum += Math.abs(order[i] - order[i - 1]);
    }
    return sum;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) { total += values[i]; }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) return false;
        }
        return true;
    }
        return even - odd;
    }


public int crestValue(int[] values) {
    int best = values[0];
    for (int value : values) {
        if (value > best) best = value;
    }
    return best;
}

}
