import java.util.Arrays;
import java.util.List;

public class TransitSnackMonitor {
    public static void main(String[] args) {
        int[] kioskSales = {31, 24, 29, 18, 35, 27, 22, 26, 30, 21};
        int[] restockDelay = {2, 3, 4, 5, 2, 4, 5, 3, 2, 4};

        TransitSnackMath math = new TransitSnackMath();
        int[] health = math.buildHealth(kioskSales, restockDelay);
        int[] order = math.rankDispatch(health);
        List<String> notes = math.describe(order, health);

        System.out.println("=== Transit Snack Monitor ===");
        System.out.println("Health: " + Arrays.toString(health));
        System.out.println("Order: " + Arrays.toString(order));
        for (String note : notes) {
            System.out.println(note);
        }

        System.out.println("Rush Score: " + math.rushScore(health));
        System.out.println("Coverage Gap: " + math.coverageGap(health));
        System.out.println("Checksum: " + math.checksum(order));
        System.out.println("Peak Kiosk: " + math.peakKiosk(health));
        System.out.println("Signal Band: " + math.signalBand(health));
        System.out.println("Total Score: " + math.sumValues(order));
        System.out.println("Middle Average: " + math.middleAverage(order));
        System.out.println("Stable Wave: " + math.isWaveStable(order));

    }
}
