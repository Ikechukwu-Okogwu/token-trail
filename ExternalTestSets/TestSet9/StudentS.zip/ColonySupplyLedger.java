import java.util.Arrays;
import java.util.List;

public class ColonySupplyLedger {
    public static void main(String[] args) {
        int[] depotDemand = {18, 23, 17, 28, 19, 24, 16, 30, 21, 26};
        int[] terrainCost = {6, 5, 7, 4, 8, 5, 9, 3, 6, 4};

        ColonySupplyMath math = new ColonySupplyMath();
        int[] urgency = math.buildUrgency(depotDemand, terrainCost);
        int[] convoy = math.rankConvoys(urgency);
        List<String> notes = math.describe(convoy, urgency);

        System.out.println("=== Colony Supply Ledger ===");
        System.out.println("Urgency: " + Arrays.toString(urgency));
        System.out.println("Convoy: " + Arrays.toString(convoy));
        for (String note : notes) {
            System.out.println(note);
        }

        System.out.println("Terrain Pressure: " + math.terrainPressure(urgency));
        System.out.println("Supply Band: " + math.supplyBand(urgency));
        System.out.println("Checksum: " + math.checksum(convoy));
        System.out.println("Remote Depot: " + math.remoteDepot(convoy));
        System.out.println("Spread Gap: " + math.spreadGap(urgency));
        System.out.println("Total Score: " + math.sumValues(convoy));
        System.out.println("Middle Average: " + math.middleAverage(convoy));
        System.out.println("Stable Wave: " + math.isWaveStable(convoy));

    }
}
