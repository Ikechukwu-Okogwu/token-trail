import java.util.ArrayList;
import java.util.List;

public class ColonySupplyMath {
    public int[] buildUrgency(int[] depotDemand, int[] terrainCost) {
        int[] urgency = new int[depotDemand.length];
        for (int i = 0; i < depotDemand.length; i++) {
            urgency[i] = depotDemand[i] * 3 - terrainCost[i] * 2 + (i % 4);
        }
        balance(urgency);
        return urgency;
    }

    public int[] rankConvoys(int[] urgency) {
        int[] convoy = new int[urgency.length];
        boolean[] used = new boolean[urgency.length];
        for (int slot = 0; slot < convoy.length; slot++) {
            int best = -1;
            for (int i = 0; i < urgency.length; i++) {
                if (!used[i] && (best == -1 || urgency[i] > urgency[best])) best = i;
            }
            convoy[slot] = best;
            used[best] = true;
        }
        return convoy;
    }

    public List<String> describe(int[] convoy, int[] urgency) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < convoy.length; i++) {
            rows.add("Dispatch convoy to depot " + convoy[i] + " with urgency " + urgency[convoy[i]]);
        }
        return rows;
    }

    public int terrainPressure(int[] urgency) {
        int total = 0;
        for (int value : urgency) total += value;
        return total;
    }

    public String supplyBand(int[] urgency) {
        int peak = urgency[0];
        for (int value : urgency) {
            if (value > peak) peak = value;
        }
        if (peak > 60) return "red";
        if (peak > 45) return "amber";
        return "green";
    }

    public int checksum(int[] convoy) {
        int sum = 0;
        for (int i = 0; i < convoy.length; i++) {
            sum += convoy[i] * (i + 6);
        }
        return sum;
    }

    public int remoteDepot(int[] convoy) {
        return convoy[convoy.length - 1];
    }

    public int spreadGap(int[] urgency) {
        int min = urgency[0];
        int max = urgency[0];
        for (int value : urgency) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        return max - min;
    }

    public int edgeSum(int[] urgency) {
        return urgency[0] + urgency[urgency.length - 1];
    }

    public int midpointStop(int[] convoy) {
        return convoy[convoy.length / 2];
    }

    public int downwardSteps(int[] urgency) {
        int count = 0;
        for (int i = 1; i < urgency.length; i++) {
            if (urgency[i] < urgency[i - 1]) count++;
        }
        return count;
    }

    private void balance(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

public int turningScore(int[] convoy) {
    int sum = 0;
    for (int i = 1; i < convoy.length; i++) {
        sum += Math.abs(convoy[i] - convoy[i - 1]);
    }
    return sum;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) return false;
        }
        return true;
    }
        return even - odd;
    }


public int crestValue(int[] values) {
    int best = values[0];
    for (int value : values) {
        if (value > best) best = value;
    }
    return best;
}

}
