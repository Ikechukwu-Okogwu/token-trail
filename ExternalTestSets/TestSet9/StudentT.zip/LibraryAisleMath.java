import java.util.ArrayList;
import java.util.List;

public class LibraryAisleMath {
    public int[] buildPlacementScore(int[] checkoutRate, int[] walkingCost) {
        int[] score = new int[checkoutRate.length];
        for (int i = 0; i < checkoutRate.length; i++) {
            score[i] = checkoutRate[i] * 2 - walkingCost[i] + (i % 5);
        }
        smooth(score);
        return score;
    }

    public int[] rankAisles(int[] score) {
        int[] order = new int[score.length];
        boolean[] used = new boolean[score.length];
        for (int slot = 0; slot < order.length; slot++) {
            int best = -1;
            for (int i = 0; i < score.length; i++) {
                if (!used[i] && (best == -1 || score[i] > score[best])) best = i;
            }
            order[slot] = best;
            used[best] = true;
        }
        return order;
    }

    public List<String> describe(int[] order, int[] score) {
        List<String> rows = new ArrayList<>();
        for (int i = 0; i < order.length; i++) {
            rows.add("Move aisle " + order[i] + " closer to front with score " + score[order[i]]);
        }
        return rows;
    }

    public int balanceGap(int[] score) {
        int even = 0;
        int odd = 0;
        for (int i = 0; i < score.length; i++) {
            if (i % 2 == 0) even += score[i];
            else odd += score[i];
        }
        return Math.abs(even - odd);
    }

    public int accessIndex(int[] score) {
        int total = 0;
        for (int value : score) total += value;
        return total / score.length;
    }

    public int checksum(int[] order) {
        int sum = 0;
        for (int i = 0; i < order.length; i++) {
            sum += order[i] * (i + 2);
        }
        return sum;
    }

    public int peakAisle(int[] score) {
        int peak = 0;
        for (int i = 1; i < score.length; i++) {
            if (score[i] > score[peak]) peak = i;
        }
        return peak;
    }

    public String urgencyBand(int[] score) {
        int min = score[0];
        int max = score[0];
        for (int value : score) {
            if (value < min) min = value;
            if (value > max) max = value;
        }
        if (max - min > 25) return "urgent";
        if (max - min > 15) return "moderate";
        return "steady";
    }

    public int edgeSum(int[] score) {
        return score[0] + score[score.length - 1];
    }

    public int midpointStop(int[] order) {
        return order[order.length / 2];
    }

    public int downwardSteps(int[] score) {
        int count = 0;
        for (int i = 1; i < score.length; i++) {
            if (score[i] < score[i - 1]) count++;
        }
        return count;
    }

    private void smooth(int[] values) {
        for (int i = 1; i < values.length - 1; i++) {
            values[i] = (values[i - 1] + values[i] + values[i + 1]) / 3;
        }
    }

public int turningScore(int[] order) {
    int sum = 0;
    for (int i = 1; i < order.length; i++) {
        sum += Math.abs(order[i] - order[i - 1]);
    }
    return sum;
}


public int parityGap(int[] values) {
    int even = 0;
    int odd = 0;
    for (int i = 0; i < values.length; i++) {
        if (i % 2 == 0) even += values[i];
        else odd += values[i];
    }
    return Math.abs(even - odd);
}


    public int sumValues(int[] values) {
        int total = 0;
        for (int value : values) { total += value; }
        return total;
    }

    public int middleAverage(int[] values) {
        if (values.length <= 2) return sumValues(values);
        int total = 0;
        for (int i = 1; i < values.length - 1; i++) {
            total += values[i];
        }
        return total / (values.length - 2);
    }

    public boolean isWaveStable(int[] values) {
        for (int i = 1; i < values.length; i++) {
            if (Math.abs(values[i] - values[i - 1]) > 10) {
                return false;
            }
        }
        return true;
    }
        return even - odd;
    }

}
