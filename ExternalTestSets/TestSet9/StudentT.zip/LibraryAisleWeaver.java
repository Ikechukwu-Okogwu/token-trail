import java.util.Arrays;
import java.util.List;

public class LibraryAisleWeaver {
    public static void main(String[] args) {
        int[] checkoutRate = {22, 15, 31, 18, 9, 27, 20, 11, 25, 14};
        int[] walkingCost = {3, 6, 2, 4, 7, 3, 5, 6, 4, 5};

        LibraryAisleMath math = new LibraryAisleMath();
        int[] score = math.buildPlacementScore(checkoutRate, walkingCost);
        int[] order = math.rankAisles(score);
        List<String> cards = math.describe(order, score);

        System.out.println("=== Library Aisle Weaver ===");
        System.out.println("Score: " + Arrays.toString(score));
        System.out.println("Order: " + Arrays.toString(order));
        for (String card : cards) {
            System.out.println(card);
        }

        System.out.println("Balance Gap: " + math.balanceGap(score));
        System.out.println("Access Index: " + math.accessIndex(score));
        System.out.println("Checksum: " + math.checksum(order));
        System.out.println("Peak Aisle: " + math.peakAisle(score));
        System.out.println("Urgency Band: " + math.urgencyBand(score));
        System.out.println("Total Score: " + math.sumValues(order));
        System.out.println("Middle Average: " + math.middleAverage(order));
        System.out.println("Stable Wave: " + math.isWaveStable(order));

    }
}
