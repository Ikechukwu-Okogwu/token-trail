/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_01.
 * Classification: pair/triple source.
 * File role: declarations and shared interfaces.
 */

#ifndef SORT_H
#define SORT_H

#include <stddef.h>

// This helper keeps one part of the assignment logic isolated and readable.
typedef struct {
    long comparisons;
    long writes;
    int partitions;
} SortStats;

// Keep this routine separate so the data-structure steps stay easy to trace.
void sort_numbers(int *values, size_t count, SortStats *stats);
// This block handles one focused stage of the algorithm instead of mixing concerns.
int is_sorted(const int *values, size_t count);
// The method below is split out so the traversal or sorting flow stays predictable.
long checksum(const int *values, size_t count);
// This helper exists to make the later debug output easier to reason about.
int unique_count(const int *values, size_t count);
// The declaration below is intentionally explicit so the control flow stays obvious.
int median_value(const int *values, size_t count);
// This helper keeps one part of the assignment logic isolated and readable.
int span_width(const int *values, size_t count);
// Keep this routine separate so the data-structure steps stay easy to trace.
long alternating_checksum(const int *values, size_t count);
// This block handles one focused stage of the algorithm instead of mixing concerns.
void print_report(const int *values, size_t count, const SortStats *stats);

#endif
