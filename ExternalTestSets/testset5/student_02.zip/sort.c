/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_02.
 * Classification: pair/triple variant.
 * File role: sorting logic and metric tracking.
 */

#include "sort.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// This helper keeps one part of the assignment logic isolated and readable.
static void insertion_sort(int *values, int left, int right, SortStats *stats) {
    for (int i = left + 1; i <= right; ++i) {  // walk across the current working set
        int key = values[i];  // update the local state used by the algorithm
        int j = i - 1;  // update the local state used by the algorithm
        while (j >= left) {  // walk across the current working set
            stats->comparisons++;  // keep the running counters and state aligned
            if (values[j] <= key) {  // short-circuit obvious branches before doing more work
                break;
            }
            values[j + 1] = values[j];  // update the local state used by the algorithm
            stats->writes++;  // keep the running counters and state aligned
            --j;  // keep the running counters and state aligned
        }
        values[j + 1] = key;  // update the local state used by the algorithm
        stats->writes++;  // keep the running counters and state aligned
    }
}

// Keep this routine separate so the data-structure steps stay easy to trace.
static void merge_sections(int *values, int *buffer, int left, int mid, int right, SortStats *stats) {
    int i = left;  // update the local state used by the algorithm
    int j = mid + 1;  // update the local state used by the algorithm
    int k = left;  // update the local state used by the algorithm
    while (i <= mid && j <= right) {  // walk across the current working set
        stats->comparisons++;  // keep the running counters and state aligned
        if (values[i] <= values[j]) {  // short-circuit obvious branches before doing more work
            buffer[k++] = values[i++];  // keep the running counters and state aligned
        } else {
            buffer[k++] = values[j++];  // keep the running counters and state aligned
        }
        stats->writes++;  // keep the running counters and state aligned
    }
    while (i <= mid) {  // walk across the current working set
        buffer[k++] = values[i++];  // keep the running counters and state aligned
        stats->writes++;  // keep the running counters and state aligned
    }
    while (j <= right) {  // walk across the current working set
        buffer[k++] = values[j++];  // keep the running counters and state aligned
        stats->writes++;  // keep the running counters and state aligned
    }
    for (i = left; i <= right; ++i) {  // walk across the current working set
        values[i] = buffer[i];  // update the local state used by the algorithm
        stats->writes++;  // keep the running counters and state aligned
    }
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static void merge_sort_recursive(int *values, int *buffer, int left, int right, SortStats *stats) {
    if (right - left <= 12) {  // short-circuit obvious branches before doing more work
        // The method below is split out so the traversal or sorting flow stays predictable.
        insertion_sort(values, left, right, stats);
        return;
    }
    // This helper exists to make the later debug output easier to reason about.
    int mid = left + (right - left) / 2;  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    merge_sort_recursive(values, buffer, left, mid, stats);
    // This helper keeps one part of the assignment logic isolated and readable.
    merge_sort_recursive(values, buffer, mid + 1, right, stats);
    // Keep this routine separate so the data-structure steps stay easy to trace.
    merge_sections(values, buffer, left, mid, right, stats);
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
void rank_values(int *values, size_t count, SortStats *stats) {
    if (count < 2 || stats == NULL) {  // short-circuit obvious branches before doing more work
        return;
    }
    stats->comparisons = 0;  // update the local state used by the algorithm
    stats->writes = 0;  // update the local state used by the algorithm
    stats->partitions = 0;  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    int *buffer = (int *) malloc(count * sizeof(int));  // update the local state used by the algorithm
    if (buffer == NULL) {  // short-circuit obvious branches before doing more work
        // This helper exists to make the later debug output easier to reason about.
        insertion_sort(values, 0, (int) count - 1, stats);
        return;
    }
    // The declaration below is intentionally explicit so the control flow stays obvious.
    merge_sort_recursive(values, buffer, 0, (int) count - 1, stats);
    // This helper keeps one part of the assignment logic isolated and readable.
    free(buffer);
}

// Keep this routine separate so the data-structure steps stay easy to trace.
int already_sorted(const int *values, size_t count) {
    for (size_t i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i - 1] > values[i]) {  // short-circuit obvious branches before doing more work
            return 0;  // send the computed value back to the caller
        }
    }
    return 1;  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
long weighted_checksum(const int *values, size_t count) {
    long total = 0;  // update the local state used by the algorithm
    for (size_t i = 0; i < count; ++i) {  // walk across the current working set
        // The method below is split out so the traversal or sorting flow stays predictable.
        total += values[i] * (long) (i + 3);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// This helper exists to make the later debug output easier to reason about.
int unique_count(const int *values, size_t count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int unique = 1;  // update the local state used by the algorithm
    for (size_t i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i] != values[i - 1]) {  // short-circuit obvious branches before doing more work
            unique++;  // keep the running counters and state aligned
        }
    }
    return unique;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
int median_value(const int *values, size_t count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    if (count % 2 == 1) {  // short-circuit obvious branches before doing more work
        return values[count / 2];  // send the computed value back to the caller
    }
    // This helper keeps one part of the assignment logic isolated and readable.
    return (values[(count / 2) - 1] + values[count / 2]) / 2;  // send the computed value back to the caller
}

// Keep this routine separate so the data-structure steps stay easy to trace.
int span_width(const int *values, size_t count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return values[count - 1] - values[0];  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
long alternating_checksum(const int *values, size_t count) {
    long total = 0;  // update the local state used by the algorithm
    for (size_t i = 0; i < count; ++i) {  // walk across the current working set
        // The method below is split out so the traversal or sorting flow stays predictable.
        int direction = (i % 2 == 0) ? 1 : -1;
        // This helper exists to make the later debug output easier to reason about.
        total += values[i] * (long) direction * (long) (i + 1);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
void emit_report(const int *values, size_t count, const SortStats *stats) {
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("count=%zu\n", count);  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("sorted=%d\n", already_sorted(values, count));  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("checksum=%ld\n", weighted_checksum(values, count));  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("unique=%d\n", unique_count(values, count));  // update the local state used by the algorithm
    // This helper exists to make the later debug output easier to reason about.
    printf("median=%d\n", median_value(values, count));  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("span=%d\n", span_width(values, count));  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("alt_checksum=%ld\n", alternating_checksum(values, count));  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("comparisons=%ld\n", stats->comparisons);  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("writes=%ld\n", stats->writes);  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("partitions=%d\n", stats->partitions);  // update the local state used by the algorithm
    if (count > 0) {  // short-circuit obvious branches before doing more work
        // This helper exists to make the later debug output easier to reason about.
        printf("first=%d\n", values[0]);  // update the local state used by the algorithm
        // The declaration below is intentionally explicit so the control flow stays obvious.
        printf("last=%d\n", values[count - 1]);  // update the local state used by the algorithm
    }
}
