/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_03.
 * Classification: pair/triple variant.
 * File role: driver logic and console-facing test flow.
 */

#include <stdio.h>
#include <stdlib.h>

// This helper keeps one part of the assignment logic isolated and readable.
typedef struct {
    long comparisons;
    long writes;
    int partitions;
} RankStats;

// Keep this routine separate so the data-structure steps stay easy to trace.
static void insertion_sort(int *values, int left, int right, RankStats *stats) {
    for (int i = left + 1; i <= right; ++i) {  // walk across the current working set
        int key = values[i];  // update the local state used by the algorithm
        int j = i - 1;  // update the local state used by the algorithm
        while (j >= left) {  // walk across the current working set
            stats->comparisons++;  // keep the running counters and state aligned
            if (values[j] <= key) {  // short-circuit obvious branches before doing more work
                break;
            }
            values[j + 1] = values[j];  // update the local state used by the algorithm
            stats->writes++;  // keep the running counters and state aligned
            --j;  // keep the running counters and state aligned
        }
        values[j + 1] = key;  // update the local state used by the algorithm
        stats->writes++;  // keep the running counters and state aligned
    }
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static void merge_sections(int *values, int *buffer, int left, int mid, int right, RankStats *stats) {
    int i = left;  // update the local state used by the algorithm
    int j = mid + 1;  // update the local state used by the algorithm
    int k = left;  // update the local state used by the algorithm
    while (i <= mid && j <= right) {  // walk across the current working set
        stats->comparisons++;  // keep the running counters and state aligned
        if (values[i] <= values[j]) {  // short-circuit obvious branches before doing more work
            buffer[k++] = values[i++];  // keep the running counters and state aligned
        } else {
            buffer[k++] = values[j++];  // keep the running counters and state aligned
        }
        stats->writes++;  // keep the running counters and state aligned
    }
    while (i <= mid) {  // walk across the current working set
        buffer[k++] = values[i++];  // keep the running counters and state aligned
        stats->writes++;  // keep the running counters and state aligned
    }
    while (j <= right) {  // walk across the current working set
        buffer[k++] = values[j++];  // keep the running counters and state aligned
        stats->writes++;  // keep the running counters and state aligned
    }
    for (i = left; i <= right; ++i) {  // walk across the current working set
        values[i] = buffer[i];  // update the local state used by the algorithm
        stats->writes++;  // keep the running counters and state aligned
    }
}

// The method below is split out so the traversal or sorting flow stays predictable.
static void hybrid_sort(int *values, int *buffer, int left, int right, RankStats *stats) {
    if (right - left <= 12) {  // short-circuit obvious branches before doing more work
        // This helper exists to make the later debug output easier to reason about.
        insertion_sort(values, left, right, stats);
        return;
    }
    // The declaration below is intentionally explicit so the control flow stays obvious.
    int mid = left + (right - left) / 2;  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    hybrid_sort(values, buffer, left, mid, stats);
    // Keep this routine separate so the data-structure steps stay easy to trace.
    hybrid_sort(values, buffer, mid + 1, right, stats);
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    merge_sections(values, buffer, left, mid, right, stats);
}

// The method below is split out so the traversal or sorting flow stays predictable.
static long checksum(const int *values, size_t count) {
    long total = 0;  // update the local state used by the algorithm
    for (size_t i = 0; i < count; ++i) {  // walk across the current working set
        // This helper exists to make the later debug output easier to reason about.
        total += values[i] * (long) (i + 5);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
static int is_sorted(const int *values, size_t count) {
    for (size_t i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i - 1] > values[i]) {  // short-circuit obvious branches before doing more work
            return 0;  // send the computed value back to the caller
        }
    }
    return 1;  // send the computed value back to the caller
}

// This helper keeps one part of the assignment logic isolated and readable.
static int smallest_value(const int *values, size_t count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int smallest = values[0];  // update the local state used by the algorithm
    for (size_t i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i] < smallest) {  // short-circuit obvious branches before doing more work
            smallest = values[i];  // update the local state used by the algorithm
        }
    }
    return smallest;  // send the computed value back to the caller
}

// Keep this routine separate so the data-structure steps stay easy to trace.
static int largest_value(const int *values, size_t count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int largest = values[0];  // update the local state used by the algorithm
    for (size_t i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i] > largest) {  // short-circuit obvious branches before doing more work
            largest = values[i];  // update the local state used by the algorithm
        }
    }
    return largest;  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
int main(void) {
    int values[256];
    size_t count = 0;  // update the local state used by the algorithm
    RankStats stats = {0, 0, 0};  // update the local state used by the algorithm
    while (count < 256 && scanf("%d", &values[count]) == 1) {  // walk across the current working set
        ++count;  // keep the running counters and state aligned
    }
    if (count > 1) {  // short-circuit obvious branches before doing more work
        // The method below is split out so the traversal or sorting flow stays predictable.
        int *buffer = (int *) malloc(count * sizeof(int));  // update the local state used by the algorithm
        if (buffer != NULL) {  // short-circuit obvious branches before doing more work
            // This helper exists to make the later debug output easier to reason about.
            hybrid_sort(values, buffer, 0, (int) count - 1, &stats);
            // The declaration below is intentionally explicit so the control flow stays obvious.
            free(buffer);
        } else {
            // This helper keeps one part of the assignment logic isolated and readable.
            insertion_sort(values, 0, (int) count - 1, &stats);
        }
    }
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("count=%zu\n", count);  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("sorted=%d\n", is_sorted(values, count));  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("checksum=%ld\n", checksum(values, count));  // update the local state used by the algorithm
    // This helper exists to make the later debug output easier to reason about.
    printf("comparisons=%ld\n", stats.comparisons);  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("writes=%ld\n", stats.writes);  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("smallest=%d\n", smallest_value(values, count));  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("largest=%d\n", largest_value(values, count));  // update the local state used by the algorithm
    return 0;  // send the computed value back to the caller
}
