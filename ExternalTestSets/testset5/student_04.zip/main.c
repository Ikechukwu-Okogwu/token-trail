/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_04.
 * Classification: independent.
 * File role: driver logic and console-facing test flow.
 */

#include <stdio.h>

// This helper keeps one part of the assignment logic isolated and readable.
typedef struct {
    long comparisons;
    long moves;
    int gaps;
} ShellStats;

// Keep this routine separate so the data-structure steps stay easy to trace.
static void shell_sort(int *values, int count, ShellStats *stats) {
    for (int gap = count / 2; gap > 0; gap /= 2) {  // walk across the current working set
        stats->gaps++;  // keep the running counters and state aligned
        for (int i = gap; i < count; ++i) {  // walk across the current working set
            int hold = values[i];  // update the local state used by the algorithm
            int j = i;  // update the local state used by the algorithm
            while (j >= gap) {  // walk across the current working set
                stats->comparisons++;  // keep the running counters and state aligned
                if (values[j - gap] <= hold) {  // short-circuit obvious branches before doing more work
                    break;
                }
                values[j] = values[j - gap];  // update the local state used by the algorithm
                stats->moves++;  // keep the running counters and state aligned
                j -= gap;  // keep the running counters and state aligned
            }
            values[j] = hold;  // update the local state used by the algorithm
            stats->moves++;  // keep the running counters and state aligned
        }
    }
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static int duplicate_count(const int *values, int count) {
    int duplicates = 0;  // update the local state used by the algorithm
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i] == values[i - 1]) {  // short-circuit obvious branches before doing more work
            duplicates++;  // keep the running counters and state aligned
        }
    }
    return duplicates;  // send the computed value back to the caller
}

// The method below is split out so the traversal or sorting flow stays predictable.
static long weighted_sum(const int *values, int count) {
    long total = 0;  // update the local state used by the algorithm
    for (int i = 0; i < count; ++i) {  // walk across the current working set
        // This helper exists to make the later debug output easier to reason about.
        total += values[i] * (long) (i + 7);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
static int longest_non_decreasing_run(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int best = 1;  // update the local state used by the algorithm
    int current = 1;  // update the local state used by the algorithm
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i - 1] <= values[i]) {  // short-circuit obvious branches before doing more work
            current++;  // keep the running counters and state aligned
        } else {
            if (current > best) {  // short-circuit obvious branches before doing more work
                best = current;  // update the local state used by the algorithm
            }
            current = 1;  // update the local state used by the algorithm
        }
    }
    return current > best ? current : best;  // send the computed value back to the caller
}

// This helper keeps one part of the assignment logic isolated and readable.
static int median_value(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return values[count / 2];  // send the computed value back to the caller
}

// Keep this routine separate so the data-structure steps stay easy to trace.
static int range_width(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return values[count - 1] - values[0];  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static int sorted(const int *values, int count) {
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i - 1] > values[i]) {  // short-circuit obvious branches before doing more work
            return 0;  // send the computed value back to the caller
        }
    }
    return 1;  // send the computed value back to the caller
}

// The method below is split out so the traversal or sorting flow stays predictable.
static int count_even_values(const int *values, int count) {
    int total = 0;  // update the local state used by the algorithm
    for (int i = 0; i < count; ++i) {  // walk across the current working set
        if (values[i] % 2 == 0) {  // short-circuit obvious branches before doing more work
            total++;  // keep the running counters and state aligned
        }
    }
    return total;  // send the computed value back to the caller
}

// This helper exists to make the later debug output easier to reason about.
static long prefix_checksum(const int *values, int count) {
    long total = 0;  // update the local state used by the algorithm
    int limit = count < 6 ? count : 6;  // update the local state used by the algorithm
    for (int i = 0; i < limit; ++i) {  // walk across the current working set
        // The declaration below is intentionally explicit so the control flow stays obvious.
        total += values[i] * (long) (limit - i);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// This helper keeps one part of the assignment logic isolated and readable.
int main(void) {
    int values[256];
    int count = 0;  // update the local state used by the algorithm
    ShellStats stats = {0, 0, 0};  // update the local state used by the algorithm
    while (count < 256 && scanf("%d", &values[count]) == 1) {  // walk across the current working set
        count++;  // keep the running counters and state aligned
    }
    // Keep this routine separate so the data-structure steps stay easy to trace.
    shell_sort(values, count, &stats);
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("count=%d\n", count);  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("sorted=%d\n", sorted(values, count));  // update the local state used by the algorithm
    // This helper exists to make the later debug output easier to reason about.
    printf("duplicates=%d\n", duplicate_count(values, count));  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("weighted_sum=%ld\n", weighted_sum(values, count));  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("comparisons=%ld\n", stats.comparisons);  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("moves=%ld\n", stats.moves);  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("gaps=%d\n", stats.gaps);  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("longest_run=%d\n", longest_non_decreasing_run(values, count));  // update the local state used by the algorithm
    // This helper exists to make the later debug output easier to reason about.
    printf("median=%d\n", median_value(values, count));  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("range=%d\n", range_width(values, count));  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("even_values=%d\n", count_even_values(values, count));  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("prefix_checksum=%ld\n", prefix_checksum(values, count));  // update the local state used by the algorithm
    return 0;  // send the computed value back to the caller
}
