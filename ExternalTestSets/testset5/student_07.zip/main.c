/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_07.
 * Classification: difficult pair source.
 * File role: driver logic and console-facing test flow.
 */

#include <stdio.h>

// This helper keeps one part of the assignment logic isolated and readable.
typedef struct {
    long swaps;
    long comparisons;
} SortStats;

// Keep this routine separate so the data-structure steps stay easy to trace.
static void swap_values(int *a, int *b, SortStats *stats) {
    int temp = *a;  // update the local state used by the algorithm
    *a = *b;
    *b = temp;
    stats->swaps++;  // keep the running counters and state aligned
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static int partition_values(int *values, int low, int high, SortStats *stats) {
    int pivot = values[high];  // update the local state used by the algorithm
    int split = low;  // update the local state used by the algorithm
    for (int i = low; i < high; ++i) {  // walk across the current working set
        stats->comparisons++;  // keep the running counters and state aligned
        if (values[i] <= pivot) {  // short-circuit obvious branches before doing more work
            // The method below is split out so the traversal or sorting flow stays predictable.
            swap_values(&values[split], &values[i], stats);
            split++;  // keep the running counters and state aligned
        }
    }
    // This helper exists to make the later debug output easier to reason about.
    swap_values(&values[split], &values[high], stats);
    return split;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
static void quick_sort(int *values, int low, int high, SortStats *stats) {
    if (low >= high) {  // short-circuit obvious branches before doing more work
        return;
    }
    // This helper keeps one part of the assignment logic isolated and readable.
    int pivot = partition_values(values, low, high, stats);  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    quick_sort(values, low, pivot - 1, stats);
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    quick_sort(values, pivot + 1, high, stats);
}

// The method below is split out so the traversal or sorting flow stays predictable.
static long checksum(const int *values, int count) {
    long total = 0;  // update the local state used by the algorithm
    for (int i = 0; i < count; ++i) {  // walk across the current working set
        // This helper exists to make the later debug output easier to reason about.
        total += values[i] * (long) (i + 11);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
static int sorted(const int *values, int count) {
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i - 1] > values[i]) {  // short-circuit obvious branches before doing more work
            return 0;  // send the computed value back to the caller
        }
    }
    return 1;  // send the computed value back to the caller
}

// This helper keeps one part of the assignment logic isolated and readable.
static int smallest(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int best = values[0];  // update the local state used by the algorithm
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i] < best) {  // short-circuit obvious branches before doing more work
            best = values[i];  // update the local state used by the algorithm
        }
    }
    return best;  // send the computed value back to the caller
}

// Keep this routine separate so the data-structure steps stay easy to trace.
static int largest(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int best = values[0];  // update the local state used by the algorithm
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i] > best) {  // short-circuit obvious branches before doing more work
            best = values[i];  // update the local state used by the algorithm
        }
    }
    return best;  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static int even_count(const int *values, int count) {
    int total = 0;  // update the local state used by the algorithm
    for (int i = 0; i < count; ++i) {  // walk across the current working set
        if (values[i] % 2 == 0) {  // short-circuit obvious branches before doing more work
            total++;  // keep the running counters and state aligned
        }
    }
    return total;  // send the computed value back to the caller
}

// The method below is split out so the traversal or sorting flow stays predictable.
static int spread(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return values[count - 1] - values[0];  // send the computed value back to the caller
}

// This helper exists to make the later debug output easier to reason about.
int main(void) {
    int values[256];
    int count = 0;  // update the local state used by the algorithm
    SortStats stats = {0, 0};  // update the local state used by the algorithm
    while (count < 256 && scanf("%d", &values[count]) == 1) {  // walk across the current working set
        count++;  // keep the running counters and state aligned
    }
    if (count > 1) {  // short-circuit obvious branches before doing more work
        // The declaration below is intentionally explicit so the control flow stays obvious.
        quick_sort(values, 0, count - 1, &stats);
    }
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("count=%d\n", count);  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("sorted=%d\n", sorted(values, count));  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("checksum=%ld\n", checksum(values, count));  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("swaps=%ld\n", stats.swaps);  // update the local state used by the algorithm
    // This helper exists to make the later debug output easier to reason about.
    printf("comparisons=%ld\n", stats.comparisons);  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("smallest=%d\n", smallest(values, count));  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("largest=%d\n", largest(values, count));  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("even_count=%d\n", even_count(values, count));  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("spread=%d\n", spread(values, count));  // update the local state used by the algorithm
    return 0;  // send the computed value back to the caller
}
