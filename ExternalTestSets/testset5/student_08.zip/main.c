/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_08.
 * Classification: difficult pair obfuscated.
 * File role: driver logic and console-facing test flow.
 */

#include <stdio.h>

// This helper keeps one part of the assignment logic isolated and readable.
typedef struct {
    long swaps;
    long comparisons;
} SortStats;

// Keep this routine separate so the data-structure steps stay easy to trace.
static void touch(int *a, int *b, SortStats *stats) {
    int saved = *a;  // update the local state used by the algorithm
    *a = *b;
    *b = saved;
    stats->swaps++;  // keep the running counters and state aligned
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static int split_once(int *items, int left, int right, SortStats *stats) {
    int pivot = items[right];  // update the local state used by the algorithm
    int boundary = left;  // update the local state used by the algorithm
    for (int i = left; i < right; ++i) {  // walk across the current working set
        stats->comparisons++;  // keep the running counters and state aligned
        if (!(items[i] > pivot)) {  // short-circuit obvious branches before doing more work
            // The method below is split out so the traversal or sorting flow stays predictable.
            touch(&items[boundary], &items[i], stats);
            boundary++;  // keep the running counters and state aligned
        }
    }
    // This helper exists to make the later debug output easier to reason about.
    touch(&items[boundary], &items[right], stats);
    return boundary;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
static void sort_range(int *items, int left, int right, SortStats *stats) {
    if (!(left < right)) {  // short-circuit obvious branches before doing more work
        return;
    }
    // This helper keeps one part of the assignment logic isolated and readable.
    int split = split_once(items, left, right, stats);  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    sort_range(items, left, split - 1, stats);
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    sort_range(items, split + 1, right, stats);
}

// The method below is split out so the traversal or sorting flow stays predictable.
static long checksum(const int *items, int count) {
    long total = 0;  // update the local state used by the algorithm
    for (int i = 0; i < count; ++i) {  // walk across the current working set
        // This helper exists to make the later debug output easier to reason about.
        total += items[i] * (long) (i + 11);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
static int sorted(const int *items, int count) {
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (items[i - 1] > items[i]) {  // short-circuit obvious branches before doing more work
            return 0;  // send the computed value back to the caller
        }
    }
    return 1;  // send the computed value back to the caller
}

// This helper keeps one part of the assignment logic isolated and readable.
static int smallest(const int *items, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int chosen = items[0];  // update the local state used by the algorithm
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (items[i] < chosen) {  // short-circuit obvious branches before doing more work
            chosen = items[i];  // update the local state used by the algorithm
        }
    }
    return chosen;  // send the computed value back to the caller
}

// Keep this routine separate so the data-structure steps stay easy to trace.
static int largest(const int *items, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int chosen = items[0];  // update the local state used by the algorithm
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (items[i] > chosen) {  // short-circuit obvious branches before doing more work
            chosen = items[i];  // update the local state used by the algorithm
        }
    }
    return chosen;  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static int even_count(const int *items, int count) {
    int total = 0;  // update the local state used by the algorithm
    for (int i = 0; i < count; ++i) {  // walk across the current working set
        if ((items[i] % 2) == 0) {  // short-circuit obvious branches before doing more work
            total++;  // keep the running counters and state aligned
        }
    }
    return total;  // send the computed value back to the caller
}

// The method below is split out so the traversal or sorting flow stays predictable.
static int spread(const int *items, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return items[count - 1] - items[0];  // send the computed value back to the caller
}

// This helper exists to make the later debug output easier to reason about.
int main(void) {
    int items[256];
    int count = 0;  // update the local state used by the algorithm
    SortStats stats = {0, 0};  // update the local state used by the algorithm
    while (count < 256 && scanf("%d", &items[count]) == 1) {  // walk across the current working set
        count++;  // keep the running counters and state aligned
    }
    if (count > 1) {  // short-circuit obvious branches before doing more work
        // The declaration below is intentionally explicit so the control flow stays obvious.
        sort_range(items, 0, count - 1, &stats);
    }
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("count=%d\n", count);  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("sorted=%d\n", sorted(items, count));  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("checksum=%ld\n", checksum(items, count));  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("swaps=%ld\n", stats.swaps);  // update the local state used by the algorithm
    // This helper exists to make the later debug output easier to reason about.
    printf("comparisons=%ld\n", stats.comparisons);  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("smallest=%d\n", smallest(items, count));  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("largest=%d\n", largest(items, count));  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("even_count=%d\n", even_count(items, count));  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("spread=%d\n", spread(items, count));  // update the local state used by the algorithm
    return 0;  // send the computed value back to the caller
}
