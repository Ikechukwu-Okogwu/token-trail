/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_09.
 * Classification: independent multifile.
 * File role: declarations and shared interfaces.
 */

#ifndef IO_HELPERS_H
#define IO_HELPERS_H

#include <stddef.h>

// This helper keeps one part of the assignment logic isolated and readable.
size_t read_values(int *values, size_t limit);
// Keep this routine separate so the data-structure steps stay easy to trace.
void print_values(const int *values, size_t count);

#endif
