/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_09.
 * Classification: independent multifile.
 * File role: reporting and derived metric helpers.
 */

#include "metrics.h"

// This helper keeps one part of the assignment logic isolated and readable.
long weighted_sum(const int *values, size_t count) {
    long total = 0;  // update the local state used by the algorithm
    for (size_t i = 0; i < count; ++i) {  // walk across the current working set
        // Keep this routine separate so the data-structure steps stay easy to trace.
        total += values[i] * (long) (i + 13);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
int sorted_runs(const int *values, size_t count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int runs = 1;  // update the local state used by the algorithm
    for (size_t i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i] < values[i - 1]) {  // short-circuit obvious branches before doing more work
            runs++;  // keep the running counters and state aligned
        }
    }
    return runs;  // send the computed value back to the caller
}
