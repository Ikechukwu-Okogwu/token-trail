/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_09.
 * Classification: independent multifile.
 * File role: declarations and shared interfaces.
 */

#ifndef METRICS_H
#define METRICS_H

#include <stddef.h>

// This helper keeps one part of the assignment logic isolated and readable.
long weighted_sum(const int *values, size_t count);
// Keep this routine separate so the data-structure steps stay easy to trace.
int sorted_runs(const int *values, size_t count);

#endif
