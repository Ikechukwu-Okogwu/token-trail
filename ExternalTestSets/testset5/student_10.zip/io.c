/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_10.
 * Classification: independent multifile.
 * File role: input and output helpers.
 */

#include "io.h"
#include <stdio.h>

// This helper keeps one part of the assignment logic isolated and readable.
size_t read_values(int *values, size_t limit) {
    size_t count = 0;  // update the local state used by the algorithm
    while (count < limit && scanf("%d", &values[count]) == 1) {  // walk across the current working set
        count++;  // keep the running counters and state aligned
    }
    return count;  // send the computed value back to the caller
}

// Keep this routine separate so the data-structure steps stay easy to trace.
void print_values(const int *values, size_t count) {
    for (size_t i = 0; i < count; ++i) {  // walk across the current working set
        if (i > 0) {  // short-circuit obvious branches before doing more work
            // This block handles one focused stage of the algorithm instead of mixing concerns.
            printf(" ");  // print a compact snapshot for quick manual checking
        }
        // The method below is split out so the traversal or sorting flow stays predictable.
        printf("%d", values[i]);  // print a compact snapshot for quick manual checking
    }
    // This helper exists to make the later debug output easier to reason about.
    printf("\n");  // print a compact snapshot for quick manual checking
}
