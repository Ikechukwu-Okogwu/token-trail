/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_10.
 * Classification: independent multifile.
 * File role: driver logic and console-facing test flow.
 */

#include "sort.h"
#include "io.h"
#include "metrics.h"
#include <stdio.h>

// This helper keeps one part of the assignment logic isolated and readable.
int main(void) {
    int values[256];
    // Keep this routine separate so the data-structure steps stay easy to trace.
    size_t count = read_values(values, 256);  // update the local state used by the algorithm
    MetricStats stats = {0, 0, 0};  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    organize_values(values, count, &stats);
    // The method below is split out so the traversal or sorting flow stays predictable.
    print_values(values, count);
    // This helper exists to make the later debug output easier to reason about.
    printf("runs=%d\n", sorted_runs(values, count));  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("weighted=%ld\n", weighted_sum(values, count));  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    write_report(values, count, &stats);
    return 0;  // send the computed value back to the caller
}
