/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_11.
 * Classification: noisy independent.
 * File role: driver logic and console-facing test flow.
 */

#include <stdio.h>

// This helper keeps one part of the assignment logic isolated and readable.
typedef struct {
    long comparisons;
    long moves;
} SortStats;

// Keep this routine separate so the data-structure steps stay easy to trace.
static void insertion_sort(int *values, int count, SortStats *stats) {
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        int key = values[i];  // update the local state used by the algorithm
        int j = i - 1;  // update the local state used by the algorithm
        while (j >= 0) {  // walk across the current working set
            stats->comparisons++;  // keep the running counters and state aligned
            if (values[j] <= key) {  // short-circuit obvious branches before doing more work
                break;
            }
            values[j + 1] = values[j];  // update the local state used by the algorithm
            stats->moves++;  // keep the running counters and state aligned
            --j;  // keep the running counters and state aligned
        }
        values[j + 1] = key;  // update the local state used by the algorithm
        stats->moves++;  // keep the running counters and state aligned
    }
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static int distinct_count(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    int distinct = 1;  // update the local state used by the algorithm
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i] != values[i - 1]) {  // short-circuit obvious branches before doing more work
            distinct++;  // keep the running counters and state aligned
        }
    }
    return distinct;  // send the computed value back to the caller
}

// The method below is split out so the traversal or sorting flow stays predictable.
static long checksum(const int *values, int count) {
    long total = 0;  // update the local state used by the algorithm
    for (int i = 0; i < count; ++i) {  // walk across the current working set
        // This helper exists to make the later debug output easier to reason about.
        total += values[i] * (long) (i + 17);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
static int odd_count(const int *values, int count) {
    int total = 0;  // update the local state used by the algorithm
    for (int i = 0; i < count; ++i) {  // walk across the current working set
        if (values[i] % 2 != 0) {  // short-circuit obvious branches before doing more work
            total++;  // keep the running counters and state aligned
        }
    }
    return total;  // send the computed value back to the caller
}

// This helper keeps one part of the assignment logic isolated and readable.
static int spread(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return values[count - 1] - values[0];  // send the computed value back to the caller
}

// Keep this routine separate so the data-structure steps stay easy to trace.
static int median_value(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return values[count / 2];  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
static int smallest(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return values[0];  // send the computed value back to the caller
}

// The method below is split out so the traversal or sorting flow stays predictable.
static int largest(const int *values, int count) {
    if (count == 0) {  // short-circuit obvious branches before doing more work
        return 0;  // send the computed value back to the caller
    }
    return values[count - 1];  // send the computed value back to the caller
}

// This helper exists to make the later debug output easier to reason about.
static int sorted(const int *values, int count) {
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i - 1] > values[i]) {  // short-circuit obvious branches before doing more work
            return 0;  // send the computed value back to the caller
        }
    }
    return 1;  // send the computed value back to the caller
}

// The declaration below is intentionally explicit so the control flow stays obvious.
static int descending_pairs(const int *values, int count) {
    int pairs = 0;  // update the local state used by the algorithm
    for (int i = 1; i < count; ++i) {  // walk across the current working set
        if (values[i - 1] > values[i]) {  // short-circuit obvious branches before doing more work
            pairs++;  // keep the running counters and state aligned
        }
    }
    return pairs;  // send the computed value back to the caller
}

// This helper keeps one part of the assignment logic isolated and readable.
static long tail_checksum(const int *values, int count) {
    long total = 0;  // update the local state used by the algorithm
    int start = count > 5 ? count - 5 : 0;  // update the local state used by the algorithm
    for (int i = start; i < count; ++i) {  // walk across the current working set
        // Keep this routine separate so the data-structure steps stay easy to trace.
        total += values[i] * (long) (i + 19);  // keep the running counters and state aligned
    }
    return total;  // send the computed value back to the caller
}

// This block handles one focused stage of the algorithm instead of mixing concerns.
int main(void) {
    int values[256];
    int count = 0;  // update the local state used by the algorithm
    SortStats stats = {0, 0};  // update the local state used by the algorithm
    while (count < 256 && scanf("%d", &values[count]) == 1) {  // walk across the current working set
        count++;  // keep the running counters and state aligned
    }
    // The method below is split out so the traversal or sorting flow stays predictable.
    insertion_sort(values, count, &stats);
    // This helper exists to make the later debug output easier to reason about.
    printf("count=%d\n", count);  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("distinct=%d\n", distinct_count(values, count));  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("sorted=%d\n", sorted(values, count));  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("checksum=%ld\n", checksum(values, count));  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("comparisons=%ld\n", stats.comparisons);  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("moves=%ld\n", stats.moves);  // update the local state used by the algorithm
    // This helper exists to make the later debug output easier to reason about.
    printf("odd_count=%d\n", odd_count(values, count));  // update the local state used by the algorithm
    // The declaration below is intentionally explicit so the control flow stays obvious.
    printf("spread=%d\n", spread(values, count));  // update the local state used by the algorithm
    // This helper keeps one part of the assignment logic isolated and readable.
    printf("median=%d\n", median_value(values, count));  // update the local state used by the algorithm
    // Keep this routine separate so the data-structure steps stay easy to trace.
    printf("smallest=%d\n", smallest(values, count));  // update the local state used by the algorithm
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    printf("largest=%d\n", largest(values, count));  // update the local state used by the algorithm
    // The method below is split out so the traversal or sorting flow stays predictable.
    printf("descending_pairs=%d\n", descending_pairs(values, count));  // update the local state used by the algorithm
    // This helper exists to make the later debug output easier to reason about.
    printf("tail_checksum=%ld\n", tail_checksum(values, count));  // update the local state used by the algorithm
    return 0;  // send the computed value back to the caller
}
