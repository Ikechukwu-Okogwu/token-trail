/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_13.
 * Classification: independent.
 * File role: driver logic and console-facing test flow.
 */

#include "sort.h"
#include <stdio.h>

// This helper keeps one part of the assignment logic isolated and readable.
int main(void) {
    int values[256];
    size_t count = 0;  // update the local state used by the algorithm
    BlendStats stats = {0, 0, 0};  // update the local state used by the algorithm

    while (count < 256 && scanf("%d", &values[count]) == 1) {  // walk across the current working set
        ++count;  // keep the running counters and state aligned
    }

    // Keep this routine separate so the data-structure steps stay easy to trace.
    blend_sort(values, count, &stats);
    // This block handles one focused stage of the algorithm instead of mixing concerns.
    blend_report(values, count, &stats);
    return 0;  // send the computed value back to the caller
}
