/*
 * Phase 3 generated artifact for Sorting assignment.
 * Submission: student_13.
 * Classification: independent.
 * File role: declarations and shared interfaces.
 */

#ifndef SORT_H
#define SORT_H

#include <stddef.h>

// This helper keeps one part of the assignment logic isolated and readable.
typedef struct {
    long comparisons;
    long writes;
    int partitions;
} BlendStats;

// Keep this routine separate so the data-structure steps stay easy to trace.
void blend_sort(int *values, size_t count, BlendStats *stats);
// This block handles one focused stage of the algorithm instead of mixing concerns.
int sorted_state(const int *values, size_t count);
// The method below is split out so the traversal or sorting flow stays predictable.
long blend_checksum(const int *values, size_t count);
// This helper exists to make the later debug output easier to reason about.
int unique_count(const int *values, size_t count);
// The declaration below is intentionally explicit so the control flow stays obvious.
int median_value(const int *values, size_t count);
// This helper keeps one part of the assignment logic isolated and readable.
int span_width(const int *values, size_t count);
// Keep this routine separate so the data-structure steps stay easy to trace.
long alternating_checksum(const int *values, size_t count);
// This block handles one focused stage of the algorithm instead of mixing concerns.
void blend_report(const int *values, size_t count, const BlendStats *stats);

#endif
