# -*- coding: utf-8 -*-
"""
Returns a random integer in [0, n) (left-inclusive, right-exclusive) based on console input.
"""

import random


def main():
    # Prompt user for upper bound
    nyuuryoku = input("正の整数を入力してください（上限、その値は含まない）：").strip()

    try:
        jougen = int(nyuuryoku)
    except ValueError:
        print("エラー：有効な整数を入力してください。")
        return

    if jougen <= 0:
        print("エラー：正の整数を入力してください。")
        return

    # random.randrange(n) yields an integer in [0, n)
    kekka = random.randrange(jougen)
    print(f"ランダムな整数 [0, {jougen})：{kekka}")


if __name__ == "__main__":
    main()
