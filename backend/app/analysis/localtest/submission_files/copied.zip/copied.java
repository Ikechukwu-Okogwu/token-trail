# -*- coding: utf-8 -*-
"""
Returns a random integer in [0, n) (left-inclusive, right-exclusive) based on console input.
"""

import random


def main():
    # Prompt user for upper bound
    user_input = input("Enter a positive integer (exclusive upper bound): ").strip()

    try:
        n = int(user_input)
    except ValueError:
        print("Error: Please enter a valid integer.")
        return

    if n <= 0:
        print("Error: Please enter a positive integer.")
        return

    # random.randrange(n) yields an integer in [0, n)
    result = random.randrange(n)
    print(f"Random integer in [0, {n}): {result}")


if __name__ == "__main__":
    main()
